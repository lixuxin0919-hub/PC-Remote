# PC遥控器 v2.1.0

- Added in-app Follow system / 简体中文 / English language selection.
- Localized all static Compose UI text and core runtime Bluetooth/profile/control summaries.
- Made Follow system the new-install default and isolated locale preference from profile import/export.
- Prevented slider track taps from changing values; sliders now require a horizontal drag starting on the thumb.
- Isolated high-frequency pressure updates from full touchpad-page recomposition.
- Added bounded English translation caching and simplified cached background drawing.
- Reduced expensive glass shadows while preserving the Liquid Glass hierarchy.
- Corrected icon visual sizing, long English button layout, disabled button rendering, and Snackbar contrast.
- Added slider and translation unit tests plus bilingual, interaction, rendering, and performance QA evidence.
