# v2.1.1 发布检查

结论：可用于测试交付。

- 版本：`versionName 2.1.1`，`versionCode 22`，应用 ID `com.gunianan.btremote`。
- 构建：`clean check lintDebug testDebugUnitTest hidReportSenderSelfTest assembleDebug assembleRelease` 通过。
- 自动检查：Debug 与 Release 单元测试通过；HID 自检 7 项通过；Lint 通过。
- 产物：Debug APK 可安装且使用 Android Debug 签名；Release APK 为未签名产物，不作为可安装交付件。
- 文档：README、变更记录、性能审计、UI 审查与差异审查均已更新。
- 隐私：本轮未新增权限、网络请求、密钥或外部服务；交付包仅包含源码、Debug APK、文档和性能证据。
- 限制：性能数据来自 60Hz API 35 模拟器；必须在真实 90/120Hz 手机按同一流程复测，不能据此宣称固定高刷新率帧率。
