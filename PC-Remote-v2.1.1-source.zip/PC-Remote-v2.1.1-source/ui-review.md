# UI Review — PC遥控器 v2.1.0

当前结论：模拟器已覆盖界面通过，P0 = 0，P1 = 0，P2 = 0；实机 HID 和扩展可访问性检查待完成。

## 审查证据

- qa/v2/screenshots/01-control-portrait.png
- qa/v2/screenshots/02-devices-portrait.png
- qa/v2/screenshots/03-customize-portrait.png
- qa/v2/screenshots/04-settings-portrait.png
- qa/v2/screenshots/05-control-landscape.png
- qa/v2/screenshots/06-profile-editor.png
- qa/v2/screenshots/07-action-picker.png
- qa/v2/screenshots/08-custom-gesture-editor.png
- qa/v2/screenshots/09-custom-gesture-recorded.png
- qa/v2/screenshots/10-custom-gesture-tested.png
- qa/v2/screenshots/11-custom-gesture-check-tested.png
- qa/v2/screenshots/12-custom-gesture-ready.png
- qa/v2/no-swipe-*.xml
- qa/v2/settings-before-switch.xml
- qa/v2/settings-after-return.xml
- qa/v2/screenshots/32-small-screen-control.png
- qa/v2/screenshots/35-small-screen-trackpad-buttons-on.png
- qa/v2/screenshots/36-small-screen-trackpad-buttons-off.png
- qa/v2/screenshots/37-landscape-trackpad.png
- qa/v2/screenshots/38-small-screen-control-final-icons.png
- qa/v2/comparisons/reference-vs-compact-video.png

## 视觉与层级

- Liquid Glass 视觉克制一致：玻璃卡片、冷蓝背景、白色高不透明内容面和蓝色主操作保持稳定。
- 顶部状态卡不会与系统状态栏形成硬色块，连接状态和当前模式优先级明确。
- 屏幕标题、分区标题、正文、辅助文字和状态标签形成清晰字号与颜色层级。
- 设备页操作顺序为状态 → 配对工具 → 已配对列表 → HID 限制，符合任务流程。
- 自定义页先提供“新建空白 / 复制默认”，再展示模式卡和管理动作。
- 模式编辑器将基础信息、控制区、布局、控件和手势拆分成可滚动分区。
- 动作选择器通过分类标签、当前选择和确认区降低动作绑定歧义。
- 自定义手势编辑器将 3 次样本、5 次测试、冲突状态、成功率、动作和保存可用性持续呈现在同一流程中。

## 交互与可用性

- 四个标签只能点按切换；横向滑动不会翻页，控制手势与页面导航无冲突。
- 使用 rememberSaveableStateHolder 保留页面滚动和临时状态；设置页往返层级证据一致。
- 控制页的手势轨迹识别在后台执行，识别反馈 1.2 秒后清除。
- 三个音量按钮等宽，减小/增加支持长按重复，静音为单次点按。
- 默认视频模式的三枚媒体键与三枚音量键在 360 × 720 dp 视口中全部位于底栏上方，不需要滚动。
- 触控板页为固定操作面，没有滚动节点；“按键 开/关”隐藏左右键后，触控区扩大并重新居中。
- 双指与三指快捷动作可以在设置页逐项自定义，动作选择器复用现有配置模型与校验。
- 触控板移动与滚动进入有界、合并队列，避免高采样率下创建大量协程。
- 页面、模式、连接和生命周期边界统一取消在途动作并释放输入。
- 滑杆拖动时只更新本地预览，松手后持久化，减少主线程写入频率。
- 滑杆必须在滑块附近按下并超过水平 touch slop 才进入拖动；点击轨道和纵向列表滚动不再误改数值。
- 触控板高频 pressure 状态下沉到独立指示器，整页不再按每个输入采样重组。
- 英文翻译结果使用有界缓存，列表项目重新进入视口不会重复遍历翻译表。
- 中英文、普通/主操作/禁用按钮、媒体与音量图标均完成模拟器截图复核；设备页禁用按钮横带已关闭。
- 已配对设备使用 LazyColumn 项而不是把整表塞入单个内容块。

## 响应式与沉浸式

- 竖屏使用浮动底栏和底部手势安全区。
- 2856 × 1280 px 横屏使用右侧浮动 rail，内容为 rail 和系统导航栏预留空间。
- 顶部状态卡和页面内容使用状态栏 inset；编辑器也保留顶部和底部可滚动空间。
- 方向切换由 MainActivity configChanges 处理，检查期间应用 PID 未变化。
- 2856 × 1280 px 横屏触控板使用右侧 rail，触控面、按键开关和设置入口均未裁切。

## 资产与一致性

- 当前可见导航、媒体、音量和模式图标均来自 image-2 PNG 资产。
- 视频快捷键分别使用上一首、播放暂停、下一首专属 image-2 图标，不再回退到通用遥控器图标。
- 文本、按钮和图标未使用 emoji、占位字符或截图式 UI。
- 控制页媒体提示和自定义页模式图标遵循相同蓝色描边/填充语言。

## 未覆盖项

- 已完成用户参考截图与 360 × 720 dp 实现的同画布比较；原参考截图为裁切状态，因此比较用于信息密度与可见范围判断，不作为逐像素验收。
- 尚无 v2 的 200% 字体和 TalkBack 完整截图/操作记录。
- 模拟器不能显示真实 Android-to-Windows HID 已连接输入结果。
- 真实 OEM 蓝牙栈下的重连、长按、卡键保护和连接错误文案必须实机复核。

发布前不得把上述未覆盖项表述为已验证。
