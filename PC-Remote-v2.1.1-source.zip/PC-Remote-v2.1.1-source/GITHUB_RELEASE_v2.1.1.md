# PC Remote v2.1.1

An Android-native Bluetooth HID controller built with Kotlin and Jetpack Compose. A phone can act as a Windows Bluetooth remote, touchpad, and customizable shortcut panel without Wi-Fi, a local network, or companion desktop software.

## What’s new

- Improved global scrolling and configuration-write performance to reduce jank on Settings and Custom Profiles screens.
- Completed English and Simplified Chinese localization, with system language used by default.
- Added previous/next video and standard previous/next track plus play/pause media controls.
- Added optional left and right touchpad buttons; hiding them automatically expands the touch surface.
- Added customizable multi-finger touchpad shortcuts and user-recorded gestures.
- Refined switches, sliders, bottom navigation, and the light glass-inspired interface.
- Limited slider changes to drag gestures to prevent accidental track taps.

## Installation

1. Download `PC-Remote-v2.1.1-debug.apk`.
2. Allow installation from unknown sources on a device running Android 9 or later.
3. Grant the Nearby devices permission on first launch.
4. Open pairing mode on the Devices screen, then add the phone from Windows Bluetooth settings.

> The APK uses an Android development signature. It is intended for testing and evaluation, not store distribution.

## Compatibility

Bluetooth HID Device Profile support is required from the phone’s system software. Some manufacturers disable or remove this system capability, which cannot be restored at the application layer. Real-world Bluetooth behavior also depends on the phone firmware, the Windows Bluetooth stack, and the wireless environment.
