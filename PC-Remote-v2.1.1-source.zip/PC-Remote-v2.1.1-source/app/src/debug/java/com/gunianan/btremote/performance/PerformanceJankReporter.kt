package com.gunianan.btremote.performance

import android.view.Window
import android.util.Log
import androidx.metrics.performance.JankStats
import androidx.metrics.performance.PerformanceMetricsState

/** Debug-only in-memory aggregation; never logs each frame. */
object PerformanceJankReporter {
    private val lock = Any()
    private var jankStats: JankStats? = null
    private var metricsState: PerformanceMetricsState.Holder? = null
    private var totalFrames = 0L
    private var jankyFrames = 0L
    private var longestFrameNanos = 0L

    fun start(window: Window) {
        if (jankStats != null) return
        metricsState = PerformanceMetricsState.getHolderForHierarchy(window.decorView)
        jankStats = JankStats.createAndTrack(window) { frameData ->
            synchronized(lock) {
                totalFrames++
                if (frameData.isJank) jankyFrames++
                longestFrameNanos = maxOf(longestFrameNanos, frameData.frameDurationUiNanos)
            }
        }
        setState("activity", "MainActivity")
    }

    fun setState(key: String, value: String) { metricsState?.state?.putState(key, value) }
    fun resume() { jankStats?.isTrackingEnabled = true }
    fun pause() {
        jankStats?.isTrackingEnabled = false
        Log.i(TAG, summary())
    }
    fun stop() { jankStats?.isTrackingEnabled = false; jankStats = null; metricsState = null }
    fun summary(): String = synchronized(lock) { "frames=$totalFrames,janky=$jankyFrames,longestUiNanos=$longestFrameNanos" }

    private const val TAG = "PcRemoteJank"
}
