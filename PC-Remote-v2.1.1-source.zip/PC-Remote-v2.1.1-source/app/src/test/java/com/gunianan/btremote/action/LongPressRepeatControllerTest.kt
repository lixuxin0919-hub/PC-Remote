package com.gunianan.btremote.action

import java.util.PriorityQueue
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LongPressRepeatControllerTest {
    @Test
    fun releaseBeforeThresholdCancelsWithoutStartOrStopCallbacks() {
        val scheduler = ManualScheduler()
        val events = mutableListOf<String>()
        val controller = controller(scheduler)
        controller.start("volume", callbacks(events))

        scheduler.advanceBy(499)
        assertTrue(controller.release("volume"))
        scheduler.advanceBy(1_000)

        assertTrue(events.isEmpty())
        assertFalse(controller.isRunning)
    }

    @Test
    fun activatesAtFiveHundredAndRepeatsEveryHundredMilliseconds() {
        val scheduler = ManualScheduler()
        val events = mutableListOf<String>()
        val controller = controller(scheduler)
        controller.start("volume", callbacks(events))

        scheduler.advanceBy(499)
        assertTrue(events.isEmpty())
        scheduler.advanceBy(1)
        assertEquals(listOf("start"), events)
        scheduler.advanceBy(300)

        assertEquals(listOf("start", "repeat", "repeat", "repeat"), events)
        assertTrue(controller.isActivated)
    }

    @Test
    fun aSecondStartCannotCreateDuplicateTasks() {
        val scheduler = ManualScheduler()
        val events = mutableListOf<String>()
        val controller = controller(scheduler)

        assertEquals(
            LongPressStartResult.STARTED,
            controller.start("first", callbacks(events)),
        )
        assertEquals(
            LongPressStartResult.ALREADY_RUNNING,
            controller.start("second", callbacks(events)),
        )
        scheduler.advanceBy(600)

        assertEquals(listOf("start", "repeat"), events)
    }

    @Test
    fun pointerUpFromAnotherOwnerCannotStopTheActivePress() {
        val scheduler = ManualScheduler()
        val events = mutableListOf<String>()
        val controller = controller(scheduler)
        controller.start("left", callbacks(events))
        scheduler.advanceBy(500)

        assertFalse(controller.release("right"))
        scheduler.advanceBy(100)

        assertEquals(listOf("start", "repeat"), events)
        assertTrue(controller.isRunning)
    }

    @Test
    fun lifecycleCancellationStopsOnceAndPreventsFurtherRepeats() {
        val reasons = listOf(
            LongPressStopReason.PAGE_EXIT to LongPressRepeatController::cancelForPageExit,
            LongPressStopReason.PROFILE_SWITCH to LongPressRepeatController::cancelForProfileSwitch,
            LongPressStopReason.DISCONNECTED to LongPressRepeatController::cancelForDisconnect,
            LongPressStopReason.APP_BACKGROUND to LongPressRepeatController::cancelForBackground,
        )

        reasons.forEach { (expectedReason, cancel) ->
            val scheduler = ManualScheduler()
            val events = mutableListOf<String>()
            val controller = controller(scheduler)
            controller.start("key", callbacks(events))
            scheduler.advanceBy(600)

            assertTrue(cancel(controller))
            assertFalse(cancel(controller))
            scheduler.advanceBy(1_000)

            assertEquals(listOf("start", "repeat", "stop:$expectedReason"), events)
            assertFalse(controller.isRunning)
        }
    }

    @Test
    fun hardTimeoutStopsAtThirtySecondsAfterActivation() {
        val scheduler = ManualScheduler()
        val stops = mutableListOf<LongPressStopReason>()
        var repeatCount = 0
        val controller = controller(scheduler)
        controller.start(
            "seek",
            LongPressCallbacks(
                onRepeat = { repeatCount++ },
                onStop = { stops += it },
            ),
        )

        scheduler.advanceBy(500 + 29_999)
        assertTrue(controller.isRunning)
        scheduler.advanceBy(1)

        assertEquals(listOf(LongPressStopReason.TIMEOUT), stops)
        assertEquals(299, repeatCount)
        assertFalse(controller.isRunning)
    }

    @Test
    fun callbackFailureStopsAndReleasesExactlyOnce() {
        val scheduler = ManualScheduler()
        val stops = mutableListOf<LongPressStopReason>()
        val controller = controller(scheduler)
        controller.start(
            "broken",
            LongPressCallbacks(
                onStart = {},
                onRepeat = { error("boom") },
                onStop = { stops += it },
            ),
        )

        scheduler.advanceBy(600)
        scheduler.advanceBy(1_000)

        assertEquals(listOf(LongPressStopReason.CALLBACK_FAILURE), stops)
        assertFalse(controller.isRunning)
    }

    @Test
    fun closeReleasesAnActivatedPressAndRejectsFutureStarts() {
        val scheduler = ManualScheduler()
        val events = mutableListOf<String>()
        val controller = controller(scheduler)
        controller.start("key", callbacks(events))
        scheduler.advanceBy(500)

        controller.close()

        assertEquals(listOf("start", "stop:CLOSED"), events)
        assertEquals(
            LongPressStartResult.CLOSED,
            controller.start("again", callbacks(events)),
        )
    }

    private fun controller(scheduler: ManualScheduler) = LongPressRepeatController(
        scheduler = scheduler,
        clock = scheduler,
        timing = LongPressTiming(),
    )

    private fun callbacks(events: MutableList<String>) = LongPressCallbacks(
        onStart = { events += "start" },
        onRepeat = { events += "repeat" },
        onStop = { events += "stop:$it" },
    )

    private class ManualScheduler : LongPressScheduler, MonotonicClock {
        private data class Entry(
            val dueAt: Long,
            val order: Long,
            val block: () -> Unit,
            var cancelled: Boolean = false,
        )

        private val tasks = PriorityQueue<Entry>(compareBy<Entry> { it.dueAt }.thenBy { it.order })
        private var nextOrder = 0L
        private var now = 0L

        override fun nowMillis(): Long = now

        override fun schedule(delayMillis: Long, block: () -> Unit): ScheduledTask {
            val entry = Entry(now + delayMillis, nextOrder++, block)
            tasks += entry
            return ScheduledTask { entry.cancelled = true }
        }

        fun advanceBy(durationMillis: Long) {
            val target = now + durationMillis
            while (true) {
                val next = tasks.peek() ?: break
                if (next.dueAt > target) break
                tasks.remove()
                now = next.dueAt
                if (!next.cancelled) next.block()
            }
            now = target
        }
    }
}
