package com.gunianan.btremote.action

import com.gunianan.btremote.domain.ControlAreaType
import com.gunianan.btremote.domain.ControlItem
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.GestureBinding
import com.gunianan.btremote.domain.GestureType
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.domain.SequenceStep
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RemoteActionRouterTest {
    @Test
    fun gestureBindingIdMapsToItsAction() = runBlocking {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor)
        router.updateProfile(profile(bindings = listOf(binding("swipe-up", 0x01))))

        val result = router.routeGesture("swipe-up")

        assertTrue(result.isSuccessful)
        assertEquals(listOf(RemoteCommand.Consumer(0x01)), executor.commands)
    }

    @Test
    fun replacingProfileMakesChangedBindingEffectiveImmediately() = runBlocking {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor)
        router.updateProfile(profile(id = "video", bindings = listOf(binding("right", 0x10))))
        router.routeGesture("right")

        router.updateProfile(profile(id = "video", bindings = listOf(binding("right", 0x20))))
        router.routeGesture("right")

        assertEquals(
            listOf(RemoteCommand.Consumer(0x10), RemoteCommand.Consumer(0x20)),
            executor.commands,
        )
    }

    @Test
    fun missingOrDisabledGestureDoesNotReachExecutor() = runBlocking {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor)
        router.updateProfile(
            profile(bindings = listOf(binding("disabled", 1).copy(enabled = false))),
        )

        assertEquals(
            IgnoreReason.GESTURE_NOT_FOUND,
            (router.routeGesture("missing") as ActionResult.Ignored).reason,
        )
        assertEquals(
            IgnoreReason.GESTURE_DISABLED,
            (router.routeGesture("disabled") as ActionResult.Ignored).reason,
        )
        assertTrue(executor.commands.isEmpty())
    }

    @Test
    fun switchingProfileUsesOnlyTheNewControls() = runBlocking {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor)
        router.updateProfile(profile(id = "a", controls = listOf(control("shared", 4))))
        router.routeControl("shared", ControlEvent.TAP)

        router.updateProfile(profile(id = "b", controls = listOf(control("shared", 5))))
        router.routeControl("shared", ControlEvent.TAP)

        assertEquals(listOf(RemoteCommand.Keyboard(4), RemoteCommand.Keyboard(5)), executor.commands)
        assertEquals("b", router.currentProfileId())
    }

    @Test
    fun heldLongPressRoutesBalancedDownAndUpPhases() = runBlocking {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor)
        val item = control("seek", 79).copy(
            tapAction = null,
            longPressAction = RemoteActionConfig.KeyboardKey(79),
            repeatAction = null,
        )

        router.route(item, ControlEvent.LONG_PRESS_START)
        router.route(item, ControlEvent.LONG_PRESS_END)

        assertEquals(
            listOf(
                RemoteCommand.Keyboard(79, phase = KeyPhase.DOWN),
                RemoteCommand.Keyboard(79, phase = KeyPhase.UP),
            ),
            executor.commands,
        )
    }

    @Test
    fun periodicLongPressUsesTapsAndNeedsNoHeldRelease() = runBlocking {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor)
        val item = control("volume", 4).copy(
            tapAction = RemoteActionConfig.ConsumerKey(1),
            longPressAction = RemoteActionConfig.KeyboardKey(79),
            repeatAction = RemoteActionConfig.KeyboardKey(80),
        )

        router.route(item, ControlEvent.LONG_PRESS_START)
        router.route(item, ControlEvent.LONG_PRESS_REPEAT)
        val end = router.route(item, ControlEvent.LONG_PRESS_END)

        assertEquals(ActionResult.Success(0), end)
        assertEquals(
            listOf(
                RemoteCommand.Keyboard(79, phase = KeyPhase.TAP),
                RemoteCommand.Keyboard(80, phase = KeyPhase.TAP),
            ),
            executor.commands,
        )
    }

    @Test
    fun confidenceThresholdRejectsWeakMatch() = runBlocking {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor)
        router.updateProfile(
            profile(bindings = listOf(binding("circle", 1).copy(minConfidence = 0.8f))),
        )

        val weak = router.routeGesture("circle", confidence = 0.79f)
        val strong = router.routeGesture("circle", confidence = 0.8f)

        assertEquals(IgnoreReason.LOW_CONFIDENCE, (weak as ActionResult.Ignored).reason)
        assertTrue(strong.isSuccessful)
        assertEquals(1, executor.commands.size)
    }

    @Test
    fun sequencePreservesOrderPhasesAndDelay() = runBlocking {
        val executor = RecordingExecutor()
        val delays = mutableListOf<Long>()
        val router = RemoteActionRouter(executor, ActionDelay { delays += it })
        val key = RemoteActionConfig.KeyboardKey(44)
        val sequence = RemoteActionConfig.CustomSequence(
            steps = listOf(
                SequenceStep.Tap(key),
                SequenceStep.Delay(75),
                SequenceStep.Down(key),
                SequenceStep.Up(key),
            ),
        )

        val result = router.route(sequence)

        assertEquals(ActionResult.Success(3), result)
        assertEquals(listOf(75L), delays)
        assertEquals(
            listOf(
                RemoteCommand.Keyboard(44, phase = KeyPhase.TAP),
                RemoteCommand.Keyboard(44, phase = KeyPhase.DOWN),
                RemoteCommand.Keyboard(44, phase = KeyPhase.UP),
            ),
            executor.commands,
        )
    }

    @Test
    fun stopOnFailurePreventsLaterSequenceCommands() = runBlocking {
        val executor = RecordingExecutor(failAtIndex = 1)
        val router = RemoteActionRouter(executor)
        val sequence = RemoteActionConfig.CustomSequence(
            steps = listOf(
                SequenceStep.Tap(RemoteActionConfig.KeyboardKey(4)),
                SequenceStep.Tap(RemoteActionConfig.KeyboardKey(5)),
                SequenceStep.Tap(RemoteActionConfig.KeyboardKey(6)),
            ),
            stopOnFailure = true,
        )

        val result = router.route(sequence)

        assertTrue(result is ActionResult.Failure)
        assertEquals(1, (result as ActionResult.Failure).executedCommandCount)
        assertEquals(2, executor.commands.size)
    }

    @Test
    fun sequenceFailureReleasesEverySuccessfulDown() = runBlocking {
        val executor = RecordingExecutor(failAtIndex = 1)
        val router = RemoteActionRouter(executor)
        val held = RemoteActionConfig.KeyboardKey(44)
        val sequence = RemoteActionConfig.CustomSequence(
            steps = listOf(
                SequenceStep.Down(held),
                SequenceStep.Tap(RemoteActionConfig.KeyboardKey(45)),
                SequenceStep.Up(held),
            ),
        )

        val result = router.route(sequence)

        assertTrue(result is ActionResult.Failure)
        assertEquals(
            listOf(
                RemoteCommand.Keyboard(44, phase = KeyPhase.DOWN),
                RemoteCommand.Keyboard(45, phase = KeyPhase.TAP),
                RemoteCommand.Keyboard(44, phase = KeyPhase.UP),
            ),
            executor.commands,
        )
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun cancellingDelayedSequenceStillReleasesHeldKey() = runTest {
        val gate = CompletableDeferred<Unit>()
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor, ActionDelay { gate.await() })
        val held = RemoteActionConfig.KeyboardKey(44)
        val sequence = RemoteActionConfig.CustomSequence(
            steps = listOf(
                SequenceStep.Down(held),
                SequenceStep.Delay(1_000),
                SequenceStep.Up(held),
            ),
        )

        val execution = async { router.route(sequence) }
        runCurrent()
        execution.cancelAndJoin()

        assertEquals(
            listOf(
                RemoteCommand.Keyboard(44, phase = KeyPhase.DOWN),
                RemoteCommand.Keyboard(44, phase = KeyPhase.UP),
            ),
            executor.commands,
        )
    }

    @Test
    fun sequenceTimeoutReturnsFailureAndReleasesHeldKey() = runTest {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(
            executor = executor,
            limits = RemoteActionRouter.RouterLimits(
                maximumSingleDelayMillis = 1_000,
                maximumSequenceDurationMillis = 100,
            ),
        )
        val held = RemoteActionConfig.KeyboardKey(44)

        val result = router.route(
            RemoteActionConfig.CustomSequence(
                listOf(
                    SequenceStep.Down(held),
                    SequenceStep.Delay(1_000),
                    SequenceStep.Up(held),
                ),
            ),
        )

        assertTrue(result is ActionResult.Failure)
        assertEquals(FailureReason.SEQUENCE_LIMIT_EXCEEDED, (result as ActionResult.Failure).reason)
        assertEquals(
            listOf(
                RemoteCommand.Keyboard(44, phase = KeyPhase.DOWN),
                RemoteCommand.Keyboard(44, phase = KeyPhase.UP),
            ),
            executor.commands,
        )
    }

    @Test
    fun unbalancedRuntimeSequenceFailsClosedAndReleasesKey() = runBlocking {
        val executor = RecordingExecutor()
        val router = RemoteActionRouter(executor)

        val result = router.route(
            RemoteActionConfig.CustomSequence(
                listOf(SequenceStep.Down(RemoteActionConfig.KeyboardKey(44))),
            ),
        )

        assertTrue(result is ActionResult.Failure)
        assertEquals(
            listOf(
                RemoteCommand.Keyboard(44, phase = KeyPhase.DOWN),
                RemoteCommand.Keyboard(44, phase = KeyPhase.UP),
            ),
            executor.commands,
        )
    }

    private class RecordingExecutor(
        private val failAtIndex: Int? = null,
    ) : RemoteCommandExecutor {
        val commands = mutableListOf<RemoteCommand>()

        override suspend fun execute(command: RemoteCommand): ActionResult {
            commands += command
            return if (commands.lastIndex == failAtIndex) {
                ActionResult.Failure(FailureReason.EXECUTOR_REJECTED, "rejected")
            } else {
                ActionResult.Success()
            }
        }
    }

    private fun profile(
        id: String = "profile",
        controls: List<ControlItem> = emptyList(),
        bindings: List<GestureBinding> = emptyList(),
    ) = ControlProfile(
        id = id,
        name = id,
        controlAreaType = ControlAreaType.GESTURE,
        controls = controls,
        gestureBindings = bindings,
        createdAt = 1,
        updatedAt = 1,
    )

    private fun binding(id: String, usageId: Int) = GestureBinding(
        id = id,
        gestureType = GestureType.SWIPE_UP,
        action = RemoteActionConfig.ConsumerKey(usageId),
    )

    private fun control(id: String, keyCode: Int) = ControlItem(
        id = id,
        title = id,
        position = 0,
        tapAction = RemoteActionConfig.KeyboardKey(keyCode),
    )
}
