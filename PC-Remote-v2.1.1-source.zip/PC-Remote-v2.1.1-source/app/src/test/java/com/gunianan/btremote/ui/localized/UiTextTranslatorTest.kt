package com.gunianan.btremote.ui.localized

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class UiTextTranslatorTest {
    @Test
    fun `Chinese locale preserves source text`() {
        assertEquals("设置", UiTextTranslator.translate("设置", "zh"))
    }

    @Test
    fun `English locale translates core navigation and dynamic summaries`() {
        assertEquals("Settings", UiTextTranslator.translate("设置", "en"))
        val summary = UiTextTranslator.translate("视频 · 3 个控件 · 5 个手势", "en")
        assertFalse(summary.any { it.code in 0x3400..0x9FFF })
    }

    @Test
    fun `non Chinese user text is left unchanged`() {
        assertEquals("My Studio", UiTextTranslator.translate("My Studio", "en"))
    }
}
