package com.gunianan.btremote.trackpad.gesture

import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.trackpad.input.TrackpadPointerEvent
import com.gunianan.btremote.trackpad.input.TrackpadPointerEvent.Action as PointerAction
import com.gunianan.btremote.trackpad.input.TrackpadPointerSample
import com.gunianan.btremote.trackpad.settings.TrackpadSettings
import com.gunianan.btremote.trackpad.settings.TrackpadGestureActions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrackpadGestureStateMachineTest {
    @Test
    fun `single finger move preserves fine deltas and emits pointer motion`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(pointerAcceleration = 0f))
        machine.onEvent(event(PointerAction.DOWN, 0, p(0, 10f, 10f)))

        val first = machine.onEvent(event(PointerAction.MOVE, 10, p(0, 10.4f, 10.4f)))
        val second = machine.onEvent(event(PointerAction.MOVE, 20, p(0, 11.2f, 11.2f)))

        assertTrue(first.none { it is TrackpadGestureOutput.MovePointer })
        assertTrue(second.any { it == TrackpadGestureOutput.MovePointer(1, 1) })
    }

    @Test
    fun `tap and two finger tap map to left and right click without crossover`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(adaptivePressureEnabled = false))
        machine.onEvent(event(PointerAction.DOWN, 0, p(0, 20f, 20f)))
        val left = machine.onEvent(event(PointerAction.UP, 100, p(0, 20f, 20f)))

        machine.onEvent(event(PointerAction.DOWN, 300, p(0, 20f, 20f)))
        machine.onEvent(event(PointerAction.POINTER_DOWN, 320, p(0, 20f, 20f), p(1, 40f, 20f)))
        val right = machine.onEvent(event(PointerAction.POINTER_UP, 410, p(0, 20f, 20f), p(1, 40f, 20f)))
        val trailingUp = machine.onEvent(event(PointerAction.UP, 430, p(0, 20f, 20f)))

        assertTrue(left.contains(TrackpadGestureOutput.Click(MouseButton.LEFT)))
        assertTrue(right.contains(TrackpadGestureOutput.Click(MouseButton.RIGHT)))
        assertFalse(trailingUp.any { it is TrackpadGestureOutput.Click })
    }

    @Test
    fun `double tap hold owns a balanced drag`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(adaptivePressureEnabled = false))
        machine.onEvent(event(PointerAction.DOWN, 0, p(0, 10f, 10f)))
        machine.onEvent(event(PointerAction.UP, 80, p(0, 10f, 10f)))
        machine.onEvent(event(PointerAction.DOWN, 180, p(0, 10f, 10f)))
        val move = machine.onEvent(event(PointerAction.MOVE, 210, p(0, 20f, 10f)))
        val up = machine.onEvent(event(PointerAction.UP, 260, p(0, 20f, 10f)))

        assertTrue(move.contains(TrackpadGestureOutput.SetButton(MouseButton.LEFT, true)))
        assertTrue(up.contains(TrackpadGestureOutput.SetButton(MouseButton.LEFT, false)))
    }

    @Test
    fun `vertical scroll locks out pinch and navigation`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(adaptivePressureEnabled = false))
        beginTwo(machine)
        val output = machine.onEvent(event(PointerAction.MOVE, 80, p(0, 10f, 35f), p(1, 30f, 35f)))

        assertTrue(output.any { it is TrackpadGestureOutput.Scroll })
        assertFalse(output.any { it is TrackpadGestureOutput.ModifiedScroll || it is TrackpadGestureOutput.ConfiguredAction })
    }

    @Test
    fun `pinch emits ctrl wheel and cannot also scroll`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(adaptivePressureEnabled = false))
        beginTwo(machine)
        val output = machine.onEvent(event(PointerAction.MOVE, 80, p(0, 0f, 10f), p(1, 40f, 10f)))

        assertTrue(output.any {
            it is TrackpadGestureOutput.ModifiedScroll && it.modifier == KeyboardModifier.LEFT_CONTROL
        })
        assertFalse(output.any { it is TrackpadGestureOutput.Scroll })
    }

    @Test
    fun `two fingers becoming one rebase motion without a phantom click`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(adaptivePressureEnabled = false))
        beginTwo(machine)
        machine.onEvent(event(PointerAction.MOVE, 80, p(0, 10f, 35f), p(1, 30f, 35f)))
        val transition = machine.onEvent(
            TrackpadPointerEvent(
                action = PointerAction.POINTER_UP,
                eventTimeMillis = 100,
                changedPointerId = 1,
                pointers = listOf(p(0, 10f, 35f), p(1, 30f, 35f)),
            ),
        )
        val move = machine.onEvent(event(PointerAction.MOVE, 120, p(0, 12f, 36f)))
        val finalUp = machine.onEvent(event(PointerAction.UP, 140, p(0, 12f, 36f)))

        assertTrue(transition.none { it is TrackpadGestureOutput.Click })
        assertTrue(move.any { it is TrackpadGestureOutput.MovePointer })
        assertTrue(finalUp.none { it is TrackpadGestureOutput.Click })
    }

    @Test
    fun `fast two finger horizontal swipe emits one alt navigation shortcut`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(adaptivePressureEnabled = false))
        beginTwo(machine)
        machine.onEvent(event(PointerAction.MOVE, 100, p(0, 110f, 10f), p(1, 130f, 10f)))
        val output = machine.onEvent(event(PointerAction.POINTER_UP, 180, p(0, 110f, 10f), p(1, 130f, 10f)))

        val shortcuts = output.filterIsInstance<TrackpadGestureOutput.ConfiguredAction>()
        assertEquals(1, shortcuts.size)
        assertEquals(
            RemoteActionConfig.KeyboardShortcut(setOf(KeyboardModifier.LEFT_ALT), 0x4F),
            shortcuts.single().action,
        )
    }

    @Test
    fun `slow two finger horizontal motion becomes shift wheel instead of navigation`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(adaptivePressureEnabled = false))
        beginTwo(machine)
        machine.onEvent(event(PointerAction.MOVE, 200, p(0, 20f, 10f), p(1, 40f, 10f)))
        val output = machine.onEvent(event(PointerAction.MOVE, 700, p(0, 45f, 10f), p(1, 65f, 10f)))
        val end = machine.onEvent(event(PointerAction.POINTER_UP, 760, p(0, 45f, 10f), p(1, 65f, 10f)))

        assertTrue((output + end).any {
            it is TrackpadGestureOutput.ModifiedScroll && it.modifier == KeyboardModifier.LEFT_SHIFT
        })
        assertTrue((output + end).none { it is TrackpadGestureOutput.ConfiguredAction })
    }

    @Test
    fun `custom two finger action replaces the default shortcut`() {
        val custom = RemoteActionConfig.KeyboardKey(0x2C)
        val machine = TrackpadGestureStateMachine(
            TrackpadSettings(
                adaptivePressureEnabled = false,
                gestureActions = TrackpadGestureActions(twoFingerForward = custom),
            ),
        )
        beginTwo(machine)
        machine.onEvent(event(PointerAction.MOVE, 100, p(0, 110f, 10f), p(1, 130f, 10f)))
        val output = machine.onEvent(event(PointerAction.POINTER_UP, 180, p(0, 110f, 10f), p(1, 130f, 10f)))

        assertEquals(
            listOf(TrackpadGestureOutput.ConfiguredAction(custom)),
            output.filterIsInstance<TrackpadGestureOutput.ConfiguredAction>(),
        )
    }

    @Test
    fun `three finger swipe maps to win tab only once`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(adaptivePressureEnabled = false))
        machine.onEvent(event(PointerAction.DOWN, 0, p(0, 10f, 100f)))
        machine.onEvent(event(PointerAction.POINTER_DOWN, 10, p(0, 10f, 100f), p(1, 30f, 100f)))
        machine.onEvent(event(PointerAction.POINTER_DOWN, 20, p(0, 10f, 100f), p(1, 30f, 100f), p(2, 50f, 100f)))
        machine.onEvent(event(PointerAction.MOVE, 100, p(0, 10f, 0f), p(1, 30f, 0f), p(2, 50f, 0f)))
        val output = machine.onEvent(event(PointerAction.POINTER_UP, 140, p(0, 10f, 0f), p(1, 30f, 0f), p(2, 50f, 0f)))
        val trailing = machine.onEvent(event(PointerAction.UP, 180, p(0, 10f, 0f)))

        assertEquals(
            listOf(TrackpadGestureOutput.ConfiguredAction(
                RemoteActionConfig.KeyboardShortcut(setOf(KeyboardModifier.LEFT_GUI), 0x2B),
            )),
            output.filterIsInstance<TrackpadGestureOutput.ConfiguredAction>(),
        )
        assertTrue(trailing.none { it is TrackpadGestureOutput.ConfiguredAction || it is TrackpadGestureOutput.Click })
    }

    @Test
    fun `four fingers disabled never downgrade to lower gesture`() {
        val machine = TrackpadGestureStateMachine(TrackpadSettings(fourFingerGesturesEnabled = false, adaptivePressureEnabled = false))
        machine.onEvent(event(PointerAction.DOWN, 0, p(0, 0f, 0f)))
        machine.onEvent(event(PointerAction.POINTER_DOWN, 10, p(0, 0f, 0f), p(1, 10f, 0f)))
        machine.onEvent(event(PointerAction.POINTER_DOWN, 20, p(0, 0f, 0f), p(1, 10f, 0f), p(2, 20f, 0f)))
        machine.onEvent(event(PointerAction.POINTER_DOWN, 30, p(0, 0f, 0f), p(1, 10f, 0f), p(2, 20f, 0f), p(3, 30f, 0f)))
        machine.onEvent(event(PointerAction.MOVE, 90, p(0, 0f, -100f), p(1, 10f, -100f), p(2, 20f, -100f), p(3, 30f, -100f)))
        val output = machine.onEvent(event(PointerAction.POINTER_UP, 120, p(0, 0f, -100f), p(1, 10f, -100f), p(2, 20f, -100f), p(3, 30f, -100f)))

        assertTrue(output.all { it == TrackpadGestureOutput.PressureCleared })
    }

    private fun beginTwo(machine: TrackpadGestureStateMachine) {
        machine.onEvent(event(PointerAction.DOWN, 0, p(0, 10f, 10f)))
        machine.onEvent(event(PointerAction.POINTER_DOWN, 10, p(0, 10f, 10f), p(1, 30f, 10f)))
    }

    private fun p(id: Int, x: Float, y: Float, pressure: Float = 0.2f) =
        TrackpadPointerSample(id, x, y, pressure, 0.2f, 10f, 8f)

    private fun event(action: PointerAction, time: Long, vararg pointers: TrackpadPointerSample) =
        TrackpadPointerEvent(action, time, pointers.firstOrNull()?.id, pointers.toList())
}
