package com.gunianan.btremote.ui.components

import org.junit.Assert.assertEquals
import org.junit.Test

class PcRemoteControlsTest {
    @Test
    fun `range mapping is reversible at endpoints and midpoint`() {
        val range = 0.5f..3f
        listOf(0f, 0.5f, 1f).forEach { fraction ->
            assertEquals(fraction, normalize(valueAt(fraction, range), range), 0.0001f)
        }
    }

    @Test
    fun `step snapping keeps endpoints and nearest interval`() {
        assertEquals(0f, snapFraction(-1f, 4), 0f)
        assertEquals(1f, snapFraction(2f, 4), 0f)
        assertEquals(0.4f, snapFraction(0.44f, 4), 0.0001f)
    }
}
