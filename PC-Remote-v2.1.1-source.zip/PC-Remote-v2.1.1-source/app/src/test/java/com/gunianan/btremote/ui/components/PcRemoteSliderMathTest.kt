package com.gunianan.btremote.ui.components

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PcRemoteSliderMathTest {
    @Test
    fun `track taps outside thumb are ignored`() {
        assertFalse(isWithinSliderThumb(pointerX = 180f, thumbCenterX = 60f, touchRadius = 24f))
    }

    @Test
    fun `thumb and its touch halo can start a drag`() {
        assertTrue(isWithinSliderThumb(pointerX = 60f, thumbCenterX = 60f, touchRadius = 24f))
        assertTrue(isWithinSliderThumb(pointerX = 83.9f, thumbCenterX = 60f, touchRadius = 24f))
    }

    @Test
    fun `thumb touch halo is inclusive at both edges`() {
        assertTrue(isWithinSliderThumb(pointerX = 36f, thumbCenterX = 60f, touchRadius = 24f))
        assertTrue(isWithinSliderThumb(pointerX = 84f, thumbCenterX = 60f, touchRadius = 24f))
    }
}
