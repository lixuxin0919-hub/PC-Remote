package com.gunianan.btremote.action

import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.MouseCommand
import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.RemoteActionConfig
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class PointerActionQueueTest {

    @Test
    fun oneThousandMoveSamplesStayBoundedMergeAndPreserveDelta() = runTest {
        val gate = CompletableDeferred<Unit>()
        val started = CompletableDeferred<Unit>()
        val executed = mutableListOf<RemoteActionConfig>()
        val queue = PointerActionQueue(this, capacity = 8) { action ->
            if (action is RemoteActionConfig.KeyboardKey) {
                started.complete(Unit)
                gate.await()
            } else {
                executed += action
            }
        }

        assertEquals(
            PointerActionQueue.OfferResult.ENQUEUED,
            queue.offer(RemoteActionConfig.KeyboardKey(4)),
        )
        runCurrent()
        started.await()

        repeat(1_000) {
            queue.offer(move(deltaX = 1, deltaY = -1))
            assertTrue(queue.pendingCount <= queue.capacity)
        }

        assertEquals(1, queue.pendingCount)
        assertEquals(999L, queue.snapshot().mergedMotionCount)

        gate.complete(Unit)
        advanceUntilIdle()

        val moves = executed.filterIsInstance<RemoteActionConfig.MouseAction>()
        assertEquals(1_000, moves.sumOf { it.deltaX })
        assertEquals(-1_000, moves.sumOf { it.deltaY })
        assertTrue(moves.all { it.deltaX in -127..127 && it.deltaY in -127..127 })
        assertTrue(moves.size < 1_000)
        queue.close()
    }

    @Test
    fun adjacentScrollSamplesMergeButDiscreteActionsRemainInOrder() = runTest {
        val gate = CompletableDeferred<Unit>()
        val executed = mutableListOf<RemoteActionConfig>()
        val queue = PointerActionQueue(this, capacity = 8) { action ->
            if (action is RemoteActionConfig.KeyboardKey) gate.await() else executed += action
        }
        queue.offer(RemoteActionConfig.KeyboardKey(4))
        runCurrent()

        val click = mouse(MouseCommand.CLICK, MouseButton.LEFT)
        val down = mouse(MouseCommand.DOWN, MouseButton.RIGHT)
        val up = mouse(MouseCommand.UP, MouseButton.RIGHT)
        queue.offer(RemoteActionConfig.ScrollAction(vertical = 100))
        queue.offer(RemoteActionConfig.ScrollAction(vertical = 100))
        queue.offer(click)
        queue.offer(down)
        queue.offer(up)

        gate.complete(Unit)
        advanceUntilIdle()

        assertEquals(
            listOf(click, down, up),
            executed.filterIsInstance<RemoteActionConfig.MouseAction>(),
        )
        val scrolls = executed.filterIsInstance<RemoteActionConfig.ScrollAction>()
        assertEquals(200, scrolls.sumOf { it.vertical })
        assertTrue(scrolls.all { it.vertical in -127..127 })
        queue.close()
    }

    @Test
    fun oneLargeMotionSampleIsChunkedWithoutLosingDelta() = runTest {
        val executed = mutableListOf<RemoteActionConfig>()
        val queue = PointerActionQueue(this, capacity = 8) { executed += it }

        queue.offer(move(deltaX = 500, deltaY = -500))
        queue.offer(RemoteActionConfig.ScrollAction(horizontal = 300, vertical = -300))
        advanceUntilIdle()

        val moves = executed.filterIsInstance<RemoteActionConfig.MouseAction>()
        assertEquals(500, moves.sumOf { it.deltaX })
        assertEquals(-500, moves.sumOf { it.deltaY })
        assertTrue(moves.all { it.deltaX in -127..127 && it.deltaY in -127..127 })

        val scrolls = executed.filterIsInstance<RemoteActionConfig.ScrollAction>()
        assertEquals(300, scrolls.sumOf { it.horizontal })
        assertEquals(-300, scrolls.sumOf { it.vertical })
        assertTrue(scrolls.all { it.horizontal in -127..127 && it.vertical in -127..127 })
        queue.close()
    }

    @Test
    fun adjacentModifiedScrollSamplesMergeAndRemainHidSafe() = runTest {
        val gate = CompletableDeferred<Unit>()
        val started = CompletableDeferred<Unit>()
        val executed = mutableListOf<RemoteActionConfig>()
        val queue = PointerActionQueue(this, capacity = 8) { action ->
            if (action is RemoteActionConfig.KeyboardKey) {
                started.complete(Unit)
                gate.await()
            } else {
                executed += action
            }
        }

        queue.offer(RemoteActionConfig.KeyboardKey(4))
        runCurrent()
        started.await()

        repeat(1_000) {
            queue.offer(
                RemoteActionConfig.ModifiedScrollAction(
                    modifiers = setOf(KeyboardModifier.LEFT_CONTROL),
                    vertical = 1,
                ),
            )
        }

        assertEquals(1, queue.pendingCount)
        assertEquals(999L, queue.snapshot().mergedMotionCount)

        gate.complete(Unit)
        advanceUntilIdle()

        val scrolls = executed.filterIsInstance<RemoteActionConfig.ModifiedScrollAction>()
        assertEquals(1_000, scrolls.sumOf { it.vertical })
        assertTrue(scrolls.all { it.vertical in -127..127 })
        assertTrue(scrolls.all { it.modifiers == setOf(KeyboardModifier.LEFT_CONTROL) })
        assertTrue(scrolls.size < 1_000)
        queue.close()
    }

    @Test
    fun releaseReserveKeepsRequiredUpWhenQueueIsAtCapacity() = runTest {
        val gate = CompletableDeferred<Unit>()
        val executed = mutableListOf<RemoteActionConfig>()
        val queue = PointerActionQueue(this, capacity = 8) { action ->
            if (action is RemoteActionConfig.KeyboardKey) gate.await() else executed += action
        }
        queue.offer(RemoteActionConfig.KeyboardKey(4))
        runCurrent()

        val downLeft = mouse(MouseCommand.DOWN, MouseButton.LEFT)
        val fillers = (1..4).map { RemoteActionConfig.ConsumerKey(it) }
        (listOf(downLeft) + fillers).forEach {
            assertEquals(PointerActionQueue.OfferResult.ENQUEUED, queue.offer(it))
        }

        val upRight = mouse(MouseCommand.UP, MouseButton.RIGHT)
        val upMiddle = mouse(MouseCommand.UP, MouseButton.MIDDLE)
        val upLeft = mouse(MouseCommand.UP, MouseButton.LEFT)
        assertEquals(PointerActionQueue.OfferResult.ENQUEUED, queue.offer(upRight))
        assertEquals(PointerActionQueue.OfferResult.ENQUEUED, queue.offer(upMiddle))
        assertEquals(PointerActionQueue.OfferResult.ENQUEUED, queue.offer(upLeft))
        assertEquals(queue.capacity, queue.pendingCount)

        // Regular actions cannot consume the slots reserved for releases.
        assertEquals(
            PointerActionQueue.OfferResult.REJECTED_FULL,
            queue.offer(mouse(MouseCommand.CLICK, MouseButton.LEFT)),
        )

        gate.complete(Unit)
        advanceUntilIdle()

        assertEquals(
            listOf(downLeft) + fillers + listOf(upRight, upMiddle, upLeft),
            executed,
        )
        assertEquals(MouseCommand.UP, (executed.last() as RemoteActionConfig.MouseAction).command)
        queue.close()
    }

    @Test
    fun oldestMotionIsDiscardedBeforeNewDiscreteInputAtCapacity() = runTest {
        val gate = CompletableDeferred<Unit>()
        val executed = mutableListOf<RemoteActionConfig>()
        val queue = PointerActionQueue(this, capacity = 8) { action ->
            if (action is RemoteActionConfig.KeyboardKey) gate.await() else executed += action
        }
        queue.offer(RemoteActionConfig.KeyboardKey(4))
        runCurrent()

        queue.offer(move(1, 0))
        queue.offer(RemoteActionConfig.ScrollAction(vertical = 1))
        queue.offer(move(2, 0))
        queue.offer(RemoteActionConfig.ScrollAction(vertical = 2))
        queue.offer(move(3, 0))
        val click = mouse(MouseCommand.CLICK, MouseButton.LEFT)

        assertEquals(PointerActionQueue.OfferResult.ENQUEUED, queue.offer(click))
        assertEquals(1L, queue.snapshot().droppedMotionCount)
        assertTrue(queue.pendingCount <= queue.capacity)

        gate.complete(Unit)
        advanceUntilIdle()

        assertEquals(click, executed.last())
        queue.close()
    }

    @Test
    fun closeCancelsWorkerClearsPendingAndRejectsNewOffers() = runTest {
        val started = CompletableDeferred<Unit>()
        val queue = PointerActionQueue(this, capacity = 8) { action ->
            if (action is RemoteActionConfig.KeyboardKey) {
                started.complete(Unit)
                awaitCancellation()
            }
        }
        queue.offer(RemoteActionConfig.KeyboardKey(4))
        runCurrent()
        started.await()
        queue.offer(move(10, 10))

        queue.cancel()
        advanceUntilIdle()

        assertTrue(queue.isClosed)
        assertEquals(0, queue.pendingCount)
        assertEquals(PointerActionQueue.OfferResult.CLOSED, queue.offer(move(1, 1)))
    }

    private fun move(deltaX: Int, deltaY: Int) = RemoteActionConfig.MouseAction(
        command = MouseCommand.MOVE,
        deltaX = deltaX,
        deltaY = deltaY,
    )

    private fun mouse(command: MouseCommand, button: MouseButton) =
        RemoteActionConfig.MouseAction(command = command, button = button)
}
