package com.gunianan.btremote.action

import com.gunianan.btremote.domain.HidConsumerUsages
import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.RemoteActionConfig
import org.junit.Assert.assertEquals
import org.junit.Test

class ActionDisplayNameResolverTest {
    @Test
    fun `media actions expose the bound user facing action`() {
        assertEquals(
            "上一首 / 上一条",
            ActionDisplayNameResolver.resolve(RemoteActionConfig.ConsumerKey(HidConsumerUsages.PREVIOUS_TRACK)),
        )
        assertEquals(
            "下一首 / 下一条",
            ActionDisplayNameResolver.resolve(RemoteActionConfig.ConsumerKey(HidConsumerUsages.NEXT_TRACK)),
        )
    }

    @Test
    fun `shortcut includes modifiers and key`() {
        assertEquals(
            "Ctrl+C",
            ActionDisplayNameResolver.resolve(
                RemoteActionConfig.KeyboardShortcut(setOf(KeyboardModifier.LEFT_CONTROL), 0x06),
            ),
        )
    }
}
