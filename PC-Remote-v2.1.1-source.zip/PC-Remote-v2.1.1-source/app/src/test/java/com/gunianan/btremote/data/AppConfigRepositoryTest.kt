package com.gunianan.btremote.data

import com.gunianan.btremote.domain.DefaultConfigFactory
import com.gunianan.btremote.domain.SYSTEM_DEFAULT_PROFILE_ID
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppConfigRepositoryTest {
    @Test
    fun `repository migrates legacy settings once and persists JSON`() {
        val configStore = InMemoryKeyValueStore()
        val legacyStore = InMemoryKeyValueStore().apply {
            values["haptic"] = false
            values["auto_connect"] = false
            values["keep_screen_on"] = false
            values["last_device_address"] = "AA:BB:CC:DD:EE:FF"
        }
        val repository = AppConfigRepository(configStore, legacyStore, nowProvider = { 1_000L })

        with(repository.current().globalSettings) {
            assertFalse(hapticEnabled)
            assertFalse(autoConnect)
            assertFalse(keepScreenOn)
            assertEquals("AA:BB:CC:DD:EE:FF", lastDeviceAddress)
        }
        legacyStore.values["haptic"] = true
        val reloaded = AppConfigRepository(configStore, legacyStore, nowProvider = { 2_000L })
        assertFalse(reloaded.current().globalSettings.hapticEnabled)
        assertNotNull(configStore.getString("app_config_v1"))
    }

    @Test
    fun `system profile cannot be deleted`() {
        val repository = AppConfigRepository(InMemoryKeyValueStore(), nowProvider = { 1_000L })

        expectThrows<SystemProfileProtectedException> {
            repository.deleteProfile(SYSTEM_DEFAULT_PROFILE_ID)
        }
        assertEquals(2, repository.current().profiles.size)
    }

    @Test
    fun `restore replaces edited system seed but preserves custom profiles and selections`() {
        var now = 1_000L
        val repository = AppConfigRepository(
            InMemoryKeyValueStore(),
            nowProvider = { now },
            idGenerator = ProfileIdGenerator { "profile.copy" },
        )
        val copied = repository.copyProfile(SYSTEM_DEFAULT_PROFILE_ID, "剪辑模式")
        repository.setStartupProfile(copied.id)
        val editedSystem = repository.current().profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }
            .copy(name = "被修改的名称", controls = emptyList(), updatedAt = 1_500L)
        repository.upsertProfile(editedSystem)
        now = 2_000L

        val restored = repository.restoreSystemProfile()

        val system = restored.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }
        assertEquals("默认视频模式", system.name)
        assertEquals(6, system.controls.size)
        assertTrue(restored.profiles.any { it.id == com.gunianan.btremote.domain.SYSTEM_TRACKPAD_PROFILE_ID })
        assertTrue(restored.profiles.any { it.id == copied.id })
        assertEquals(copied.id, restored.startupProfileId)
    }

    @Test
    fun `invalid persisted JSON recovers safely and keeps a backup`() {
        val store = InMemoryKeyValueStore().apply {
            values["app_config_v1"] = "{not-json"
        }

        val repository = AppConfigRepository(store, nowProvider = { 1_000L })

        assertEquals(DefaultConfigFactory.create(1_000L), repository.current())
        assertNotNull(repository.recovery)
        assertTrue(repository.recovery!!.corruptedPayloadBackedUp)
        assertEquals("{not-json", store.getString("app_config_corrupted_backup"))
    }

    @Test
    fun `cold process activation applies the selected startup profile`() {
        val repository = AppConfigRepository(
            InMemoryKeyValueStore(),
            nowProvider = { 1_000L },
            idGenerator = ProfileIdGenerator { "profile.startup" },
        )
        val startup = repository.copyProfile(SYSTEM_DEFAULT_PROFILE_ID, "启动模式")
        repository.setStartupProfile(startup.id)
        repository.setActiveProfile(SYSTEM_DEFAULT_PROFILE_ID)

        val activated = repository.activateStartupProfile()

        assertEquals(startup.id, activated.activeProfileId)
        assertEquals(startup.id, activated.startupProfileId)
    }

    private class InMemoryKeyValueStore : KeyValueStore {
        val values = mutableMapOf<String, Any>()

        override fun contains(key: String): Boolean = values.containsKey(key)
        override fun getString(key: String): String? = values[key] as? String
        override fun getBoolean(key: String, defaultValue: Boolean): Boolean =
            values[key] as? Boolean ?: defaultValue

        override fun putString(key: String, value: String): Boolean {
            values[key] = value
            return true
        }

        override fun putBoolean(key: String, value: Boolean): Boolean {
            values[key] = value
            return true
        }
    }

    private inline fun <reified T : Throwable> expectThrows(block: () -> Unit): T {
        try {
            block()
        } catch (error: Throwable) {
            if (error is T) return error
            throw error
        }
        error("Expected ${T::class.java.simpleName}")
    }
}
