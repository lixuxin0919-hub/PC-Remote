package com.gunianan.btremote.bluetooth

import com.gunianan.btremote.action.ActionResult
import com.gunianan.btremote.action.HidKeyStateManager
import com.gunianan.btremote.action.KeyPhase
import com.gunianan.btremote.action.KeyReleaseReason
import com.gunianan.btremote.action.MonotonicClock
import com.gunianan.btremote.action.MouseButtonId
import com.gunianan.btremote.action.RemoteCommand
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class BluetoothRemoteCommandExecutorTest {
    @Test
    fun `keyboard shortcut tap emits press then matching release`() = runTest {
        val fixture = fixture()
        fixture.executor.execute(RemoteCommand.Keyboard(0x2C, modifierMask = 0x02))

        assertEquals(
            listOf(
                "1:[2, 0, 44, 0, 0, 0, 0, 0]",
                "1:[0, 0, 0, 0, 0, 0, 0, 0]",
            ),
            fixture.frames,
        )
        fixture.close()
    }

    @Test
    fun `consumer usage id is translated to descriptor bit mask`() = runTest {
        val fixture = fixture()
        val result = fixture.executor.execute(RemoteCommand.Consumer(usageId = 0xB6))

        assertTrue(result is ActionResult.Success)
        assertEquals(listOf("3:[32]", "3:[0]"), fixture.frames)
        fixture.close()
    }

    @Test
    fun `modified scroll always emits modifier wheel and keyboard release`() = runTest {
        val fixture = fixture()
        val result = fixture.executor.execute(RemoteCommand.ModifiedScroll(modifierMask = 0x02, vertical = -3))

        assertTrue(result is ActionResult.Success)
        assertEquals(
            listOf(
                "1:[2, 0, 0, 0, 0, 0, 0, 0]",
                "2:[0, 0, 0, -3]",
                "1:[0, 0, 0, 0, 0, 0, 0, 0]",
            ),
            fixture.frames,
        )
        fixture.close()
    }

    @Test
    fun `held mouse button is preserved while moving and released on lifecycle boundary`() = runTest {
        val fixture = fixture()
        fixture.executor.execute(RemoteCommand.MouseButton(MouseButtonId.LEFT, KeyPhase.DOWN))
        fixture.executor.execute(RemoteCommand.MouseMove(deltaX = 9, deltaY = -4))
        val releases = fixture.executor.releaseAll(KeyReleaseReason.APP_BACKGROUND)

        assertEquals(1, releases.released)
        assertEquals(
            listOf(
                "2:[1, 0, 0, 0]",
                "2:[1, 9, -4, 0]",
                "2:[0, 0, 0, 0]",
            ),
            fixture.frames,
        )
        fixture.close()
    }

    @Test
    fun `unsupported consumer usages fail without transport output`() = runTest {
        val fixture = fixture()
        val result = fixture.executor.execute(RemoteCommand.Consumer(usageId = 0x999))

        assertTrue(result is ActionResult.Failure)
        assertTrue(fixture.frames.isEmpty())
        fixture.close()
    }

    @Test
    fun `repeated send failures emit one throttled recovery signal`() = runTest {
        var recoverySignals = 0
        val sender = HidReportSender(0L, { _ -> }, System::currentTimeMillis)
        val senderSession = sender.openSession { _, _ -> false }
        val executor = BluetoothRemoteCommandExecutor(
            keyStateManager = HidKeyStateManager(minimumDownIntervalMillis = 0L),
            clock = MonotonicClock { 5_000L },
            failureThrottleMillis = 1_500L,
            onTransportFailure = { _, _ -> recoverySignals++ },
        )
        executor.bindSession("failing-session", senderSession)

        val first = executor.execute(RemoteCommand.Consumer(usageId = 0xE9))
        val second = executor.execute(RemoteCommand.Consumer(usageId = 0xEA))

        assertTrue(first is ActionResult.Failure)
        assertTrue(second is ActionResult.Failure)
        assertEquals(1, recoverySignals)
        executor.close()
        sender.close()
    }

    @Test
    fun `caller cancellation cannot leave a successful key down untracked`() = runTest {
        val firstFrameStarted = CountDownLatch(1)
        val allowFirstFrame = CountDownLatch(1)
        val frames = Collections.synchronizedList(mutableListOf<String>())
        val sender = HidReportSender(0L, { _ -> }, System::currentTimeMillis)
        val senderSession = sender.openSession { reportId, payload ->
            frames += "$reportId:${payload.contentToString()}"
            if (frames.size == 1) {
                firstFrameStarted.countDown()
                allowFirstFrame.await(1, TimeUnit.SECONDS)
            }
            true
        }
        val executor = BluetoothRemoteCommandExecutor(
            keyStateManager = HidKeyStateManager(minimumDownIntervalMillis = 0L),
        )
        executor.bindSession("cancellation-session", senderSession)

        val caller = launch(start = CoroutineStart.UNDISPATCHED) {
            executor.execute(RemoteCommand.Keyboard(keyCode = 0x2C, phase = KeyPhase.DOWN))
        }
        assertTrue(firstFrameStarted.await(1, TimeUnit.SECONDS))
        caller.cancel()
        allowFirstFrame.countDown()
        caller.join()
        val released = executor.releaseAll(KeyReleaseReason.APP_BACKGROUND)

        assertEquals(1, released.released)
        assertEquals(
            listOf(
                "1:[0, 0, 44, 0, 0, 0, 0, 0]",
                "1:[0, 0, 0, 0, 0, 0, 0, 0]",
            ),
            frames,
        )
        executor.close()
        sender.close()
    }

    @Test
    fun `held key watchdog releases an unpaired down after thirty seconds`() = runTest {
        val frames = Collections.synchronizedList(mutableListOf<String>())
        val sender = HidReportSender(0L, { _ -> }, System::currentTimeMillis)
        val senderSession = sender.openSession { reportId, payload ->
            frames += "$reportId:${payload.contentToString()}"
            true
        }
        val executor = BluetoothRemoteCommandExecutor(
            keyStateManager = HidKeyStateManager(minimumDownIntervalMillis = 0L),
            watchdogScope = this,
            heldKeyTimeoutMillis = 30_000L,
        )
        executor.bindSession("watchdog-session", senderSession)

        executor.execute(RemoteCommand.Keyboard(0x2C, phase = KeyPhase.DOWN))
        advanceTimeBy(29_999L)
        assertEquals(1, frames.size)
        advanceTimeBy(1L)
        advanceUntilIdle()

        // HidReportSender owns a real serial executor; virtual coroutine time can
        // finish before that executor publishes the release frame under heavy CI load.
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(1)
        while (frames.size < 2 && System.nanoTime() < deadline) {
            Thread.yield()
        }

        assertEquals(
            listOf(
                "1:[0, 0, 44, 0, 0, 0, 0, 0]",
                "1:[0, 0, 0, 0, 0, 0, 0, 0]",
            ),
            frames,
        )
        executor.close()
        sender.close()
    }

    private suspend fun fixture(): Fixture {
        val frames = Collections.synchronizedList(mutableListOf<String>())
        val sender = HidReportSender(0L, { _ -> }, System::currentTimeMillis)
        val senderSession = sender.openSession { reportId, payload ->
            frames += "$reportId:${payload.contentToString()}"
            true
        }
        val executor = BluetoothRemoteCommandExecutor(
            keyStateManager = HidKeyStateManager(
                clock = MonotonicClock { 1_000L },
                minimumDownIntervalMillis = 0L,
            ),
        )
        executor.bindSession("test-session", senderSession)
        return Fixture(executor, sender, frames)
    }

    private data class Fixture(
        val executor: BluetoothRemoteCommandExecutor,
        val sender: HidReportSender,
        val frames: MutableList<String>,
    ) {
        suspend fun close() {
            executor.close()
            sender.close()
        }
    }
}
