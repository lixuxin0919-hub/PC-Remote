package com.gunianan.btremote.data

import com.gunianan.btremote.domain.ConfigValidationException
import com.gunianan.btremote.domain.GesturePoint
import com.gunianan.btremote.domain.GestureSample
import com.gunianan.btremote.domain.GestureTemplate
import com.gunianan.btremote.domain.DefaultConfigFactory
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.domain.SYSTEM_DEFAULT_PROFILE_ID
import com.gunianan.btremote.domain.SYSTEM_TRACKPAD_PROFILE_ID
import com.gunianan.btremote.trackpad.settings.TrackpadGestureActionSlot
import kotlinx.serialization.encodeToString
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ConfigJsonCodecTest {
    @Test
    fun `schema one migrates once to video shortcuts and trackpad system mode`() {
        val current = DefaultConfigFactory.create(now = 1_000L)
        val legacyVideo = current.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }.copy(
            controls = current.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }
                .controls.filter { it.id.startsWith("system.volume.") }
                .mapIndexed { index, item -> item.copy(position = index) },
        )
        val legacy = current.copy(schemaVersion = 1, profiles = listOf(legacyVideo))

        val migrated = ConfigJsonCodec.decodeConfig(ConfigJsonCodec.json.encodeToString(legacy))
        val migratedAgain = ConfigMigrator.migrate(migrated, now = 9_000L)

        assertEquals(2, migrated.schemaVersion)
        assertTrue(migrated.profiles.any { it.id == SYSTEM_TRACKPAD_PROFILE_ID })
        assertEquals(
            1,
            migrated.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }
                .controls.count { it.id == "system.video.play_pause" },
        )
        assertEquals(migrated, migratedAgain)
    }

    @Test
    fun `config JSON round trips and ignores unknown future fields`() {
        val original = DefaultConfigFactory.create(now = 1_000L)
        val encoded = ConfigJsonCodec.encodeConfig(original)
        val withFutureField = encoded.dropLast(1) + ",\"futureField\":{\"enabled\":true}}"

        assertEquals(original, ConfigJsonCodec.decodeConfig(encoded))
        assertEquals(original, ConfigJsonCodec.decodeConfig(withFutureField))
    }

    @Test
    fun `trackpad button visibility and custom gesture actions persist`() {
        val original = DefaultConfigFactory.create(now = 1_000L)
        val customAction = RemoteActionConfig.ConsumerKey(0xCD)
        val trackpad = original.globalSettings.trackpad
        val changed = original.copy(
            globalSettings = original.globalSettings.copy(
                trackpad = trackpad.copy(
                    showMouseButtons = false,
                    gestureActions = trackpad.gestureActions.withAction(
                        TrackpadGestureActionSlot.THREE_FINGER_UP,
                        customAction,
                    ),
                ),
            ),
        )

        val decoded = ConfigJsonCodec.decodeConfig(ConfigJsonCodec.encodeConfig(changed))

        assertFalse(decoded.globalSettings.trackpad.showMouseButtons)
        assertEquals(
            customAction,
            decoded.globalSettings.trackpad.gestureActions.threeFingerUp,
        )
    }

    @Test
    fun `decoder rejects missing and unsupported schema versions`() {
        val config = DefaultConfigFactory.create(now = 1_000L)
        val unsupported = ConfigJsonCodec.json.encodeToString(config.copy(schemaVersion = 99))

        expectThrows<UnsupportedConfigVersionException> {
            ConfigJsonCodec.decodeConfig(unsupported)
        }
        expectThrows<UnsupportedConfigVersionException> {
            ConfigJsonCodec.decodeConfig("{\"profiles\":[]}")
        }
    }

    @Test
    fun `decoder rejects invalid action and duplicate profile IDs`() {
        val config = DefaultConfigFactory.create(now = 1_000L)
        val system = config.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }
        val invalidAction = system.controls.first().copy(
            tapAction = RemoteActionConfig.KeyboardKey(0),
        )
        val invalidActionConfig = config.copy(
            profiles = listOf(system.copy(controls = listOf(invalidAction) + system.controls.drop(1))),
        )
        val duplicateConfig = config.copy(profiles = config.profiles + system)

        expectThrows<ConfigValidationException> {
            ConfigJsonCodec.decodeConfig(ConfigJsonCodec.json.encodeToString(invalidActionConfig))
        }
        expectThrows<ConfigValidationException> {
            ConfigJsonCodec.decodeConfig(ConfigJsonCodec.json.encodeToString(duplicateConfig))
        }
    }

    @Test
    fun `import remaps collision and never overwrites system profile`() {
        val current = DefaultConfigFactory.create(now = 1_000L)
        val exportedSystem = ConfigJsonCodec.exportProfile(
            current.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID },
        )

        val result = ProfileImportService.importProfile(
            rawJson = exportedSystem,
            currentConfig = current,
            now = 2_000L,
            idGenerator = ProfileIdGenerator { "profile.imported" },
        )

        assertTrue(result.idRemapped)
        assertEquals("profile.imported", result.importedProfileId)
        assertEquals(3, result.config.profiles.size)
        assertEquals(1, result.config.profiles.count { it.id == SYSTEM_DEFAULT_PROFILE_ID })
        val imported = result.config.profiles.single { it.id == "profile.imported" }
        assertFalse(imported.isSystemProfile)
        assertFalse(imported.isDefault)
        assertNotEquals(SYSTEM_DEFAULT_PROFILE_ID, imported.id)
    }

    @Test
    fun `import remaps a colliding custom ID and preserves the original`() {
        val systemConfig = DefaultConfigFactory.create(now = 1_000L)
        val custom = systemConfig.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }.copy(
            id = "profile.office",
            name = "Office",
            isSystemProfile = false,
            isDefault = false,
        )
        val current = systemConfig.copy(profiles = systemConfig.profiles + custom)
        val result = ProfileImportService.importProfile(
            rawJson = ConfigJsonCodec.exportProfile(custom),
            currentConfig = current,
            now = 2_000L,
            idGenerator = ProfileIdGenerator { "profile.office.imported" },
        )

        assertTrue(result.idRemapped)
        assertEquals(1, result.config.profiles.count { it.id == "profile.office" })
        assertEquals(1, result.config.profiles.count { it.id == "profile.office.imported" })
    }

    @Test
    fun `encoder and profile export enforce the same size limit as decoder`() {
        val baseline = DefaultConfigFactory.create(now = 1_000L)
        val points = List(512) { index ->
            GesturePoint(
                x = 0.12345679f,
                y = -0.9876543f,
                elapsedMs = index.toLong(),
            )
        }
        val samples = List(3) { GestureSample(points) }
        val gestures = List(32) { index ->
            GestureTemplate(
                id = "large.gesture.$index",
                name = "大型手势 $index",
                samples = samples,
                createdAt = 1_000L,
                updatedAt = 1_000L,
            )
        }
        val oversizedProfile = baseline.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }
            .copy(customGestures = gestures)
        val oversizedConfig = baseline.copy(
            profiles = baseline.profiles.map { if (it.id == SYSTEM_DEFAULT_PROFILE_ID) oversizedProfile else it },
        )

        expectThrows<ConfigFormatException> { ConfigJsonCodec.exportProfile(oversizedProfile) }
        expectThrows<ConfigFormatException> { ConfigJsonCodec.encodeConfig(oversizedConfig) }
    }

    private inline fun <reified T : Throwable> expectThrows(block: () -> Unit): T {
        try {
            block()
            fail("Expected ${T::class.java.simpleName}")
        } catch (error: Throwable) {
            if (error is T) return error
            throw error
        }
        error("unreachable")
    }
}
