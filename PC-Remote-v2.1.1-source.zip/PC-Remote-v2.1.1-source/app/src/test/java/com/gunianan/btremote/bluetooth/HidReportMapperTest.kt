package com.gunianan.btremote.bluetooth

import com.gunianan.btremote.action.MouseButtonId
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HidReportMapperTest {
    @Test
    fun `consumer usages follow the one-byte SDP bit order`() {
        assertEquals(0x01, HidReportMapper.consumerMask(0xE9))
        assertEquals(0x02, HidReportMapper.consumerMask(0xEA))
        assertEquals(0x04, HidReportMapper.consumerMask(0xE2))
        assertEquals(0x08, HidReportMapper.consumerMask(0xCD))
        assertEquals(0x10, HidReportMapper.consumerMask(0xB5))
        assertEquals(0x20, HidReportMapper.consumerMask(0xB6))
        assertEquals(0x40, HidReportMapper.consumerMask(0xB7))
        assertEquals(0x80, HidReportMapper.consumerMask(0xB3))
        assertNull(HidReportMapper.consumerMask(0x1234))
    }

    @Test
    fun `keyboard shortcut maps modifier and key into boot keyboard report`() {
        val frame = HidReportMapper.keyboardFrame(modifierMask = 0x05, keyCode = 0x2C)
        assertEquals(HidReportSender.REPORT_ID_KEYBOARD, frame.reportId)
        assertArrayEquals(
            byteArrayOf(0x05, 0, 0x2C, 0, 0, 0, 0, 0),
            frame.payload,
        )
    }

    @Test
    fun `mouse reports preserve buttons and clamp every signed axis`() {
        val frame = HidReportMapper.mouseFrame(
            buttons = HidReportMapper.MOUSE_LEFT or HidReportMapper.MOUSE_RIGHT,
            deltaX = 500,
            deltaY = -500,
            wheel = 140,
        )
        assertEquals(HidReportSender.REPORT_ID_MOUSE, frame.reportId)
        assertArrayEquals(byteArrayOf(3, 127, -127, 127), frame.payload)
    }

    @Test
    fun `mouse click restores an already held button`() {
        val report = HidReportMapper.mouseClick(
            currentButtons = HidReportMapper.MOUSE_LEFT,
            button = MouseButtonId.RIGHT,
        )
        assertArrayEquals(byteArrayOf(3, 0, 0, 0), report.pressedPayload)
        assertArrayEquals(byteArrayOf(1, 0, 0, 0), report.releasedPayload)
    }
}
