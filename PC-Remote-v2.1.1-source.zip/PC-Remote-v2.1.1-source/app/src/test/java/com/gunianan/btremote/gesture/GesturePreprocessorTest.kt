package com.gunianan.btremote.gesture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GesturePreprocessorTest {
    @Test
    fun resamplingAlwaysProducesConfiguredPointCount() {
        val preprocessor = GesturePreprocessor(sampleCount = 48)
        val uneven = listOf(
            PointSample(0f, 0f, 0L),
            PointSample(1f, 0f, 10L),
            PointSample(75f, 0f, 20L),
            PointSample(80f, 120f, 30L),
        )

        val prepared = preprocessor.prepare(uneven, rotationInvariant = false)

        assertNotNull(prepared)
        assertEquals(48, prepared?.points?.size)
        assertTrue(prepared!!.originalPathLength > 190f)
    }

    @Test
    fun translationAndUniformScalePreserveHighSimilarity() {
        val base = DefaultGestureTemplates.zShape().points
        val transformed = base.map { it.copy(x = it.x * 1.7f + 900f, y = it.y * 1.7f - 300f) }
        val recognizer = OneDollarRecognizer()

        val similarity = recognizer.similarity(base, transformed, rotationInvariant = false)

        assertTrue("similarity=$similarity", similarity > 0.98f)
    }
}
