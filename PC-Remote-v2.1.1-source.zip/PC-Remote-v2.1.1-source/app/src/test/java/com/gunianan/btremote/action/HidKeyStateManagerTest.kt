package com.gunianan.btremote.action

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HidKeyStateManagerTest {
    @Test
    fun duplicateDownIsIgnoredWithoutDuplicateTransportEvent() = runBlocking {
        val clock = FakeClock()
        val transport = RecordingTransport()
        val manager = HidKeyStateManager(clock, minimumDownIntervalMillis = 20)
        val session = manager.openSession("pc", transport)
        val key = HidKey.Keyboard(44)

        assertTrue(session.keyDown(key).isSuccessful)
        val duplicate = session.keyDown(key)

        assertEquals(IgnoreReason.DUPLICATE_KEY_DOWN, (duplicate as ActionResult.Ignored).reason)
        assertEquals(listOf("pc:${RemoteCommand.Keyboard(44, phase = KeyPhase.DOWN)}"), transport.events)
        assertEquals(setOf(key), session.pressedKeys())
    }

    @Test
    fun keyUpBypassesRateLimitAndClearsState() = runBlocking {
        val clock = FakeClock()
        val transport = RecordingTransport()
        val manager = HidKeyStateManager(clock, minimumDownIntervalMillis = 100)
        val session = manager.openSession("pc", transport)
        val key = HidKey.Keyboard(4)

        session.keyDown(key)
        val up = session.keyUp(key)

        assertTrue(up.isSuccessful)
        assertTrue(session.pressedKeys().isEmpty())
        assertEquals(KeyPhase.DOWN, (transport.commands[0] as RemoteCommand.Keyboard).phase)
        assertEquals(KeyPhase.UP, (transport.commands[1] as RemoteCommand.Keyboard).phase)
    }

    @Test
    fun rateLimitRejectsASecondDifferentDownUntilIntervalPasses() = runBlocking {
        val clock = FakeClock()
        val transport = RecordingTransport()
        val manager = HidKeyStateManager(clock, minimumDownIntervalMillis = 100)
        val session = manager.openSession("pc", transport)

        session.keyDown(HidKey.Keyboard(4))
        clock.advanceBy(99)
        val limited = session.keyDown(HidKey.Keyboard(5))
        clock.advanceBy(1)
        val accepted = session.keyDown(HidKey.Keyboard(5))

        assertEquals(IgnoreReason.RATE_LIMITED, (limited as ActionResult.Ignored).reason)
        assertTrue(accepted.isSuccessful)
        assertEquals(2, transport.commands.size)
    }

    @Test
    fun tapAlwaysSendsBalancedDownAndUp() = runBlocking {
        val transport = RecordingTransport()
        val manager = HidKeyStateManager(FakeClock(), minimumDownIntervalMillis = 0)
        val session = manager.openSession("pc", transport)

        val result = session.tap(HidKey.Consumer(0x10))

        assertEquals(ActionResult.Success(2), result)
        assertEquals(
            listOf(
                RemoteCommand.Consumer(0x10, KeyPhase.DOWN),
                RemoteCommand.Consumer(0x10, KeyPhase.UP),
            ),
            transport.commands,
        )
        assertTrue(session.pressedKeys().isEmpty())
    }

    @Test
    fun releaseAllAttemptsEveryPressedKey() = runBlocking {
        val clock = FakeClock()
        val transport = RecordingTransport()
        val manager = HidKeyStateManager(clock, minimumDownIntervalMillis = 0)
        val session = manager.openSession("pc", transport)
        session.keyDown(HidKey.Keyboard(4))
        session.keyDown(HidKey.Consumer(1))
        session.keyDown(HidKey.MouseButton(MouseButtonId.LEFT))

        val result = session.releaseAll(KeyReleaseReason.PAGE_EXIT)

        assertEquals(3, result.attempted)
        assertEquals(3, result.released)
        assertTrue(result.allReleased)
        assertTrue(session.pressedKeys().isEmpty())
        assertEquals(6, transport.commands.size)
    }

    @Test
    fun failedUpRemainsTrackedSoReleaseAllCanRetry() = runBlocking {
        val transport = RecordingTransport(failUpCount = 1)
        val manager = HidKeyStateManager(FakeClock(), minimumDownIntervalMillis = 0)
        val session = manager.openSession("pc", transport)
        val key = HidKey.Keyboard(4)
        session.keyDown(key)

        val firstUp = session.keyUp(key)
        assertTrue(firstUp is ActionResult.Failure)
        assertEquals(setOf(key), session.pressedKeys())

        val retry = session.releaseAll(KeyReleaseReason.APP_BACKGROUND)
        assertTrue(retry.allReleased)
        assertTrue(session.pressedKeys().isEmpty())
    }

    @Test
    fun replacingSessionReleasesOldKeyOnOldCapturedTransport() = runBlocking {
        val manager = HidKeyStateManager(FakeClock(), minimumDownIntervalMillis = 0)
        val oldTransport = RecordingTransport()
        val newTransport = RecordingTransport()
        val oldSession = manager.openSession("old", oldTransport)
        oldSession.keyDown(HidKey.Keyboard(44))

        val newSession = manager.openSession("new", newTransport)
        val staleResult = oldSession.keyUp(HidKey.Keyboard(44))
        newSession.tap(HidKey.Keyboard(40))

        assertEquals(IgnoreReason.STALE_SESSION, (staleResult as ActionResult.Ignored).reason)
        assertEquals(
            listOf(KeyPhase.DOWN, KeyPhase.UP),
            oldTransport.commands.map { (it as RemoteCommand.Keyboard).phase },
        )
        assertEquals(
            listOf(KeyPhase.DOWN, KeyPhase.UP),
            newTransport.commands.map { (it as RemoteCommand.Keyboard).phase },
        )
    }

    @Test
    fun disconnectDiscardsStateWithoutUsingDeadTransport() = runBlocking {
        val transport = RecordingTransport()
        val manager = HidKeyStateManager(FakeClock(), minimumDownIntervalMillis = 0)
        val session = manager.openSession("pc", transport)
        session.keyDown(HidKey.Keyboard(4))

        val discarded = session.discardAfterDisconnect()
        val stale = session.keyUp(HidKey.Keyboard(4))

        assertEquals(1, discarded)
        assertEquals(IgnoreReason.STALE_SESSION, (stale as ActionResult.Ignored).reason)
        assertEquals(1, transport.commands.size)
        assertTrue(manager.currentPressedKeys().isEmpty())
    }

    @Test
    fun transportExceptionBecomesFailureAndDoesNotRecordKey() = runBlocking {
        val manager = HidKeyStateManager(FakeClock(), minimumDownIntervalMillis = 0)
        val session = manager.openSession("pc") { _, _ -> error("offline") }

        val result = session.keyDown(HidKey.Keyboard(4))

        assertEquals(FailureReason.TRANSPORT_FAILURE, (result as ActionResult.Failure).reason)
        assertTrue(session.pressedKeys().isEmpty())
    }

    private class FakeClock : MonotonicClock {
        private var now = 0L
        override fun nowMillis(): Long = now
        fun advanceBy(durationMillis: Long) {
            now += durationMillis
        }
    }

    private class RecordingTransport(
        private var failUpCount: Int = 0,
    ) : HidKeyTransport {
        val events = mutableListOf<String>()
        val commands = mutableListOf<RemoteCommand>()

        override suspend fun send(sessionId: String, command: RemoteCommand): ActionResult {
            events += "$sessionId:$command"
            commands += command
            val isUp = when (command) {
                is RemoteCommand.Keyboard -> command.phase == KeyPhase.UP
                is RemoteCommand.Consumer -> command.phase == KeyPhase.UP
                is RemoteCommand.MouseButton -> command.phase == KeyPhase.UP
                is RemoteCommand.MouseMove,
                is RemoteCommand.ModifiedScroll,
                is RemoteCommand.Scroll,
                is RemoteCommand.Internal,
                -> false
            }
            return if (isUp && failUpCount > 0) {
                failUpCount--
                ActionResult.Failure(FailureReason.TRANSPORT_FAILURE, "release failed")
            } else {
                ActionResult.Success()
            }
        }
    }
}
