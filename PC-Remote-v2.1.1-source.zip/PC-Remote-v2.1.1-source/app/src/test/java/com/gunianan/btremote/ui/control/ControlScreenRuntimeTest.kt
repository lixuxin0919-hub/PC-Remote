package com.gunianan.btremote.ui.control

import com.gunianan.btremote.domain.ControlLayout
import com.gunianan.btremote.domain.GestureType
import com.gunianan.btremote.domain.Handedness
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ControlScreenRuntimeTest {
    @Test
    fun `profile handedness overrides global and inherit resolves safely`() {
        assertEquals(Handedness.LEFT, resolveHandedness(Handedness.LEFT, Handedness.RIGHT))
        assertEquals(Handedness.RIGHT, resolveHandedness(Handedness.RIGHT, Handedness.LEFT))
        assertEquals(Handedness.LEFT, resolveHandedness(Handedness.INHERIT, Handedness.LEFT))
        assertEquals(Handedness.RIGHT, resolveHandedness(null, Handedness.RIGHT))
        assertEquals(Handedness.RIGHT, resolveHandedness(null, Handedness.INHERIT))
    }

    @Test
    fun `every layout resolves to its runtime column count`() {
        assertEquals(1, ControlLayout.SINGLE_COLUMN.resolvedGridColumns(4))
        assertEquals(2, ControlLayout.TWO_COLUMN.resolvedGridColumns(4))
        assertEquals(3, ControlLayout.THREE_COLUMN.resolvedGridColumns(1))
        assertEquals(3, ControlLayout.LARGE_GESTURE.resolvedGridColumns(1))
        assertEquals(4, ControlLayout.COMPACT_REMOTE.resolvedGridColumns(1))
        assertEquals(3, ControlLayout.FULLSCREEN_GESTURE.resolvedGridColumns(1))
        assertEquals(1, ControlLayout.CUSTOM_GRID.resolvedGridColumns(0))
        assertEquals(4, ControlLayout.CUSTOM_GRID.resolvedGridColumns(8))
    }

    @Test
    fun `compact and fullscreen layouts use intentional surface presets`() {
        assertEquals(0.36f, ControlLayout.COMPACT_REMOTE.resolvedGestureAreaHeightFraction(0.7f))
        assertEquals(0.84f, ControlLayout.FULLSCREEN_GESTURE.resolvedGestureAreaHeightFraction(0.4f))
        assertEquals(0.58f, ControlLayout.LARGE_GESTURE.resolvedGestureAreaHeightFraction(0.58f))
        assertEquals(0.30f, ControlLayout.TWO_COLUMN.resolvedGestureAreaHeightFraction(0.1f))
        assertEquals(0.95f, ControlLayout.THREE_COLUMN.resolvedGestureAreaHeightFraction(1.2f))
    }

    @Test
    fun `touchpad binding feedback uses canonical user facing labels`() {
        assertEquals("触控板轻点", GestureType.TOUCHPAD_TAP.touchpadLabel())
        assertEquals("触控板双击", GestureType.TOUCHPAD_DOUBLE_TAP.touchpadLabel())
        assertEquals("长按拖动", GestureType.TOUCHPAD_LONG_PRESS_DRAG.touchpadLabel())
        assertEquals("双指滚动", GestureType.TOUCHPAD_TWO_FINGER_SCROLL.touchpadLabel())
        assertEquals("双指右键", GestureType.TOUCHPAD_TWO_FINGER_TAP.touchpadLabel())
    }

    @Test
    fun `touchpad binding throttle dispatches leading event and bounded repeats`() {
        val throttle = TouchpadBindingThrottle(minimumIntervalMs = 180L)

        assertTrue(throttle.shouldDispatch(1_000L))
        assertFalse(throttle.shouldDispatch(1_179L))
        assertTrue(throttle.shouldDispatch(1_180L))
        assertFalse(throttle.shouldDispatch(1_200L))
        assertTrue(throttle.shouldDispatch(1_360L))
    }

    @Test
    fun `touchpad binding throttle recovers from a clock reset`() {
        val throttle = TouchpadBindingThrottle(minimumIntervalMs = 180L)

        assertTrue(throttle.shouldDispatch(10_000L))
        assertTrue(throttle.shouldDispatch(5L))
        assertFalse(throttle.shouldDispatch(100L))
    }
}
