package com.gunianan.btremote.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DefaultConfigFactoryTest {
    @Test
    fun `first launch contains protected video and trackpad system profiles`() {
        val config = DefaultConfigFactory.create(now = 1_000L)

        assertEquals(CURRENT_SCHEMA_VERSION, config.schemaVersion)
        assertEquals(SYSTEM_DEFAULT_PROFILE_ID, config.activeProfileId)
        assertEquals(SYSTEM_DEFAULT_PROFILE_ID, config.startupProfileId)
        assertEquals(2, config.profiles.size)
        with(config.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }) {
            assertEquals("默认视频模式", name)
            assertTrue(isDefault)
            assertTrue(isSystemProfile)
            assertEquals(ControlAreaType.GESTURE, controlAreaType)
            assertEquals(6, controls.size)
            assertEquals(6, gestureBindings.size)
            assertNull(gestureBindings.single { it.gestureType == GestureType.LONG_PRESS }.repeatPolicy)
        }
        with(config.profiles.single { it.id == SYSTEM_TRACKPAD_PROFILE_ID }) {
            assertEquals("触控板模式", name)
            assertFalse(isDefault)
            assertTrue(isSystemProfile)
            assertEquals(ControlAreaType.TOUCHPAD, controlAreaType)
        }
        assertTrue(ConfigValidator.validate(config).isValid)
    }

    @Test
    fun `default gesture set leaves complex presets unbound`() {
        val types = DefaultConfigFactory.create(1_000L)
            .profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }
            .gestureBindings.mapTo(hashSetOf()) { it.gestureType }

        assertFalse(GestureType.CIRCLE in types)
        assertFalse(GestureType.X in types)
        assertFalse(GestureType.Z in types)
        assertFalse(GestureType.CHECK in types)
        assertFalse(GestureType.CUSTOM in types)
    }

    @Test
    fun `validator rejects invalid action duplicate IDs and broken system flags`() {
        val base = DefaultConfigFactory.create(1_000L)
        val system = base.profiles.single { it.id == SYSTEM_DEFAULT_PROFILE_ID }
        val invalidControl = system.controls.first().copy(
            tapAction = RemoteActionConfig.KeyboardKey(0),
        )
        val invalidProfile = system.copy(
            isDefault = false,
            controls = listOf(invalidControl, invalidControl),
        )
        val result = ConfigValidator.validate(
            base.copy(profiles = listOf(invalidProfile) + base.profiles.filterNot { it.id == SYSTEM_DEFAULT_PROFILE_ID }),
        )

        assertFalse(result.isValid)
        assertTrue(result.issues.any { it.code == ValidationCode.INVALID_ACTION || it.code == ValidationCode.OUT_OF_RANGE })
        assertTrue(result.issues.any { it.code == ValidationCode.DUPLICATE_ID })
        assertTrue(result.issues.any { it.code == ValidationCode.SYSTEM_PROFILE_VIOLATION })
    }

    @Test
    fun `validator accepts every supported action family`() {
        val actions = listOf(
            RemoteActionConfig.KeyboardKey(0x2C),
            RemoteActionConfig.KeyboardShortcut(setOf(KeyboardModifier.LEFT_CONTROL), 0x06),
            RemoteActionConfig.ConsumerKey(0xE9),
            RemoteActionConfig.MouseAction(MouseCommand.CLICK, MouseButton.LEFT),
            RemoteActionConfig.MouseAction(MouseCommand.MOVE, deltaX = 10, deltaY = -3),
            RemoteActionConfig.ScrollAction(vertical = -1),
            RemoteActionConfig.ModifiedScrollAction(setOf(KeyboardModifier.LEFT_SHIFT), vertical = 1),
            RemoteActionConfig.InternalAction(InternalActionType.OPEN_SETTINGS),
            RemoteActionConfig.CustomSequence(
                listOf(
                    SequenceStep.Down(RemoteActionConfig.KeyboardKey(0x4F)),
                    SequenceStep.Delay(50),
                    SequenceStep.Up(RemoteActionConfig.KeyboardKey(0x4F)),
                    SequenceStep.Repeat(RemoteActionConfig.ConsumerKey(0xE9), 3, 100),
                ),
            ),
        )

        actions.forEach { action ->
            assertTrue("Expected valid action: $action", ConfigValidator.validateAction(action).isValid)
        }
    }

    @Test
    fun `trackpad system mode cannot be converted to a generic control page`() {
        val base = DefaultConfigFactory.create(1_000L)
        val changed = base.profiles.map { profile ->
            if (profile.id == SYSTEM_TRACKPAD_PROFILE_ID) {
                profile.copy(controlAreaType = ControlAreaType.GESTURE)
            } else {
                profile
            }
        }

        val result = ConfigValidator.validate(base.copy(profiles = changed))

        assertFalse(result.isValid)
        assertTrue(result.issues.any {
            it.code == ValidationCode.SYSTEM_PROFILE_VIOLATION && it.message.contains("专用触控板页面")
        })
    }

    @Test
    fun `validator rejects keyboard usages outside the advertised descriptor range`() {
        assertTrue(ConfigValidator.validateAction(RemoteActionConfig.KeyboardKey(0x65)).isValid)
        assertFalse(ConfigValidator.validateAction(RemoteActionConfig.KeyboardKey(0x66)).isValid)
        assertFalse(ConfigValidator.validateAction(RemoteActionConfig.KeyboardKey(0xE0)).isValid)
    }

    @Test
    fun `validator rejects actions the current transport cannot execute`() {
        val invalidActions = listOf(
            RemoteActionConfig.ConsumerKey(0x01),
            RemoteActionConfig.ScrollAction(horizontal = 1),
            RemoteActionConfig.CustomSequence(
                listOf(SequenceStep.Down(RemoteActionConfig.KeyboardKey(0x4F))),
            ),
            RemoteActionConfig.CustomSequence(
                listOf(SequenceStep.Up(RemoteActionConfig.KeyboardKey(0x4F))),
            ),
            RemoteActionConfig.CustomSequence(
                listOf(
                    SequenceStep.Repeat(
                        action = RemoteActionConfig.ConsumerKey(HidConsumerUsages.VOLUME_INCREMENT),
                        count = 300,
                        intervalMs = 30_000,
                    ),
                ),
            ),
        )

        invalidActions.forEach { action ->
            assertFalse("Expected invalid action: $action", ConfigValidator.validateAction(action).isValid)
        }
    }

    @Test
    fun `gesture repeat policy is rejected until live hold callbacks are supported`() {
        val profile = DefaultConfigFactory.createSystemProfile(1_000L)
        val binding = profile.gestureBindings.first().copy(repeatPolicy = RepeatPolicy())

        val result = ConfigValidator.validateProfile(
            profile.copy(gestureBindings = listOf(binding) + profile.gestureBindings.drop(1)),
        )

        assertFalse(result.isValid)
        assertTrue(result.issues.any { it.path.endsWith("repeatPolicy") })
    }
}
