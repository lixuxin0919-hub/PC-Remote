package com.gunianan.btremote.bluetooth;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/** Self-contained JVM tests; run with javac/java and no external test dependency. */
public final class HidReportSenderTest {
    private int passed;

    public static void main(String[] args) throws Exception {
        HidReportSenderTest tests = new HidReportSenderTest();
        tests.reportBuildersMatchDescriptorAndDefendCopies();
        tests.transactionsAreSerializedOffCallerThread();
        tests.pressFailureDoesNotEmitRelease();
        tests.replacementSessionKeepsOldReleaseOnOldTransport();
        tests.closeInterruptsDelayButStillReleasesAndCancelsQueue();
        tests.rawFramesSupportPhasesAndPointerReports();
        tests.boundedQueueRejectsExcessInputWithoutBlockingCaller();
        System.out.println("HidReportSenderTest: " + tests.passed + " tests passed");
    }

    private void reportBuildersMatchDescriptorAndDefendCopies() {
        HidReportSender.Report keyboard = HidReportSender.Report.keyboard(0x02, 0x2C);
        assertEquals(HidReportSender.REPORT_ID_KEYBOARD, keyboard.getReportId(), "keyboard id");
        assertArrayEquals(new byte[] {2, 0, 0x2C, 0, 0, 0, 0, 0}, keyboard.getPressedPayload(), "keyboard press");
        assertArrayEquals(new byte[8], keyboard.getReleasedPayload(), "keyboard release");

        HidReportSender.Report mouse = HidReportSender.Report.mouseWheel(-999);
        assertArrayEquals(new byte[] {0, 0, 0, -127}, mouse.getPressedPayload(), "mouse clamp");
        HidReportSender.Report click = HidReportSender.Report.mouseButton(0x03, 0x02);
        assertArrayEquals(new byte[] {3, 0, 0, 0}, click.getPressedPayload(), "button press preserves held state");
        assertArrayEquals(new byte[] {2, 0, 0, 0}, click.getReleasedPayload(), "button release restores held state");
        HidReportSender.Report consumer = HidReportSender.Report.consumer(HidReportSender.CONSUMER_NEXT_TRACK);
        assertArrayEquals(new byte[] {0x10}, consumer.getPressedPayload(), "consumer bit");

        byte[] pressed = {7};
        HidReportSender.Report generic = HidReportSender.Report.of(9, pressed, new byte[] {0});
        pressed[0] = 99;
        byte[] exposed = generic.getPressedPayload();
        exposed[0] = 88;
        assertArrayEquals(new byte[] {7}, generic.getPressedPayload(), "defensive copies");
        assertThrows(IllegalArgumentException.class, () -> HidReportSender.Report.of(1, new byte[] {1}, new byte[] {0, 0}));
        pass();
    }

    private void transactionsAreSerializedOffCallerThread() throws Exception {
        List<String> events = Collections.synchronizedList(new ArrayList<>());
        String callerThread = Thread.currentThread().getName();
        AtomicLong clock = new AtomicLong(10L);
        HidReportSender sender = new HidReportSender(
                5L,
                millis -> events.add("sleep:" + Thread.currentThread().getName()),
                clock::getAndIncrement);
        try {
            sender.openSession((reportId, payload) -> {
                events.add(reportId + ":" + Arrays.toString(payload) + ":" + Thread.currentThread().getName());
                return true;
            });
            CompletableFuture<HidReportSender.SendResult> first = sender.submit(HidReportSender.Report.keyboard(0x2C));
            CompletableFuture<HidReportSender.SendResult> second = sender.submit(
                    HidReportSender.Report.consumer(HidReportSender.CONSUMER_NEXT_TRACK));

            assertEquals(HidReportSender.Status.COMPLETED, await(first).getStatus(), "first status");
            assertEquals(HidReportSender.Status.COMPLETED, await(second).getStatus(), "second status");
            assertEquals(6, events.size(), "event count");
            assertTrue(events.get(0).startsWith("1:[0, 0, 44"), "first press first");
            assertTrue(events.get(1).startsWith("sleep:"), "first hold before release");
            assertTrue(events.get(2).startsWith("1:[0, 0, 0"), "first release before next press");
            assertTrue(events.get(3).startsWith("3:[16]"), "second press after first release");
            for (String event : events) {
                assertFalse(event.endsWith(":" + callerThread), "work must not run on caller thread: " + event);
            }
        } finally {
            sender.close();
        }
        pass();
    }

    private void pressFailureDoesNotEmitRelease() throws Exception {
        AtomicLong calls = new AtomicLong();
        HidReportSender sender = new HidReportSender(0L, millis -> {}, System::currentTimeMillis);
        try {
            sender.openSession((id, payload) -> {
                calls.incrementAndGet();
                return false;
            });
            HidReportSender.SendResult result = await(sender.submit(HidReportSender.Report.consumer(1)));
            assertEquals(HidReportSender.Status.PRESS_FAILED, result.getStatus(), "press failure status");
            assertFalse(result.wasReleaseAttempted(), "release skipped when press rejected");
            assertEquals(1L, calls.get(), "single transport call");
        } finally {
            sender.close();
        }
        pass();
    }

    private void replacementSessionKeepsOldReleaseOnOldTransport() throws Exception {
        CountDownLatch sleeping = new CountDownLatch(1);
        CountDownLatch continueSleep = new CountDownLatch(1);
        List<String> oldCalls = Collections.synchronizedList(new ArrayList<>());
        List<String> newCalls = Collections.synchronizedList(new ArrayList<>());
        HidReportSender sender = new HidReportSender(
                10L,
                millis -> {
                    sleeping.countDown();
                    continueSleep.await();
                },
                System::currentTimeMillis);
        try {
            HidReportSender.Session oldSession = sender.openSession(recordingTransport(oldCalls));
            CompletableFuture<HidReportSender.SendResult> oldReport = oldSession.submit(HidReportSender.Report.consumer(0x10));
            assertTrue(sleeping.await(1, TimeUnit.SECONDS), "old report reached hold");

            sender.openSession(recordingTransport(newCalls));
            assertEquals(
                    HidReportSender.Status.STALE_SESSION,
                    await(oldSession.submit(HidReportSender.Report.consumer(0x20))).getStatus(),
                    "old handle rejected");
            CompletableFuture<HidReportSender.SendResult> newReport = sender.submit(HidReportSender.Report.consumer(0x20));
            continueSleep.countDown();

            assertEquals(HidReportSender.Status.COMPLETED, await(oldReport).getStatus(), "old completes release");
            assertEquals(HidReportSender.Status.COMPLETED, await(newReport).getStatus(), "new completes");
            assertEquals(Arrays.asList("3:[16]", "3:[0]"), oldCalls, "old release transport");
            assertEquals(Arrays.asList("3:[32]", "3:[0]"), newCalls, "new transaction transport");
        } finally {
            continueSleep.countDown();
            sender.close();
        }
        pass();
    }

    private void closeInterruptsDelayButStillReleasesAndCancelsQueue() throws Exception {
        CountDownLatch sleeping = new CountDownLatch(1);
        List<String> calls = Collections.synchronizedList(new ArrayList<>());
        HidReportSender sender = new HidReportSender(
                1000L,
                millis -> {
                    sleeping.countDown();
                    new CountDownLatch(1).await();
                },
                System::currentTimeMillis);
        sender.openSession(recordingTransport(calls));
        CompletableFuture<HidReportSender.SendResult> running = sender.submit(HidReportSender.Report.consumer(1));
        CompletableFuture<HidReportSender.SendResult> queued = sender.submit(HidReportSender.Report.consumer(2));
        assertTrue(sleeping.await(1, TimeUnit.SECONDS), "running transaction reached hold");

        sender.close();

        HidReportSender.SendResult runningResult = await(running);
        assertEquals(HidReportSender.Status.DELAY_INTERRUPTED, runningResult.getStatus(), "close interruption status");
        assertTrue(runningResult.wasReleaseAttempted(), "close still releases pressed usage");
        assertEquals(HidReportSender.Status.CLOSED, await(queued).getStatus(), "queued work cancelled");
        assertEquals(Arrays.asList("3:[1]", "3:[0]"), calls, "only running transaction emitted");
        assertThrows(IllegalStateException.class, () -> sender.openSession(recordingTransport(new ArrayList<>())));
        pass();
    }

    private void rawFramesSupportPhasesAndPointerReports() throws Exception {
        HidReportSender.Frame keyboardUp = HidReportSender.Frame.keyboard(0, 0);
        assertEquals(HidReportSender.REPORT_ID_KEYBOARD, keyboardUp.getReportId(), "raw keyboard id");
        assertArrayEquals(new byte[8], keyboardUp.getPayload(), "raw keyboard release");
        HidReportSender.Frame pointer = HidReportSender.Frame.mouse(0x03, 999, -999, 7);
        assertArrayEquals(new byte[] {3, 127, -127, 7}, pointer.getPayload(), "raw pointer clamp");
        assertThrows(
                IllegalArgumentException.class,
                () -> HidReportSender.Frame.of(HidReportSender.REPORT_ID_MOUSE, new byte[] {0}));

        List<String> calls = Collections.synchronizedList(new ArrayList<>());
        HidReportSender sender = new HidReportSender(0L, millis -> {}, System::currentTimeMillis);
        try {
            HidReportSender.Session session = sender.openSession(recordingTransport(calls));
            HidReportSender.SendResult result = await(session.submitFrame(pointer));
            assertEquals(HidReportSender.Status.COMPLETED, result.getStatus(), "raw frame status");
            assertFalse(result.wasReleaseAttempted(), "raw frame has no synthetic release");
            assertEquals(Collections.singletonList("2:[3, 127, -127, 7]"), calls, "one raw frame");
        } finally {
            sender.close();
        }
        pass();
    }

    private void boundedQueueRejectsExcessInputWithoutBlockingCaller() throws Exception {
        CountDownLatch sleeping = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        HidReportSender sender = new HidReportSender(
                10L,
                millis -> {
                    sleeping.countDown();
                    release.await();
                },
                System::currentTimeMillis,
                1);
        try {
            sender.openSession((id, payload) -> true);
            CompletableFuture<HidReportSender.SendResult> running = sender.submit(
                    HidReportSender.Report.consumer(1));
            assertTrue(sleeping.await(1, TimeUnit.SECONDS), "worker occupied by first transaction");
            CompletableFuture<HidReportSender.SendResult> queued = sender.submitFrame(
                    HidReportSender.Frame.mouse(0, 1, 0, 0));
            HidReportSender.SendResult rejected = await(sender.submitFrame(
                    HidReportSender.Frame.mouse(0, 2, 0, 0)));
            assertEquals(HidReportSender.Status.QUEUE_FULL, rejected.getStatus(), "excess input rejected");
            release.countDown();
            assertEquals(HidReportSender.Status.COMPLETED, await(running).getStatus(), "running report completes");
            assertEquals(HidReportSender.Status.COMPLETED, await(queued).getStatus(), "admitted raw frame completes");
        } finally {
            release.countDown();
            sender.close();
        }
        pass();
    }

    private static HidReportSender.Transport recordingTransport(List<String> calls) {
        return (reportId, payload) -> {
            calls.add(reportId + ":" + Arrays.toString(payload));
            return true;
        };
    }

    private static HidReportSender.SendResult await(CompletableFuture<HidReportSender.SendResult> future) throws Exception {
        return future.get(2, TimeUnit.SECONDS);
    }

    private void pass() {
        passed++;
    }

    private static void assertTrue(boolean value, String message) {
        if (!value) {
            throw new AssertionError(message);
        }
    }

    private static void assertFalse(boolean value, String message) {
        assertTrue(!value, message);
    }

    private static void assertEquals(Object expected, Object actual, String message) {
        if (!expected.equals(actual)) {
            throw new AssertionError(message + " expected=" + expected + " actual=" + actual);
        }
    }

    private static void assertArrayEquals(byte[] expected, byte[] actual, String message) {
        if (!Arrays.equals(expected, actual)) {
            throw new AssertionError(message + " expected=" + Arrays.toString(expected) + " actual=" + Arrays.toString(actual));
        }
    }

    private static void assertThrows(Class<? extends Throwable> type, ThrowingRunnable action) {
        try {
            action.run();
        } catch (Throwable error) {
            if (type.isInstance(error)) {
                return;
            }
            throw new AssertionError("expected " + type.getSimpleName() + " but got " + error, error);
        }
        throw new AssertionError("expected " + type.getSimpleName());
    }

    @FunctionalInterface
    private interface ThrowingRunnable {
        void run() throws Exception;
    }
}
