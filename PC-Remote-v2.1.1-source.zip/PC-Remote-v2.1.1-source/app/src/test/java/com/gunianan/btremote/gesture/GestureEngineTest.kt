package com.gunianan.btremote.gesture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class GestureEngineTest {
    @Test
    fun swipeUpIsRecognizedByRule() {
        assertRuleGesture("swipe_up", line(100f, 260f, 100f, 30f))
    }

    @Test
    fun swipeDownIsRecognizedByRule() {
        assertRuleGesture("swipe_down", line(100f, 30f, 100f, 260f))
    }

    @Test
    fun swipeLeftIsRecognizedByRule() {
        assertRuleGesture("swipe_left", line(260f, 100f, 30f, 100f))
    }

    @Test
    fun swipeRightIsRecognizedByRule() {
        assertRuleGesture("swipe_right", line(30f, 100f, 260f, 100f))
    }

    @Test
    fun shortStationaryStrokeIsTap() {
        val match = GestureEngine().recognize(
            listOf(
                PointSample(100f, 100f, 0L),
                PointSample(102f, 101f, 90L),
            ),
        )

        assertNotNull(match)
        assertEquals("tap", match?.gestureId)
        assertEquals(RecognitionSource.RULE, match?.source)
    }

    @Test
    fun twoCompactStrokesAreDoubleTap() {
        val first = listOf(
            PointSample(100f, 100f, 0L),
            PointSample(101f, 100f, 60L),
        )
        val second = listOf(
            PointSample(103f, 101f, 190L),
            PointSample(104f, 101f, 245L),
        )

        val result = GestureEngine().recognizeSequence(listOf(first, second))

        assertTrue(result.isSuccess)
        assertEquals("double_tap", result.match?.gestureId)
    }

    @Test
    fun stationaryStrokeOverHalfSecondIsLongPress() {
        val match = GestureEngine().recognize(
            listOf(
                PointSample(100f, 100f, 0L),
                PointSample(102f, 101f, 620L),
            ),
        )

        assertEquals("long_press", match?.gestureId)
    }

    @Test
    fun circleIsRecognizedAfterScaleAndTranslation() {
        val candidate = transform(DefaultGestureTemplates.circle().points, scale = 0.73f, dx = 420f, dy = -37f)
        assertTemplateGesture("circle", candidate)
    }

    @Test
    fun xIsRecognized() {
        assertTemplateGesture("x", transform(DefaultGestureTemplates.xShape().points, 1.12f, -22f, 16f))
    }

    @Test
    fun zIsRecognized() {
        assertTemplateGesture("z", transform(DefaultGestureTemplates.zShape().points, 0.86f, 75f, 90f))
    }

    @Test
    fun checkIsRecognizedInsteadOfDirectionalSwipe() {
        val result = GestureEngine().recognizeDetailed(DefaultGestureTemplates.checkShape().points)

        assertTrue(result.failure?.message.orEmpty(), result.isSuccess)
        assertEquals("check", result.match?.gestureId)
        assertEquals(RecognitionSource.TEMPLATE, result.match?.source)
    }

    @Test
    fun unrelatedTriangleFailsHighConfidenceThreshold() {
        val engine = GestureEngine(
            templates = listOf(DefaultGestureTemplates.circle()),
            config = GestureEngineConfig(templateConfidenceThreshold = 0.96f),
        )
        val triangle = DefaultGestureTemplates.interpolate(
            listOf(30f to 240f, 150f to 25f, 270f to 240f, 30f to 240f),
        )

        val result = engine.recognizeDetailed(triangle)

        assertFalse(result.isSuccess)
        assertEquals(RecognitionFailureReason.LOW_CONFIDENCE, result.failure?.reason)
        assertTrue(result.candidates.isNotEmpty())
    }

    @Test
    fun nonTapTrajectoryBelowMinimumLengthFailsAsTooShort() {
        val result = GestureEngine().recognizeDetailed(
            listOf(
                PointSample(0f, 0f, 0L),
                PointSample(25f, 0f, 350L),
            ),
        )

        assertFalse(result.isSuccess)
        assertEquals(RecognitionFailureReason.TOO_SHORT, result.failure?.reason)
    }

    @Test
    fun trajectoryOverMaximumDurationFailsWithoutExecuting() {
        val points = DefaultGestureTemplates.circle().points.mapIndexed { index, point ->
            point.copy(timeMillis = index * 60L)
        }

        val result = GestureEngine().recognizeDetailed(points)

        assertFalse(result.isSuccess)
        assertEquals(RecognitionFailureReason.TOO_LONG, result.failure?.reason)
    }

    @Test
    fun customRotationInvariantTemplateUsesMultipleRecordings() {
        val first = trianglePoints(rotationRadians = 0.0)
        val second = trianglePoints(rotationRadians = 0.18)
        val custom = GestureTemplate(
            id = "custom_triangle",
            displayName = "自定义三角形",
            points = first,
            rotationInvariant = true,
            additionalSamples = listOf(second),
        )
        val engine = GestureEngine(templates = listOf(custom))
        val rotatedCandidate = trianglePoints(rotationRadians = PI / 2.0)

        val result = engine.recognizeDetailed(rotatedCandidate)

        assertTrue(result.failure?.message.orEmpty(), result.isSuccess)
        assertEquals("custom_triangle", result.match?.gestureId)
        assertTrue(result.candidates.first().sampleIndex in 0..1)
    }

    @Test
    fun similarNewRecordingIsReportedAsConflict() {
        val engine = GestureEngine()
        val proposed = GestureTemplate(
            id = "custom_round",
            displayName = "我的圆",
            points = transform(DefaultGestureTemplates.circle().points, 0.82f, 50f, -20f),
            rotationInvariant = true,
        )

        val conflicts = engine.findConflicts(proposed, threshold = 0.85f)

        assertTrue(conflicts.any { it.existingGestureId == "circle" && it.similarity >= 0.85f })
    }

    @Test
    fun equallySimilarTemplatesReturnAmbiguousFailure() {
        val points = trianglePoints(0.0)
        val engine = GestureEngine(
            templates = listOf(
                GestureTemplate("triangle_a", "三角 A", points, rotationInvariant = true),
                GestureTemplate("triangle_b", "三角 B", points, rotationInvariant = true),
            ),
        )

        val result = engine.recognizeDetailed(transform(points, 1.1f, 20f, 30f))

        assertFalse(result.isSuccess)
        assertEquals(RecognitionFailureReason.AMBIGUOUS, result.failure?.reason)
        assertEquals(2, result.candidates.size)
    }

    @Test
    fun invalidTimestampOrderIsRejected() {
        val result = GestureEngine().recognizeDetailed(
            listOf(
                PointSample(0f, 0f, 100L),
                PointSample(100f, 0f, 90L),
            ),
        )

        assertEquals(RecognitionFailureReason.INVALID_TIMESTAMPS, result.failure?.reason)
    }

    @Test
    fun unrelatedMultipleStrokesNeverFallThroughToSymbolTemplate() {
        val strokes = listOf(
            line(30f, 30f, 35f, 35f, count = 3).map { it.copy(timeMillis = it.timeMillis) },
            line(120f, 40f, 125f, 45f, count = 3).map { it.copy(timeMillis = it.timeMillis + 200L) },
            line(200f, 100f, 205f, 105f, count = 3).map { it.copy(timeMillis = it.timeMillis + 400L) },
        )

        val result = GestureEngine().recognizeSequence(strokes)

        assertFalse(result.isSuccess)
        assertEquals(RecognitionFailureReason.NO_MATCH, result.failure?.reason)
    }

    private fun assertRuleGesture(expectedId: String, points: List<PointSample>) {
        val match = GestureEngine().recognize(points)
        assertNotNull(match)
        assertEquals(expectedId, match?.gestureId)
        assertEquals(RecognitionSource.RULE, match?.source)
    }

    private fun assertTemplateGesture(expectedId: String, points: List<PointSample>) {
        val result = GestureEngine().recognizeDetailed(points)
        assertTrue(result.failure?.message.orEmpty(), result.isSuccess)
        assertEquals(expectedId, result.match?.gestureId)
        assertEquals(RecognitionSource.TEMPLATE, result.match?.source)
    }

    private fun line(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        count: Int = 24,
    ): List<PointSample> = (0 until count).map { index ->
        val ratio = index.toFloat() / (count - 1)
        PointSample(
            x = startX + (endX - startX) * ratio,
            y = startY + (endY - startY) * ratio,
            timeMillis = index * 16L,
        )
    }

    private fun transform(
        points: List<PointSample>,
        scale: Float,
        dx: Float,
        dy: Float,
    ): List<PointSample> = points.map { point ->
        point.copy(x = point.x * scale + dx, y = point.y * scale + dy)
    }

    private fun trianglePoints(rotationRadians: Double): List<PointSample> {
        val raw = DefaultGestureTemplates.interpolate(
            listOf(150f to 25f, 275f to 250f, 25f to 250f, 150f to 25f),
        )
        val centerX = 150f
        val centerY = 150f
        val cosine = cos(rotationRadians)
        val sine = sin(rotationRadians)
        return raw.map { point ->
            val x = point.x - centerX
            val y = point.y - centerY
            point.copy(
                x = (x * cosine - y * sine + centerX).toFloat(),
                y = (x * sine + y * cosine + centerY).toFloat(),
            )
        }
    }
}
