package com.gunianan.btremote.action

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class OrderedLongPressDispatcherTest {
    @Test
    fun releaseAtActivationBoundaryCannotOvertakeDown() = runTest {
        val allowDown = CompletableDeferred<Unit>()
        val events = mutableListOf<String>()
        val dispatcher = dispatcher()

        dispatcher.start {
            allowDown.await()
            events += "down"
        }
        dispatcher.stop { events += "up" }
        runCurrent()
        assertTrue(events.isEmpty())

        allowDown.complete(Unit)
        advanceUntilIdle()

        assertEquals(listOf("down", "up"), events)
    }

    @Test
    fun newPressWaitsForPreviousReleaseBarrier() = runTest {
        val allowRelease = CompletableDeferred<Unit>()
        val events = mutableListOf<String>()
        val dispatcher = dispatcher()

        dispatcher.start { events += "down-1" }
        dispatcher.stop {
            allowRelease.await()
            events += "up-1"
        }
        dispatcher.start { events += "down-2" }
        runCurrent()

        assertEquals(listOf("down-1"), events)
        allowRelease.complete(Unit)
        advanceUntilIdle()
        assertEquals(listOf("down-1", "up-1", "down-2"), events)
    }

    @Test
    fun repeatCallbacksAreConflatedWhileTransportIsSlow() = runTest {
        val allowRepeat = CompletableDeferred<Unit>()
        var repeatCount = 0
        val dispatcher = dispatcher()
        dispatcher.start { }

        assertTrue(dispatcher.repeat {
            allowRepeat.await()
            repeatCount++
        })
        assertFalse(dispatcher.repeat { repeatCount++ })
        assertFalse(dispatcher.repeat { repeatCount++ })

        allowRepeat.complete(Unit)
        advanceUntilIdle()
        assertEquals(1, repeatCount)
    }

    private fun kotlinx.coroutines.test.TestScope.dispatcher() = OrderedLongPressDispatcher(
        launchAction = { block -> launch { block() } },
        launchRelease = { block -> launch { block() } },
    )
}
