package com.gunianan.btremote.trackpad.pressure

import com.gunianan.btremote.trackpad.input.TrackpadPointerSample
import com.gunianan.btremote.trackpad.settings.TrackpadSettings
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdaptivePressureEngineTest {
    @Test
    fun `flat pressure degrades to contact area without claiming reliable pressure`() {
        val engine = AdaptivePressureEngine()
        var reading = engine.evaluate(sample(0.5f, 4f), 0L, TrackpadSettings())
        repeat(10) { index ->
            reading = engine.evaluate(sample(0.5f, 8f + index), 120L + index * 40L, TrackpadSettings())
        }
        assertFalse(reading.reliable)
        assertTrue(reading.score > 0f)
    }

    @Test
    fun `varying pressure becomes reliable and filtering stays bounded`() {
        val engine = AdaptivePressureEngine()
        var previous = 0f
        var reading: PressureReading? = null
        repeat(18) { index ->
            reading = engine.evaluate(sample(0.1f + index * 0.04f, 9f), index * 20L, TrackpadSettings())
            assertTrue(kotlin.math.abs(requireNotNull(reading).score - previous) <= 0.29f)
            previous = requireNotNull(reading).score
        }
        assertTrue(requireNotNull(reading).reliable)
    }

    @Test
    fun `calibration rejects too few samples and persists useful ranges`() {
        assertTrue(PressureCalibrator.calibrate(PressureCalibrationSamples(emptyList(), emptyList(), emptyList()), 1L) == null)
        val light = List(10) { sample(0.1f + it * 0.002f, 5f) }
        val normal = List(10) { sample(0.45f + it * 0.003f, 9f) }
        val force = List(10) { sample(0.82f + it * 0.003f, 14f) }
        val profile = PressureCalibrator.calibrate(PressureCalibrationSamples(light, normal, force), 99L)

        assertNotNull(profile)
        assertTrue(requireNotNull(profile).pressureReliable)
        assertTrue(profile.pressureMaximum > profile.pressureMinimum)
        assertTrue(profile.contactAreaMaximum > profile.contactAreaMinimum)
    }

    private fun sample(pressure: Float, major: Float) =
        TrackpadPointerSample(0, 0f, 0f, pressure, 0.2f, major, major * 0.8f)
}
