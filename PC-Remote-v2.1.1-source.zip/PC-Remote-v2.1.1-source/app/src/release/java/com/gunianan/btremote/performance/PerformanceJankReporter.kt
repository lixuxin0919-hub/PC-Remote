package com.gunianan.btremote.performance

import android.view.Window

/** Release builds contain no detailed frame telemetry. */
object PerformanceJankReporter {
    fun start(window: Window) = Unit
    fun setState(key: String, value: String) = Unit
    fun resume() = Unit
    fun pause() = Unit
    fun stop() = Unit
    fun summary(): String = "disabled"
}
