package com.gunianan.btremote.data

import com.gunianan.btremote.domain.AppConfig
import com.gunianan.btremote.domain.CURRENT_SCHEMA_VERSION
import com.gunianan.btremote.domain.ConfigValidationException
import com.gunianan.btremote.domain.ConfigValidator
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.ProfileExportEnvelope
import kotlinx.serialization.SerializationException
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject

class ConfigFormatException(message: String, cause: Throwable? = null) : IllegalArgumentException(message, cause)

class UnsupportedConfigVersionException(val foundVersion: Int?) : IllegalArgumentException(
    "不支持的配置版本：${foundVersion ?: "缺失"}，当前仅支持 $CURRENT_SCHEMA_VERSION",
)

/** Strict typed codec. Unknown future fields are ignored, while types and business rules remain strict. */
object ConfigJsonCodec {
    const val MAX_JSON_CHARS: Int = 2_000_000

    val json: Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        explicitNulls = false
        isLenient = false
        coerceInputValues = false
        allowSpecialFloatingPointValues = false
        classDiscriminator = "type"
    }

    fun encodeConfig(config: AppConfig): String {
        ConfigValidator.validate(config).requireValid()
        return requireWithinSizeLimit(json.encodeToString(config))
    }

    fun decodeConfig(raw: String): AppConfig {
        val root = parseRoot(raw)
        val version = requireSupportedSchemaVersion(root)
        val decoded = decodeTyped<AppConfig>(raw)
        require(decoded.schemaVersion == version) { "配置版本字段不一致" }
        return ConfigMigrator.migrate(decoded).also { ConfigValidator.validate(it).requireValid() }
    }

    fun exportProfile(profile: ControlProfile, iconDataBase64: String? = null): String {
        ConfigValidator.validateProfile(profile).requireValid()
        val portable = profile.copy(customIconPath = null)
        return requireWithinSizeLimit(json.encodeToString(ProfileExportEnvelope(profile = portable, iconDataBase64 = iconDataBase64)))
    }

    fun decodeProfileExport(raw: String): ProfileExportEnvelope {
        val root = parseRoot(raw)
        requireSupportedSchemaVersion(root)
        if (root["profile"] !is JsonObject) {
            throw ConfigFormatException("profile 必须是 JSON 对象")
        }
        return decodeTyped<ProfileExportEnvelope>(raw).also {
            ConfigValidator.validateProfile(it.profile).requireValid()
        }
    }

    private fun parseRoot(raw: String): JsonObject {
        if (raw.isBlank()) throw ConfigFormatException("配置 JSON 不能为空")
        requireWithinSizeLimit(raw)
        return try {
            json.parseToJsonElement(raw).jsonObject
        } catch (error: SerializationException) {
            throw ConfigFormatException("配置必须是合法的 JSON 对象", error)
        } catch (error: IllegalArgumentException) {
            throw ConfigFormatException("配置必须是合法的 JSON 对象", error)
        }
    }

    private fun requireWithinSizeLimit(raw: String): String {
        if (raw.length > MAX_JSON_CHARS) {
            throw ConfigFormatException("配置 JSON 超过 ${MAX_JSON_CHARS / 1_000_000} MB 限制")
        }
        return raw
    }

    private fun requireSupportedSchemaVersion(root: JsonObject): Int {
        val primitive = root["schemaVersion"] as? JsonPrimitive
        val version = primitive?.intOrNull
        if (version == null || version !in ConfigMigrator.OLDEST_SUPPORTED_SCHEMA_VERSION..CURRENT_SCHEMA_VERSION) {
            throw UnsupportedConfigVersionException(version)
        }
        return version
    }

    private inline fun <reified T> decodeTyped(raw: String): T = try {
        json.decodeFromString(raw)
    } catch (error: ConfigValidationException) {
        throw error
    } catch (error: SerializationException) {
        throw ConfigFormatException("配置结构或字段类型无效", error)
    } catch (error: IllegalArgumentException) {
        throw ConfigFormatException("配置结构或字段类型无效", error)
    }
}
