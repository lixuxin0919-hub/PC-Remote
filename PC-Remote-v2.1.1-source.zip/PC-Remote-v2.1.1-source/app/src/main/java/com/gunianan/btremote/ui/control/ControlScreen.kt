package com.gunianan.btremote.ui.control

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gunianan.btremote.R
import com.gunianan.btremote.domain.ControlAreaType
import com.gunianan.btremote.domain.ControlItem
import com.gunianan.btremote.domain.ControlItemSize
import com.gunianan.btremote.domain.ControlLayout
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.GesturePoint
import com.gunianan.btremote.domain.GestureSample
import com.gunianan.btremote.domain.GestureType
import com.gunianan.btremote.domain.GlobalSettings
import com.gunianan.btremote.domain.Handedness
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.gesture.DefaultGestureTemplates
import com.gunianan.btremote.gesture.GestureEngine
import com.gunianan.btremote.gesture.GestureEngineConfig
import com.gunianan.btremote.gesture.GestureRecognition
import com.gunianan.btremote.gesture.GestureTemplate
import com.gunianan.btremote.gesture.PointSample
import com.gunianan.btremote.ui.components.AssetIcon
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.GlassPill
import com.gunianan.btremote.ui.components.SectionHeading
import com.gunianan.btremote.ui.control.surface.GestureSurface
import com.gunianan.btremote.ui.control.surface.HybridSurface
import com.gunianan.btremote.ui.control.surface.TouchpadCallbacks
import com.gunianan.btremote.ui.control.surface.TouchpadSurface
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

data class ControlScreenCallbacks(
    val onOpenDevices: () -> Unit,
    val onTapControl: (String) -> Unit,
    val onDoubleTapControl: (String) -> Unit,
    val onBeginLongPress: (String) -> Unit,
    val onEndLongPress: (controlId: String, invokeTapWhenShort: Boolean) -> Boolean,
    val onGesture: (GestureType, Float, String?, String) -> Unit,
    val onGestureFailure: (String, Float) -> Unit,
    val onGestureStarted: () -> Unit,
    val onMovePointer: (Int, Int) -> Unit,
    val onClickPointer: (MouseButton) -> Unit,
    val onSetPointerButton: (MouseButton, Boolean) -> Unit,
    val onScrollPointer: (Int, Int) -> Unit,
)

@Composable
@OptIn(ExperimentalLayoutApi::class)
fun ControlScreen(
    profile: ControlProfile,
    globalSettings: GlobalSettings,
    gesturePanelState: GesturePanelState,
    callbacks: ControlScreenCallbacks,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(start = 20.dp, top = 154.dp, end = 20.dp, bottom = 132.dp),
) {
    val appearance = profile.appearance
    val layout = appearance?.layout ?: ControlLayout.LARGE_GESTURE
    val effectiveHandedness = resolveHandedness(appearance?.handedness, globalSettings.handedness)
    val quickControlColumns = layout.resolvedGridColumns(appearance?.gridColumns ?: 3)
    val sensitivity = (appearance?.gestureSensitivity ?: globalSettings.gestureSensitivity)
        .coerceIn(0.45f, 2.5f)
    val confidenceThreshold = (appearance?.confidenceThreshold ?: globalSettings.confidenceThreshold)
        .coerceIn(0.45f, 0.98f)
    val gestureEngine = remember(profile.id, profile.updatedAt, confidenceThreshold) {
        GestureEngine(
            templates = DefaultGestureTemplates.create() + profile.customGestures.mapNotNull { template ->
                template.toRuntimeTemplate()
            },
            config = GestureEngineConfig(templateConfidenceThreshold = confidenceThreshold),
        )
    }
    val controlsBySection = remember(profile.id, profile.updatedAt, profile.controls) {
        val visible = profile.controls.filter(ControlItem::visible).sortedBy(ControlItem::position)
        ControlSections(
            volume = visible.filter { it.icon in VolumeIconTokens },
            video = visible.filter { it.icon in VideoIconTokens },
            other = visible.filterNot { it.icon in VolumeIconTokens || it.icon in VideoIconTokens },
        )
    }
    val volumeControls = controlsBySection.volume
    val videoControls = controlsBySection.video
    val otherControls = controlsBySection.other
    val denseMediaDashboard = videoControls.isNotEmpty() && volumeControls.isNotEmpty() && otherControls.isEmpty()

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val surfaceHeightFraction = layout.resolvedGestureAreaHeightFraction(
            appearance?.gestureAreaHeightFraction ?: 0.58f,
        )
        val minimumSurfaceHeight = when {
            denseMediaDashboard -> if (maxHeight < 760.dp) 136.dp else 156.dp
            layout == ControlLayout.COMPACT_REMOTE -> 220.dp
            else -> 250.dp
        }
        val maximumSurfaceHeight = when (layout) {
            ControlLayout.COMPACT_REMOTE -> if (maxWidth > maxHeight) 300.dp else 400.dp
            ControlLayout.FULLSCREEN_GESTURE -> (maxHeight - 24.dp).coerceAtLeast(minimumSurfaceHeight)
            else -> if (maxWidth > maxHeight) 400.dp else 620.dp
        }
        val surfaceHeight = if (denseMediaDashboard && maxWidth <= maxHeight) {
            when {
                maxHeight < 760.dp -> 136.dp
                maxHeight < 860.dp -> 156.dp
                else -> 190.dp
            }
        } else {
            (maxHeight * surfaceHeightFraction)
                .coerceIn(minimumSurfaceHeight, maximumSurfaceHeight.coerceAtLeast(minimumSurfaceHeight))
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            verticalArrangement = Arrangement.spacedBy(if (denseMediaDashboard) 10.dp else 14.dp),
        ) {
            item(key = "control-title") {
                ControlPageTitle(profile, Alignment.Start)
            }

            item(key = "control-surface") {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(6.dp),
                    cornerRadius = 34.dp,
                ) {
                    ControlArea(
                        profile = profile,
                        gestureEngine = gestureEngine,
                        sensitivity = sensitivity,
                        hybridEnabled = globalSettings.hybridModeEnabled,
                        showGestureTrail = globalSettings.showGestureTrail,
                        panelState = gesturePanelState,
                        callbacks = callbacks,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(surfaceHeight),
                    )
                }
            }

            if (videoControls.isNotEmpty()) {
                item(key = "video-shortcuts") {
                    MediaSectionHeading("快捷调整视频", "切换上一条、播放暂停或下一条", denseMediaDashboard)
                    Spacer(Modifier.height(if (denseMediaDashboard) 6.dp else 9.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        videoControls.take(3).forEach { control ->
                            ConfiguredControlButton(
                                control = control,
                                callbacks = callbacks,
                                modifier = Modifier.weight(1f),
                                compact = true,
                                localizeText = profile.isSystemProfile,
                            )
                        }
                    }
                }
            }

            if (volumeControls.isNotEmpty()) {
                item(key = "volume") {
                    MediaSectionHeading("音量", "减小与增加支持长按连续发送", denseMediaDashboard)
                    Spacer(Modifier.height(if (denseMediaDashboard) 6.dp else 9.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        volumeControls.take(3).forEach { control ->
                            ConfiguredControlButton(
                                control = control,
                                callbacks = callbacks,
                                modifier = Modifier.weight(1f),
                                compact = true,
                                localizeText = profile.isSystemProfile,
                            )
                        }
                    }
                }
            }

            if (otherControls.isNotEmpty()) {
                item(key = "custom-controls") {
                    SectionHeading("快捷控件", subtitle = "所有动作均由当前模式配置驱动")
                    Spacer(Modifier.height(9.dp))
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val gap = 10.dp
                        val availableWidth = (maxWidth - gap * (quickControlColumns - 1).toFloat())
                            .coerceAtLeast(0.dp)
                        val baseWidth = availableWidth / quickControlColumns.toFloat()
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(
                                space = gap,
                                alignment = if (effectiveHandedness == Handedness.LEFT) {
                                    Alignment.Start
                                } else {
                                    Alignment.End
                                },
                            ),
                            verticalArrangement = Arrangement.spacedBy(gap),
                            maxItemsInEachRow = quickControlColumns,
                        ) {
                            otherControls.forEach { control ->
                                val span = control.size.resolvedColumnSpan(quickControlColumns)
                                val controlWidth = baseWidth * span.toFloat() + gap * (span - 1).toFloat()
                                ConfiguredControlButton(
                                    control = control,
                                    callbacks = callbacks,
                                    modifier = Modifier.width(controlWidth),
                                    localizeText = profile.isSystemProfile,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class ControlSections(
    val volume: List<ControlItem>,
    val video: List<ControlItem>,
    val other: List<ControlItem>,
)

@Composable
private fun MediaSectionHeading(title: String, subtitle: String, compact: Boolean) {
    if (!compact) {
        SectionHeading(title, subtitle = subtitle)
        return
    }
    Column {
        Text(title, fontSize = 17.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold)
        Text(subtitle, fontSize = 12.sp, lineHeight = 16.sp, color = PcRemoteColors.Muted)
    }
}

@Composable
private fun ControlPageTitle(
    profile: ControlProfile,
    alignment: Alignment.Horizontal,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment,
    ) {
        Text("控制", style = PcRemoteTypography.ScreenTitle)
        Text(
            profile.controlAreaType.displayName(),
            style = PcRemoteTypography.Caption,
        )
    }
}

@Composable
private fun ControlArea(
    profile: ControlProfile,
    gestureEngine: GestureEngine,
    sensitivity: Float,
    hybridEnabled: Boolean,
    showGestureTrail: Boolean,
    panelState: GesturePanelState,
    callbacks: ControlScreenCallbacks,
    modifier: Modifier,
) {
    val scope = rememberCoroutineScope()
    val currentCallbacks by rememberUpdatedState(callbacks)
    val enabledTouchpadBindings = remember(profile.id, profile.updatedAt, profile.gestureBindings) {
        profile.gestureBindings
            .asSequence()
            .filter { it.enabled && it.gestureType.isTouchpadGesture() }
            .mapTo(mutableSetOf()) { it.gestureType }
    }
    val defaultDragButtonDown = remember(profile.id, profile.updatedAt) { AtomicBoolean(false) }
    val scrollBindingThrottle = remember(profile.id, profile.updatedAt) { TouchpadBindingThrottle() }
    var pendingTap by remember(profile.id) { mutableStateOf<List<PointSample>?>(null) }
    var pendingTapJob by remember(profile.id) { mutableStateOf<Job?>(null) }

    fun dispatchTouchpadBinding(type: GestureType): Boolean {
        if (type !in enabledTouchpadBindings) return false
        callbacks.onGesture(type, 1f, null, type.touchpadLabel())
        return true
    }

    fun releaseDefaultDrag() {
        if (defaultDragButtonDown.getAndSet(false)) {
            callbacks.onSetPointerButton(MouseButton.LEFT, false)
        }
    }

    fun publish(recognition: GestureRecognition) {
        val match = recognition.match
        if (match == null) {
            callbacks.onGestureFailure(
                recognition.failure?.message ?: "未识别手势",
                recognition.candidates.firstOrNull()?.confidence ?: 0f,
            )
            return
        }
        val mapped = match.gestureId.toDomainGesture(profile)
        if (mapped == null) {
            callbacks.onGestureFailure("手势未绑定到当前模式", match.confidence)
        } else {
            callbacks.onGesture(mapped.first, match.confidence, mapped.second, match.displayName)
        }
    }

    fun recognize(points: List<PointSample>) {
        scope.launch {
            val recognition = withContext(Dispatchers.Default) { gestureEngine.recognizeDetailed(points) }
            if (recognition.match?.gestureId == "tap") {
                val previous = pendingTap
                if (previous != null) {
                    pendingTapJob?.cancel()
                    pendingTap = null
                    val doubleResult = withContext(Dispatchers.Default) {
                        gestureEngine.recognizeSequence(listOf(previous, points))
                    }
                    publish(doubleResult)
                } else {
                    pendingTap = points
                    pendingTapJob = scope.launch {
                        delay(300L)
                        if (pendingTap === points) {
                            pendingTap = null
                            publish(recognition)
                        }
                    }
                }
            } else {
                pendingTapJob?.cancel()
                pendingTap = null
                publish(recognition)
            }
        }
    }

    val touchpadCallbacks = TouchpadCallbacks(
        onMove = { delta ->
            callbacks.onMovePointer(
                (delta.x * sensitivity).roundToInt(),
                (delta.y * sensitivity).roundToInt(),
            )
        },
        onTap = {
            if (!dispatchTouchpadBinding(GestureType.TOUCHPAD_TAP)) {
                callbacks.onClickPointer(MouseButton.LEFT)
            }
        },
        onDoubleTap = {
            if (!dispatchTouchpadBinding(GestureType.TOUCHPAD_DOUBLE_TAP)) {
                callbacks.onClickPointer(MouseButton.LEFT)
                callbacks.onClickPointer(MouseButton.LEFT)
            }
        },
        onDragStart = {
            if (!dispatchTouchpadBinding(GestureType.TOUCHPAD_LONG_PRESS_DRAG) &&
                defaultDragButtonDown.compareAndSet(false, true)
            ) {
                callbacks.onSetPointerButton(MouseButton.LEFT, true)
            }
        },
        onDrag = { delta ->
            if (defaultDragButtonDown.get()) {
                callbacks.onMovePointer(
                    (delta.x * sensitivity).roundToInt(),
                    (delta.y * sensitivity).roundToInt(),
                )
            }
        },
        onDragEnd = { releaseDefaultDrag() },
        onScroll = { delta ->
            if (GestureType.TOUCHPAD_TWO_FINGER_SCROLL in enabledTouchpadBindings) {
                if (scrollBindingThrottle.shouldDispatch(monotonicTimeMillis())) {
                    dispatchTouchpadBinding(GestureType.TOUCHPAD_TWO_FINGER_SCROLL)
                }
            } else {
                callbacks.onScrollPointer((-delta.y / 5f).roundToInt(), 0)
            }
        },
        onRightClick = {
            if (!dispatchTouchpadBinding(GestureType.TOUCHPAD_TWO_FINGER_TAP)) {
                callbacks.onClickPointer(MouseButton.RIGHT)
            }
        },
        onGestureCancelled = {
            releaseDefaultDrag()
            callbacks.onGestureFailure("手势已取消", 0f)
        },
    )

    Box(modifier = modifier) {
        when (profile.controlAreaType) {
            ControlAreaType.GESTURE -> GestureSurface(
                onStrokeComplete = ::recognize,
                onStrokeStarted = callbacks.onGestureStarted,
                retainCompletedStroke = false,
                showTrail = showGestureTrail,
                modifier = Modifier.fillMaxSize(),
            )
            ControlAreaType.TOUCHPAD -> TouchpadSurface(
                callbacks = touchpadCallbacks,
                modifier = Modifier.fillMaxSize(),
            )
            ControlAreaType.HYBRID -> HybridSurface(
                onStrokeComplete = ::recognize,
                onStrokeStarted = callbacks.onGestureStarted,
                touchpadCallbacks = touchpadCallbacks,
                modifier = Modifier.fillMaxSize(),
                enabled = hybridEnabled,
            )
        }

        if (panelState is GesturePanelState.Result && profile.controlAreaType != ControlAreaType.TOUCHPAD) {
            Text(
                text = panelState.actionName,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 28.dp),
                color = PcRemoteColors.Primary,
                fontSize = 25.sp,
                lineHeight = 31.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
            )
        }
    }

    // A profile/page transition can dispose the surface before its pointer loop
    // observes the final UP. Keep the release independent from that loop.
    DisposableEffect(defaultDragButtonDown) {
        onDispose {
            if (defaultDragButtonDown.getAndSet(false)) {
                currentCallbacks.onSetPointerButton(MouseButton.LEFT, false)
            }
        }
    }
}

@Composable
private fun ConfiguredControlButton(
    control: ControlItem,
    callbacks: ControlScreenCallbacks,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    localizeText: Boolean = true,
) {
    val scope = rememberCoroutineScope()
    var pendingTap by remember(control.id) { mutableStateOf<Job?>(null) }
    var pressed by remember(control.id) { mutableStateOf(false) }
    val pressedScale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(stiffness = 700f, dampingRatio = 0.82f),
        label = "controlPress",
    )
    val supportsDoubleTap = control.doubleTapAction != null
    val shape = RoundedCornerShape(if (compact) 23.dp else 25.dp)
    GlassCard(
        modifier = modifier
            .heightIn(min = if (compact) 64.dp else 88.dp)
            .graphicsLayer {
                scaleX = pressedScale
                scaleY = pressedScale
                translationY = if (pressed) 2.dp.toPx() else 0f
            }
            .clip(shape)
            .pointerInput(control.id, supportsDoubleTap) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    pressed = true
                    callbacks.onBeginLongPress(control.id)
                    var released = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id }
                        if (change == null || !change.pressed) {
                            released = true
                            break
                        }
                        change.consume()
                    }
                    val activated = callbacks.onEndLongPress(
                        control.id,
                        !supportsDoubleTap,
                    )
                    pressed = false
                    if (released && !activated && supportsDoubleTap) {
                        if (pendingTap?.isActive == true) {
                            pendingTap?.cancel()
                            pendingTap = null
                            callbacks.onDoubleTapControl(control.id)
                        } else {
                            pendingTap = scope.launch {
                                delay(300L)
                                callbacks.onTapControl(control.id)
                                pendingTap = null
                            }
                        }
                    }
                }
            }
            .semantics {
                contentDescription = control.title
                role = Role.Button
                onClick {
                    callbacks.onTapControl(control.id)
                    true
                }
            },
        cornerRadius = if (compact) 23.dp else 25.dp,
        contentPadding = PaddingValues(0.dp),
        strong = true,
        shadowElevation = 4.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = if (compact) 8.dp else 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            AssetIcon(
                resourceId = control.icon.toDrawable(),
                contentDescription = control.title,
                modifier = Modifier.size(if (compact) 21.dp else 28.dp),
                tint = PcRemoteColors.Primary,
            )
            Spacer(Modifier.height(if (compact) 4.dp else 7.dp))
            Text(
                text = control.title,
                color = PcRemoteColors.PrimaryDeep,
                fontSize = if (compact) 14.sp else 17.sp,
                lineHeight = if (compact) 18.sp else 21.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                localize = localizeText,
            )
        }
    }
}

private fun com.gunianan.btremote.domain.GestureTemplate.toRuntimeTemplate(): GestureTemplate? {
    val first = samples.firstOrNull() ?: return null
    val runtimeSamples = samples.map { sample -> sample.toRuntimePoints() }.filter { it.size >= 2 }
    if (runtimeSamples.isEmpty()) return null
    return GestureTemplate(
        id = id,
        displayName = name,
        points = runtimeSamples.first(),
        rotationInvariant = rotationInvariant,
        additionalSamples = runtimeSamples.drop(1),
    )
}

private fun GestureSample.toRuntimePoints(): List<PointSample> = points.map { point -> point.toRuntimePoint() }

private fun GesturePoint.toRuntimePoint(): PointSample = PointSample(
    x = x * 200f,
    y = y * 200f,
    timeMillis = elapsedMs,
)

private fun String.toDomainGesture(profile: ControlProfile): Pair<GestureType, String?>? = when (this) {
    "swipe_up" -> GestureType.SWIPE_UP to null
    "swipe_down" -> GestureType.SWIPE_DOWN to null
    "swipe_left" -> GestureType.SWIPE_LEFT to null
    "swipe_right" -> GestureType.SWIPE_RIGHT to null
    "tap" -> GestureType.TAP to null
    "double_tap" -> GestureType.DOUBLE_TAP to null
    "long_press" -> GestureType.LONG_PRESS to null
    "circle" -> GestureType.CIRCLE to null
    "x" -> GestureType.X to null
    "z" -> GestureType.Z to null
    "check" -> GestureType.CHECK to null
    else -> if (profile.customGestures.any { it.id == this }) GestureType.CUSTOM to this else null
}

private fun ControlAreaType.displayName(): String = when (this) {
    ControlAreaType.GESTURE -> "手势控制"
    ControlAreaType.TOUCHPAD -> "触控板"
    ControlAreaType.HYBRID -> "混合控制"
}

private fun String?.toDrawable(): Int = when (this) {
    "video" -> R.drawable.mode_video
    "music" -> R.drawable.mode_music
    "volume_down" -> R.drawable.volume_down
    "volume_mute" -> R.drawable.volume_mute
    "volume_up" -> R.drawable.volume_up
    "media_previous" -> R.drawable.media_previous
    "media_play_pause" -> R.drawable.media_play_pause
    "media_next" -> R.drawable.media_next
    "device", "presentation" -> R.drawable.nav_devices
    "settings", "game" -> R.drawable.nav_settings
    else -> R.drawable.nav_remote
}

internal fun resolveHandedness(
    profileHandedness: Handedness?,
    globalHandedness: Handedness,
): Handedness = when (profileHandedness) {
    Handedness.LEFT -> Handedness.LEFT
    Handedness.RIGHT -> Handedness.RIGHT
    Handedness.INHERIT, null -> when (globalHandedness) {
        Handedness.LEFT -> Handedness.LEFT
        Handedness.RIGHT, Handedness.INHERIT -> Handedness.RIGHT
    }
}

internal fun ControlLayout.resolvedGridColumns(customColumns: Int): Int = when (this) {
    ControlLayout.SINGLE_COLUMN -> 1
    ControlLayout.TWO_COLUMN -> 2
    ControlLayout.THREE_COLUMN -> 3
    ControlLayout.COMPACT_REMOTE -> 4
    ControlLayout.CUSTOM_GRID -> customColumns.coerceIn(1, 4)
    ControlLayout.LARGE_GESTURE,
    ControlLayout.FULLSCREEN_GESTURE,
    -> 3
}

internal fun ControlLayout.resolvedGestureAreaHeightFraction(configuredFraction: Float): Float = when (this) {
    ControlLayout.COMPACT_REMOTE -> 0.36f
    ControlLayout.FULLSCREEN_GESTURE -> 0.84f
    else -> configuredFraction.coerceIn(0.30f, 0.95f)
}

private fun ControlItemSize.resolvedColumnSpan(columnCount: Int): Int = when (this) {
    ControlItemSize.COMPACT,
    ControlItemSize.STANDARD,
    -> 1
    ControlItemSize.WIDE -> minOf(2, columnCount)
    ControlItemSize.LARGE -> columnCount
}

private fun GestureType.isTouchpadGesture(): Boolean = when (this) {
    GestureType.TOUCHPAD_TAP,
    GestureType.TOUCHPAD_DOUBLE_TAP,
    GestureType.TOUCHPAD_LONG_PRESS_DRAG,
    GestureType.TOUCHPAD_TWO_FINGER_SCROLL,
    GestureType.TOUCHPAD_TWO_FINGER_TAP,
    -> true
    else -> false
}

internal fun GestureType.touchpadLabel(): String = when (this) {
    GestureType.TOUCHPAD_TAP -> "触控板轻点"
    GestureType.TOUCHPAD_DOUBLE_TAP -> "触控板双击"
    GestureType.TOUCHPAD_LONG_PRESS_DRAG -> "长按拖动"
    GestureType.TOUCHPAD_TWO_FINGER_SCROLL -> "双指滚动"
    GestureType.TOUCHPAD_TWO_FINGER_TAP -> "双指右键"
    else -> error("$this 不是触控板手势")
}

internal class TouchpadBindingThrottle(
    private val minimumIntervalMs: Long = 180L,
) {
    init {
        require(minimumIntervalMs > 0L)
    }

    private var lastDispatchAtMs: Long? = null

    fun shouldDispatch(nowMs: Long): Boolean {
        val previous = lastDispatchAtMs
        if (previous != null && nowMs >= previous && nowMs - previous < minimumIntervalMs) {
            return false
        }
        lastDispatchAtMs = nowMs
        return true
    }
}

private fun monotonicTimeMillis(): Long = System.nanoTime() / 1_000_000L

private val VolumeIconTokens = setOf("volume_down", "volume_mute", "volume_up")
private val VideoIconTokens = setOf("media_previous", "media_play_pause", "media_next")
