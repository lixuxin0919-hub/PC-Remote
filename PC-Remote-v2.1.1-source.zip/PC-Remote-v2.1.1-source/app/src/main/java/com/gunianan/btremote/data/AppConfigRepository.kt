package com.gunianan.btremote.data

import android.content.Context
import com.gunianan.btremote.domain.AppConfig
import com.gunianan.btremote.domain.ConfigValidator
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.DefaultConfigFactory
import com.gunianan.btremote.domain.SYSTEM_DEFAULT_PROFILE_ID
import com.gunianan.btremote.domain.SYSTEM_PROFILE_IDS
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.Base64
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class ConfigPersistenceException(message: String) : IllegalStateException(message)
class SystemProfileProtectedException : IllegalArgumentException("系统模式不能删除")
class ProfileNotFoundException(profileId: String) : NoSuchElementException("模式不存在：$profileId")

data class ConfigRecovery(
    val reason: String,
    val corruptedPayloadBackedUp: Boolean,
)

/**
 * Validated JSON repository backed by [KeyValueStore]. Production publishes atomic in-process
 * snapshots and lets SharedPreferences flush them asynchronously; tests use an in-memory store.
 * A StateFlow exposes a single process-wide source of truth.
 */
class AppConfigRepository(
    private val store: KeyValueStore,
    private val legacyStore: KeyValueStore? = null,
    private val nowProvider: () -> Long = System::currentTimeMillis,
    private val idGenerator: ProfileIdGenerator = UuidProfileIdGenerator,
    private val profileIconDirectory: File? = null,
    private val persistenceExecutor: ExecutorService? = null,
) {
    private val lock = Any()
    private val initialLoad = loadInitialConfig()
    private val mutableConfig = MutableStateFlow(initialLoad.config)

    val config: StateFlow<AppConfig> = mutableConfig.asStateFlow()
    val recovery: ConfigRecovery? = initialLoad.recovery

    fun current(): AppConfig = mutableConfig.value

    /** Saves a complete validated snapshot without silently changing its revision. */
    fun save(config: AppConfig): AppConfig = synchronized(lock) {
        ConfigValidator.validate(config).requireValid()
        schedulePersist(config)
        mutableConfig.value = config
        config
    }

    /** Applies one atomic in-process mutation and assigns the next revision. */
    fun update(transform: (AppConfig) -> AppConfig): AppConfig = synchronized(lock) {
        val current = mutableConfig.value
        val candidate = transform(current).copy(revision = current.revision + 1)
        ConfigValidator.validate(candidate).requireValid()
        schedulePersist(candidate)
        mutableConfig.value = candidate
        candidate
    }

    fun upsertProfile(profile: ControlProfile): AppConfig = update { current ->
        val index = current.profiles.indexOfFirst { it.id == profile.id }
        if (index < 0) {
            current.copy(profiles = current.profiles + profile)
        } else {
            current.copy(profiles = current.profiles.toMutableList().also { it[index] = profile })
        }
    }

    fun copyProfile(sourceProfileId: String, copyName: String? = null): ControlProfile {
        lateinit var created: ControlProfile
        update { current ->
            val source = current.profiles.firstOrNull { it.id == sourceProfileId }
                ?: throw ProfileNotFoundException(sourceProfileId)
            val now = nowProvider()
            created = source.copy(
                id = nextUniqueProfileId(current),
                name = copyName?.takeIf { it.isNotBlank() } ?: "${source.name} 副本",
                isDefault = false,
                isSystemProfile = false,
                createdAt = now,
                updatedAt = now,
            )
            current.copy(profiles = current.profiles + created)
        }
        created.customIconPath?.let { sourcePath ->
            val source = safeIconFile(sourcePath)
            if (source != null) {
                val target = File(requireNotNull(profileIconDirectory), "${created.id.replace(Regex("[^A-Za-z0-9._-]"), "_")}.png")
                source.copyTo(target, overwrite = true)
                created = created.copy(customIconPath = target.absolutePath, customIconUpdatedAt = nowProvider())
                upsertProfile(created)
            }
        }
        return created
    }

    fun deleteProfile(profileId: String): AppConfig {
        if (profileId in SYSTEM_PROFILE_IDS) throw SystemProfileProtectedException()
        val iconPath = current().profiles.firstOrNull { it.id == profileId }?.customIconPath
        return update { current ->
            if (current.profiles.none { it.id == profileId }) throw ProfileNotFoundException(profileId)
            current.copy(
                profiles = current.profiles.filterNot { it.id == profileId },
                activeProfileId = if (current.activeProfileId == profileId) {
                    SYSTEM_DEFAULT_PROFILE_ID
                } else {
                    current.activeProfileId
                },
                startupProfileId = if (current.startupProfileId == profileId) {
                    SYSTEM_DEFAULT_PROFILE_ID
                } else {
                    current.startupProfileId
                },
            )
        }.also { safeIconFile(iconPath)?.delete() }
    }

    fun setActiveProfile(profileId: String): AppConfig = update { current ->
        current.requireProfile(profileId)
        current.copy(activeProfileId = profileId)
    }

    fun setStartupProfile(profileId: String): AppConfig = update { current ->
        current.requireProfile(profileId)
        current.copy(startupProfileId = profileId)
    }

    /** Applies the persisted startup selection once when a new app process creates its ViewModel. */
    fun activateStartupProfile(): AppConfig {
        val current = current()
        return if (current.activeProfileId == current.startupProfileId) {
            current
        } else {
            setActiveProfile(current.startupProfileId)
        }
    }

    fun restoreSystemProfile(): AppConfig = update { current ->
        DefaultConfigFactory.restoreSystemProfile(current, nowProvider())
    }

    fun exportProfile(profileId: String): String {
        val profile = current().profiles.firstOrNull { it.id == profileId }
            ?: throw ProfileNotFoundException(profileId)
        val encodedIcon = safeIconFile(profile.customIconPath)?.takeIf { it.length() <= 1_400_000 }
            ?.readBytes()?.let(Base64.getEncoder()::encodeToString)
        return ConfigJsonCodec.exportProfile(profile, encodedIcon)
    }

    fun importProfile(rawJson: String): ProfileImportResult = synchronized(lock) {
        val result = ProfileImportService.importProfile(
            rawJson = rawJson,
            currentConfig = mutableConfig.value,
            now = nowProvider(),
            idGenerator = idGenerator,
        )
        val envelope = ConfigJsonCodec.decodeProfileExport(rawJson)
        var finalResult = result
        envelope.iconDataBase64?.let { encoded ->
            val bytes = runCatching { Base64.getDecoder().decode(encoded) }
                .getOrElse { throw ConfigFormatException("模式图标数据无效") }
            if (bytes.size > 1_400_000) throw ConfigFormatException("模式图标数据过大")
            profileIconDirectory?.let { directory ->
                directory.mkdirs()
                val file = File(directory, "${result.importedProfileId.replace(Regex("[^A-Za-z0-9._-]"), "_")}.png")
                file.writeBytes(bytes)
                val profiles = result.config.profiles.map { profile ->
                    if (profile.id == result.importedProfileId) profile.copy(customIconPath = file.absolutePath, customIconUpdatedAt = nowProvider()) else profile
                }
                finalResult = result.copy(config = result.config.copy(profiles = profiles))
            }
        }
        schedulePersist(finalResult.config)
        mutableConfig.value = finalResult.config
        finalResult
    }

    private fun loadInitialConfig(): LoadResult {
        val raw = store.getString(KEY_CONFIG)
        if (raw != null) {
            return try {
                LoadResult(ConfigJsonCodec.decodeConfig(raw), recovery = null)
            } catch (error: IllegalArgumentException) {
                val backedUp = store.putString(KEY_CORRUPTED_BACKUP, raw.take(ConfigJsonCodec.MAX_JSON_CHARS))
                val recovered = createAndMigrateDefault()
                persistSynchronously(recovered)
                markLegacyMigrationComplete()
                LoadResult(
                    config = recovered,
                    recovery = ConfigRecovery(
                        reason = error.message ?: "配置损坏",
                        corruptedPayloadBackedUp = backedUp,
                    ),
                )
            }
        }

        val initial = createAndMigrateDefault()
        persistSynchronously(initial)
        markLegacyMigrationComplete()
        return LoadResult(initial, recovery = null)
    }

    private fun createAndMigrateDefault(): AppConfig {
        val baseline = DefaultConfigFactory.create(nowProvider())
        if (store.getBoolean(KEY_LEGACY_MIGRATION_COMPLETE, false)) return baseline
        return LegacySettingsMigrator.migrate(baseline, legacyStore)
    }

    private fun markLegacyMigrationComplete() {
        if (!store.getBoolean(KEY_LEGACY_MIGRATION_COMPLETE, false) &&
            !store.putBoolean(KEY_LEGACY_MIGRATION_COMPLETE, true)
        ) {
            throw ConfigPersistenceException("无法写入旧设置迁移标记")
        }
    }

    /**
     * UI state is published immediately, while JSON encoding and SharedPreferences work are
     * serialized off the main thread in production. The queue preserves write order so a later
     * setting cannot be overwritten by an earlier snapshot.
     */
    private fun schedulePersist(config: AppConfig) {
        val executor = persistenceExecutor
        if (executor == null) {
            persistSynchronously(config)
        } else {
            executor.execute { persistSynchronously(config) }
        }
    }

    private fun persistSynchronously(config: AppConfig) {
        val encoded = ConfigJsonCodec.encodeConfig(config)
        if (!store.putString(KEY_CONFIG, encoded)) {
            throw ConfigPersistenceException("无法持久化配置")
        }
    }

    fun close() {
        persistenceExecutor?.shutdown()
    }

    private fun nextUniqueProfileId(config: AppConfig): String {
        val occupied = config.profiles.mapTo(hashSetOf()) { it.id }
        repeat(32) {
            val candidate = idGenerator.nextId()
            if (candidate !in SYSTEM_PROFILE_IDS &&
                candidate.matches(Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")) &&
                candidate !in occupied
            ) {
                return candidate
            }
        }
        throw IllegalStateException("无法生成唯一的模式 ID")
    }

    private fun safeIconFile(path: String?): File? {
        val directory = profileIconDirectory?.canonicalFile ?: return null
        val file = path?.let(::File)?.canonicalFile ?: return null
        return file.takeIf { it.parentFile == directory && it.isFile }
    }

    private fun AppConfig.requireProfile(profileId: String) {
        if (profiles.none { it.id == profileId }) throw ProfileNotFoundException(profileId)
    }

    private data class LoadResult(
        val config: AppConfig,
        val recovery: ConfigRecovery?,
    )

    companion object {
        const val PREFERENCES_NAME = "pc_remote_config"
        private const val KEY_CONFIG = "app_config_v1"
        private const val KEY_CORRUPTED_BACKUP = "app_config_corrupted_backup"
        private const val KEY_LEGACY_MIGRATION_COMPLETE = "legacy_settings_migrated"

        fun fromSharedPreferences(
            context: Context,
            nowProvider: () -> Long = System::currentTimeMillis,
            idGenerator: ProfileIdGenerator = UuidProfileIdGenerator,
        ): AppConfigRepository {
            val applicationContext = context.applicationContext
            val configStore = SharedPreferencesKeyValueStore(
                applicationContext.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE),
            )
            val legacyStore = SharedPreferencesKeyValueStore(
                applicationContext.getSharedPreferences(
                    LegacySettingsMigrator.LEGACY_PREFERENCES_NAME,
                    Context.MODE_PRIVATE,
                ),
            )
            val iconDirectory = File(applicationContext.filesDir, "profile_icons").apply { mkdirs() }
            val executor = Executors.newSingleThreadExecutor { runnable ->
                Thread(runnable, "pc-remote-config-writer").apply { isDaemon = true }
            }
            return AppConfigRepository(
                configStore,
                legacyStore,
                nowProvider,
                idGenerator,
                iconDirectory,
                executor,
            )
        }
    }
}
