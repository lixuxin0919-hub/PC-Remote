package com.gunianan.btremote.gesture

import java.util.Locale

/**
 * Hybrid recognizer. Deterministic rules run first; symbol and custom-template
 * recognition is only attempted when no rule applies.
 */
class GestureEngine(
    templates: List<GestureTemplate> = DefaultGestureTemplates.create(),
    private val config: GestureEngineConfig = GestureEngineConfig(),
    private val ruleRecognizer: RuleGestureRecognizer = RuleGestureRecognizer(),
    preprocessor: GesturePreprocessor = GesturePreprocessor(),
) {
    private val templateRecognizer = OneDollarRecognizer(templates, preprocessor)
    private val pathPreprocessor = preprocessor

    fun replaceTemplates(templates: List<GestureTemplate>) {
        templateRecognizer.replaceTemplates(templates)
    }

    fun addTemplates(templates: List<GestureTemplate>) {
        templateRecognizer.addTemplates(templates)
    }

    /** Compatibility API for callers that only need a successful match. */
    fun recognize(points: List<PointSample>): GestureMatch? = recognizeDetailed(points).match

    fun recognizeDetailed(points: List<PointSample>): GestureRecognition {
        validate(points)?.let { return GestureRecognition(failure = it) }

        ruleRecognizer.recognizeCandidate(points)?.let { candidate ->
            return GestureRecognition(
                match = candidate.toMatch(),
                candidates = listOf(candidate),
            )
        }

        if (strokeCount(points) > 1) {
            return failure(
                RecognitionFailureReason.NO_MATCH,
                "仅双击支持多笔输入，其他符号必须单笔完成。",
            )
        }

        if (pathPreprocessor.rawPathLength(points) < config.minTemplatePathLengthPx) {
            return failure(
                RecognitionFailureReason.TOO_SHORT,
                "轨迹过短，未达到 ${config.minTemplatePathLengthPx.toInt()} px。",
            )
        }

        val candidates = templateRecognizer.candidates(points)
        if (candidates.isEmpty()) {
            return failure(
                RecognitionFailureReason.NO_MATCH,
                "没有可用模板或轨迹无法归一化。",
            )
        }

        val best = candidates.first()
        if (best.confidence < config.templateConfidenceThreshold) {
            return GestureRecognition(
                candidates = candidates,
                failure = RecognitionFailure(
                    RecognitionFailureReason.LOW_CONFIDENCE,
                    "最佳置信度 ${formatConfidence(best.confidence)} 低于阈值 " +
                        "${formatConfidence(config.templateConfidenceThreshold)}。",
                ),
            )
        }

        val runnerUp = candidates.getOrNull(1)
        if (
            runnerUp != null &&
            runnerUp.confidence >= config.templateConfidenceThreshold &&
            best.confidence - runnerUp.confidence < config.ambiguityMargin
        ) {
            return GestureRecognition(
                candidates = candidates,
                failure = RecognitionFailure(
                    RecognitionFailureReason.AMBIGUOUS,
                    "轨迹同时接近“${best.displayName}”和“${runnerUp.displayName}”。",
                ),
            )
        }

        return GestureRecognition(
            match = best.toMatch(),
            candidates = candidates,
        )
    }

    /** Convenience API for a stateless multi-stroke gesture such as double tap. */
    fun recognizeSequence(strokes: List<List<PointSample>>): GestureRecognition {
        if (strokes.isEmpty()) return recognizeDetailed(emptyList())
        val points = ArrayList<PointSample>(strokes.sumOf { it.size })
        strokes.forEachIndexed { strokeIndex, stroke ->
            stroke.forEach { points += it.copy(strokeId = strokeIndex) }
        }
        return recognizeDetailed(points)
    }

    fun findConflicts(
        proposed: GestureTemplate,
        threshold: Float = config.conflictSimilarityThreshold,
        excludeGestureId: String? = proposed.id,
    ): List<GestureConflict> =
        templateRecognizer.findConflicts(proposed, threshold, excludeGestureId)

    fun templateSimilarity(
        first: List<PointSample>,
        second: List<PointSample>,
        rotationInvariant: Boolean,
    ): Float = templateRecognizer.similarity(first, second, rotationInvariant)

    private fun validate(points: List<PointSample>): RecognitionFailure? {
        if (points.isEmpty()) {
            return RecognitionFailure(RecognitionFailureReason.EMPTY_INPUT, "没有采集到触控点。")
        }
        if (points.any { !it.x.isFinite() || !it.y.isFinite() }) {
            return RecognitionFailure(RecognitionFailureReason.INVALID_COORDINATE, "轨迹包含无效坐标。")
        }
        for (index in 1 until points.size) {
            if (points[index].timeMillis < points[index - 1].timeMillis) {
                return RecognitionFailure(
                    RecognitionFailureReason.INVALID_TIMESTAMPS,
                    "触控时间戳必须单调递增。",
                )
            }
        }

        val duration = points.last().timeMillis - points.first().timeMillis
        if (duration > config.maxGestureDurationMs) {
            return RecognitionFailure(
                RecognitionFailureReason.TOO_LONG,
                "手势持续 ${duration} ms，超过 ${config.maxGestureDurationMs} ms。",
            )
        }
        return null
    }

    private fun failure(reason: RecognitionFailureReason, message: String) =
        GestureRecognition(failure = RecognitionFailure(reason, message))

    private fun GestureCandidate.toMatch() = GestureMatch(
        gestureId = gestureId,
        confidence = confidence,
        source = source,
        displayName = displayName,
    )

    private fun strokeCount(points: List<PointSample>): Int {
        var count = 1
        for (index in 1 until points.size) {
            if (points[index].strokeId != points[index - 1].strokeId) count++
        }
        return count
    }

    private fun formatConfidence(value: Float): String =
        String.format(Locale.ROOT, "%.2f", value)
}
