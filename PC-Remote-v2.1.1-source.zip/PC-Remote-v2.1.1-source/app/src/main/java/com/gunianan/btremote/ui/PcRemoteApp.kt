package com.gunianan.btremote.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Snackbar
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gunianan.btremote.PcRemoteUiEvent
import com.gunianan.btremote.PcRemoteViewModel
import com.gunianan.btremote.R
import com.gunianan.btremote.action.KeyReleaseReason
import com.gunianan.btremote.bluetooth.BluetoothHidUiState
import com.gunianan.btremote.bluetooth.HidConnectionState
import com.gunianan.btremote.bluetooth.PairedBluetoothDevice
import com.gunianan.btremote.locale.AppLanguage
import com.gunianan.btremote.locale.AppLocaleManager
import com.gunianan.btremote.performance.PerformanceIsolation
import com.gunianan.btremote.performance.PerformanceJankReporter
import com.gunianan.btremote.performance.PlainScrollBaselineScreen
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.domain.SYSTEM_TRACKPAD_PROFILE_ID
import com.gunianan.btremote.trackpad.ui.TrackpadScreen
import com.gunianan.btremote.trackpad.ui.TrackpadScreenCallbacks
import com.gunianan.btremote.ui.components.AssetIcon
import com.gunianan.btremote.ui.components.AuroraBackground
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.GlassPill
import com.gunianan.btremote.ui.components.StatusDot
import com.gunianan.btremote.ui.control.ControlScreen
import com.gunianan.btremote.ui.control.ControlScreenCallbacks
import com.gunianan.btremote.ui.customize.CustomizeScreen
import com.gunianan.btremote.ui.customize.CustomGestureEditorScreen
import com.gunianan.btremote.ui.customize.ProfileEditorScreen
import com.gunianan.btremote.ui.devices.DeviceScreenCallbacks
import com.gunianan.btremote.ui.devices.DevicesScreen
import com.gunianan.btremote.ui.navigation.AppTab
import com.gunianan.btremote.ui.navigation.FloatingBottomNavigation
import com.gunianan.btremote.ui.navigation.FloatingNavigationRail
import com.gunianan.btremote.ui.localized.UiTextTranslator
import com.gunianan.btremote.ui.settings.SettingsScreen
import com.gunianan.btremote.ui.settings.SettingsScreenCallbacks
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTheme
import com.gunianan.btremote.ui.theme.PcRemoteTypography
import kotlinx.coroutines.flow.StateFlow

data class PcRemoteHostActions(
    val onPairing: () -> Unit,
    val onOpenSystemBluetooth: () -> Unit,
    val onRefreshDevices: () -> Unit,
    val onRepairHid: () -> Unit,
    val onConnectDevice: (String) -> Unit,
    val onDisconnectDevice: () -> Unit,
    val onExportProfile: (profileName: String, json: String) -> Unit,
    val onOpenDeveloperEmail: () -> Unit,
    val onKeepScreenOnChanged: (Boolean) -> Unit,
    val onAutoConnectChanged: (Boolean) -> Unit,
    val onLanguageChanged: (AppLanguage) -> Unit,
    val onReleaseAllKeys: (KeyReleaseReason) -> Unit,
    val onPickProfileIconPhoto: (String) -> Unit,
    val onPickProfileIconFile: (String) -> Unit,
)

@Composable
fun PcRemoteApp(
    viewModel: PcRemoteViewModel,
    hidState: StateFlow<BluetoothHidUiState>,
    pairedDevices: StateFlow<List<PairedBluetoothDevice>>,
    hostActions: PcRemoteHostActions,
) {
    val performanceFlags by PerformanceIsolation.flags.collectAsStateWithLifecycle()
    if (performanceFlags.showPlainScrollBaseline) {
        PcRemoteTheme { PlainScrollBaselineScreen() }
        return
    }
    val context = LocalContext.current
    val uiLanguage = context.resources.configuration.locales[0].language
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
    val globalSettings by viewModel.globalSettings.collectAsStateWithLifecycle()
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val startupProfileId by viewModel.startupProfileId.collectAsStateWithLifecycle()
    val schemaVersion by viewModel.schemaVersion.collectAsStateWithLifecycle()
    val hapticEnabled by viewModel.hapticEnabled.collectAsStateWithLifecycle()
    val currentHidState by hidState.collectAsStateWithLifecycle()
    val currentPairedDevices by pairedDevices.collectAsStateWithLifecycle()
    val editorDraft by viewModel.editorDraft.collectAsStateWithLifecycle()
    val customGestureEditorProfileId by viewModel.customGestureEditorProfileId.collectAsStateWithLifecycle()
    val gesturePanelState by viewModel.gesturePanelState.collectAsStateWithLifecycle()
    val profilePickerVisible by viewModel.profilePickerVisible.collectAsStateWithLifecycle()
    val profileIconCrop by viewModel.profileIconCrop.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val pageStateHolder = rememberSaveableStateHolder()
    val haptic = LocalHapticFeedback.current
    var internalActionPanel by rememberSaveable { mutableStateOf<InternalActionPanel?>(null) }

    LaunchedEffect(selectedTab) {
        PerformanceJankReporter.setState("screen", selectedTab.name)
        PerformanceJankReporter.setState("interaction", "Idle")
    }

    LaunchedEffect(viewModel, uiLanguage) {
        viewModel.events.collect { event ->
            when (event) {
                is PcRemoteUiEvent.Message -> snackbar.showSnackbar(UiTextTranslator.translate(event.text, uiLanguage))
                PcRemoteUiEvent.HapticSuccess -> if (hapticEnabled) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
                PcRemoteUiEvent.HapticFailure -> if (hapticEnabled) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
                PcRemoteUiEvent.OpenQuickActions -> {
                    internalActionPanel = InternalActionPanel.QUICK_ACTIONS
                }
                PcRemoteUiEvent.OpenKeyboard -> {
                    internalActionPanel = InternalActionPanel.KEYBOARD
                }
            }
        }
    }

    LaunchedEffect(globalSettings.keepScreenOn) {
        hostActions.onKeepScreenOnChanged(globalSettings.keepScreenOn)
    }
    LaunchedEffect(globalSettings.autoConnect) {
        hostActions.onAutoConnectChanged(globalSettings.autoConnect)
    }
    LaunchedEffect(selectedTab) {
        hostActions.onReleaseAllKeys(KeyReleaseReason.PAGE_EXIT)
    }
    LaunchedEffect(activeProfile.id) {
        hostActions.onReleaseAllKeys(KeyReleaseReason.PROFILE_SWITCH)
    }
    LaunchedEffect(currentHidState.connectionState) {
        if (currentHidState.connectionState != HidConnectionState.CONNECTED) {
            viewModel.cancelForDisconnect()
        }
    }

    PcRemoteTheme {
        AuroraBackground(plain = performanceFlags.plainBackground) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val useRail = maxWidth >= 700.dp && maxWidth > maxHeight

                if (editorDraft != null && customGestureEditorProfileId == editorDraft?.id) {
                    CustomGestureEditorScreen(
                        profile = requireNotNull(editorDraft),
                        availableProfiles = profiles,
                        confidenceThreshold = editorDraft?.appearance?.confidenceThreshold
                            ?: globalSettings.confidenceThreshold,
                        onCancel = viewModel::closeCustomGestureEditor,
                        onSave = viewModel::saveCustomGesture,
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .then(
                                if (useRail) Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                                else Modifier,
                            ),
                    )
                } else if (editorDraft != null) {
                    ProfileEditorScreen(
                        profile = requireNotNull(editorDraft),
                        globalSettings = globalSettings,
                        availableProfiles = profiles,
                        onProfileChange = viewModel::updateEditorDraft,
                        onSave = viewModel::saveEditor,
                        onCancel = viewModel::cancelEditor,
                        onOpenHelp = {
                            viewModel.cancelEditor()
                            viewModel.selectTab(AppTab.SETTINGS)
                        },
                        onOpenCustomGestureEditor = viewModel::openCustomGestureEditor,
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .then(
                                if (useRail) Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                                else Modifier,
                            ),
                        contentPadding = PaddingValues(
                            start = 20.dp,
                            top = 20.dp,
                            end = if (useRail) 124.dp else 20.dp,
                            bottom = if (useRail) 28.dp else 128.dp,
                        ),
                    )
                } else {
                    val pageModifier = Modifier
                        .fillMaxSize()
                        .padding(end = if (useRail) 108.dp else 0.dp)
                        .then(
                            if (useRail) Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                            else Modifier,
                        )
                    pageStateHolder.SaveableStateProvider(selectedTab.name) {
                        when (selectedTab) {
                            AppTab.CONTROL -> if (activeProfile.id == SYSTEM_TRACKPAD_PROFILE_ID) {
                                TrackpadScreen(
                                    settings = globalSettings.trackpad,
                                    callbacks = TrackpadScreenCallbacks(
                                        onMovePointer = viewModel::movePointer,
                                        onClickPointer = viewModel::clickPointer,
                                        onSetPointerButton = viewModel::setPointerButton,
                                        onScrollPointer = viewModel::scrollPointer,
                                        onModifiedScroll = { modifier, amount ->
                                            viewModel.dispatchAction(
                                                RemoteActionConfig.ModifiedScrollAction(setOf(modifier), amount),
                                                quiet = true,
                                            )
                                        },
                                        onConfiguredAction = { action -> viewModel.dispatchAction(action, quiet = true) },
                                        onShowMouseButtonsChanged = { show ->
                                            viewModel.updateGlobalSettings { global ->
                                                global.copy(trackpad = global.trackpad.copy(showMouseButtons = show))
                                            }
                                        },
                                        onOpenSettings = { viewModel.selectTab(AppTab.SETTINGS) },
                                        onCancelInputs = {
                                            viewModel.cancelTrackpadInput()
                                            hostActions.onReleaseAllKeys(KeyReleaseReason.EXPLICIT)
                                        },
                                    ),
                                    modifier = pageModifier,
                                    contentPadding = responsivePagePadding(useRail, hasStatusCard = true),
                                )
                            } else {
                                ControlScreen(
                                    profile = activeProfile,
                                    globalSettings = globalSettings,
                                    gesturePanelState = gesturePanelState,
                                    callbacks = ControlScreenCallbacks(
                                        onOpenDevices = { viewModel.selectTab(AppTab.DEVICES) },
                                        onTapControl = viewModel::tapControl,
                                        onDoubleTapControl = viewModel::doubleTapControl,
                                        onBeginLongPress = viewModel::beginLongPress,
                                        onEndLongPress = viewModel::endLongPress,
                                        onGesture = viewModel::dispatchGesture,
                                        onGestureFailure = viewModel::reportGestureFailure,
                                        onGestureStarted = viewModel::clearGesturePanel,
                                        onMovePointer = viewModel::movePointer,
                                        onClickPointer = viewModel::clickPointer,
                                        onSetPointerButton = viewModel::setPointerButton,
                                        onScrollPointer = viewModel::scrollPointer,
                                    ),
                                    modifier = pageModifier,
                                    contentPadding = responsivePagePadding(useRail, hasStatusCard = true),
                                )
                            }
                            AppTab.DEVICES -> DevicesScreen(
                                uiState = currentHidState,
                                pairedDevices = currentPairedDevices,
                                callbacks = DeviceScreenCallbacks(
                                    onPairing = hostActions.onPairing,
                                    onOpenSystemBluetooth = hostActions.onOpenSystemBluetooth,
                                    onRefresh = hostActions.onRefreshDevices,
                                    onRepair = hostActions.onRepairHid,
                                    onConnect = hostActions.onConnectDevice,
                                    onDisconnect = hostActions.onDisconnectDevice,
                                ),
                                modifier = pageModifier.windowInsetsPadding(WindowInsets.statusBars),
                                contentPadding = responsivePagePadding(useRail, hasStatusCard = false),
                            )
                            AppTab.CUSTOMIZE -> CustomizeScreen(
                                profiles = profiles,
                                activeProfileId = activeProfile.id,
                                startupProfileId = startupProfileId,
                                schemaVersion = schemaVersion,
                                onSelectProfile = viewModel::selectProfile,
                                onCreateBlank = { viewModel.createBlankProfile() },
                                onCopyProfile = { sourceId ->
                                    viewModel.copyProfile(sourceId)?.let { viewModel.beginEditProfile(it.id) }
                                },
                                onEditProfile = viewModel::beginEditProfile,
                                onRenameProfile = viewModel::renameProfile,
                                onChangeIcon = viewModel::setProfileIcon,
                                onPickIconPhoto = hostActions.onPickProfileIconPhoto,
                                onPickIconFile = hostActions.onPickProfileIconFile,
                                onRemoveCustomIcon = viewModel::removeCustomProfileIcon,
                                onDeleteProfile = viewModel::deleteProfile,
                                onMoveProfile = viewModel::moveProfile,
                                onSetStartupProfile = viewModel::setStartupProfile,
                                onImportProfile = viewModel::importProfile,
                                onExportProfile = { profileId ->
                                    val profile = profiles.firstOrNull { it.id == profileId }
                                    val json = viewModel.exportProfile(profileId)
                                    if (profile != null && json != null) {
                                        hostActions.onExportProfile(profile.name, json)
                                    }
                                },
                                onRestoreSystemProfile = viewModel::restoreSystemProfile,
                                modifier = pageModifier.windowInsetsPadding(WindowInsets.statusBars),
                                contentPadding = responsivePagePadding(useRail, hasStatusCard = false),
                            )
                            AppTab.SETTINGS -> SettingsScreen(
                                settings = globalSettings,
                                profiles = profiles,
                                startupProfileId = startupProfileId,
                                appLanguage = AppLocaleManager.selectedLanguage(context),
                                callbacks = SettingsScreenCallbacks(
                                    onSettingsChange = { updated -> viewModel.updateGlobalSettings { updated } },
                                    onStartupProfileChange = viewModel::setStartupProfile,
                                    onRestoreSystemProfile = viewModel::restoreSystemProfile,
                                    onOpenDeveloperEmail = hostActions.onOpenDeveloperEmail,
                                    onLanguageChange = hostActions.onLanguageChanged,
                                ),
                                modifier = pageModifier.windowInsetsPadding(WindowInsets.statusBars),
                                contentPadding = responsivePagePadding(useRail, hasStatusCard = false),
                            )
                        }
                    }
                }

                if (!performanceFlags.hideFloatingTopCard && selectedTab == AppTab.CONTROL && editorDraft == null) {
                    FloatingStatusBar(
                        hidState = currentHidState,
                        profile = activeProfile,
                        onStatusClick = { viewModel.selectTab(AppTab.DEVICES) },
                        onProfileClick = viewModel::openProfilePicker,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(horizontal = 18.dp)
                            .padding(end = if (useRail) 104.dp else 0.dp)
                            .windowInsetsPadding(WindowInsets.statusBars),
                    )
                }

                if (!performanceFlags.hideFloatingBottomBar && editorDraft == null) {
                    if (useRail) {
                        FloatingNavigationRail(
                            selected = selectedTab,
                            onSelect = viewModel::selectTab,
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(top = 80.dp, end = 12.dp, bottom = 20.dp)
                                .windowInsetsPadding(WindowInsets.navigationBars),
                        )
                    } else {
                        FloatingBottomNavigation(
                            selected = selectedTab,
                            onSelect = viewModel::selectTab,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 18.dp, vertical = 12.dp)
                                .windowInsetsPadding(WindowInsets.navigationBars),
                        )
                    }
                }

                SnackbarHost(
                    hostState = snackbar,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = if (useRail) 24.dp else 116.dp),
                ) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = Color(0xF2182231),
                        contentColor = Color.White,
                        actionColor = Color(0xFF72B9FF),
                    )
                }

                when (internalActionPanel) {
                    InternalActionPanel.KEYBOARD -> HidKeyboardPanel(
                        onKeyClick = { keyCode ->
                            viewModel.dispatchAction(RemoteActionConfig.KeyboardKey(keyCode))
                        },
                        onDismiss = { internalActionPanel = null },
                    )
                    InternalActionPanel.QUICK_ACTIONS -> QuickActionsPanel(
                        profile = activeProfile,
                        onControlClick = viewModel::tapControl,
                        onDismiss = { internalActionPanel = null },
                    )
                    null -> Unit
                }

                if (profilePickerVisible && editorDraft == null) {
                    ProfileSelectionDialog(
                        profiles = profiles,
                        activeProfileId = activeProfile.id,
                        onSelect = viewModel::selectProfile,
                        onCreate = {
                            viewModel.closeProfilePicker()
                            viewModel.createBlankProfile()
                        },
                        onManage = {
                            viewModel.closeProfilePicker()
                            viewModel.selectTab(AppTab.CUSTOMIZE)
                        },
                        onDismiss = viewModel::closeProfilePicker,
                    )
                }
                profileIconCrop?.let { draft ->
                    ProfileIconCropDialog(draft.bitmap, viewModel::saveProfileIconCrop, viewModel::cancelProfileIconCrop)
                }
            }
        }
    }
}

@Composable
private fun FloatingStatusBar(
    hidState: BluetoothHidUiState,
    profile: com.gunianan.btremote.domain.ControlProfile,
    onStatusClick: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        cornerRadius = 28.dp,
        contentPadding = PaddingValues(horizontal = 15.dp, vertical = 12.dp),
        strong = true,
    ) {
        Column {
            Text(
                text = "PC遥控器",
                style = PcRemoteTypography.Caption,
                color = PcRemoteColors.PrimaryDeep,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.size(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onStatusClick),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AssetIcon(
                    resourceId = R.drawable.nav_devices,
                    contentDescription = "设备状态",
                    modifier = Modifier.size(31.dp),
                    tint = PcRemoteColors.Primary,
                )
                Spacer(Modifier.size(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusDot(hidState.connectionState.statusColor())
                        Spacer(Modifier.size(6.dp))
                        Text(
                            text = hidState.connectedDevice?.name ?: hidState.title,
                            style = PcRemoteTypography.SectionTitle,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Text(
                        text = when (hidState.connectionState) {
                            HidConnectionState.CONNECTED -> "已连接 · 蓝牙 HID"
                            else -> hidState.detail
                        },
                        style = PcRemoteTypography.Caption,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.size(8.dp))
            GlassPill(onClick = onProfileClick) {
                ProfileIconView(profile, Modifier.size(22.dp), PcRemoteColors.Primary)
                Spacer(Modifier.size(7.dp))
                Text(
                    text = profile.name,
                    color = PcRemoteColors.Primary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    localize = profile.isSystemProfile,
                )
            }
            }
        }
    }
}

private fun responsivePagePadding(useRail: Boolean, hasStatusCard: Boolean) = PaddingValues(
    start = 20.dp,
    top = if (hasStatusCard) 154.dp else 20.dp,
    end = 20.dp,
    bottom = if (useRail) 28.dp else 124.dp,
)

private fun HidConnectionState.statusColor() = when (this) {
    HidConnectionState.CONNECTED -> PcRemoteColors.Success
    HidConnectionState.READY -> PcRemoteColors.Primary
    HidConnectionState.STARTING,
    HidConnectionState.ACQUIRING_PROFILE,
    HidConnectionState.REGISTERING,
    HidConnectionState.CONNECTING,
    HidConnectionState.DISCONNECTING,
    -> PcRemoteColors.Warning
    HidConnectionState.ERROR,
    HidConnectionState.PERMISSION_REQUIRED,
    HidConnectionState.UNSUPPORTED,
    -> PcRemoteColors.Error
    else -> PcRemoteColors.Idle
}
