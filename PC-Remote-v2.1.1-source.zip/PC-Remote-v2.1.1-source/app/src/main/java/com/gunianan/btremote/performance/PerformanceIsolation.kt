package com.gunianan.btremote.performance

import android.content.Intent
import com.gunianan.btremote.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Debug-only experiment controls. They have no settings UI. */
data class PerformanceIsolationFlags(
    val showPlainScrollBaseline: Boolean = false,
    val plainBackground: Boolean = false,
    val hideFloatingBottomBar: Boolean = false,
    val hideFloatingTopCard: Boolean = false,
    val plainCards: Boolean = false,
    val plainSwitches: Boolean = false,
    val plainSliders: Boolean = false,
    val disableLocalImages: Boolean = false,
    val disableAnimations: Boolean = false,
    val useStaticScreenData: Boolean = false,
    val disableBluetoothStateCollection: Boolean = false,
    val disableSettingsStateCollection: Boolean = false,
    val disablePersistenceWrites: Boolean = false,
)

object PerformanceIsolation {
    private val mutableFlags = MutableStateFlow(PerformanceIsolationFlags())
    val flags: StateFlow<PerformanceIsolationFlags> = mutableFlags.asStateFlow()

    fun updateFromIntent(intent: Intent?) {
        if (!BuildConfig.DEBUG || intent == null) return
        fun flag(name: String) = intent.getBooleanExtra("perf_$name", false)
        mutableFlags.value = PerformanceIsolationFlags(
            showPlainScrollBaseline = flag("plain_baseline"),
            plainBackground = flag("plain_background"),
            hideFloatingBottomBar = flag("hide_bottom_bar"),
            hideFloatingTopCard = flag("hide_top_card"),
            plainCards = flag("plain_cards"),
            plainSwitches = flag("plain_switches"),
            plainSliders = flag("plain_sliders"),
            disableLocalImages = flag("disable_images"),
            disableAnimations = flag("disable_animations"),
            useStaticScreenData = flag("static_data"),
            disableBluetoothStateCollection = flag("disable_bluetooth"),
            disableSettingsStateCollection = flag("disable_settings"),
            disablePersistenceWrites = flag("disable_persistence"),
        )
    }
}
