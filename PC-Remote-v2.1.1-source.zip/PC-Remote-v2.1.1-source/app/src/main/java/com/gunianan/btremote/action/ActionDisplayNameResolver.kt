package com.gunianan.btremote.action

import com.gunianan.btremote.domain.HidConsumerUsages
import com.gunianan.btremote.domain.InternalActionType
import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.MouseCommand
import com.gunianan.btremote.domain.RemoteActionConfig

/** Produces the short, user-facing result shown after a gesture executes. */
object ActionDisplayNameResolver {
    fun resolve(action: RemoteActionConfig): String = when (action) {
        is RemoteActionConfig.KeyboardKey -> keyboardKeyName(action.keyCode)
        is RemoteActionConfig.KeyboardShortcut -> {
            val modifiers = action.modifiers.joinToString("+") { it.shortName() }
            listOf(modifiers, keyboardKeyName(action.keyCode)).filter(String::isNotBlank).joinToString("+")
        }
        is RemoteActionConfig.ConsumerKey -> consumerKeyName(action.usageId)
        is RemoteActionConfig.MouseAction -> mouseName(action.command, action.button)
        is RemoteActionConfig.ScrollAction -> when {
            action.vertical < 0 -> "向上滚动"
            action.vertical > 0 -> "向下滚动"
            action.horizontal < 0 -> "向左滚动"
            action.horizontal > 0 -> "向右滚动"
            else -> "滚动"
        }
        is RemoteActionConfig.ModifiedScrollAction -> when {
            KeyboardModifier.LEFT_SHIFT in action.modifiers -> "水平滚动"
            KeyboardModifier.LEFT_CONTROL in action.modifiers -> "缩放"
            else -> "组合滚动"
        }
        is RemoteActionConfig.InternalAction -> when (action.action) {
            InternalActionType.OPEN_PROFILE_PICKER -> "选择控制模式"
            InternalActionType.OPEN_KEYBOARD -> "打开键盘"
            InternalActionType.OPEN_QUICK_ACTIONS -> "打开快捷动作"
            InternalActionType.TOGGLE_CONTROL_AREA_TYPE -> "切换控制面板"
            InternalActionType.SWITCH_PROFILE -> "切换控制模式"
            InternalActionType.OPEN_SETTINGS -> "打开设置"
        }
        is RemoteActionConfig.CustomSequence -> "执行自定义序列"
    }

    private fun keyboardKeyName(keyCode: Int): String = when (keyCode) {
        0x28 -> "回车"
        0x29 -> "Esc"
        0x2A -> "退格"
        0x2B -> "Tab"
        0x2C -> "空格"
        0x4A -> "Home"
        0x4B -> "PageUp"
        0x4C -> "Delete"
        0x4D -> "End"
        0x4E -> "PageDown"
        0x4F -> "方向键 →"
        0x50 -> "方向键 ←"
        0x51 -> "方向键 ↓"
        0x52 -> "方向键 ↑"
        in 0x04..0x1D -> ('A'.code + keyCode - 0x04).toChar().toString()
        else -> "键盘按键"
    }

    private fun consumerKeyName(usageId: Int): String = when (usageId) {
        HidConsumerUsages.PLAY_PAUSE -> "播放/暂停"
        HidConsumerUsages.PREVIOUS_TRACK -> "上一首 / 上一条"
        HidConsumerUsages.NEXT_TRACK -> "下一首 / 下一条"
        HidConsumerUsages.STOP -> "停止播放"
        HidConsumerUsages.FAST_FORWARD -> "快进"
        HidConsumerUsages.VOLUME_DECREMENT -> "音量减"
        HidConsumerUsages.MUTE -> "静音"
        HidConsumerUsages.VOLUME_INCREMENT -> "音量加"
        else -> "媒体控制"
    }

    private fun KeyboardModifier.shortName(): String = when (this) {
        KeyboardModifier.LEFT_CONTROL, KeyboardModifier.RIGHT_CONTROL -> "Ctrl"
        KeyboardModifier.LEFT_SHIFT, KeyboardModifier.RIGHT_SHIFT -> "Shift"
        KeyboardModifier.LEFT_ALT, KeyboardModifier.RIGHT_ALT -> "Alt"
        KeyboardModifier.LEFT_GUI, KeyboardModifier.RIGHT_GUI -> "Win"
    }

    private fun mouseName(command: MouseCommand, button: MouseButton?): String = when (command) {
        MouseCommand.MOVE -> "移动指针"
        MouseCommand.CLICK -> when (button) {
            MouseButton.RIGHT -> "右键单击"
            MouseButton.MIDDLE -> "中键单击"
            else -> "左键单击"
        }
        MouseCommand.DOWN -> "按下${button.buttonName()}"
        MouseCommand.UP -> "释放${button.buttonName()}"
    }

    private fun MouseButton?.buttonName(): String = when (this) {
        MouseButton.LEFT -> "左键"
        MouseButton.RIGHT -> "右键"
        MouseButton.MIDDLE -> "中键"
        null -> "鼠标键"
    }
}
