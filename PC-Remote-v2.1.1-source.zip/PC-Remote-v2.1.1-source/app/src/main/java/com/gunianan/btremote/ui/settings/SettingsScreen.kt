package com.gunianan.btremote.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import com.gunianan.btremote.ui.components.PcRemoteSlider
import com.gunianan.btremote.ui.components.PcRemoteSwitch
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gunianan.btremote.BuildConfig
import com.gunianan.btremote.R
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.GlobalSettings
import com.gunianan.btremote.domain.Handedness
import com.gunianan.btremote.locale.AppLanguage
import com.gunianan.btremote.trackpad.input.TrackpadInputAdapter
import com.gunianan.btremote.trackpad.input.TrackpadPointerSample
import com.gunianan.btremote.trackpad.pressure.AdaptivePressureEngine
import com.gunianan.btremote.trackpad.pressure.PressureCalibrationSamples
import com.gunianan.btremote.trackpad.pressure.PressureCalibrator
import com.gunianan.btremote.trackpad.pressure.PressureLevel
import com.gunianan.btremote.trackpad.pressure.PressureReading
import com.gunianan.btremote.trackpad.settings.ForcePressAction
import com.gunianan.btremote.trackpad.settings.PointerSensitivityPreset
import com.gunianan.btremote.trackpad.settings.TrackpadDragMode
import com.gunianan.btremote.trackpad.settings.TrackpadSettings
import com.gunianan.btremote.trackpad.settings.TrackpadGestureActionSlot
import com.gunianan.btremote.trackpad.settings.TrackpadGestureActions
import com.gunianan.btremote.ui.customize.ActionPickerDialog
import com.gunianan.btremote.ui.customize.displaySummary
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.SectionHeading
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography
import kotlin.math.roundToInt

data class SettingsScreenCallbacks(
    val onSettingsChange: (GlobalSettings) -> Unit,
    val onStartupProfileChange: (String) -> Unit,
    val onRestoreSystemProfile: () -> Unit,
    val onOpenDeveloperEmail: () -> Unit,
    val onLanguageChange: (AppLanguage) -> Unit,
)

@Composable
fun SettingsScreen(
    settings: GlobalSettings,
    profiles: List<ControlProfile>,
    startupProfileId: String,
    appLanguage: AppLanguage,
    callbacks: SettingsScreenCallbacks,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(start = 20.dp, top = 154.dp, end = 20.dp, bottom = 138.dp),
) {
    var showHelp by rememberSaveable { mutableStateOf(false) }
    var showStartupPicker by rememberSaveable { mutableStateOf(false) }
    var showRestoreConfirm by rememberSaveable { mutableStateOf(false) }
    var showPressureCalibration by rememberSaveable { mutableStateOf(false) }
    var showPressureDebug by rememberSaveable { mutableStateOf(false) }
    var showShortcutEditor by rememberSaveable { mutableStateOf(false) }
    var editingShortcut by rememberSaveable { mutableStateOf<TrackpadGestureActionSlot?>(null) }
    val startup = profiles.firstOrNull { it.id == startupProfileId }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") {
            Column {
                Text("设置", style = PcRemoteTypography.ScreenTitle)
                Spacer(Modifier.height(4.dp))
                Text("全局交互、启动模式与使用说明", style = PcRemoteTypography.Body, color = PcRemoteColors.Muted)
            }
        }

        item(key = "interaction") {
            SectionHeading("交互偏好")
            Spacer(Modifier.height(9.dp))
            GlassCard(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
                SettingToggleRow(
                    title = "自动连接上次电脑",
                    subtitle = "打开应用后尝试恢复上一次 HID 连接",
                    checked = settings.autoConnect,
                    onCheckedChange = { callbacks.onSettingsChange(settings.copy(autoConnect = it)) },
                )
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow(
                    title = "震动反馈",
                    subtitle = "成功与失败使用不同触感；模式可单独覆盖",
                    checked = settings.hapticEnabled,
                    onCheckedChange = { callbacks.onSettingsChange(settings.copy(hapticEnabled = it)) },
                )
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow(
                    title = "保持屏幕常亮",
                    subtitle = "控制期间不自动熄屏",
                    checked = settings.keepScreenOn,
                    onCheckedChange = { callbacks.onSettingsChange(settings.copy(keepScreenOn = it)) },
                )
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow(
                    title = "启用混合模式",
                    subtitle = "允许手势与触控板在同一区域进行意图仲裁",
                    checked = settings.hybridModeEnabled,
                    onCheckedChange = { callbacks.onSettingsChange(settings.copy(hybridModeEnabled = it)) },
                )
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow(
                    title = "显示滑动轨迹",
                    subtitle = "绘制手势时在控制板上显示实时蓝色轨迹",
                    checked = settings.showGestureTrail,
                    onCheckedChange = { callbacks.onSettingsChange(settings.copy(showGestureTrail = it)) },
                )
            }
        }

        item(key = "language") {
            SectionHeading(
                stringResource(R.string.language_section),
                subtitle = stringResource(R.string.language_section_subtitle),
            )
            Spacer(Modifier.height(9.dp))
            GlassCard {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        AppLanguage.SYSTEM to stringResource(R.string.language_system),
                        AppLanguage.SIMPLIFIED_CHINESE to stringResource(R.string.language_zh_cn),
                        AppLanguage.ENGLISH to stringResource(R.string.language_english),
                    ).forEach { (language, label) ->
                        GlassActionButton(
                            text = label,
                            onClick = { callbacks.onLanguageChange(language) },
                            modifier = Modifier.fillMaxWidth(),
                            primary = appLanguage == language,
                        )
                    }
                }
            }
        }

        item(key = "gesture") {
            SectionHeading("手势默认值", subtitle = "控制模式中的设置优先于这里")
            Spacer(Modifier.height(9.dp))
            GlassCard {
                ValueSlider(
                    title = "灵敏度",
                    value = settings.gestureSensitivity,
                    valueRange = 0.5f..2f,
                    valueLabel = { "${(it * 100).roundToInt()}%" },
                    onValueCommit = {
                        callbacks.onSettingsChange(settings.copy(gestureSensitivity = it))
                    },
                )
                Spacer(Modifier.height(12.dp))
                ValueSlider(
                    title = "识别置信度",
                    value = settings.confidenceThreshold,
                    valueRange = 0.5f..0.95f,
                    valueLabel = { "${(it * 100).roundToInt()}%" },
                    onValueCommit = {
                        callbacks.onSettingsChange(settings.copy(confidenceThreshold = it))
                    },
                )
            }
        }

        item(key = "trackpad") {
            val trackpad = settings.trackpad
            SectionHeading("触控板", subtitle = "固定全屏模式、滚动与自适应压力")
            Spacer(Modifier.height(9.dp))
            GlassCard {
                ValueSlider(
                    title = "指针灵敏度",
                    value = trackpad.pointerSensitivity,
                    valueRange = 0.5f..2f,
                    valueLabel = { "${(it * 100).roundToInt()}%" },
                    onValueCommit = { value ->
                        callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(pointerSensitivity = value)))
                    },
                )
                Spacer(Modifier.height(9.dp))
                Text("灵敏度预设", style = PcRemoteTypography.Caption)
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(
                        PointerSensitivityPreset.PRECISE to "精准",
                        PointerSensitivityPreset.STANDARD to "标准",
                        PointerSensitivityPreset.FAST to "快速",
                    ).forEach { (preset, label) ->
                        GlassActionButton(
                            text = label,
                            onClick = {
                                val sensitivity = when (preset) {
                                    PointerSensitivityPreset.PRECISE -> 0.72f
                                    PointerSensitivityPreset.STANDARD -> 1f
                                    PointerSensitivityPreset.FAST -> 1.38f
                                    PointerSensitivityPreset.CUSTOM -> trackpad.pointerSensitivity
                                }
                                callbacks.onSettingsChange(
                                    settings.copy(trackpad = trackpad.copy(
                                        sensitivityPreset = preset,
                                        pointerSensitivity = sensitivity,
                                    )),
                                )
                            },
                            modifier = Modifier.weight(1f),
                            primary = trackpad.sensitivityPreset == preset,
                        )
                    }
                }
                Spacer(Modifier.height(9.dp))
                ValueSlider(
                    title = "鼠标加速度",
                    value = trackpad.pointerAcceleration,
                    valueRange = 0f..0.6f,
                    valueLabel = { "${(it * 100).roundToInt()}%" },
                    onValueCommit = { value ->
                        callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(pointerAcceleration = value)))
                    },
                )
                Spacer(Modifier.height(9.dp))
                ValueSlider(
                    title = "滚动速度",
                    value = trackpad.scrollSpeed,
                    valueRange = 0.5f..2f,
                    valueLabel = { "${(it * 100).roundToInt()}%" },
                    onValueCommit = { value ->
                        callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(scrollSpeed = value)))
                    },
                )
                Spacer(Modifier.height(9.dp))
                ValueSlider(
                    title = "双击速度",
                    value = trackpad.doubleTapTimeoutMs.toFloat(),
                    valueRange = 200f..500f,
                    valueLabel = { "${it.roundToInt()}ms" },
                    onValueCommit = { value ->
                        callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(doubleTapTimeoutMs = value.roundToInt().toLong())))
                    },
                )
                Spacer(Modifier.height(9.dp))
                Text("拖拽方式", style = PcRemoteTypography.Caption)
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(
                        TrackpadDragMode.DOUBLE_TAP_HOLD to "双击按住",
                        TrackpadDragMode.LONG_PRESS to "长按",
                        TrackpadDragMode.DOUBLE_TAP_HOLD_OR_LONG_PRESS to "两者",
                    ).forEach { (mode, label) ->
                        GlassActionButton(
                            text = label,
                            onClick = { callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(dragMode = mode))) },
                            modifier = Modifier.weight(1f),
                            primary = trackpad.dragMode == mode,
                        )
                    }
                }
                HorizontalDivider(color = PcRemoteColors.Hairline, modifier = Modifier.padding(top = 8.dp))
                SettingToggleRow("自然滚动", "手指上移时内容向上滚动", trackpad.naturalScrolling) {
                    callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(naturalScrolling = it)))
                }
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow("双指导航", "快速横滑执行自定义的前进或后退动作", trackpad.twoFingerNavigationEnabled) {
                    callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(twoFingerNavigationEnabled = it)))
                }
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow("三指快捷手势", "上、下、左、右与轻点动作均可自定义", trackpad.threeFingerGesturesEnabled) {
                    callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(threeFingerGesturesEnabled = it)))
                }
                HorizontalDivider(color = PcRemoteColors.Hairline)
                InfoActionRow("自定义手势快捷键", "修改双指前进后退与三指手势执行的动作") {
                    showShortcutEditor = true
                }
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow("四指扩展手势", "默认关闭；开启后预留高级扩展", trackpad.fourFingerGesturesEnabled) {
                    callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(fourFingerGesturesEnabled = it)))
                }
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow("显示鼠标按键", "在触控区底部显示左键和右键", trackpad.showMouseButtons) {
                    callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(showMouseButtons = it)))
                }
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow("触控反馈", "点击与模式锁定时提供轻微震动", trackpad.hapticEnabled) {
                    callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(hapticEnabled = it)))
                }
                HorizontalDivider(color = PcRemoteColors.Hairline)
                SettingToggleRow("自适应压力", "压力不可用时自动改用接触面积与按住时长", trackpad.adaptivePressureEnabled) {
                    callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(adaptivePressureEnabled = it)))
                }
                if (trackpad.adaptivePressureEnabled) {
                    Spacer(Modifier.height(8.dp))
                    ValueSlider(
                        title = "压力灵敏度",
                        value = trackpad.pressureSensitivity,
                        valueRange = 0.6f..1.6f,
                        valueLabel = { "${(it * 100).roundToInt()}%" },
                        onValueCommit = { value ->
                            callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(pressureSensitivity = value)))
                        },
                    )
                    Spacer(Modifier.height(9.dp))
                    ValueSlider(
                        title = "正常按压阈值",
                        value = trackpad.normalPressThreshold,
                        valueRange = 0.2f..(trackpad.forcePressThreshold - 0.05f).coerceAtLeast(0.25f),
                        valueLabel = { "${(it * 100).roundToInt()}%" },
                        onValueCommit = { value ->
                            callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(normalPressThreshold = value)))
                        },
                    )
                    Spacer(Modifier.height(9.dp))
                    ValueSlider(
                        title = "重按阈值",
                        value = trackpad.forcePressThreshold,
                        valueRange = (trackpad.normalPressThreshold + 0.05f).coerceAtMost(0.9f)..0.95f,
                        valueLabel = { "${(it * 100).roundToInt()}%" },
                        onValueCommit = { value ->
                            callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(forcePressThreshold = value)))
                        },
                    )
                    HorizontalDivider(color = PcRemoteColors.Hairline, modifier = Modifier.padding(top = 8.dp))
                    SettingToggleRow("重按拖拽", "达到重按阈值时按住鼠标左键；关闭后仅显示强度", trackpad.forcePressAction == ForcePressAction.DRAG) {
                        callbacks.onSettingsChange(
                            settings.copy(trackpad = trackpad.copy(
                                forcePressAction = if (it) ForcePressAction.DRAG else ForcePressAction.NONE,
                            )),
                        )
                    }
                    HorizontalDivider(color = PcRemoteColors.Hairline)
                    SettingToggleRow("压感震动", "首次达到重按状态时提供一次轻微反馈", trackpad.pressureHapticEnabled) {
                        callbacks.onSettingsChange(settings.copy(trackpad = trackpad.copy(pressureHapticEnabled = it)))
                    }
                    HorizontalDivider(color = PcRemoteColors.Hairline, modifier = Modifier.padding(top = 8.dp))
                    InfoActionRow(
                        "压力校准",
                        trackpad.calibration?.let { "已校准 · ${it.sampleCount} 个样本" } ?: "按轻触、正常按压与重按完成设备适配",
                    ) { showPressureCalibration = true }
                    HorizontalDivider(color = PcRemoteColors.Hairline)
                    InfoActionRow("压力调试", "实时查看 pressure、面积与设备信号可靠性") {
                        showPressureDebug = true
                    }
                }
                HorizontalDivider(color = PcRemoteColors.Hairline)
                InfoValueRow("水平滚动回退", "Shift + 滚轮（兼容模式）")
                HorizontalDivider(color = PcRemoteColors.Hairline)
                InfoActionRow("恢复触控板默认设置", "仅重置触控板与压力选项") {
                    callbacks.onSettingsChange(settings.copy(trackpad = TrackpadSettings()))
                }
            }
        }

        item(key = "hand") {
            SectionHeading("左右手与启动")
            Spacer(Modifier.height(9.dp))
            GlassCard {
                Text("主要使用手", style = PcRemoteTypography.Caption)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    listOf(Handedness.LEFT to "左手", Handedness.RIGHT to "右手").forEach { (hand, label) ->
                        GlassActionButton(
                            text = label,
                            onClick = { callbacks.onSettingsChange(settings.copy(handedness = hand)) },
                            modifier = Modifier.weight(1f),
                            primary = settings.handedness == hand,
                        )
                    }
                }
                Spacer(Modifier.height(13.dp))
                Text("启动控制模式", style = PcRemoteTypography.Caption)
                Spacer(Modifier.height(7.dp))
                GlassActionButton(
                    text = startup?.name ?: "选择启动模式",
                    onClick = { showStartupPicker = true },
                    modifier = Modifier.fillMaxWidth(),
                    localizeText = startup?.isSystemProfile != false,
                )
            }
        }

        item(key = "help") {
            SectionHeading("帮助与安全")
            Spacer(Modifier.height(9.dp))
            GlassCard {
                InfoActionRow(
                    title = "快速开始与手势说明",
                    subtitle = "配对、连接、触控板和自定义手势指南",
                    onClick = { showHelp = true },
                )
                HorizontalDivider(color = PcRemoteColors.Hairline)
                InfoActionRow(
                    title = "恢复默认视频模式",
                    subtitle = "不会删除你的其他自定义模式",
                    onClick = { showRestoreConfirm = true },
                )
            }
        }

        item(key = "about") {
            SectionHeading("关于")
            Spacer(Modifier.height(9.dp))
            GlassCard {
                InfoValueRow("应用", "PC遥控器")
                HorizontalDivider(color = PcRemoteColors.Hairline)
                InfoValueRow("版本", "v${BuildConfig.VERSION_NAME}")
                HorizontalDivider(color = PcRemoteColors.Hairline)
                InfoActionRow("开发者联系方式", "lixuxin0919@gmail.com", callbacks.onOpenDeveloperEmail)
            }
            Text(
                text = "需要 Android 9 或更高版本，且手机系统支持 Bluetooth HID Device Profile。",
                style = PcRemoteTypography.Caption,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            )
        }
    }

    if (showStartupPicker) {
        AlertDialog(
            onDismissRequest = { showStartupPicker = false },
            title = { Text("选择启动控制模式") },
            text = {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(profiles.size, key = { profiles[it].id }) { index ->
                        val profile = profiles[index]
                        GlassActionButton(
                            text = profile.name,
                            onClick = {
                                callbacks.onStartupProfileChange(profile.id)
                                showStartupPicker = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                            primary = profile.id == startupProfileId,
                            localizeText = profile.isSystemProfile,
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showStartupPicker = false }) { Text("完成") } },
        )
    }

    if (showHelp) {
        HelpDialog(onDismiss = { showHelp = false })
    }

    if (showRestoreConfirm) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirm = false },
            title = { Text("恢复默认视频模式？") },
            text = { Text("系统模式的名称、控件、动作和手势会恢复初始值；其他模式保持不变。") },
            confirmButton = {
                TextButton(onClick = {
                    callbacks.onRestoreSystemProfile()
                    showRestoreConfirm = false
                }) { Text("恢复") }
            },
            dismissButton = { TextButton(onClick = { showRestoreConfirm = false }) { Text("取消") } },
        )
    }
    if (showPressureCalibration) {
        PressureCalibrationDialog(
            onDismiss = { showPressureCalibration = false },
            onComplete = { calibration ->
                callbacks.onSettingsChange(
                    settings.copy(trackpad = settings.trackpad.copy(
                        calibration = calibration,
                        normalPressThreshold = calibration.normalPressThreshold,
                        forcePressThreshold = calibration.forcePressThreshold,
                    )),
                )
                showPressureCalibration = false
            },
        )
    }
    if (showPressureDebug) {
        PressureDebugDialog(
            settings = settings.trackpad,
            onDismiss = { showPressureDebug = false },
        )
    }
    if (showShortcutEditor) {
        TrackpadShortcutEditorDialog(
            actions = settings.trackpad.gestureActions,
            onEdit = { slot ->
                showShortcutEditor = false
                editingShortcut = slot
            },
            onDismiss = { showShortcutEditor = false },
        )
    }
    editingShortcut?.let { slot ->
        ActionPickerDialog(
            initialAction = settings.trackpad.gestureActions.actionFor(slot),
            availableProfiles = profiles,
            onDismiss = {
                editingShortcut = null
                showShortcutEditor = true
            },
            onConfirm = { action ->
                callbacks.onSettingsChange(
                    settings.copy(trackpad = settings.trackpad.copy(
                        gestureActions = settings.trackpad.gestureActions.withAction(slot, action),
                    )),
                )
                editingShortcut = null
                showShortcutEditor = true
            },
        )
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(role = Role.Switch) { onCheckedChange(!checked) }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = PcRemoteTypography.Caption)
        }
        PcRemoteSwitch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun ValueSlider(
    title: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    valueLabel: (Float) -> String,
    onValueCommit: (Float) -> Unit,
) {
    var draftValue by remember(value, valueRange.start, valueRange.endInclusive) {
        mutableStateOf(value.coerceIn(valueRange))
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(valueLabel(draftValue), color = PcRemoteColors.Primary, fontWeight = FontWeight.SemiBold)
    }
    PcRemoteSlider(
        value = draftValue,
        onValueChange = { draftValue = it },
        onValueChangeFinished = { onValueCommit(draftValue) },
        valueRange = valueRange,
    )
}

@Composable
private fun InfoActionRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = PcRemoteTypography.Caption)
        }
    }
}

@Composable
private fun InfoValueRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 13.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(value, color = PcRemoteColors.Muted)
    }
}

@Composable
private fun HelpDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("使用说明") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { HelpStep("1. 配对电脑", "在设备页进入配对模式，再从 Windows 蓝牙设置添加本手机。") }
                item { HelpStep("2. 连接", "从已配对设备列表点按连接；系统允许时会自动恢复上次电脑。") }
                item { HelpStep("3. 手势控制", "默认模式支持上下左右、轻点；自定义模式可绑定圆圈、X、Z、勾和录制手势。") }
                item { HelpStep("4. 触控板", "单指移动，轻点左键，双击，两指滚动，两指轻点右键，长按后拖动。") }
                item { HelpStep("5. 安全释放", "页面切换、模式切换、断连、退到后台和 30 秒超时都会释放按住的键。") }
                item { HelpStep("能力边界", "纯 HID 不会读取电脑音量、播放或静音状态，界面不会伪造这些状态。") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("知道了") } },
    )
}

@Composable
private fun HelpStep(title: String, detail: String) {
    Column {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(detail, style = PcRemoteTypography.Caption)
    }
}

private enum class CalibrationStage(val title: String, val detail: String) {
    LIGHT("轻触", "像移动光标一样轻轻触摸并移动"),
    NORMAL("正常按压", "使用日常点击的力度按住并移动"),
    FORCE("重按", "用明显更大的力度按住，但不要让手指不适"),
}

@Composable
@OptIn(ExperimentalComposeUiApi::class)
private fun PressureCalibrationDialog(
    onDismiss: () -> Unit,
    onComplete: (com.gunianan.btremote.trackpad.settings.PressureCalibrationProfile) -> Unit,
) {
    var stage by remember { mutableStateOf(CalibrationStage.LIGHT) }
    var light by remember { mutableStateOf(emptyList<TrackpadPointerSample>()) }
    var normal by remember { mutableStateOf(emptyList<TrackpadPointerSample>()) }
    var force by remember { mutableStateOf(emptyList<TrackpadPointerSample>()) }
    var error by remember { mutableStateOf<String?>(null) }
    val currentCount = when (stage) {
        CalibrationStage.LIGHT -> light.size
        CalibrationStage.NORMAL -> normal.size
        CalibrationStage.FORCE -> force.size
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("压力校准 · ${stage.title}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stage.detail, style = PcRemoteTypography.Body)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .background(PcRemoteColors.Primary.copy(alpha = 0.08f), RoundedCornerShape(24.dp))
                        .border(1.dp, PcRemoteColors.Primary.copy(alpha = 0.25f), RoundedCornerShape(24.dp))
                        .pointerInteropFilter { motion ->
                            val samples = TrackpadInputAdapter.from(motion).pointers
                            if (samples.isNotEmpty() && currentCount < 80) {
                                when (stage) {
                                    CalibrationStage.LIGHT -> light = (light + samples).takeLast(80)
                                    CalibrationStage.NORMAL -> normal = (normal + samples).takeLast(80)
                                    CalibrationStage.FORCE -> force = (force + samples).takeLast(80)
                                }
                            }
                            true
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("在这里按压", fontWeight = FontWeight.SemiBold)
                        Text("$currentCount / 20+ 样本", style = PcRemoteTypography.Caption)
                    }
                }
                error?.let { Text(it, color = PcRemoteColors.Error, style = PcRemoteTypography.Caption) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = currentCount >= 20,
                onClick = {
                    when (stage) {
                        CalibrationStage.LIGHT -> stage = CalibrationStage.NORMAL
                        CalibrationStage.NORMAL -> stage = CalibrationStage.FORCE
                        CalibrationStage.FORCE -> {
                            val result = PressureCalibrator.calibrate(
                                PressureCalibrationSamples(light, normal, force),
                                System.currentTimeMillis(),
                            )
                            if (result == null) error = "样本差异不足，请重新完成校准" else onComplete(result)
                        }
                    }
                },
            ) { Text(if (stage == CalibrationStage.FORCE) "完成" else "下一步") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}

@Composable
@OptIn(ExperimentalComposeUiApi::class)
private fun PressureDebugDialog(settings: TrackpadSettings, onDismiss: () -> Unit) {
    var sample by remember { mutableStateOf<TrackpadPointerSample?>(null) }
    var reading by remember { mutableStateOf<PressureReading?>(null) }
    var touchStartedAt by remember { mutableStateOf<Long?>(null) }
    val engine = remember { AdaptivePressureEngine() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("压力调试") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(Color.White.copy(alpha = 0.55f), RoundedCornerShape(24.dp))
                        .border(1.dp, PcRemoteColors.GlassBorder, RoundedCornerShape(24.dp))
                        .pointerInteropFilter { motion ->
                            val event = TrackpadInputAdapter.from(motion)
                            if (event.action == com.gunianan.btremote.trackpad.input.TrackpadPointerEvent.Action.DOWN) {
                                touchStartedAt = event.eventTimeMillis
                                engine.reset()
                            }
                            val current = event.pointers.firstOrNull()
                            sample = current
                            if (current != null && event.action != com.gunianan.btremote.trackpad.input.TrackpadPointerEvent.Action.UP) {
                                reading = engine.evaluate(
                                    current,
                                    event.eventTimeMillis - (touchStartedAt ?: event.eventTimeMillis),
                                    settings,
                                )
                            }
                            if (event.action == com.gunianan.btremote.trackpad.input.TrackpadPointerEvent.Action.UP ||
                                event.action == com.gunianan.btremote.trackpad.input.TrackpadPointerEvent.Action.CANCEL
                            ) {
                                touchStartedAt = null
                                sample = null
                                reading = null
                            }
                            true
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("触摸并改变力度", fontWeight = FontWeight.SemiBold) }
                val current = sample
                InfoValueRow("pressure", current?.pressure?.let { "%.4f".format(it) } ?: "—")
                InfoValueRow("size", current?.size?.let { "%.4f".format(it) } ?: "—")
                InfoValueRow("touchMajor × minor", current?.let { "%.1f × %.1f".format(it.touchMajor, it.touchMinor) } ?: "—")
                InfoValueRow("估算接触面积", current?.let { "%.1f".format(AdaptivePressureEngine.contactArea(it)) } ?: "—")
                InfoValueRow("按压时长", reading?.let { "${it.durationMillis} ms" } ?: "—")
                InfoValueRow("平滑 pressure", reading?.let { "%.4f".format(it.smoothedPressure) } ?: "—")
                InfoValueRow("综合压感", reading?.let { "%.1f%%".format(it.score * 100f) } ?: "—")
                InfoValueRow("当前状态", reading?.debugStateName() ?: "未触摸")
                InfoValueRow("真实压力可靠", reading?.let { if (it.reliable) "是" else "否 · 模拟压感" } ?: "—")
                Text("若 pressure 长期不变，正式模式会自动使用接触面积与按住时长。", style = PcRemoteTypography.Caption)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("完成") } },
    )
}

private fun PressureReading.debugStateName(): String = when {
    simulated && level == PressureLevel.UNRELIABLE -> "数据不可靠"
    simulated -> "模拟压感"
    level == PressureLevel.LIGHT -> "轻触"
    level == PressureLevel.NORMAL -> "正常按压"
    level == PressureLevel.FORCE -> "重按"
    else -> "数据不可靠"
}

@Composable
private fun TrackpadShortcutEditorDialog(
    actions: TrackpadGestureActions,
    onEdit: (TrackpadGestureActionSlot) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("自定义触控板手势") },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 470.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                items(TrackpadGestureActionSlot.entries.size, key = { TrackpadGestureActionSlot.entries[it].name }) { index ->
                    val slot = TrackpadGestureActionSlot.entries[index]
                    InfoActionRow(
                        title = slot.displayName,
                        subtitle = actions.actionFor(slot).displaySummary(),
                        onClick = { onEdit(slot) },
                    )
                    if (index < TrackpadGestureActionSlot.entries.lastIndex) {
                        HorizontalDivider(color = PcRemoteColors.Hairline)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("完成") } },
    )
}
