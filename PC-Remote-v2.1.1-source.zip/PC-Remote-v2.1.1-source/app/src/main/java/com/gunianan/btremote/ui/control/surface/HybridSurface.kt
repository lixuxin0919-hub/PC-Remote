package com.gunianan.btremote.ui.control.surface

import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.gunianan.btremote.gesture.PointSample
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlin.math.hypot

/**
 * Explicit gesture/touchpad arbitration for an opt-in HYBRID profile.
 *
 * Priority is deterministic:
 * 1. Two pointers always become touchpad scroll/right-click.
 * 2. A stationary 500 ms hold becomes mouse drag.
 * 3. Sustained one-finger movement becomes relative mouse movement.
 * 4. A one-finger stroke released before either commitment is sent to the
 *    gesture engine, including tap, double-tap sequences and drawn symbols.
 *
 * [enabled] defaults to false. A profile/editor must deliberately enable this
 * experimental surface; the component never enables hybrid mode globally.
 */
@Composable
fun HybridSurface(
    onStrokeComplete: (List<PointSample>) -> Unit,
    touchpadCallbacks: TouchpadCallbacks,
    modifier: Modifier = Modifier,
    enabled: Boolean = false,
    config: HybridArbitrationConfig = HybridArbitrationConfig(),
    colors: ControlSurfaceColors = ControlSurfaceDefaults.colors(),
    cornerRadius: Dp = 28.dp,
    contentDescription: String = "混合手势与触控板控制区",
    onStrokeCancelled: () -> Unit = {},
    onStrokeStarted: () -> Unit = {},
    content: @Composable BoxScope.() -> Unit = {},
) {
    val currentOnStrokeComplete by rememberUpdatedState(onStrokeComplete)
    val currentTouchpadCallbacks by rememberUpdatedState(touchpadCallbacks)
    val currentOnStrokeCancelled by rememberUpdatedState(onStrokeCancelled)
    val currentOnStrokeStarted by rememberUpdatedState(onStrokeStarted)
    val path = remember { Path() }
    var pathVersion by remember { mutableIntStateOf(0) }
    var activeTouches by remember { mutableStateOf(emptyList<Offset>()) }

    fun clearVisuals() {
        path.reset()
        pathVersion++
        activeTouches = emptyList()
    }

    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 220.dp)
            .controlSurfaceFrame(colors, cornerRadius)
            .semantics {
                this.contentDescription = contentDescription
                if (!enabled) disabled()
            }
            .pointerInput(enabled, config) {
                if (!enabled) {
                    clearVisuals()
                    return@pointerInput
                }
                detectHybridInput(
                    config = config,
                    callbacks = { currentTouchpadCallbacks },
                    onStrokeComplete = { currentOnStrokeComplete(it) },
                    onStrokeStarted = { currentOnStrokeStarted() },
                    onStrokeCancelled = { currentOnStrokeCancelled() },
                    path = path,
                    invalidatePath = { pathVersion++ },
                    updateTouches = { activeTouches = it },
                    clearVisuals = ::clearVisuals,
                )
            },
    ) {
        SurfaceGrid(
            colors = colors.copy(grid = Color.Transparent, touchIndicator = Color.Transparent),
            path = path,
            pathVersion = pathVersion,
            enabled = enabled,
        )
        SurfaceContent(content)
    }
}

private suspend fun PointerInputScope.detectHybridInput(
    config: HybridArbitrationConfig,
    callbacks: () -> TouchpadCallbacks,
    onStrokeComplete: (List<PointSample>) -> Unit,
    onStrokeStarted: () -> Unit,
    onStrokeCancelled: () -> Unit,
    path: Path,
    invalidatePath: () -> Unit,
    updateTouches: (List<Offset>) -> Unit,
    clearVisuals: () -> Unit,
) {
    val gestureConfig = config.gesture
    val touchConfig = config.touchpad
    val minimumSampleDistancePx = gestureConfig.minimumSampleDistance.toPx()
    val movementNoisePx = touchConfig.movementNoise.toPx()
    val longPressSlopPx = touchConfig.longPressSlop.toPx()
    val scrollActivationSlopPx = touchConfig.scrollActivationSlop.toPx()
    val twoFingerTapSlopPx = touchConfig.twoFingerTapSlop.toPx()
    val mouseActivationDistancePx = config.mouseActivationDistance.toPx()

    var activeDrag = false
    var sessionActive = false

    try {
        while (currentCoroutineContext().isActive) {
            awaitPointerEventScope {
                val down = awaitFirstDown(requireUnconsumed = false)
                down.consume()
                sessionActive = true
                onStrokeStarted()
                updateTouches(listOf(down.position))
                path.reset()
                path.moveTo(down.position.x, down.position.y)
                invalidatePath()

                val pointerId = down.id
                val downPosition = down.position
                val downTime = down.uptimeMillis
                val points = ArrayList<PointSample>(128).apply {
                    add(down.asPointSample())
                }
                var lastPosition = down.position
                var lastSamplePosition = down.position
                var lastSampleTime = down.uptimeMillis
                var pathLength = 0f
                var intent = OneFingerIntent.UNDECIDED
                var twoFinger: TwoFingerSession? = null
                var finished = false
                var cancelled = false

                while (!finished) {
                    val event = awaitPointerEvent()
                    val pressed = event.changes.filter { it.pressed }
                    updateTouches(pressed.map { it.position })
                    val twoFingerSession = twoFinger

                    if (twoFingerSession == null) {
                        if (pressed.size > 2) {
                            cancelled = true
                            event.changes.forEach(PointerInputChange::consume)
                            drainPointersAndUpdate(updateTouches)
                            finished = true
                            continue
                        }

                        if (pressed.size == 2) {
                            if (activeDrag) {
                                callbacks().onDragEnd(true)
                                activeDrag = false
                            }
                            // Two fingers have absolute priority. The buffered
                            // one-finger path is discarded and never recognized.
                            path.reset()
                            invalidatePath()
                            twoFinger = TwoFingerSession.start(
                                changes = pressed,
                                startTimeMillis = event.changes.maxOf { it.uptimeMillis },
                            )
                            event.changes.forEach(PointerInputChange::consume)
                            continue
                        }

                        val change = event.changes.firstOrNull { it.id == pointerId }
                        if (change == null) {
                            cancelled = true
                            event.changes.forEach(PointerInputChange::consume)
                            finished = true
                            continue
                        }

                        val delta = change.position - lastPosition
                        val stepDistance = delta.getDistance()
                        val previousPathLength = pathLength
                        pathLength += stepDistance
                        val displacement = offsetDistance(downPosition, change.position)
                        val duration = (change.uptimeMillis - downTime).coerceAtLeast(0L)

                        if (!change.pressed) {
                            when (intent) {
                                OneFingerIntent.DRAG -> {
                                    callbacks().onDragEnd(false)
                                    activeDrag = false
                                }

                                OneFingerIntent.UNDECIDED -> {
                                    appendHybridSample(points, change, gestureConfig.maximumPointCount)
                                    if (change.position != lastSamplePosition) {
                                        path.lineTo(change.position.x, change.position.y)
                                        invalidatePath()
                                    }
                                    onStrokeComplete(points.toList())
                                }

                                OneFingerIntent.MOVE -> Unit
                            }
                            change.consume()
                            finished = true
                            continue
                        }

                        if (intent == OneFingerIntent.UNDECIDED) {
                            intent = when {
                                duration >= touchConfig.longPressDurationMs &&
                                    previousPathLength <= longPressSlopPx -> {
                                    activeDrag = true
                                    path.reset()
                                    invalidatePath()
                                    callbacks().onDragStart(change.position)
                                    OneFingerIntent.DRAG
                                }

                                duration >= config.mouseActivationDurationMs &&
                                    displacement >= mouseActivationDistancePx -> {
                                    path.reset()
                                    invalidatePath()
                                    OneFingerIntent.MOVE
                                }

                                else -> OneFingerIntent.UNDECIDED
                            }
                        }

                        when (intent) {
                            OneFingerIntent.UNDECIDED -> {
                                val sampleDistance = offsetDistance(lastSamplePosition, change.position)
                                val sampleElapsed = change.uptimeMillis - lastSampleTime
                                if (
                                    sampleDistance >= minimumSampleDistancePx ||
                                    sampleElapsed >= gestureConfig.maximumSampleIntervalMs
                                ) {
                                    appendHybridSample(points, change, gestureConfig.maximumPointCount)
                                    path.lineTo(change.position.x, change.position.y)
                                    invalidatePath()
                                    lastSamplePosition = change.position
                                    lastSampleTime = change.uptimeMillis
                                }
                            }

                            OneFingerIntent.MOVE -> if (stepDistance >= movementNoisePx) {
                                callbacks().onMove(delta)
                            }

                            OneFingerIntent.DRAG -> if (stepDistance >= movementNoisePx) {
                                callbacks().onDrag(delta)
                            }
                        }
                        lastPosition = change.position
                        event.changes.forEach(PointerInputChange::consume)
                    } else {
                        val foreignPressedPointer = pressed.any { it.id !in twoFingerSession.pointerIds }
                        if (foreignPressedPointer) {
                            cancelled = true
                            event.changes.forEach(PointerInputChange::consume)
                            drainPointersAndUpdate(updateTouches)
                            finished = true
                            continue
                        }

                        val update = twoFingerSession.update(event.changes)
                        if (update.bothPressed) {
                            if (
                                !twoFingerSession.scrolling &&
                                twoFingerSession.maximumTravel >= scrollActivationSlopPx
                            ) {
                                twoFingerSession.scrolling = true
                            }
                            if (
                                twoFingerSession.scrolling &&
                                update.centroidDelta.getDistance() >= movementNoisePx
                            ) {
                                callbacks().onScroll(update.centroidDelta)
                            }
                        }

                        if (update.allReleased) {
                            val duration = (update.eventTimeMillis - twoFingerSession.startTimeMillis)
                                .coerceAtLeast(0L)
                            if (
                                !twoFingerSession.scrolling &&
                                duration <= touchConfig.twoFingerTapMaximumDurationMs &&
                                twoFingerSession.maximumTravel <= twoFingerTapSlopPx
                            ) {
                                callbacks().onRightClick(twoFingerSession.currentCentroid())
                            }
                            finished = true
                        }
                        event.changes.forEach(PointerInputChange::consume)
                    }
                }

                sessionActive = false
                updateTouches(emptyList())
                if (cancelled) {
                    clearVisuals()
                    onStrokeCancelled()
                    callbacks().onGestureCancelled()
                }
            }
        }
    } catch (cancelled: CancellationException) {
        if (activeDrag) callbacks().onDragEnd(true)
        if (sessionActive) {
            onStrokeCancelled()
            callbacks().onGestureCancelled()
        }
        clearVisuals()
        throw cancelled
    } finally {
        activeDrag = false
        sessionActive = false
        updateTouches(emptyList())
    }
}

private fun PointerInputChange.asPointSample() = PointSample(
    x = position.x,
    y = position.y,
    timeMillis = uptimeMillis,
)

private fun appendHybridSample(
    points: ArrayList<PointSample>,
    change: PointerInputChange,
    maximumPointCount: Int,
) {
    val sample = change.asPointSample()
    val previous = points.lastOrNull()
    if (
        previous != null &&
        previous.x == sample.x &&
        previous.y == sample.y &&
        previous.timeMillis == sample.timeMillis
    ) {
        return
    }
    if (points.size < maximumPointCount) {
        points += sample
    } else {
        points[points.lastIndex] = sample
    }
}
