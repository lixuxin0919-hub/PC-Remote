package com.gunianan.btremote.action

/** Executes normalized commands without exposing transport details to UI or gesture code. */
fun interface RemoteCommandExecutor {
    suspend fun execute(command: RemoteCommand): ActionResult
}

sealed interface ActionResult {
    val isSuccessful: Boolean

    data class Success(
        val executedCommandCount: Int = 1,
        val message: String? = null,
    ) : ActionResult {
        init {
            require(executedCommandCount >= 0) { "executedCommandCount must not be negative" }
        }

        override val isSuccessful: Boolean = true
    }

    data class Ignored(
        val reason: IgnoreReason,
        val message: String? = null,
    ) : ActionResult {
        override val isSuccessful: Boolean = false
    }

    data class Failure(
        val reason: FailureReason,
        val message: String,
        val cause: Throwable? = null,
        val executedCommandCount: Int = 0,
    ) : ActionResult {
        init {
            require(executedCommandCount >= 0) { "executedCommandCount must not be negative" }
        }

        override val isSuccessful: Boolean = false
    }
}

enum class IgnoreReason {
    NO_ACTION,
    NO_ACTIVE_PROFILE,
    CONTROL_NOT_FOUND,
    CONTROL_HIDDEN,
    GESTURE_NOT_FOUND,
    GESTURE_DISABLED,
    LOW_CONFIDENCE,
    DUPLICATE_KEY_DOWN,
    KEY_NOT_PRESSED,
    RATE_LIMITED,
    STALE_SESSION,
    ALREADY_RUNNING,
}

enum class FailureReason {
    EXECUTOR_REJECTED,
    INVALID_ACTION,
    UNSUPPORTED_PHASE,
    SEQUENCE_LIMIT_EXCEEDED,
    SESSION_CLOSED,
    TRANSPORT_FAILURE,
    CALLBACK_FAILURE,
}

