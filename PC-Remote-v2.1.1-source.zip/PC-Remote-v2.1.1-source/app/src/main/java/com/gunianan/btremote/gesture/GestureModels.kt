package com.gunianan.btremote.gesture

/**
 * A touch sample captured with a monotonic clock.
 *
 * [strokeId] is normally zero. Give consecutive taps different IDs when a
 * caller wants the stateless recognizer to classify a multi-stroke gesture
 * such as a double tap.
 */
data class PointSample(
    val x: Float,
    val y: Float,
    val timeMillis: Long,
    val strokeId: Int = 0,
)

enum class RecognitionSource {
    RULE,
    TEMPLATE,
}

data class GestureMatch(
    val gestureId: String,
    val confidence: Float,
    val source: RecognitionSource,
    val displayName: String = gestureId,
)

/**
 * One logical gesture may have several recordings. The first recording is
 * kept in [points] for simple persistence formats and [additionalSamples]
 * stores the remaining recordings.
 */
data class GestureTemplate(
    val id: String,
    val displayName: String,
    val points: List<PointSample>,
    val rotationInvariant: Boolean = true,
    val additionalSamples: List<List<PointSample>> = emptyList(),
) {
    val samples: List<List<PointSample>>
        get() = listOf(points) + additionalSamples
}

data class GestureCandidate(
    val gestureId: String,
    val displayName: String,
    val confidence: Float,
    val source: RecognitionSource,
    /** Index of the closest recording inside a multi-sample template. */
    val sampleIndex: Int? = null,
)

enum class RecognitionFailureReason {
    EMPTY_INPUT,
    INVALID_COORDINATE,
    INVALID_TIMESTAMPS,
    TOO_SHORT,
    TOO_LONG,
    LOW_CONFIDENCE,
    AMBIGUOUS,
    NO_MATCH,
}

data class RecognitionFailure(
    val reason: RecognitionFailureReason,
    val message: String,
)

/**
 * A diagnostic result suitable for editor previews and failure feedback.
 * Failed recognition never contains a match, so callers cannot accidentally
 * execute a low-confidence action.
 */
data class GestureRecognition(
    val match: GestureMatch? = null,
    val candidates: List<GestureCandidate> = emptyList(),
    val failure: RecognitionFailure? = null,
) {
    val isSuccess: Boolean
        get() = match != null
}

data class GestureConflict(
    val existingGestureId: String,
    val existingDisplayName: String,
    val similarity: Float,
    val proposedSampleIndex: Int,
    val existingSampleIndex: Int,
)

/** Runtime tuning values. Profile-level settings can create a new engine. */
data class GestureEngineConfig(
    val templateConfidenceThreshold: Float = 0.72f,
    val ambiguityMargin: Float = 0.055f,
    val minTemplatePathLengthPx: Float = 36f,
    val maxGestureDurationMs: Long = 3_500L,
    val conflictSimilarityThreshold: Float = 0.82f,
) {
    init {
        require(templateConfidenceThreshold in 0f..1f)
        require(ambiguityMargin in 0f..1f)
        require(minTemplatePathLengthPx >= 0f)
        require(maxGestureDurationMs > 0L)
        require(conflictSimilarityThreshold in 0f..1f)
    }
}
