package com.gunianan.btremote.data

import com.gunianan.btremote.domain.AppConfig
import com.gunianan.btremote.domain.ConfigValidator
import com.gunianan.btremote.domain.ControlItem
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.GestureBinding
import com.gunianan.btremote.domain.InternalActionType
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.domain.SYSTEM_DEFAULT_PROFILE_ID
import com.gunianan.btremote.domain.SYSTEM_PROFILE_IDS
import com.gunianan.btremote.domain.SequenceStep
import java.util.UUID

fun interface ProfileIdGenerator {
    fun nextId(): String
}

object UuidProfileIdGenerator : ProfileIdGenerator {
    override fun nextId(): String = "profile.${UUID.randomUUID()}"
}

data class ProfileImportResult(
    val config: AppConfig,
    val importedProfileId: String,
    val idRemapped: Boolean,
)

object ProfileImportService {
    fun importProfile(
        rawJson: String,
        currentConfig: AppConfig,
        now: Long = System.currentTimeMillis(),
        idGenerator: ProfileIdGenerator = UuidProfileIdGenerator,
    ): ProfileImportResult {
        ConfigValidator.validate(currentConfig).requireValid()
        val envelope = ConfigJsonCodec.decodeProfileExport(rawJson)
        val source = envelope.profile
        val occupiedIds = currentConfig.profiles.mapTo(hashSetOf()) { it.id }
        val mustRemap = source.id in SYSTEM_PROFILE_IDS || source.id in occupiedIds
        val importedId = if (mustRemap) nextUniqueId(occupiedIds, idGenerator) else source.id

        val imported = source
            .remapProfileReferences(source.id, importedId)
            .copy(
                id = importedId,
                isDefault = false,
                isSystemProfile = false,
                createdAt = now,
                updatedAt = now,
                customIconPath = null,
            )
        val merged = currentConfig.copy(
            profiles = currentConfig.profiles + imported,
            revision = currentConfig.revision + 1,
        )
        ConfigValidator.validate(merged).requireValid()
        return ProfileImportResult(
            config = merged,
            importedProfileId = importedId,
            idRemapped = mustRemap,
        )
    }

    private fun nextUniqueId(occupiedIds: Set<String>, idGenerator: ProfileIdGenerator): String {
        repeat(32) {
            val candidate = idGenerator.nextId()
            val syntacticallyValid = candidate !in SYSTEM_PROFILE_IDS &&
                candidate.matches(Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$"))
            if (syntacticallyValid && candidate !in occupiedIds) return candidate
        }
        throw IllegalStateException("无法生成唯一的模式 ID")
    }

    private fun ControlProfile.remapProfileReferences(oldId: String, newId: String): ControlProfile {
        if (oldId == newId) return this
        return copy(
            controls = controls.map { it.remapProfileReferences(oldId, newId) },
            gestureBindings = gestureBindings.map { it.remapProfileReferences(oldId, newId) },
        )
    }

    private fun ControlItem.remapProfileReferences(oldId: String, newId: String): ControlItem = copy(
        tapAction = tapAction?.remapProfileReferences(oldId, newId),
        doubleTapAction = doubleTapAction?.remapProfileReferences(oldId, newId),
        longPressAction = longPressAction?.remapProfileReferences(oldId, newId),
        repeatAction = repeatAction?.remapProfileReferences(oldId, newId),
    )

    private fun GestureBinding.remapProfileReferences(oldId: String, newId: String): GestureBinding =
        copy(action = action.remapProfileReferences(oldId, newId))

    private fun RemoteActionConfig.remapProfileReferences(
        oldId: String,
        newId: String,
    ): RemoteActionConfig = when (this) {
        is RemoteActionConfig.InternalAction -> if (
            action == InternalActionType.SWITCH_PROFILE && targetProfileId == oldId
        ) {
            copy(targetProfileId = newId)
        } else {
            this
        }
        is RemoteActionConfig.CustomSequence -> copy(
            steps = steps.map { it.remapProfileReferences(oldId, newId) },
        )
        else -> this
    }

    private fun SequenceStep.remapProfileReferences(oldId: String, newId: String): SequenceStep =
        when (this) {
            is SequenceStep.Tap -> copy(action = action.remapProfileReferences(oldId, newId))
            is SequenceStep.Down -> copy(action = action.remapProfileReferences(oldId, newId))
            is SequenceStep.Up -> copy(action = action.remapProfileReferences(oldId, newId))
            is SequenceStep.Repeat -> copy(action = action.remapProfileReferences(oldId, newId))
            is SequenceStep.Delay -> this
        }
}
