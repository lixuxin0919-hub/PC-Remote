package com.gunianan.btremote.domain

import com.gunianan.btremote.trackpad.settings.TrackpadSettings
import kotlinx.serialization.Serializable

@Serializable
data class AppConfig(
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val profiles: List<ControlProfile>,
    val activeProfileId: String,
    val startupProfileId: String,
    val globalSettings: GlobalSettings = GlobalSettings(),
    /** Monotonically increasing local revision used to avoid stale in-process updates. */
    val revision: Long = 0,
)

@Serializable
data class GlobalSettings(
    val hapticEnabled: Boolean = true,
    val autoConnect: Boolean = true,
    val keepScreenOn: Boolean = true,
    val lastDeviceAddress: String? = null,
    val handedness: Handedness = Handedness.RIGHT,
    val gestureSensitivity: Float = 1.0f,
    val confidenceThreshold: Float = 0.72f,
    val hybridModeEnabled: Boolean = false,
    val showGestureTrail: Boolean = true,
    val trackpad: TrackpadSettings = TrackpadSettings(),
)

@Serializable
data class ProfileExportEnvelope(
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val profile: ControlProfile,
    val iconDataBase64: String? = null,
)
