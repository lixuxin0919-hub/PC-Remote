package com.gunianan.btremote.ui.customize

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import com.gunianan.btremote.ui.components.PcRemoteSlider
import com.gunianan.btremote.ui.components.PcRemoteSwitch
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gunianan.btremote.domain.ControlAreaType
import com.gunianan.btremote.domain.ControlItem
import com.gunianan.btremote.domain.ControlItemSize
import com.gunianan.btremote.domain.ControlLayout
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.ControlSection
import com.gunianan.btremote.domain.GestureBinding
import com.gunianan.btremote.domain.GestureType
import com.gunianan.btremote.domain.GlobalSettings
import com.gunianan.btremote.domain.Handedness
import com.gunianan.btremote.domain.ProfileAppearance
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.SectionHeading
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography
import java.util.UUID
import java.util.Locale
import kotlin.math.roundToInt

/**
 * A fully hoisted profile editor. Every edit produces a new immutable [ControlProfile]; callers
 * decide when and how it is persisted. Controls are reordered in stable list/grid slots only.
 */
@Composable
@OptIn(ExperimentalLayoutApi::class)
fun ProfileEditorScreen(
    profile: ControlProfile,
    globalSettings: GlobalSettings,
    availableProfiles: List<ControlProfile>,
    onProfileChange: (ControlProfile) -> Unit,
    onSave: (ControlProfile) -> Unit,
    onCancel: () -> Unit,
    onOpenHelp: () -> Unit,
    onOpenCustomGestureEditor: (String) -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(start = 20.dp, top = 18.dp, end = 20.dp, bottom = 136.dp),
) {
    var actionTarget by remember { mutableStateOf<EditorActionTarget?>(null) }
    var showAddGestureDialog by rememberSaveable { mutableStateOf(false) }
    val appearance = profile.appearance ?: ProfileAppearance()
    val orderedControls = profile.controls.sortedBy(ControlItem::position)

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 980.dp),
            contentPadding = contentPadding,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item(key = "header") {
                EditorHeader(
                    profile = profile,
                    onCancel = onCancel,
                    onSave = { onSave(profile) },
                )
            }

            item(key = "identity") {
                EditorSection(
                    title = "模式信息",
                    subtitle = if (profile.isSystemProfile) "系统模式可编辑，但不能删除；可随时恢复初始配置" else "名称和图标会显示在控制页的模式切换器中",
                ) {
                    OutlinedTextField(
                        value = profile.name,
                        onValueChange = {
                            onProfileChange(profile.copy(name = it.take(30)))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("模式名称") },
                        supportingText = { Text("${profile.name.length}/30") },
                        singleLine = true,
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("图标", style = PcRemoteTypography.Caption)
                    Spacer(Modifier.height(7.dp))
                    ChoiceFlow(
                        values = ProfileIconChoices,
                        label = { it.label },
                        selected = { profile.icon == it.token },
                        onSelect = { onProfileChange(profile.copy(icon = it.token)) },
                    )
                }
            }

            item(key = "area-type") {
                EditorSection(
                    title = "控制区类型",
                    subtitle = "混合模式会在手势与触控板之间进行意图仲裁，默认仍建议从单一模式开始",
                ) {
                    ChoiceFlow(
                        values = ControlAreaType.entries,
                        label = ControlAreaType::displayName,
                        selected = { profile.controlAreaType == it },
                        onSelect = { onProfileChange(profile.copy(controlAreaType = it)) },
                    )
                }
            }

            item(key = "appearance") {
                AppearanceEditor(
                    appearance = appearance,
                    globalSettings = globalSettings,
                    onChange = { onProfileChange(profile.copy(appearance = it)) },
                )
            }

            item(key = "controls-heading") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    SectionHeading(
                        title = "控件",
                        subtitle = "按固定槽位排序，避免重叠与误触",
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = {
                        val nextPosition = (orderedControls.maxOfOrNull(ControlItem::position) ?: -1) + 1
                        val control = ControlItem(
                            id = "control.${UUID.randomUUID()}",
                            title = "新控件",
                            icon = "custom",
                            position = nextPosition,
                            tapAction = null,
                        )
                        onProfileChange(profile.copy(controls = profile.controls + control))
                    }) { Text("+ 添加控件") }
                }
            }

            if (orderedControls.isEmpty()) {
                item(key = "controls-empty") {
                    EmptyEditorCard("还没有控件", "添加控件后，可分别绑定点击、双击、长按和重复动作。")
                }
            } else {
                itemsIndexed(
                    items = orderedControls,
                    key = { _, item -> item.id },
                ) { index, item ->
                    ControlItemEditor(
                        item = item,
                        canMoveUp = index > 0,
                        canMoveDown = index < orderedControls.lastIndex,
                        onChange = { changed ->
                            onProfileChange(profile.replaceControl(changed))
                        },
                        onMoveUp = { onProfileChange(profile.moveControl(item.id, -1)) },
                        onMoveDown = { onProfileChange(profile.moveControl(item.id, 1)) },
                        onDelete = {
                            onProfileChange(
                                profile.copy(
                                    controls = orderedControls
                                        .filterNot { it.id == item.id }
                                        .mapIndexed { newIndex, existing -> existing.copy(position = newIndex) },
                                ),
                            )
                        },
                        onPickAction = { slot -> actionTarget = EditorActionTarget.Control(item.id, slot) },
                    )
                }
            }

            item(key = "gestures-heading") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    SectionHeading(
                        title = "手势绑定",
                        subtitle = "识别失败或低于阈值时不会发送动作",
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { showAddGestureDialog = true }) { Text("+ 添加手势") }
                }
            }

            if (profile.gestureBindings.isEmpty()) {
                item(key = "gestures-empty") {
                    EmptyEditorCard("还没有手势绑定", "添加方向、点击、图形或触控板手势，并为它选择动作。")
                }
            } else {
                itemsIndexed(
                    items = profile.gestureBindings,
                    key = { _, binding -> binding.id },
                ) { _, binding ->
                    GestureBindingEditor(
                        binding = binding,
                        inheritedThreshold = appearance.confidenceThreshold,
                        onChange = { changed ->
                            onProfileChange(profile.replaceGestureBinding(changed))
                        },
                        onDelete = {
                            onProfileChange(
                                profile.copy(
                                    gestureBindings = profile.gestureBindings.filterNot { it.id == binding.id },
                                ),
                            )
                        },
                        onPickAction = { actionTarget = EditorActionTarget.Gesture(binding.id) },
                    )
                }
            }

            item(key = "support") {
                EditorSection(
                    title = "测试与帮助",
                    subtitle = "保存前可录制自定义手势；操作说明已移入这里，不占用底部标签页",
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GlassActionButton(
                            text = "自定义手势 (${profile.customGestures.size})",
                            onClick = { onOpenCustomGestureEditor(profile.id) },
                            modifier = Modifier.weight(1f),
                            primary = true,
                        )
                        GlassActionButton(
                            text = "编辑帮助",
                            onClick = onOpenHelp,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }
    }

    actionTarget?.let { target ->
        ActionPickerDialog(
            initialAction = target.resolve(profile),
            availableProfiles = availableProfiles,
            onDismiss = { actionTarget = null },
            onConfirm = { selected ->
                onProfileChange(target.apply(profile, selected))
                actionTarget = null
            },
            onClear = {
                onProfileChange(target.clear(profile))
                actionTarget = null
            },
        )
    }

    if (showAddGestureDialog) {
        AddGestureDialog(
            profile = profile,
            onDismiss = { showAddGestureDialog = false },
            onSelect = { gestureType ->
                val binding = GestureBinding(
                    id = "gesture.${UUID.randomUUID()}",
                    gestureType = gestureType,
                    action = RemoteActionConfig.KeyboardKey(0x2C),
                )
                onProfileChange(profile.copy(gestureBindings = profile.gestureBindings + binding))
                showAddGestureDialog = false
                actionTarget = EditorActionTarget.Gesture(binding.id)
            },
            onCustomGesture = {
                showAddGestureDialog = false
                onOpenCustomGestureEditor(profile.id)
            },
        )
    }
}

@Composable
private fun EditorHeader(
    profile: ControlProfile,
    onCancel: () -> Unit,
    onSave: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text("编辑控制模式", style = PcRemoteTypography.ScreenTitle)
            Spacer(Modifier.height(3.dp))
            Text(
                profile.name.ifBlank { "未命名模式" },
                style = PcRemoteTypography.Caption,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        GlassActionButton(text = "取消", onClick = onCancel)
        GlassActionButton(
            text = "保存",
            onClick = onSave,
            primary = true,
            enabled = profile.isEditorSaveable(),
        )
    }
}

@Composable
private fun EditorSection(
    title: String,
    subtitle: String? = null,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    GlassCard(strong = false) {
        SectionHeading(title, subtitle = subtitle)
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun AppearanceEditor(
    appearance: ProfileAppearance,
    globalSettings: GlobalSettings,
    onChange: (ProfileAppearance) -> Unit,
) {
    EditorSection(
        title = "布局与手感",
        subtitle = "所有尺寸均按网格与比例约束，不支持容易产生重叠的自由像素拖拽",
    ) {
        Text("布局", style = PcRemoteTypography.Caption)
        Spacer(Modifier.height(7.dp))
        ChoiceFlow(
            values = ControlLayout.entries,
            label = ControlLayout::displayName,
            selected = { appearance.layout == it },
            onSelect = { onChange(appearance.copy(layout = it)) },
        )

        Spacer(Modifier.height(16.dp))
        ValueSlider(
            title = "网格列数",
            valueLabel = "${appearance.gridColumns} 列",
            value = appearance.gridColumns.toFloat(),
            range = 1f..4f,
            steps = 2,
            onValueChange = { onChange(appearance.copy(gridColumns = it.roundToInt().coerceIn(1, 4))) },
        )
        ValueSlider(
            title = "手势区高度",
            valueLabel = "${(appearance.gestureAreaHeightFraction * 100).roundToInt()}%",
            value = appearance.gestureAreaHeightFraction,
            range = 0.35f..0.85f,
            steps = 9,
            onValueChange = { onChange(appearance.copy(gestureAreaHeightFraction = it)) },
        )
        ValueSlider(
            title = "手势敏感度",
            valueLabel = "${String.format(Locale.ROOT, "%.1f", appearance.gestureSensitivity)}×",
            value = appearance.gestureSensitivity,
            range = 0.5f..2f,
            steps = 14,
            onValueChange = { onChange(appearance.copy(gestureSensitivity = it)) },
        )
        ValueSlider(
            title = "默认置信度阈值",
            valueLabel = "${(appearance.confidenceThreshold * 100).roundToInt()}%",
            value = appearance.confidenceThreshold,
            range = 0.5f..0.95f,
            steps = 8,
            onValueChange = { onChange(appearance.copy(confidenceThreshold = it)) },
        )

        Spacer(Modifier.height(8.dp))
        Text("左右手", style = PcRemoteTypography.Caption)
        Spacer(Modifier.height(7.dp))
        ChoiceFlow(
            values = Handedness.entries,
            label = Handedness::displayName,
            selected = { appearance.handedness == it },
            onSelect = { onChange(appearance.copy(handedness = it)) },
        )

        Spacer(Modifier.height(16.dp))
        Text("触感反馈", style = PcRemoteTypography.Caption)
        Spacer(Modifier.height(7.dp))
        ChoiceFlow(
            values = HapticPreference.entries,
            label = {
                when (it) {
                    HapticPreference.INHERIT -> "跟随全局 (${if (globalSettings.hapticEnabled) "开" else "关"})"
                    HapticPreference.ON -> "开启"
                    HapticPreference.OFF -> "关闭"
                }
            },
            selected = {
                when (it) {
                    HapticPreference.INHERIT -> appearance.hapticEnabled == null
                    HapticPreference.ON -> appearance.hapticEnabled == true
                    HapticPreference.OFF -> appearance.hapticEnabled == false
                }
            },
            onSelect = {
                onChange(
                    appearance.copy(
                        hapticEnabled = when (it) {
                            HapticPreference.INHERIT -> null
                            HapticPreference.ON -> true
                            HapticPreference.OFF -> false
                        },
                    ),
                )
            },
        )
    }
}

@Composable
private fun ControlItemEditor(
    item: ControlItem,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onChange: (ControlItem) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
    onPickAction: (ControlActionSlot) -> Unit,
) {
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("槽位 ${item.position + 1} · ${item.section.displayName()}", style = PcRemoteTypography.Caption)
                Text(
                    item.title.ifBlank { "未命名控件" },
                    color = PcRemoteColors.Text,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text("显示", style = PcRemoteTypography.Caption)
            Spacer(Modifier.padding(horizontal = 3.dp))
            PcRemoteSwitch(checked = item.visible, onCheckedChange = { onChange(item.copy(visible = it)) })
        }

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = item.title,
            onValueChange = { onChange(item.copy(title = it.take(24))) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("控件名称") },
            singleLine = true,
        )

        Spacer(Modifier.height(12.dp))
        Text("尺寸", style = PcRemoteTypography.Caption)
        Spacer(Modifier.height(6.dp))
        ChoiceFlow(
            values = ControlItemSize.entries,
            label = ControlItemSize::displayName,
            selected = { item.size == it },
            onSelect = { onChange(item.copy(size = it)) },
        )

        Spacer(Modifier.height(12.dp))
        Text("区域", style = PcRemoteTypography.Caption)
        Spacer(Modifier.height(6.dp))
        ChoiceFlow(
            values = ControlSection.entries,
            label = ControlSection::displayName,
            selected = { item.section == it },
            onSelect = { onChange(item.copy(section = it)) },
        )

        Spacer(Modifier.height(14.dp))
        HorizontalDivider(color = PcRemoteColors.Hairline)
        Spacer(Modifier.height(10.dp))
        ControlActionSlot.entries.forEach { slot ->
            ActionBindingRow(
                title = slot.label,
                summary = slot.resolve(item).displaySummary(),
                onClick = { onPickAction(slot) },
            )
            if (slot != ControlActionSlot.entries.last()) Spacer(Modifier.height(7.dp))
        }

        Spacer(Modifier.height(13.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallEditorButton("上移", onMoveUp, Modifier.weight(1f), enabled = canMoveUp)
            SmallEditorButton("下移", onMoveDown, Modifier.weight(1f), enabled = canMoveDown)
            SmallEditorButton("删除", onDelete, Modifier.weight(1f), destructive = true)
        }
    }
}

@Composable
private fun GestureBindingEditor(
    binding: GestureBinding,
    inheritedThreshold: Float,
    onChange: (GestureBinding) -> Unit,
    onDelete: () -> Unit,
    onPickAction: () -> Unit,
) {
    val hasOverride = binding.minConfidence != null
    val threshold = binding.minConfidence ?: inheritedThreshold
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(binding.gestureType.displayName(), style = PcRemoteTypography.SectionTitle)
                Spacer(Modifier.height(2.dp))
                Text(binding.action.displaySummary(), style = PcRemoteTypography.Caption)
            }
            Text(if (binding.enabled) "启用" else "停用", style = PcRemoteTypography.Caption)
            Spacer(Modifier.padding(horizontal = 3.dp))
            PcRemoteSwitch(checked = binding.enabled, onCheckedChange = { onChange(binding.copy(enabled = it)) })
        }

        Spacer(Modifier.height(11.dp))
        ActionBindingRow("执行动作", binding.action.displaySummary(), onPickAction)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("单独设置识别阈值", style = PcRemoteTypography.Body)
                Text(
                    if (hasOverride) "当前 ${(threshold * 100).roundToInt()}%" else "跟随模式 ${(threshold * 100).roundToInt()}%",
                    style = PcRemoteTypography.Caption,
                )
            }
            PcRemoteSwitch(
                checked = hasOverride,
                onCheckedChange = {
                    onChange(binding.copy(minConfidence = if (it) inheritedThreshold else null))
                },
            )
        }
        if (hasOverride) {
            PcRemoteSlider(
                value = threshold,
                onValueChange = { onChange(binding.copy(minConfidence = it)) },
                valueRange = 0.5f..0.95f,
                steps = 8,
            )
        }
        TextButton(onClick = onDelete) {
            Text("删除此绑定", color = PcRemoteColors.Error)
        }
    }
}

@Composable
private fun ActionBindingRow(
    title: String,
    summary: String,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = PcRemoteColors.GlassStrong,
            contentColor = PcRemoteColors.Text,
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
        contentPadding = PaddingValues(horizontal = 13.dp, vertical = 10.dp),
    ) {
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
            Text(title, fontSize = 12.sp, color = PcRemoteColors.Muted)
            Text(summary, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("选择", color = PcRemoteColors.PrimaryDeep, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

@Composable
private fun ValueSlider(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    onValueChange: (Float) -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = PcRemoteTypography.Body, modifier = Modifier.weight(1f))
        InlineTag(valueLabel)
    }
    PcRemoteSlider(
        value = value.coerceIn(range.start, range.endInclusive),
        onValueChange = onValueChange,
        valueRange = range,
        steps = steps,
    )
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun <T> ChoiceFlow(
    values: List<T>,
    label: (T) -> String,
    selected: (T) -> Boolean,
    onSelect: (T) -> Unit,
) {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        values.forEach { value ->
            SelectionChip(
                text = label(value),
                selected = selected(value),
                onClick = { onSelect(value) },
            )
        }
    }
}

@Composable
private fun EmptyEditorCard(title: String, body: String) {
    GlassCard {
        Text(title, style = PcRemoteTypography.SectionTitle)
        Spacer(Modifier.height(4.dp))
        Text(body, style = PcRemoteTypography.Body, color = PcRemoteColors.Muted)
    }
}

@Composable
private fun SmallEditorButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    destructive: Boolean = false,
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(42.dp),
        enabled = enabled,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(15.dp),
        contentPadding = PaddingValues(horizontal = 8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (destructive) PcRemoteColors.Error.copy(alpha = 0.09f) else PcRemoteColors.GlassStrong,
            contentColor = if (destructive) PcRemoteColors.Error else PcRemoteColors.Text,
            disabledContainerColor = PcRemoteColors.Glass.copy(alpha = 0.42f),
            disabledContentColor = PcRemoteColors.Muted.copy(alpha = 0.45f),
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
    ) { Text(text, maxLines = 1, fontSize = 13.sp) }
}

@Composable
private fun AddGestureDialog(
    profile: ControlProfile,
    onDismiss: () -> Unit,
    onSelect: (GestureType) -> Unit,
    onCustomGesture: () -> Unit,
) {
    val available = GestureType.entries.filter { type ->
        type != GestureType.CUSTOM && profile.gestureBindings.none { it.gestureType == type }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("添加手势") },
        text = {
            LazyColumn(
                modifier = Modifier.height(420.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item(key = "custom") {
                    SelectionChip(
                        text = "录制自定义手势",
                        selected = false,
                        onClick = onCustomGesture,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                itemsIndexed(available, key = { _, item -> item.name }) { _, item ->
                    SelectionChip(
                        text = item.displayName(),
                        selected = false,
                        onClick = { onSelect(item) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}

private enum class HapticPreference { INHERIT, ON, OFF }

private enum class ControlActionSlot(val label: String) {
    TAP("点击"),
    DOUBLE_TAP("双击"),
    LONG_PRESS("长按"),
    REPEAT("长按重复");

    fun resolve(item: ControlItem): RemoteActionConfig? = when (this) {
        TAP -> item.tapAction
        DOUBLE_TAP -> item.doubleTapAction
        LONG_PRESS -> item.longPressAction
        REPEAT -> item.repeatAction
    }

    fun apply(item: ControlItem, action: RemoteActionConfig?): ControlItem = when (this) {
        TAP -> item.copy(tapAction = action)
        DOUBLE_TAP -> item.copy(doubleTapAction = action)
        LONG_PRESS -> if (action == null) {
            item.copy(longPressAction = null, repeatAction = null)
        } else {
            item.copy(longPressAction = action)
        }
        REPEAT -> if (action != null && item.longPressAction == null) {
            item.copy(longPressAction = action, repeatAction = action)
        } else {
            item.copy(repeatAction = action)
        }
    }
}

private sealed interface EditorActionTarget {
    fun resolve(profile: ControlProfile): RemoteActionConfig?
    fun apply(profile: ControlProfile, action: RemoteActionConfig): ControlProfile
    fun clear(profile: ControlProfile): ControlProfile

    data class Control(val controlId: String, val slot: ControlActionSlot) : EditorActionTarget {
        override fun resolve(profile: ControlProfile): RemoteActionConfig? =
            profile.controls.firstOrNull { it.id == controlId }?.let(slot::resolve)

        override fun apply(profile: ControlProfile, action: RemoteActionConfig): ControlProfile =
            profile.updateControl(controlId) { slot.apply(it, action) }

        override fun clear(profile: ControlProfile): ControlProfile =
            profile.updateControl(controlId) { slot.apply(it, null) }
    }

    data class Gesture(val bindingId: String) : EditorActionTarget {
        override fun resolve(profile: ControlProfile): RemoteActionConfig? =
            profile.gestureBindings.firstOrNull { it.id == bindingId }?.action

        override fun apply(profile: ControlProfile, action: RemoteActionConfig): ControlProfile =
            profile.updateGesture(bindingId) { it.copy(action = action) }

        override fun clear(profile: ControlProfile): ControlProfile = profile
    }
}

private fun ControlProfile.replaceControl(changed: ControlItem): ControlProfile =
    copy(controls = controls.map { if (it.id == changed.id) changed else it })

private fun ControlProfile.isEditorSaveable(): Boolean =
    name.isNotBlank() && controls.all { control ->
        val hasAction = control.tapAction != null ||
            control.doubleTapAction != null ||
            control.longPressAction != null ||
            control.repeatAction != null
        (!control.visible || hasAction) &&
            (control.repeatAction == null || control.longPressAction != null)
    }

private fun ControlProfile.updateControl(
    controlId: String,
    transform: (ControlItem) -> ControlItem,
): ControlProfile = copy(controls = controls.map { if (it.id == controlId) transform(it) else it })

private fun ControlProfile.moveControl(controlId: String, direction: Int): ControlProfile {
    val ordered = controls.sortedBy(ControlItem::position).toMutableList()
    val from = ordered.indexOfFirst { it.id == controlId }
    if (from < 0) return this
    val to = (from + direction).coerceIn(0, ordered.lastIndex)
    if (from == to) return this
    val moved = ordered.removeAt(from)
    ordered.add(to, moved)
    return copy(controls = ordered.mapIndexed { index, item -> item.copy(position = index) })
}

private fun ControlProfile.replaceGestureBinding(changed: GestureBinding): ControlProfile =
    copy(gestureBindings = gestureBindings.map { if (it.id == changed.id) changed else it })

private fun ControlProfile.updateGesture(
    bindingId: String,
    transform: (GestureBinding) -> GestureBinding,
): ControlProfile = copy(
    gestureBindings = gestureBindings.map { if (it.id == bindingId) transform(it) else it },
)
