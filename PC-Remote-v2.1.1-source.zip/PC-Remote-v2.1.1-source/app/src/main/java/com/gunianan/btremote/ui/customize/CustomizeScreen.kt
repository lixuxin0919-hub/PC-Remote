package com.gunianan.btremote.ui.customize

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gunianan.btremote.data.ConfigJsonCodec
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.SYSTEM_DEFAULT_PROFILE_ID
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.AssetIcon
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.SectionHeading
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography

/**
 * Hoisted profile management screen. Persistent state is owned by the caller; only short-lived
 * dialog input is kept locally so process/config updates can be rendered without hidden copies.
 */
@Composable
fun CustomizeScreen(
    profiles: List<ControlProfile>,
    activeProfileId: String,
    startupProfileId: String,
    schemaVersion: Int,
    onSelectProfile: (String) -> Unit,
    onCreateBlank: () -> Unit,
    onCopyProfile: (String) -> Unit,
    onEditProfile: (String) -> Unit,
    onRenameProfile: (profileId: String, name: String) -> Unit,
    onChangeIcon: (profileId: String, iconToken: String) -> Unit,
    onPickIconPhoto: (String) -> Unit,
    onPickIconFile: (String) -> Unit,
    onRemoveCustomIcon: (String) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onMoveProfile: (profileId: String, direction: Int) -> Unit,
    onSetStartupProfile: (String) -> Unit,
    onImportProfile: (String) -> Boolean,
    onExportProfile: (String) -> Unit,
    onRestoreSystemProfile: () -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(start = 20.dp, top = 18.dp, end = 20.dp, bottom = 136.dp),
) {
    var renameProfileId by rememberSaveable { mutableStateOf<String?>(null) }
    var renameValue by rememberSaveable { mutableStateOf("") }
    var iconProfileId by rememberSaveable { mutableStateOf<String?>(null) }
    var deleteProfileId by rememberSaveable { mutableStateOf<String?>(null) }
    var showImportDialog by rememberSaveable { mutableStateOf(false) }
    var importValue by remember { mutableStateOf("") }
    var showRestoreDialog by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier,
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") {
            Column {
                Text("自定义", style = PcRemoteTypography.ScreenTitle)
                Spacer(Modifier.height(5.dp))
                Text(
                    "创建适合不同软件与工作流的控制模式",
                    style = PcRemoteTypography.Body,
                    color = PcRemoteColors.Muted,
                )
            }
        }

        item(key = "overview") {
            GlassCard(strong = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("控制模式", style = PcRemoteTypography.SectionTitle)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "${profiles.size} 个模式 · 设置会自动保存",
                            style = PcRemoteTypography.Caption,
                        )
                    }
                    InlineTag("Schema v$schemaVersion")
                }
            }
        }

        item(key = "create") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeading("新建模式", subtitle = "从空白开始，或复制一个可用模板")
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    if (maxWidth >= 560.dp) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            GlassActionButton(
                                text = "新建空白",
                                onClick = onCreateBlank,
                                modifier = Modifier.weight(1f),
                                primary = true,
                            )
                            GlassActionButton(
                                text = "复制默认视频模式",
                                onClick = { onCopyProfile(SYSTEM_DEFAULT_PROFILE_ID) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            GlassActionButton(
                                text = "新建空白",
                                onClick = onCreateBlank,
                                modifier = Modifier.fillMaxWidth(),
                                primary = true,
                            )
                            GlassActionButton(
                                text = "复制默认视频模式",
                                onClick = { onCopyProfile(SYSTEM_DEFAULT_PROFILE_ID) },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
            }
        }

        item(key = "profile-heading") {
            SectionHeading("我的控制模式", subtitle = "点按卡片切换当前模式；编辑不会影响其他模式")
        }

        itemsIndexed(
            items = profiles,
            key = { _, profile -> profile.id },
            contentType = { _, _ -> "control_profile" },
        ) { index, profile ->
            ProfileManagementCard(
                profile = profile,
                isActive = profile.id == activeProfileId,
                isStartup = profile.id == startupProfileId,
                canMoveUp = index > 0,
                canMoveDown = index < profiles.lastIndex,
                onSelect = { onSelectProfile(profile.id) },
                onEdit = { onEditProfile(profile.id) },
                onCopy = { onCopyProfile(profile.id) },
                onRename = {
                    renameProfileId = profile.id
                    renameValue = profile.name
                },
                onChangeIcon = { iconProfileId = profile.id },
                onDelete = { deleteProfileId = profile.id },
                onMoveUp = { onMoveProfile(profile.id, -1) },
                onMoveDown = { onMoveProfile(profile.id, 1) },
                onSetStartup = { onSetStartupProfile(profile.id) },
                onExport = { onExportProfile(profile.id) },
            )
        }

        item(key = "data-tools") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeading("配置与恢复", subtitle = "JSON 导入会校验版本与 ID 冲突，不会覆盖系统模式")
                GlassCard {
                    GlassActionButton(
                        text = "导入模式 JSON",
                        onClick = { showImportDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(10.dp))
                    GlassActionButton(
                        text = "恢复系统默认模式",
                        onClick = { showRestoreDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }

    val renameProfile = profiles.firstOrNull { it.id == renameProfileId }
    if (renameProfileId != null && renameProfile != null) {
        AlertDialog(
            onDismissRequest = { renameProfileId = null },
            title = { Text("重命名控制模式") },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it.take(30) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("模式名称") },
                    supportingText = { Text("${renameValue.length}/30") },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onRenameProfile(renameProfile.id, renameValue.trim())
                        renameProfileId = null
                    },
                    enabled = renameValue.isNotBlank(),
                ) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { renameProfileId = null }) { Text("取消") } },
        )
    }

    val iconProfile = profiles.firstOrNull { it.id == iconProfileId }
    if (iconProfileId != null && iconProfile != null) {
        AlertDialog(
            onDismissRequest = { iconProfileId = null },
            title = { Text("选择模式图标") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProfileIconChoices.chunked(2).forEach { rowChoices ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowChoices.forEach { choice ->
                                SelectionChip(
                                    text = choice.label,
                                    selected = iconProfile.icon == choice.token,
                                    onClick = {
                                        onChangeIcon(iconProfile.id, choice.token)
                                        iconProfileId = null
                                    },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            if (rowChoices.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                    TwoColumnActions(
                        first = { SelectionChip("从相册选择", false, { onPickIconPhoto(iconProfile.id); iconProfileId = null }, Modifier.fillMaxWidth()) },
                        second = { SelectionChip("从文件选择", false, { onPickIconFile(iconProfile.id); iconProfileId = null }, Modifier.fillMaxWidth()) },
                    )
                    if (iconProfile.customIconPath != null) {
                        SelectionChip("移除自定义图标", false, { onRemoveCustomIcon(iconProfile.id); iconProfileId = null }, Modifier.fillMaxWidth())
                    }
                }
            },
            confirmButton = { TextButton(onClick = { iconProfileId = null }) { Text("完成") } },
        )
    }

    val deleteProfile = profiles.firstOrNull { it.id == deleteProfileId }
    if (deleteProfileId != null && deleteProfile != null) {
        AlertDialog(
            onDismissRequest = { deleteProfileId = null },
            title = { Text("删除控制模式？") },
            text = {
                Text("删除“${deleteProfile.name}”后，其控件、手势配置和自定义图标也会被移除。\n此操作无法撤销。")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteProfile(deleteProfile.id)
                        deleteProfileId = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = PcRemoteColors.Error),
                ) { Text("删除") }
            },
            dismissButton = { TextButton(onClick = { deleteProfileId = null }) { Text("取消") } },
        )
    }

    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("导入控制模式") },
            text = {
                OutlinedTextField(
                    value = importValue,
                    onValueChange = { importValue = it.take(ConfigJsonCodec.MAX_JSON_CHARS) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 6,
                    maxLines = 12,
                    label = { Text("粘贴 JSON") },
                    supportingText = {
                        Text("Schema v1 · ${importValue.length}/${ConfigJsonCodec.MAX_JSON_CHARS}")
                    },
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (onImportProfile(importValue.trim())) {
                            importValue = ""
                            showImportDialog = false
                        }
                    },
                    enabled = importValue.isNotBlank(),
                ) { Text("校验并导入") }
            },
            dismissButton = { TextButton(onClick = { showImportDialog = false }) { Text("取消") } },
        )
    }

    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("恢复默认视频模式？") },
            text = { Text("系统模式会恢复为首次启动时的控件与手势。你创建的其他模式不会被删除。") },
            confirmButton = {
                TextButton(onClick = {
                    onRestoreSystemProfile()
                    showRestoreDialog = false
                }) { Text("恢复") }
            },
            dismissButton = { TextButton(onClick = { showRestoreDialog = false }) { Text("取消") } },
        )
    }
}

@Composable
private fun ProfileManagementCard(
    profile: ControlProfile,
    isActive: Boolean,
    isStartup: Boolean,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onRename: () -> Unit,
    onChangeIcon: () -> Unit,
    onDelete: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onSetStartup: () -> Unit,
    onExport: () -> Unit,
) {
    GlassCard(
        strong = isActive,
        onClick = onSelect,
        contentPadding = PaddingValues(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            com.gunianan.btremote.ui.ProfileIconView(profile, Modifier.size(48.dp), PcRemoteColors.PrimaryDeep)
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    profile.name,
                    color = PcRemoteColors.Text,
                    fontSize = 17.sp,
                    lineHeight = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    localize = profile.isSystemProfile,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    "${profile.controlAreaType.displayName()} · ${profile.controls.count { it.visible }} 个控件 · ${profile.gestureBindings.count { it.enabled }} 个手势",
                    style = PcRemoteTypography.Caption,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (profile.isSystemProfile) InlineTag("系统")
            if (isActive) InlineTag("当前", tint = PcRemoteColors.Success)
            if (isStartup) InlineTag("启动", tint = PcRemoteColors.Warning)
        }

        Spacer(Modifier.height(13.dp))
        TwoColumnActions(
            first = {
                CompactManagementButton("编辑", onEdit, Modifier.fillMaxWidth(), primary = true)
            },
            second = {
                CompactManagementButton("复制", onCopy, Modifier.fillMaxWidth())
            },
        )
        Spacer(Modifier.height(8.dp))
        TwoColumnActions(
            first = { CompactManagementButton("重命名", onRename, Modifier.fillMaxWidth()) },
            second = { CompactManagementButton("更换图标", onChangeIcon, Modifier.fillMaxWidth()) },
        )
        Spacer(Modifier.height(8.dp))
        TwoColumnActions(
            first = { CompactManagementButton("上移", onMoveUp, Modifier.fillMaxWidth(), enabled = canMoveUp) },
            second = { CompactManagementButton("下移", onMoveDown, Modifier.fillMaxWidth(), enabled = canMoveDown) },
        )
        Spacer(Modifier.height(8.dp))
        TwoColumnActions(
            first = {
                CompactManagementButton(
                    if (isStartup) "已设为启动" else "设为启动",
                    onSetStartup,
                    Modifier.fillMaxWidth(),
                    enabled = !isStartup,
                )
            },
            second = { CompactManagementButton("导出 JSON", onExport, Modifier.fillMaxWidth()) },
        )
        if (!profile.isSystemProfile) {
            Spacer(Modifier.height(8.dp))
            DestructiveManagementButton(
                text = "删除此模式",
                onClick = onDelete,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun DestructiveManagementButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(18.dp)
    val interactionSource = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .height(52.dp)
            .clip(shape)
            .background(PcRemoteColors.Error.copy(alpha = 0.10f))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = PcRemoteColors.Error,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun CompactManagementButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    destructive: Boolean = false,
    enabled: Boolean = true,
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        contentPadding = PaddingValues(horizontal = 10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = when {
                destructive -> PcRemoteColors.Error.copy(alpha = 0.09f)
                primary -> PcRemoteColors.Primary
                else -> PcRemoteColors.GlassStrong
            },
            contentColor = when {
                destructive -> PcRemoteColors.Error
                primary -> androidx.compose.ui.graphics.Color.White
                else -> PcRemoteColors.Text
            },
            disabledContainerColor = PcRemoteColors.Glass.copy(alpha = 0.45f),
            disabledContentColor = PcRemoteColors.Muted.copy(alpha = 0.5f),
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 1.dp, pressedElevation = 0.dp),
    ) {
        Text(text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
