package com.gunianan.btremote.trackpad.gesture

import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.trackpad.input.TrackpadPointerEvent
import com.gunianan.btremote.trackpad.input.TrackpadPointerSample
import com.gunianan.btremote.trackpad.pressure.AdaptivePressureEngine
import com.gunianan.btremote.trackpad.pressure.PressureLevel
import com.gunianan.btremote.trackpad.pressure.PressureReading
import com.gunianan.btremote.trackpad.settings.TrackpadDragMode
import com.gunianan.btremote.trackpad.settings.TrackpadSettings
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.ln

sealed interface TrackpadGestureOutput {
    data class MovePointer(val deltaX: Int, val deltaY: Int) : TrackpadGestureOutput
    data class Click(val button: MouseButton, val count: Int = 1) : TrackpadGestureOutput
    data class SetButton(val button: MouseButton, val pressed: Boolean) : TrackpadGestureOutput
    data class Scroll(val vertical: Int) : TrackpadGestureOutput
    data class ModifiedScroll(val modifier: KeyboardModifier, val vertical: Int) : TrackpadGestureOutput
    data class ConfiguredAction(val action: RemoteActionConfig) : TrackpadGestureOutput
    data class FourFingerExtension(val deltaX: Float, val deltaY: Float) : TrackpadGestureOutput
    data class PressureChanged(val reading: PressureReading) : TrackpadGestureOutput
    data object PressureCleared : TrackpadGestureOutput
    data object Cancelled : TrackpadGestureOutput
}

enum class TrackpadGestureState {
    IDLE,
    ONE_FINGER_CANDIDATE,
    ONE_FINGER_MOVE,
    DOUBLE_TAP_PENDING,
    DRAGGING,
    PRESSURE_CANDIDATE,
    PRESSURE_DRAGGING,
    TWO_FINGER_CANDIDATE,
    TWO_FINGER_TAP,
    TWO_FINGER_SCROLL,
    TWO_FINGER_HORIZONTAL_SCROLL,
    TWO_FINGER_PINCH,
    TWO_FINGER_SWIPE,
    THREE_FINGER_CANDIDATE,
    THREE_FINGER_TAP,
    THREE_FINGER_SWIPE,
    FOUR_FINGER_CANDIDATE,
    GESTURE_CANCELLED,
}

/** Pure gesture arbiter. Pointer-count priority is 4 > 3 > 2 > 1 and never downgrades mid-gesture. */
class TrackpadGestureStateMachine(
    private var settings: TrackpadSettings,
) {
    private val pressure = AdaptivePressureEngine()
    private var startTime = 0L
    private var maxPointerCount = 0
    private var startCenter = Point.ZERO
    private var previousCenter = Point.ZERO
    private var previousDistance = 0f
    private var movedDistance = 0f
    private var dragActive = false
    private var twoFingerLocked = TwoFingerMode.NONE
    private var wheelRemainder = 0f
    private var lastTapTime = Long.MIN_VALUE
    private var lastTapPosition = Point.ZERO
    private var doubleTapCandidate = false
    private var pointerRemainderX = 0f
    private var pointerRemainderY = 0f
    private var tapSuppressed = false
    private var horizontalScrollEmitted = false
    var state: TrackpadGestureState = TrackpadGestureState.IDLE
        private set

    fun updateSettings(value: TrackpadSettings) { settings = value }

    fun onEvent(event: TrackpadPointerEvent): List<TrackpadGestureOutput> {
        if (event.action == TrackpadPointerEvent.Action.CANCEL || event.pointers.isEmpty()) {
            return cancel()
        }
        val outputs = mutableListOf<TrackpadGestureOutput>()
        val center = center(event.pointers)
        val pointerCount = event.pointers.size
        if (event.action == TrackpadPointerEvent.Action.DOWN) {
            resetGesture(event.eventTimeMillis, pointerCount, center, event.pointers)
            return outputs
        }
        if (event.action == TrackpadPointerEvent.Action.POINTER_DOWN) {
            if (dragActive) {
                outputs += TrackpadGestureOutput.SetButton(MouseButton.LEFT, false)
                dragActive = false
            }
            pressure.reset()
            maxPointerCount = maxOf(maxPointerCount, pointerCount)
            startCenter = center
            previousCenter = center
            previousDistance = averageDistance(event.pointers, center)
            movedDistance = 0f
            twoFingerLocked = TwoFingerMode.NONE
            state = when (pointerCount) {
                2 -> TrackpadGestureState.TWO_FINGER_CANDIDATE
                3 -> TrackpadGestureState.THREE_FINGER_CANDIDATE
                else -> TrackpadGestureState.FOUR_FINGER_CANDIDATE
            }
            return outputs
        }
        if (event.action == TrackpadPointerEvent.Action.MOVE) {
            maxPointerCount = maxOf(maxPointerCount, pointerCount)
            val dx = center.x - previousCenter.x
            val dy = center.y - previousCenter.y
            movedDistance += hypot(dx, dy)
            when (maxPointerCount) {
                1 -> handleOneFinger(event, dx, dy, outputs)
                2 -> handleTwoFinger(event, center, dx, dy, outputs)
                else -> Unit
            }
            previousCenter = center
            return outputs
        }
        if (event.action == TrackpadPointerEvent.Action.POINTER_UP || event.action == TrackpadPointerEvent.Action.UP) {
            val completedPointerCount = maxPointerCount
            finishGesture(event, center, outputs)
            outputs += TrackpadGestureOutput.PressureCleared
            val survivors = if (event.action == TrackpadPointerEvent.Action.POINTER_UP) {
                event.pointers.filterNot { it.id == event.changedPointerId }
            } else {
                emptyList()
            }
            if (completedPointerCount == 2 && survivors.size == 1) {
                resetGesture(event.eventTimeMillis, 1, center(survivors), survivors)
                tapSuppressed = true
            } else {
                resetAfterFinish()
            }
        }
        return outputs
    }

    fun cancel(): List<TrackpadGestureOutput> {
        state = TrackpadGestureState.GESTURE_CANCELLED
        val outputs = buildList {
            if (dragActive) add(TrackpadGestureOutput.SetButton(MouseButton.LEFT, false))
            add(TrackpadGestureOutput.PressureCleared)
            add(TrackpadGestureOutput.Cancelled)
        }
        resetAfterFinish()
        return outputs
    }

    private fun handleOneFinger(
        event: TrackpadPointerEvent,
        dx: Float,
        dy: Float,
        outputs: MutableList<TrackpadGestureOutput>,
    ) {
        val sample = event.pointers.first()
        if (settings.adaptivePressureEnabled) {
            val reading = pressure.evaluate(sample, event.eventTimeMillis - startTime, settings)
            outputs += TrackpadGestureOutput.PressureChanged(reading)
            if (!dragActive && reading.level == PressureLevel.FORCE && settings.forcePressAction.name == "DRAG") {
                dragActive = true
                state = TrackpadGestureState.PRESSURE_DRAGGING
                outputs += TrackpadGestureOutput.SetButton(MouseButton.LEFT, true)
            }
        }
        val longPressAllowed = settings.dragMode != TrackpadDragMode.DOUBLE_TAP_HOLD
        val doubleTapDragAllowed = settings.dragMode != TrackpadDragMode.LONG_PRESS
        if (!dragActive && doubleTapCandidate && doubleTapDragAllowed &&
            (movedDistance >= DOUBLE_TAP_DRAG_SLOP || event.eventTimeMillis - startTime >= DOUBLE_TAP_DRAG_HOLD_MS)
        ) {
            dragActive = true
            state = TrackpadGestureState.DRAGGING
            outputs += TrackpadGestureOutput.SetButton(MouseButton.LEFT, true)
        }
        if (!dragActive && longPressAllowed && event.eventTimeMillis - startTime >= LONG_PRESS_MS && movedDistance < LONG_PRESS_SLOP) {
            dragActive = true
            state = TrackpadGestureState.DRAGGING
            outputs += TrackpadGestureOutput.SetButton(MouseButton.LEFT, true)
        }
        val gain = settings.pointerSensitivity * (1f + settings.pointerAcceleration * ln(1f + hypot(dx, dy)))
        if (!dragActive && (abs(dx) >= 0.1f || abs(dy) >= 0.1f)) {
            state = if (settings.adaptivePressureEnabled) {
                TrackpadGestureState.PRESSURE_CANDIDATE
            } else {
                TrackpadGestureState.ONE_FINGER_MOVE
            }
        }
        pointerRemainderX += dx * gain
        pointerRemainderY += dy * gain
        while (abs(pointerRemainderX) >= 1f || abs(pointerRemainderY) >= 1f) {
            val moveX = pointerRemainderX.toInt().coerceIn(-127, 127)
            val moveY = pointerRemainderY.toInt().coerceIn(-127, 127)
            if (moveX == 0 && moveY == 0) break
            outputs += TrackpadGestureOutput.MovePointer(moveX, moveY)
            pointerRemainderX -= moveX
            pointerRemainderY -= moveY
        }
    }

    private fun handleTwoFinger(
        event: TrackpadPointerEvent,
        center: Point,
        dx: Float,
        dy: Float,
        outputs: MutableList<TrackpadGestureOutput>,
    ) {
        val distance = averageDistance(event.pointers, center)
        val distanceDelta = distance - previousDistance
        if (twoFingerLocked == TwoFingerMode.NONE) {
            twoFingerLocked = when {
                abs(distanceDelta) >= PINCH_LOCK_DELTA -> TwoFingerMode.PINCH
                abs(dy) >= AXIS_LOCK_DELTA && abs(dy) > abs(dx) * 1.15f -> TwoFingerMode.VERTICAL
                abs(dx) >= AXIS_LOCK_DELTA && abs(dx) > abs(dy) * 1.15f -> TwoFingerMode.HORIZONTAL
                else -> TwoFingerMode.NONE
            }
        }
        when (twoFingerLocked) {
            TwoFingerMode.PINCH -> emitWheel(distanceDelta * 0.32f, outputs) {
                TrackpadGestureOutput.ModifiedScroll(KeyboardModifier.LEFT_CONTROL, it)
            }.also { state = TrackpadGestureState.TWO_FINGER_PINCH }
            TwoFingerMode.VERTICAL -> {
                state = TrackpadGestureState.TWO_FINGER_SCROLL
                val direction = if (settings.naturalScrolling) -1f else 1f
                emitWheel(dy * direction * settings.scrollSpeed * 0.16f, outputs) { TrackpadGestureOutput.Scroll(it) }
            }
            TwoFingerMode.HORIZONTAL -> if (event.eventTimeMillis - startTime > NAVIGATION_MAX_MS) {
                state = TrackpadGestureState.TWO_FINGER_HORIZONTAL_SCROLL
                val outputCountBefore = outputs.size
                emitWheel(dx * settings.scrollSpeed * 0.15f, outputs) {
                    TrackpadGestureOutput.ModifiedScroll(KeyboardModifier.LEFT_SHIFT, it)
                }
                horizontalScrollEmitted = horizontalScrollEmitted || outputs.size > outputCountBefore
            }
            TwoFingerMode.NONE -> Unit
        }
        previousDistance = distance
    }

    private fun finishGesture(
        event: TrackpadPointerEvent,
        center: Point,
        outputs: MutableList<TrackpadGestureOutput>,
    ) {
        val duration = event.eventTimeMillis - startTime
        val totalX = center.x - startCenter.x
        val totalY = center.y - startCenter.y
        when (maxPointerCount) {
            1 -> {
                if (dragActive) {
                    outputs += TrackpadGestureOutput.SetButton(MouseButton.LEFT, false)
                } else if (!tapSuppressed && movedDistance <= TAP_SLOP && duration <= TAP_TIMEOUT_MS) {
                    val isDouble = event.eventTimeMillis - lastTapTime <= settings.doubleTapTimeoutMs &&
                        hypot(center.x - lastTapPosition.x, center.y - lastTapPosition.y) <= DOUBLE_TAP_SLOP
                    outputs += TrackpadGestureOutput.Click(MouseButton.LEFT, if (isDouble) 1 else 1)
                    lastTapTime = event.eventTimeMillis
                    lastTapPosition = center
                }
            }
            2 -> when {
                twoFingerLocked == TwoFingerMode.NONE &&
                    movedDistance <= TWO_FINGER_TAP_SLOP && duration <= TAP_TIMEOUT_MS ->
                    outputs += TrackpadGestureOutput.Click(MouseButton.RIGHT).also {
                        state = TrackpadGestureState.TWO_FINGER_TAP
                    }
                twoFingerLocked == TwoFingerMode.HORIZONTAL && settings.twoFingerNavigationEnabled &&
                    abs(totalX) >= NAVIGATION_THRESHOLD && duration <= NAVIGATION_MAX_MS ->
                    outputs += TrackpadGestureOutput.ConfiguredAction(
                        if (totalX > 0) settings.gestureActions.twoFingerForward
                        else settings.gestureActions.twoFingerBack,
                    ).also { state = TrackpadGestureState.TWO_FINGER_SWIPE }
                twoFingerLocked == TwoFingerMode.HORIZONTAL && !horizontalScrollEmitted -> {
                    val wheel = (totalX * 0.12f).toInt().coerceIn(-127, 127)
                    if (wheel != 0) outputs += TrackpadGestureOutput.ModifiedScroll(KeyboardModifier.LEFT_SHIFT, wheel)
                }
            }
            3 -> if (settings.threeFingerGesturesEnabled) {
                val action = when {
                    abs(totalY) > abs(totalX) && totalY < -THREE_FINGER_THRESHOLD -> settings.gestureActions.threeFingerUp
                    abs(totalY) > abs(totalX) && totalY > THREE_FINGER_THRESHOLD -> settings.gestureActions.threeFingerDown
                    totalX < -THREE_FINGER_THRESHOLD -> settings.gestureActions.threeFingerLeft
                    totalX > THREE_FINGER_THRESHOLD -> settings.gestureActions.threeFingerRight
                    movedDistance <= THREE_FINGER_TAP_SLOP -> settings.gestureActions.threeFingerTap
                    else -> null
                }
                action?.let { outputs += TrackpadGestureOutput.ConfiguredAction(it) }
                state = if (movedDistance <= THREE_FINGER_TAP_SLOP) {
                    TrackpadGestureState.THREE_FINGER_TAP
                } else {
                    TrackpadGestureState.THREE_FINGER_SWIPE
                }
            }
            4 -> if (settings.fourFingerGesturesEnabled) {
                outputs += TrackpadGestureOutput.FourFingerExtension(totalX, totalY)
            }
            else -> Unit
        }
    }

    private fun resetGesture(time: Long, count: Int, center: Point, pointers: List<TrackpadPointerSample>) {
        startTime = time
        maxPointerCount = count
        startCenter = center
        previousCenter = center
        previousDistance = averageDistance(pointers, center)
        movedDistance = 0f
        dragActive = false
        twoFingerLocked = TwoFingerMode.NONE
        wheelRemainder = 0f
        pressure.reset()
        doubleTapCandidate = lastTapTime != Long.MIN_VALUE &&
            time - lastTapTime in 0..settings.doubleTapTimeoutMs &&
            hypot(center.x - lastTapPosition.x, center.y - lastTapPosition.y) <= DOUBLE_TAP_SLOP
        pointerRemainderX = 0f
        pointerRemainderY = 0f
        tapSuppressed = false
        horizontalScrollEmitted = false
        state = if (doubleTapCandidate) {
            TrackpadGestureState.DOUBLE_TAP_PENDING
        } else {
            TrackpadGestureState.ONE_FINGER_CANDIDATE
        }
    }

    private fun resetAfterFinish() {
        maxPointerCount = 0
        movedDistance = 0f
        dragActive = false
        twoFingerLocked = TwoFingerMode.NONE
        wheelRemainder = 0f
        pressure.reset()
        doubleTapCandidate = false
        pointerRemainderX = 0f
        pointerRemainderY = 0f
        tapSuppressed = false
        horizontalScrollEmitted = false
        state = TrackpadGestureState.IDLE
    }

    private inline fun emitWheel(
        delta: Float,
        outputs: MutableList<TrackpadGestureOutput>,
        factory: (Int) -> TrackpadGestureOutput,
    ) {
        wheelRemainder += delta
        val amount = wheelRemainder.toInt().coerceIn(-127, 127)
        if (amount != 0) {
            wheelRemainder -= amount
            outputs += factory(amount)
        }
    }

    private fun center(pointers: List<TrackpadPointerSample>) = Point(
        pointers.sumOf { it.x.toDouble() }.toFloat() / pointers.size,
        pointers.sumOf { it.y.toDouble() }.toFloat() / pointers.size,
    )

    private fun averageDistance(pointers: List<TrackpadPointerSample>, center: Point): Float =
        pointers.sumOf { hypot(it.x - center.x, it.y - center.y).toDouble() }.toFloat() / pointers.size

    private data class Point(val x: Float, val y: Float) {
        companion object { val ZERO = Point(0f, 0f) }
    }

    private enum class TwoFingerMode { NONE, VERTICAL, HORIZONTAL, PINCH }

    companion object {
        private const val TAP_SLOP = 18f
        private const val DOUBLE_TAP_SLOP = 42f
        private const val DOUBLE_TAP_DRAG_SLOP = 7f
        private const val DOUBLE_TAP_DRAG_HOLD_MS = 90L
        private const val TWO_FINGER_TAP_SLOP = 28f
        private const val THREE_FINGER_TAP_SLOP = 36f
        private const val LONG_PRESS_SLOP = 16f
        private const val TAP_TIMEOUT_MS = 260L
        private const val LONG_PRESS_MS = 480L
        private const val AXIS_LOCK_DELTA = 2.5f
        private const val PINCH_LOCK_DELTA = 3.5f
        private const val NAVIGATION_THRESHOLD = 82f
        private const val NAVIGATION_MAX_MS = 520L
        private const val THREE_FINGER_THRESHOLD = 72f
    }
}
