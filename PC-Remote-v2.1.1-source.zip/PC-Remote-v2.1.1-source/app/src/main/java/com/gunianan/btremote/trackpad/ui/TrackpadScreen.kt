package com.gunianan.btremote.trackpad.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.gunianan.btremote.R
import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.trackpad.gesture.TrackpadGestureOutput
import com.gunianan.btremote.trackpad.gesture.TrackpadGestureStateMachine
import com.gunianan.btremote.trackpad.input.TrackpadInputAdapter
import com.gunianan.btremote.trackpad.pressure.PressureLevel
import com.gunianan.btremote.trackpad.pressure.PressureReading
import com.gunianan.btremote.trackpad.settings.TrackpadSettings
import com.gunianan.btremote.ui.components.AssetIcon
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.GlassPill
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography

data class TrackpadScreenCallbacks(
    val onMovePointer: (Int, Int) -> Unit,
    val onClickPointer: (MouseButton) -> Unit,
    val onSetPointerButton: (MouseButton, Boolean) -> Unit,
    val onScrollPointer: (Int) -> Unit,
    val onModifiedScroll: (KeyboardModifier, Int) -> Unit,
    val onConfiguredAction: (RemoteActionConfig) -> Unit,
    val onShowMouseButtonsChanged: (Boolean) -> Unit,
    val onOpenSettings: () -> Unit,
    val onCancelInputs: () -> Unit,
)

/** Fixed, non-scrollable touch surface. A single MotionEvent adapter owns the entire gesture area. */
@Composable
@OptIn(ExperimentalComposeUiApi::class)
fun TrackpadScreen(
    settings: TrackpadSettings,
    callbacks: TrackpadScreenCallbacks,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues,
) {
    val machine = remember { TrackpadGestureStateMachine(settings) }
    val pressure = remember { mutableStateOf<PressureReading?>(null) }
    val eventState = remember { PressureEventState() }
    var lastGesture by remember { mutableStateOf("单指移动 · 双指滚动 · 三指切换") }
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(settings) { machine.updateSettings(settings) }
    DisposableEffect(Unit) {
        onDispose {
            machine.cancel().forEach { output ->
                dispatch(output, callbacks, onPressure = { pressure.value = it }, onPressureCleared = { pressure.value = null })
            }
        }
    }

    Column(
        modifier = modifier.fillMaxSize().padding(contentPadding),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("触控板", style = PcRemoteTypography.ScreenTitle)
                Text(lastGesture, style = PcRemoteTypography.Caption, color = PcRemoteColors.Muted)
            }
            GlassPill(onClick = { callbacks.onShowMouseButtonsChanged(!settings.showMouseButtons) }) {
                Text(if (settings.showMouseButtons) "按键 开" else "按键 关", style = PcRemoteTypography.Caption)
            }
            Spacer(Modifier.size(8.dp))
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(PcRemoteColors.GlassStrong)
                    .border(1.dp, PcRemoteColors.GlassBorder, CircleShape)
                    .clickable(role = Role.Button, onClick = callbacks.onOpenSettings),
                contentAlignment = Alignment.Center,
            ) {
                AssetIcon(R.drawable.nav_settings, "触控板设置", Modifier.size(23.dp))
            }
        }

        GlassCard(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(0.dp),
            strong = false,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(30.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = 0.26f), PcRemoteColors.Primary.copy(alpha = 0.035f)),
                        ),
                    )
                    .pointerInteropFilter { motionEvent ->
                        val outputs = runCatching {
                            machine.onEvent(TrackpadInputAdapter.from(motionEvent))
                        }.getOrElse {
                            callbacks.onCancelInputs()
                            machine.cancel()
                        }
                        outputs.forEach { output ->
                            when (output) {
                                is TrackpadGestureOutput.Scroll -> lastGesture = "双指滚动"
                                is TrackpadGestureOutput.ModifiedScroll -> lastGesture =
                                    if (output.modifier == KeyboardModifier.LEFT_CONTROL) "双指缩放" else "水平滚动"
                                is TrackpadGestureOutput.ConfiguredAction -> lastGesture = "多指快捷手势"
                                is TrackpadGestureOutput.FourFingerExtension -> lastGesture = "四指扩展手势"
                                is TrackpadGestureOutput.Click -> lastGesture =
                                    if (output.button == MouseButton.RIGHT) "双指右键" else "轻点"
                                is TrackpadGestureOutput.PressureChanged -> {
                                    if (output.reading.level == PressureLevel.FORCE &&
                                        eventState.lastLevel != PressureLevel.FORCE && settings.pressureHapticEnabled
                                    ) {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    }
                                    eventState.lastLevel = output.reading.level
                                }
                                TrackpadGestureOutput.PressureCleared -> eventState.lastLevel = null
                                else -> Unit
                            }
                            if (settings.hapticEnabled &&
                                (output is TrackpadGestureOutput.Click || output is TrackpadGestureOutput.ConfiguredAction)
                            ) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                            dispatch(
                                output,
                                callbacks,
                                onPressure = { pressure.value = it },
                                onPressureCleared = { pressure.value = null },
                            )
                        }
                        true
                    },
            ) {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    AssetIcon(R.drawable.profile_mouse, "", Modifier.size(44.dp), tint = PcRemoteColors.Primary)
                    Spacer(Modifier.height(12.dp))
                    Text("在此区域触控", style = PcRemoteTypography.SectionTitle)
                    Spacer(Modifier.height(5.dp))
                    Text("轻点单击 · 长按拖动 · 双指右键", style = PcRemoteTypography.Caption, color = PcRemoteColors.Muted)
                }
                PressureIndicator(
                    reading = pressure,
                    modifier = Modifier.align(Alignment.TopEnd).padding(18.dp),
                )
            }
        }

        if (settings.showMouseButtons) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MouseButtonPad("左键", Modifier.weight(1f)) { callbacks.onClickPointer(MouseButton.LEFT) }
                MouseButtonPad("右键", Modifier.weight(1f)) { callbacks.onClickPointer(MouseButton.RIGHT) }
            }
        }
    }
}

@Composable
private fun MouseButtonPad(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .height(54.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(PcRemoteColors.GlassStrong)
            .border(1.dp, PcRemoteColors.GlassBorder, RoundedCornerShape(18.dp))
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = PcRemoteTypography.Body)
    }
}

@Composable
private fun PressureIndicator(reading: State<PressureReading?>, modifier: Modifier = Modifier) {
    val level = reading.value?.level ?: PressureLevel.LIGHT
    val color = when (level) {
        PressureLevel.FORCE -> Color(0xFF6B5CFF)
        PressureLevel.NORMAL -> PcRemoteColors.Primary
        PressureLevel.LIGHT -> PcRemoteColors.Muted
        PressureLevel.UNRELIABLE -> Color(0xFFB07A2A)
    }
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(99.dp))
            .background(Color.White.copy(alpha = 0.52f))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(7.dp).background(color, CircleShape))
        Text(
            when (level) {
                PressureLevel.FORCE -> "重按"
                PressureLevel.NORMAL -> "按压"
                PressureLevel.LIGHT -> "轻触"
                PressureLevel.UNRELIABLE -> "面积识别"
            },
            style = PcRemoteTypography.Caption,
            color = color,
        )
    }
}

private class PressureEventState(var lastLevel: PressureLevel? = null)

private inline fun dispatch(
    output: TrackpadGestureOutput,
    callbacks: TrackpadScreenCallbacks,
    onPressure: (PressureReading) -> Unit,
    onPressureCleared: () -> Unit,
) {
    when (output) {
        is TrackpadGestureOutput.MovePointer -> callbacks.onMovePointer(output.deltaX, output.deltaY)
        is TrackpadGestureOutput.Click -> repeat(output.count) { callbacks.onClickPointer(output.button) }
        is TrackpadGestureOutput.SetButton -> callbacks.onSetPointerButton(output.button, output.pressed)
        is TrackpadGestureOutput.Scroll -> callbacks.onScrollPointer(output.vertical)
        is TrackpadGestureOutput.ModifiedScroll -> callbacks.onModifiedScroll(output.modifier, output.vertical)
        is TrackpadGestureOutput.ConfiguredAction -> callbacks.onConfiguredAction(output.action)
        is TrackpadGestureOutput.FourFingerExtension -> Unit
        is TrackpadGestureOutput.PressureChanged -> onPressure(output.reading)
        TrackpadGestureOutput.PressureCleared -> onPressureCleared()
        TrackpadGestureOutput.Cancelled -> callbacks.onCancelInputs()
    }
}
