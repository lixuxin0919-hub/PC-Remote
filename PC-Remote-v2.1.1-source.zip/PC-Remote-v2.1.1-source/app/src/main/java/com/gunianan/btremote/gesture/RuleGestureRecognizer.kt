package com.gunianan.btremote.gesture

import kotlin.math.abs
import kotlin.math.hypot

/** Fast deterministic recognition for taps, long press and four-way swipes. */
class RuleGestureRecognizer(
    private val minSwipeDistancePx: Float = 72f,
    private val maxSwipeDurationMs: Long = 1_200L,
    private val minStraightness: Float = 0.72f,
    private val dominantAxisRatio: Float = 1.25f,
    private val tapMaxTravelPx: Float = 18f,
    private val tapMaxDurationMs: Long = 260L,
    private val longPressMinDurationMs: Long = 500L,
    private val doubleTapMaxGapMs: Long = 320L,
    private val doubleTapMaxCenterDistancePx: Float = 44f,
) {
    init {
        require(minSwipeDistancePx > 0f)
        require(maxSwipeDurationMs > 0L)
        require(minStraightness in 0f..1f)
        require(dominantAxisRatio >= 1f)
        require(tapMaxTravelPx >= 0f)
        require(tapMaxDurationMs >= 0L)
        require(longPressMinDurationMs > tapMaxDurationMs)
        require(doubleTapMaxGapMs >= 0L)
        require(doubleTapMaxCenterDistancePx >= 0f)
    }

    fun recognize(points: List<PointSample>): GestureMatch? =
        recognizeCandidate(points)?.let { candidate ->
            GestureMatch(
                gestureId = candidate.gestureId,
                confidence = candidate.confidence,
                source = RecognitionSource.RULE,
                displayName = candidate.displayName,
            )
        }

    fun recognizeCandidate(points: List<PointSample>): GestureCandidate? {
        if (points.isEmpty()) return null
        if (points.any { !it.x.isFinite() || !it.y.isFinite() }) return null
        for (index in 1 until points.size) {
            if (points[index].timeMillis < points[index - 1].timeMillis) return null
        }

        val strokes = splitStrokes(points)
        if (strokes.size == 2) {
            recognizeDoubleTap(strokes[0], strokes[1])?.let { return it }
            return null
        }
        if (strokes.size != 1) return null

        val stroke = strokes.first()
        val duration = duration(stroke)
        val pathLength = pathLength(stroke)
        val dx = stroke.last().x - stroke.first().x
        val dy = stroke.last().y - stroke.first().y
        val displacement = hypot(dx, dy)

        if (pathLength <= tapMaxTravelPx) {
            return when {
                duration <= tapMaxDurationMs -> candidate(
                    id = "tap",
                    name = "轻点",
                    confidence = compactGestureConfidence(pathLength, duration, tapMaxDurationMs),
                )

                duration >= longPressMinDurationMs -> candidate(
                    id = "long_press",
                    name = "长按",
                    confidence = compactGestureConfidence(pathLength, 0L, tapMaxDurationMs),
                )

                else -> null
            }
        }

        if (
            displacement < minSwipeDistancePx ||
            duration > maxSwipeDurationMs ||
            pathLength <= 0f
        ) {
            return null
        }

        val straightness = (displacement / pathLength).coerceIn(0f, 1f)
        if (straightness < minStraightness) return null

        val absX = abs(dx)
        val absY = abs(dy)
        val (gestureId, displayName) = when {
            absX >= absY * dominantAxisRatio && dx > 0f -> "swipe_right" to "向右滑"
            absX >= absY * dominantAxisRatio && dx < 0f -> "swipe_left" to "向左滑"
            absY >= absX * dominantAxisRatio && dy > 0f -> "swipe_down" to "向下滑"
            absY >= absX * dominantAxisRatio && dy < 0f -> "swipe_up" to "向上滑"
            else -> return null
        }

        val distanceScore = (displacement / (minSwipeDistancePx * 2f)).coerceIn(0f, 1f)
        val durationScore = (1f - duration.toFloat() / (maxSwipeDurationMs * 1.5f)).coerceIn(0f, 1f)
        val confidence = (
            0.52f * straightness +
                0.36f * distanceScore +
                0.12f * durationScore
            ).coerceIn(0f, 1f)
        return candidate(gestureId, displayName, confidence)
    }

    private fun recognizeDoubleTap(
        first: List<PointSample>,
        second: List<PointSample>,
    ): GestureCandidate? {
        if (!isTapStroke(first) || !isTapStroke(second)) return null

        val gap = second.first().timeMillis - first.last().timeMillis
        if (gap !in 0..doubleTapMaxGapMs) return null

        val firstCenter = center(first)
        val secondCenter = center(second)
        val centerDistance = hypot(firstCenter.first - secondCenter.first, firstCenter.second - secondCenter.second)
        if (centerDistance > doubleTapMaxCenterDistancePx) return null

        val gapScore = 1f - gap.toFloat() / (doubleTapMaxGapMs.coerceAtLeast(1L) * 1.2f)
        val locationScore = 1f - centerDistance / doubleTapMaxCenterDistancePx.coerceAtLeast(1f)
        return candidate(
            id = "double_tap",
            name = "双击",
            confidence = (0.6f * gapScore + 0.4f * locationScore).coerceIn(0f, 1f),
        )
    }

    private fun isTapStroke(points: List<PointSample>): Boolean =
        duration(points) <= tapMaxDurationMs && pathLength(points) <= tapMaxTravelPx

    private fun compactGestureConfidence(
        travel: Float,
        duration: Long,
        maxDuration: Long,
    ): Float {
        val travelScore = 1f - travel / tapMaxTravelPx.coerceAtLeast(1f)
        val durationScore = 1f - duration.toFloat() / maxDuration.coerceAtLeast(1L)
        return (0.72f + 0.18f * travelScore + 0.1f * durationScore).coerceIn(0f, 1f)
    }

    private fun splitStrokes(points: List<PointSample>): List<List<PointSample>> {
        val strokes = ArrayList<MutableList<PointSample>>(2)
        for (point in points) {
            val current = strokes.lastOrNull()
            if (current == null || current.last().strokeId != point.strokeId) {
                strokes += mutableListOf(point)
            } else {
                current += point
            }
        }
        return strokes
    }

    private fun duration(points: List<PointSample>): Long =
        (points.last().timeMillis - points.first().timeMillis).coerceAtLeast(0L)

    private fun pathLength(points: List<PointSample>): Float {
        var total = 0f
        for (index in 1 until points.size) {
            total += hypot(
                points[index].x - points[index - 1].x,
                points[index].y - points[index - 1].y,
            )
        }
        return total
    }

    private fun center(points: List<PointSample>): Pair<Float, Float> {
        var x = 0.0
        var y = 0.0
        for (point in points) {
            x += point.x
            y += point.y
        }
        return (x / points.size).toFloat() to (y / points.size).toFloat()
    }

    private fun candidate(id: String, name: String, confidence: Float) = GestureCandidate(
        gestureId = id,
        displayName = name,
        confidence = confidence,
        source = RecognitionSource.RULE,
    )
}
