package com.gunianan.btremote.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.theme.PcRemoteTypography

@Composable
fun ProfileIconCropDialog(bitmap: Bitmap, onSave: (Float, Float, Float) -> Unit, onDismiss: () -> Unit) {
    var scale by remember(bitmap) { mutableFloatStateOf(1f) }
    var offsetX by remember(bitmap) { mutableFloatStateOf(0f) }
    var offsetY by remember(bitmap) { mutableFloatStateOf(0f) }
    Dialog(onDismissRequest = onDismiss) {
        GlassCard(cornerRadius = 30.dp, strong = true, contentPadding = PaddingValues(20.dp)) {
            Text("裁剪模式图标", style = PcRemoteTypography.SectionTitle)
            Text("双指缩放，拖动调整位置", style = PcRemoteTypography.Caption)
            Spacer(Modifier.size(16.dp))
            Image(
                bitmap.asImageBitmap(), null,
                modifier = Modifier.size(256.dp).clip(RoundedCornerShape(28.dp))
                    .pointerInput(bitmap) { detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 4f)
                        offsetX = (offsetX + pan.x / 128f).coerceIn(-1f, 1f)
                        offsetY = (offsetY + pan.y / 128f).coerceIn(-1f, 1f)
                    }}
                    .graphicsLayer { scaleX = scale; scaleY = scale; translationX = offsetX * 64f; translationY = offsetY * 64f },
                contentScale = ContentScale.Crop,
            )
            Spacer(Modifier.size(16.dp))
            Row(Modifier.fillMaxWidth()) {
                GlassActionButton("取消", onDismiss, Modifier.weight(1f))
                Spacer(Modifier.size(10.dp))
                GlassActionButton("保存图标", { onSave(scale, offsetX, offsetY) }, Modifier.weight(1f), primary = true)
            }
        }
    }
}
