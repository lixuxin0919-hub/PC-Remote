package com.gunianan.btremote.data

import com.gunianan.btremote.domain.AppConfig

/** One-way migration from the v1.x Java application's simple preference keys. */
object LegacySettingsMigrator {
    const val LEGACY_PREFERENCES_NAME = "douyin_remote_settings"

    private const val KEY_LAST_DEVICE = "last_device_address"
    private const val KEY_AUTO_CONNECT = "auto_connect"
    private const val KEY_HAPTIC = "haptic"
    private const val KEY_KEEP_SCREEN = "keep_screen_on"
    private val bluetoothAddressPattern = Regex("^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")

    fun migrate(config: AppConfig, legacyStore: KeyValueStore?): AppConfig {
        if (legacyStore == null) return config
        val previous = config.globalSettings
        val lastAddress = legacyStore.getString(KEY_LAST_DEVICE)
            ?.takeIf(bluetoothAddressPattern::matches)
        return config.copy(
            globalSettings = previous.copy(
                hapticEnabled = legacyStore.booleanOrDefault(KEY_HAPTIC, previous.hapticEnabled),
                autoConnect = legacyStore.booleanOrDefault(KEY_AUTO_CONNECT, previous.autoConnect),
                keepScreenOn = legacyStore.booleanOrDefault(KEY_KEEP_SCREEN, previous.keepScreenOn),
                lastDeviceAddress = lastAddress ?: previous.lastDeviceAddress,
            ),
        )
    }

    private fun KeyValueStore.booleanOrDefault(key: String, defaultValue: Boolean): Boolean =
        if (contains(key)) getBoolean(key, defaultValue) else defaultValue
}
