package com.gunianan.btremote.trackpad.input

import android.view.MotionEvent

data class TrackpadPointerSample(
    val id: Int,
    val x: Float,
    val y: Float,
    val pressure: Float,
    val size: Float,
    val touchMajor: Float,
    val touchMinor: Float,
)

data class TrackpadPointerEvent(
    val action: Action,
    val eventTimeMillis: Long,
    val changedPointerId: Int?,
    val pointers: List<TrackpadPointerSample>,
) {
    enum class Action { DOWN, POINTER_DOWN, MOVE, POINTER_UP, UP, CANCEL }
}

/** Converts Android pointer indices into stable pointer IDs before recognition. */
object TrackpadInputAdapter {
    fun from(event: MotionEvent): TrackpadPointerEvent {
        val actionIndex = if (event.pointerCount > 0) {
            event.actionIndex.coerceIn(0, event.pointerCount - 1)
        } else {
            -1
        }
        return TrackpadPointerEvent(
            action = when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> TrackpadPointerEvent.Action.DOWN
                MotionEvent.ACTION_POINTER_DOWN -> TrackpadPointerEvent.Action.POINTER_DOWN
                MotionEvent.ACTION_MOVE -> TrackpadPointerEvent.Action.MOVE
                MotionEvent.ACTION_POINTER_UP -> TrackpadPointerEvent.Action.POINTER_UP
                MotionEvent.ACTION_UP -> TrackpadPointerEvent.Action.UP
                else -> TrackpadPointerEvent.Action.CANCEL
            },
            eventTimeMillis = event.eventTime,
            changedPointerId = if (actionIndex >= 0) event.getPointerId(actionIndex) else null,
            pointers = List(event.pointerCount) { index ->
                TrackpadPointerSample(
                    id = event.getPointerId(index),
                    x = event.getX(index),
                    y = event.getY(index),
                    pressure = event.getPressure(index).takeIf(Float::isFinite) ?: 0f,
                    size = event.getSize(index).takeIf(Float::isFinite) ?: 0f,
                    touchMajor = event.getTouchMajor(index).takeIf(Float::isFinite) ?: 0f,
                    touchMinor = event.getTouchMinor(index).takeIf(Float::isFinite) ?: 0f,
                )
            },
        )
    }
}
