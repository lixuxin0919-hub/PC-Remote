package com.gunianan.btremote.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.gunianan.btremote.action.KeyReleaseReason
import com.gunianan.btremote.action.ReleaseAllResult
import com.gunianan.btremote.action.RemoteCommandExecutor
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Owns Android's HID Device profile and exposes lifecycle-safe, UI-neutral state.
 *
 * All platform state transitions are serialized on the main looper. Delayed retries
 * carry a generation token, so a timeout from an old target cannot mutate a new session.
 */
@SuppressLint("MissingPermission")
class BluetoothHidController(
    context: Context,
    private val hostCallbacks: BluetoothHidHostCallbacks,
    private val preferences: SharedPreferences = context.getSharedPreferences(
        BLUETOOTH_PREFERENCES,
        Context.MODE_PRIVATE,
    ),
) : AutoCloseable {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val bluetoothAdapter: BluetoothAdapter? =
        appContext.getSystemService(BluetoothManager::class.java)?.adapter
    private val reportSender = HidReportSender()
    private val bluetoothExecutor: BluetoothRemoteCommandExecutor = BluetoothRemoteCommandExecutor(
        watchdogScope = scope,
        onTransportFailure = ::handleTransportFailure,
    )

    val remoteCommandExecutor: RemoteCommandExecutor = bluetoothExecutor

    private val mutableUiState = MutableStateFlow(BluetoothHidUiState())
    val uiState: StateFlow<BluetoothHidUiState> = mutableUiState.asStateFlow()

    private val mutablePairedDevices = MutableStateFlow<List<PairedBluetoothDevice>>(emptyList())
    val pairedDevices: StateFlow<List<PairedBluetoothDevice>> = mutablePairedDevices.asStateFlow()

    private var hidProxy: BluetoothHidDevice? = null
    private var connectedDevice: BluetoothDevice? = null
    private var connectingDevice: BluetoothDevice? = null
    private var currentSessionId: String? = null

    private var started = false
    private var resumed = false
    private var destroyed = false
    private var hidRegistered = false
    private var profileRequestInProgress = false
    private var registrationInProgress = false
    private var connectPermissionRequestInFlight = false
    private var advertisePermissionRequestInFlight = false
    private var enableRequestInFlight = false
    private var pendingPairingRequest = false
    private var preserveRegistrationAttemptOnReacquire = false

    private var profileAttempt = 0
    private var registrationAttempt = 0
    private var reconnectAttempt = 0
    private var profileGeneration = 0
    private var registrationGeneration = 0
    private var connectionGeneration = 0
    private var suppressUnregisteredUntil = 0L
    private var suppressProfileDisconnectUntil = 0L

    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) = onMain {
            if (profile != BluetoothProfile.HID_DEVICE) return@onMain
            if (destroyed) {
                closeIncomingProxy(profile, proxy)
                return@onMain
            }
            if (hidProxy != null && hidProxy !== proxy) {
                closeIncomingProxy(profile, proxy)
                return@onMain
            }
            profileGeneration++
            profileRequestInProgress = false
            hidProxy = proxy as BluetoothHidDevice
            profileAttempt = 0
            registrationInProgress = false
            if (!preserveRegistrationAttemptOnReacquire) registrationAttempt = 0
            preserveRegistrationAttemptOnReacquire = false
            publish(
                HidConnectionState.STARTING,
                "正在启动 PC遥控器…",
                "正在向系统注册蓝牙 HID 设备",
            )
            scheduleRegistration(180L)
        }

        override fun onServiceDisconnected(profile: Int) = onMain {
            if (profile != BluetoothProfile.HID_DEVICE || destroyed) return@onMain
            if (SystemClock.uptimeMillis() < suppressProfileDisconnectUntil && hidProxy != null) {
                return@onMain
            }
            profileRequestInProgress = false
            hidProxy = null
            hidRegistered = false
            registrationInProgress = false
            registrationGeneration++
            connectionGeneration++
            clearConnectionAfterTransportLoss()
            publish(
                HidConnectionState.ERROR,
                "蓝牙服务已断开",
                "正在尝试恢复 HID 服务",
            )
            if (resumed) scheduleProfileAcquisition(900L)
        }
    }

    private val hidCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) = onMain {
            if (destroyed) return@onMain
            registrationInProgress = false
            hidRegistered = registered
            if (registered) {
                registrationAttempt = 0
                reconnectAttempt = 0
                if (!resumed) {
                    publish(
                        HidConnectionState.SUSPENDED,
                        "PC遥控器已暂停",
                        "HID 已就绪，返回应用后继续连接",
                    )
                    refreshPairedDevicesInternal()
                    return@onMain
                }
                publish(
                    HidConnectionState.READY,
                    "蓝牙 HID 已就绪",
                    "正在检查上次连接的电脑",
                )
                refreshPairedDevicesInternal()
                val generation = connectionGeneration
                postDelayed(420L) {
                    if (generation == connectionGeneration) adoptExistingConnectionOrReconnect()
                }
                return@onMain
            }

            connectionGeneration++
            clearConnectionAfterTransportLoss()
            if (destroyed || SystemClock.uptimeMillis() < suppressUnregisteredUntil) return@onMain
            if (!resumed) {
                publish(
                    HidConnectionState.SUSPENDED,
                    "PC遥控器已暂停",
                    "返回应用后会自动重新注册",
                )
            } else {
                retryRegistration("系统未确认 HID 注册")
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) = onMain {
            if (destroyed) return@onMain
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> establishConnectedSession(device)
                BluetoothProfile.STATE_CONNECTING -> {
                    if (connectingDevice == null) connectingDevice = device
                    publish(
                        HidConnectionState.CONNECTING,
                        "正在连接…",
                        safeDeviceName(device),
                    )
                    refreshPairedDevicesInternal()
                }
                BluetoothProfile.STATE_DISCONNECTING -> publish(
                    HidConnectionState.DISCONNECTING,
                    "正在断开…",
                    safeDeviceName(device),
                )
                else -> handleDisconnected(device)
            }
        }

        @SuppressLint("MissingPermission")
        override fun onGetReport(device: BluetoothDevice, type: Byte, id: Byte, bufferSize: Int) {
            if (destroyed) return
            val proxy = hidProxy ?: return
            if (!hasConnectPermission()) return
            val report = when (id.toInt()) {
                HidReportSender.REPORT_ID_KEYBOARD -> ByteArray(8)
                HidReportSender.REPORT_ID_MOUSE -> ByteArray(4)
                HidReportSender.REPORT_ID_CONSUMER -> ByteArray(1)
                else -> {
                    runCatching {
                        proxy.reportError(device, BluetoothHidDevice.ERROR_RSP_INVALID_RPT_ID)
                    }
                    return
                }
            }
            runCatching { proxy.replyReport(device, type, id, report) }
        }

        override fun onVirtualCableUnplug(device: BluetoothDevice) = onMain {
            if (destroyed) return@onMain
            connectionGeneration++
            if (sameDevice(connectingDevice, device)) connectingDevice = null
            if (sameDevice(connectedDevice, device)) clearConnectionAfterTransportLoss()
            safeDeviceAddress(device)?.let { address ->
                if (preferences.getString(PREF_LAST_DEVICE, null) == address) {
                    preferences.edit().remove(PREF_LAST_DEVICE).apply()
                }
            }
            publish(
                HidConnectionState.ERROR,
                "电脑已移除配对",
                "请重新进入配对模式并在电脑上添加 PC遥控器",
            )
            refreshPairedDevicesInternal()
        }
    }

    fun start(allowPermissionPrompt: Boolean = true) = onStart(allowPermissionPrompt)

    fun onStart(allowPermissionPrompt: Boolean = true) = onMain {
        if (destroyed) return@onMain
        started = true
        continueStartup(allowPermissionPrompt)
    }

    fun resume() = onResume()

    fun onResume() = onMain {
        if (destroyed) return@onMain
        resumed = true
        continueStartup(allowPermissionPrompt = false)
    }

    fun pause() = onPause()

    fun onPause() = onMain {
        if (destroyed) return@onMain
        resumed = false
        scope.launch {
            val release = bluetoothExecutor.releaseAll(KeyReleaseReason.APP_BACKGROUND)
            withContext(Dispatchers.Main.immediate) {
                if (resumed || destroyed) return@withContext
                val detail = when {
                    connectedDevice == null -> "返回应用后继续连接"
                    release.allReleased -> "已释放所有按键，连接保持待机"
                    else -> "${release.failures.size} 个按键释放失败；返回后请重新连接"
                }
                publish(HidConnectionState.SUSPENDED, "PC遥控器已暂停", detail)
            }
        }
    }

    fun destroy() = onDestroy()

    fun onDestroy() = onMain {
        if (destroyed) return@onMain
        destroyed = true
        resumed = false
        started = false
        profileGeneration++
        registrationGeneration++
        connectionGeneration++
        mainHandler.removeCallbacksAndMessages(null)
        publish(HidConnectionState.DESTROYED, "PC遥控器已关闭", "蓝牙 HID 会话已结束")

        val proxy = hidProxy
        val device = connectedDevice
        hidProxy = null
        connectedDevice = null
        connectingDevice = null
        currentSessionId = null
        hidRegistered = false
        scope.launch {
            bluetoothExecutor.close()
            withContext(Dispatchers.Main.immediate) {
                if (proxy != null && hasConnectPermission()) {
                    suppressUnregisteredUntil = SystemClock.uptimeMillis() + 1_800L
                    runCatching { if (device != null) proxy.disconnect(device) }
                    runCatching { proxy.unregisterApp() }
                    runCatching { bluetoothAdapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, proxy) }
                }
                reportSender.close()
                scope.cancel()
            }
        }
    }

    override fun close() = onDestroy()

    fun onBluetoothConnectPermissionResult(granted: Boolean) = onMain {
        connectPermissionRequestInFlight = false
        if (granted && hasConnectPermission()) {
            if (pendingPairingRequest) enterPairingMode() else continueStartup(allowPermissionPrompt = false)
        } else {
            pendingPairingRequest = false
            publishPermissionRequired()
        }
    }

    fun onBluetoothAdvertisePermissionResult(granted: Boolean) = onMain {
        advertisePermissionRequestInFlight = false
        if (granted && hasAdvertisePermission()) {
            requestDiscoverabilityFromHost()
            pendingPairingRequest = false
        } else {
            pendingPairingRequest = false
            message("未授予允许发现权限，配对模式未开启")
        }
    }

    fun onBluetoothEnableResult(enabled: Boolean) = onMain {
        enableRequestInFlight = false
        if (enabled) {
            if (pendingPairingRequest) enterPairingMode() else continueStartup(allowPermissionPrompt = false)
        } else {
            pendingPairingRequest = false
            publishBluetoothDisabled()
        }
    }

    fun onDiscoverabilityResult(enteredPairingMode: Boolean) = onMain {
        pendingPairingRequest = false
        message(
            if (enteredPairingMode) {
                "手机已进入配对模式，请在电脑蓝牙设置中添加 PC遥控器"
            } else {
                "未进入配对模式"
            },
        )
    }

    fun refresh() = onMain {
        if (destroyed) return@onMain
        refreshPairedDevicesInternal()
        if (resumed) continueStartup(allowPermissionPrompt = false)
    }

    fun connect(address: String) = onMain {
        if (destroyed || address.isBlank()) return@onMain
        val target = findBondedByAddress(address)
        if (target == null) {
            message("未找到该已配对设备，请刷新后重试")
            refreshPairedDevicesInternal()
        } else {
            reconnectAttempt = 0
            connectDevice(target, automatic = false)
        }
    }

    fun disconnect() = onMain { disconnectCurrentDevice() }

    fun repair() = onMain {
        if (destroyed) return@onMain
        if (!ensureConnectPermission(prompt = true)) return@onMain
        registrationAttempt = 0
        profileAttempt = 0
        preserveRegistrationAttemptOnReacquire = false
        publish(
            HidConnectionState.STARTING,
            "正在修复 HID 注册…",
            "清理旧状态并重新启动蓝牙服务",
        )
        reacquireHidProfile(preserveRegistrationAttempt = false)
    }

    fun pairing() = enterPairingMode()

    fun enterPairingMode() = onMain {
        if (destroyed) return@onMain
        pendingPairingRequest = true
        if (!ensureConnectPermission(prompt = true)) return@onMain
        val adapter = bluetoothAdapter
        val enabled = adapter != null && runCatching { adapter.isEnabled }.getOrDefault(false)
        if (!enabled) {
            publishBluetoothDisabled()
            if (!enableRequestInFlight) {
                enableRequestInFlight = true
                safeHost { requestBluetoothEnable() }
            }
            return@onMain
        }
        if (!hasAdvertisePermission()) {
            if (!advertisePermissionRequestInFlight) {
                advertisePermissionRequestInFlight = true
                safeHost { requestBluetoothAdvertisePermission() }
            }
            return@onMain
        }
        requestDiscoverabilityFromHost()
        pendingPairingRequest = false
    }

    fun setAutoConnectEnabled(enabled: Boolean) = onMain {
        preferences.edit().putBoolean(PREF_AUTO_CONNECT, enabled).apply()
        if (enabled && resumed && connectedDevice == null) {
            reconnectAttempt = 0
            adoptExistingConnectionOrReconnect()
        }
    }

    /** Lets profile/page transitions use the same guaranteed release path as lifecycle events. */
    suspend fun releaseAllKeys(
        reason: KeyReleaseReason = KeyReleaseReason.EXPLICIT,
    ): ReleaseAllResult = bluetoothExecutor.releaseAll(reason)

    private fun continueStartup(allowPermissionPrompt: Boolean) {
        if (destroyed || !started) return
        val adapter = bluetoothAdapter
        if (adapter == null) {
            publish(
                HidConnectionState.UNSUPPORTED,
                "此手机不支持蓝牙",
                "无法启用 Bluetooth HID Device Profile",
            )
            return
        }
        if (!ensureConnectPermission(allowPermissionPrompt)) return
        val enabled = runCatching { adapter.isEnabled }.getOrElse {
            publishPermissionRequired()
            return
        }
        if (!enabled) {
            publishBluetoothDisabled()
            if (allowPermissionPrompt && !enableRequestInFlight) {
                enableRequestInFlight = true
                safeHost { requestBluetoothEnable() }
            }
            return
        }
        refreshPairedDevicesInternal()
        if (!resumed) return

        when {
            connectedDevice != null && currentSessionId != null -> publish(
                HidConnectionState.CONNECTED,
                safeDeviceName(connectedDevice),
                "已连接 · 蓝牙 HID",
            )
            hidProxy == null -> requestHidProfile()
            !hidRegistered && !registrationInProgress -> scheduleRegistration(120L)
            hidRegistered && connectingDevice == null -> adoptExistingConnectionOrReconnect()
        }
    }

    @SuppressLint("MissingPermission")
    private fun requestHidProfile() {
        val adapter = bluetoothAdapter ?: return
        if (
            destroyed || !resumed || !hasConnectPermission() ||
            hidProxy != null || profileRequestInProgress
        ) return
        if (profileAttempt >= MAX_PROFILE_ATTEMPTS) {
            publish(
                HidConnectionState.ERROR,
                "无法启动蓝牙 HID",
                "已尝试 $MAX_PROFILE_ATTEMPTS 次，请使用“修复 HID 注册”",
            )
            return
        }
        profileRequestInProgress = true
        profileAttempt++
        val generation = ++profileGeneration
        publish(
            HidConnectionState.ACQUIRING_PROFILE,
            "正在启动蓝牙服务…",
            "获取 HID Profile $profileAttempt/$MAX_PROFILE_ATTEMPTS",
        )
        val accepted = runCatching {
            adapter.getProfileProxy(appContext, profileListener, BluetoothProfile.HID_DEVICE)
        }.getOrDefault(false)
        if (!accepted) {
            profileRequestInProgress = false
            if (profileAttempt < MAX_PROFILE_ATTEMPTS && resumed) {
                postDelayed(700L + profileAttempt * 450L) {
                    if (generation == profileGeneration) requestHidProfile()
                }
            } else {
                publish(
                    HidConnectionState.ERROR,
                    "无法启动蓝牙 HID",
                    "系统拒绝提供 HID Device Profile",
                )
            }
        } else {
            postDelayed(PROFILE_ACQUISITION_TIMEOUT_MILLIS) {
                if (
                    generation == profileGeneration && profileRequestInProgress &&
                    hidProxy == null && resumed && !destroyed
                ) {
                    profileRequestInProgress = false
                    if (profileAttempt < MAX_PROFILE_ATTEMPTS) {
                        requestHidProfile()
                    } else {
                        publish(
                            HidConnectionState.ERROR,
                            "无法启动蓝牙 HID",
                            "等待系统 HID Profile 超时",
                        )
                    }
                }
            }
        }
    }

    private fun scheduleProfileAcquisition(delayMillis: Long) {
        val generation = ++profileGeneration
        postDelayed(delayMillis) {
            if (generation == profileGeneration && resumed) requestHidProfile()
        }
    }

    private fun scheduleRegistration(delayMillis: Long) {
        val generation = ++registrationGeneration
        postDelayed(delayMillis) {
            if (generation == registrationGeneration) registerHidApp()
        }
    }

    @SuppressLint("MissingPermission")
    private fun registerHidApp() {
        val proxy = hidProxy ?: return
        if (
            destroyed || !resumed || !hasConnectPermission() || hidRegistered ||
            registrationInProgress
        ) return
        if (registrationAttempt >= MAX_REGISTRATION_ATTEMPTS) {
            publish(
                HidConnectionState.ERROR,
                "PC遥控器注册失败",
                "已尝试 $MAX_REGISTRATION_ATTEMPTS 次，请使用“修复 HID 注册”",
            )
            return
        }
        registrationInProgress = true
        registrationAttempt++
        val generation = ++registrationGeneration
        publish(
            HidConnectionState.REGISTERING,
            "正在注册 PC遥控器…",
            "HID 初始化 $registrationAttempt/$MAX_REGISTRATION_ATTEMPTS",
        )
        val sdp = BluetoothHidDeviceAppSdpSettings(
            SDP_NAME,
            SDP_DESCRIPTION,
            SDP_PROVIDER,
            BluetoothHidDevice.SUBCLASS1_COMBO,
            PcRemoteHidDescriptor.bytes,
        )
        val accepted = runCatching {
            proxy.registerApp(sdp, null, null, appContext.mainExecutor, hidCallback)
        }.getOrDefault(false)
        if (!accepted) {
            registrationInProgress = false
            retryRegistration("注册请求被系统拒绝")
            return
        }
        postDelayed(REGISTRATION_CONFIRM_TIMEOUT_MILLIS) {
            if (
                generation == registrationGeneration && !hidRegistered &&
                !destroyed
            ) {
                registrationInProgress = false
                retryRegistration("等待系统确认超时")
            }
        }
    }

    private fun retryRegistration(reason: String) {
        if (destroyed || !resumed) return
        if (registrationAttempt >= MAX_REGISTRATION_ATTEMPTS) {
            publish(
                HidConnectionState.ERROR,
                "PC遥控器注册失败",
                "$reason，请使用“修复 HID 注册”",
            )
            return
        }
        publish(HidConnectionState.REGISTERING, "正在修复 HID 注册…", reason)
        when (registrationAttempt) {
            2 -> {
                cleanupStaleRegistration()
                scheduleRegistration(720L)
            }
            4 -> reacquireHidProfile(preserveRegistrationAttempt = true)
            else -> scheduleRegistration(450L + registrationAttempt * 320L)
        }
    }

    @SuppressLint("MissingPermission")
    private fun cleanupStaleRegistration() {
        val proxy = hidProxy ?: return
        suppressUnregisteredUntil = SystemClock.uptimeMillis() + 1_200L
        runCatching { proxy.unregisterApp() }
    }

    @SuppressLint("MissingPermission")
    private fun reacquireHidProfile(preserveRegistrationAttempt: Boolean) {
        val oldProxy = hidProxy
        registrationGeneration++
        connectionGeneration++
        clearConnectionAfterTransportLoss()
        profileRequestInProgress = false
        hidProxy = null
        hidRegistered = false
        registrationInProgress = false
        preserveRegistrationAttemptOnReacquire = preserveRegistrationAttempt
        if (!preserveRegistrationAttempt) registrationAttempt = 0
        if (oldProxy != null && hasConnectPermission()) {
            suppressUnregisteredUntil = SystemClock.uptimeMillis() + 1_500L
            suppressProfileDisconnectUntil = SystemClock.uptimeMillis() + 2_000L
            runCatching { oldProxy.unregisterApp() }
            runCatching { bluetoothAdapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, oldProxy) }
        }
        profileAttempt = 0
        scheduleProfileAcquisition(850L)
    }

    @SuppressLint("MissingPermission")
    private fun refreshPairedDevicesInternal() {
        val adapter = bluetoothAdapter
        if (!hasConnectPermission() || adapter == null) {
            mutablePairedDevices.value = emptyList()
            return
        }
        val bonded = runCatching {
            if (adapter.isEnabled) adapter.bondedDevices.orEmpty() else emptySet()
        }.getOrElse {
            publish(
                HidConnectionState.ERROR,
                "无法读取已配对设备",
                "请检查附近设备权限",
            )
            emptySet()
        }
        val lastAddress = preferences.getString(PREF_LAST_DEVICE, null)
        mutablePairedDevices.value = bonded.mapNotNull(::deviceInfo)
            .map { it.copy(wasLastConnected = it.address == lastAddress) }
            .sortedWith(
                compareByDescending<PairedBluetoothDevice> { it.state == PairedDeviceState.CONNECTED }
                    .thenByDescending { it.wasLastConnected }
                    .thenBy { it.name.lowercase(Locale.getDefault()) },
            )
    }

    @SuppressLint("MissingPermission")
    private fun adoptExistingConnectionOrReconnect() {
        val proxy = hidProxy ?: return
        if (!hasConnectPermission() || !hidRegistered || destroyed || !resumed) return
        val existing = runCatching { proxy.connectedDevices.orEmpty().firstOrNull() }.getOrNull()
        if (existing != null) {
            if (!sameDevice(existing, connectedDevice) || currentSessionId == null) {
                establishConnectedSession(existing)
            }
            return
        }
        if (
            !preferences.getBoolean(PREF_AUTO_CONNECT, true) || connectedDevice != null ||
            connectingDevice != null
        ) {
            publish(HidConnectionState.READY, "蓝牙 HID 已就绪", "点按已配对电脑进行连接")
            return
        }
        val lastAddress = preferences.getString(PREF_LAST_DEVICE, null)
        if (lastAddress.isNullOrBlank()) {
            publish(HidConnectionState.READY, "蓝牙 HID 已就绪", "首次使用请进入配对模式")
            return
        }
        val target = findBondedByAddress(lastAddress)
        if (target == null) {
            publish(HidConnectionState.READY, "未找到上次电脑", "请刷新设备或重新配对")
            return
        }
        connectDevice(target, automatic = true)
    }

    @SuppressLint("MissingPermission")
    private fun findBondedByAddress(address: String): BluetoothDevice? {
        val adapter = bluetoothAdapter ?: return null
        if (!hasConnectPermission()) return null
        return runCatching {
            adapter.bondedDevices?.firstOrNull { safeDeviceAddress(it) == address }
        }.getOrNull()
    }

    @SuppressLint("MissingPermission")
    private fun connectDevice(device: BluetoothDevice, automatic: Boolean) {
        val proxy = hidProxy
        if (!ensureConnectPermission(prompt = !automatic)) return
        if (!hidRegistered || proxy == null) {
            if (!automatic) {
                message("蓝牙遥控器尚未就绪，正在自动修复")
                repair()
            }
            return
        }
        if (sameDevice(connectedDevice, device)) {
            publish(HidConnectionState.CONNECTED, safeDeviceName(device), "已连接 · 蓝牙 HID")
            return
        }
        if (connectingDevice != null) return
        if (automatic) {
            if (reconnectAttempt >= MAX_RECONNECT_ATTEMPTS) {
                publish(HidConnectionState.ERROR, "自动连接失败", "请在设备页手动重试")
                return
            }
            reconnectAttempt++
        }
        val generation = ++connectionGeneration
        connectingDevice = device
        publish(
            HidConnectionState.CONNECTING,
            if (automatic) "正在自动连接…" else "正在连接…",
            safeDeviceName(device),
        )
        refreshPairedDevicesInternal()
        val accepted = runCatching { proxy.connect(device) }.getOrDefault(false)
        if (!accepted) {
            if (generation == connectionGeneration) {
                connectionGeneration++
                connectingDevice = null
            }
            if (automatic) scheduleAutomaticReconnect(device) else publish(
                HidConnectionState.ERROR,
                "连接请求失败",
                "请删除旧配对后重新配对",
            )
            return
        }
        scheduleConnectionTimeout(device, generation, automatic)
    }

    @SuppressLint("MissingPermission")
    private fun scheduleConnectionTimeout(
        device: BluetoothDevice,
        generation: Int,
        automatic: Boolean,
    ) {
        postDelayed(CONNECTION_TIMEOUT_MILLIS) {
            if (
                destroyed || generation != connectionGeneration ||
                !sameDevice(connectingDevice, device) || sameDevice(connectedDevice, device)
            ) return@postDelayed
            connectionGeneration++
            connectingDevice = null
            runCatching { hidProxy?.disconnect(device) }
            if (automatic) {
                publish(
                    HidConnectionState.CONNECTING,
                    "连接超时，正在重试…",
                    safeDeviceName(device),
                )
                scheduleAutomaticReconnect(device)
            } else {
                publish(HidConnectionState.ERROR, "连接超时", "请确认电脑蓝牙已开启后重试")
            }
            refreshPairedDevicesInternal()
        }
    }

    private fun scheduleAutomaticReconnect(device: BluetoothDevice?) {
        if (
            !preferences.getBoolean(PREF_AUTO_CONNECT, true) || !resumed || !hidRegistered ||
            reconnectAttempt >= MAX_RECONNECT_ATTEMPTS
        ) return
        val address = device?.let(::safeDeviceAddress)
        val lastAddress = preferences.getString(PREF_LAST_DEVICE, null)
        if (address != null && address != lastAddress) return
        val generation = connectionGeneration
        postDelayed(900L + reconnectAttempt * 650L) {
            if (generation == connectionGeneration && connectedDevice == null) {
                adoptExistingConnectionOrReconnect()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun disconnectCurrentDevice() {
        if (!ensureConnectPermission(prompt = true)) return
        val proxy = hidProxy
        val device = connectedDevice
        if (proxy == null || device == null) {
            message("当前没有已连接的电脑")
            return
        }
        reconnectAttempt = MAX_RECONNECT_ATTEMPTS
        val generation = ++connectionGeneration
        publish(HidConnectionState.DISCONNECTING, "正在断开…", safeDeviceName(device))
        scope.launch {
            bluetoothExecutor.releaseAll(KeyReleaseReason.DISCONNECTED)
            if (destroyed || generation != connectionGeneration) return@launch
            val accepted = runCatching { proxy.disconnect(device) }.getOrDefault(false)
            if (!accepted) {
                publish(HidConnectionState.CONNECTED, safeDeviceName(device), "断开请求未被系统接受")
                message("断开请求未被系统接受")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun establishConnectedSession(device: BluetoothDevice) {
        if (destroyed || !hasConnectPermission()) return
        val proxy = hidProxy ?: return
        if (sameDevice(connectedDevice, device) && currentSessionId != null) {
            publish(
                if (resumed) HidConnectionState.CONNECTED else HidConnectionState.SUSPENDED,
                safeDeviceName(device),
                if (resumed) "已连接 · 蓝牙 HID" else "已释放所有按键，连接保持待机",
            )
            return
        }
        val expected = connectingDevice
        if (expected != null && !sameDevice(expected, device)) {
            runCatching { proxy.disconnect(device) }
            return
        }
        connectionGeneration++
        val generation = connectionGeneration
        connectedDevice = device
        connectingDevice = null
        reconnectAttempt = 0
        val address = safeDeviceAddress(device) ?: "unknown"
        val sessionId = "$address#$generation"
        currentSessionId = sessionId
        preferences.edit().putString(PREF_LAST_DEVICE, address).apply()
        publish(HidConnectionState.CONNECTING, safeDeviceName(device), "正在建立安全 HID 会话")

        scope.launch {
            // Release the old captured transport before opening a sender session, because
            // openSession intentionally invalidates its predecessor.
            bluetoothExecutor.releaseAll(KeyReleaseReason.SESSION_REPLACED)
            if (destroyed || currentSessionId != sessionId || generation != connectionGeneration) {
                return@launch
            }
            val senderSession = runCatching {
                reportSender.openSession { reportId, payload ->
                    if (!hasConnectPermission()) false else proxy.sendReport(device, reportId, payload)
                }
            }.getOrElse { error ->
                publish(HidConnectionState.ERROR, "HID 会话建立失败", error.message ?: "未知错误")
                return@launch
            }
            runCatching { bluetoothExecutor.bindSession(sessionId, senderSession) }
                .onSuccess {
                    if (!destroyed && currentSessionId == sessionId && generation == connectionGeneration) {
                        publish(
                            if (resumed) HidConnectionState.CONNECTED else HidConnectionState.SUSPENDED,
                            safeDeviceName(device),
                            if (resumed) "已连接 · 蓝牙 HID" else "已释放所有按键，连接保持待机",
                        )
                        refreshPairedDevicesInternal()
                        message("已连接到 ${safeDeviceName(device)}")
                    } else {
                        senderSession.close()
                    }
                }
                .onFailure { error ->
                    senderSession.close()
                    if (currentSessionId == sessionId) {
                        publish(HidConnectionState.ERROR, "HID 会话建立失败", error.message ?: "未知错误")
                    }
                }
        }
    }

    private fun handleDisconnected(device: BluetoothDevice) {
        val wasConnected = sameDevice(connectedDevice, device)
        val wasConnecting = sameDevice(connectingDevice, device)
        val lostSessionId = if (wasConnected) currentSessionId else null
        if (wasConnected) {
            connectedDevice = null
            currentSessionId = null
        }
        if (wasConnecting) connectingDevice = null
        if (wasConnected || wasConnecting) connectionGeneration++
        if (lostSessionId != null) {
            scope.launch { bluetoothExecutor.unbindAfterTransportLoss(lostSessionId) }
        }
        publish(
            if (hidRegistered) HidConnectionState.READY else HidConnectionState.REGISTERING,
            if (hidRegistered) "蓝牙 HID 已就绪" else "正在注册 PC遥控器…",
            if (hidRegistered) "点按已配对电脑进行连接" else "请稍候",
        )
        refreshPairedDevicesInternal()
        if (wasConnected || wasConnecting) scheduleAutomaticReconnect(device)
    }

    private fun clearConnectionAfterTransportLoss() {
        val lostSessionId = currentSessionId
        connectedDevice = null
        connectingDevice = null
        currentSessionId = null
        if (lostSessionId != null) {
            scope.launch { bluetoothExecutor.unbindAfterTransportLoss(lostSessionId) }
        }
        refreshPairedDevicesInternal()
    }

    @SuppressLint("MissingPermission")
    private fun handleTransportFailure(sessionId: String, message: String): Unit = onMain {
        if (destroyed || currentSessionId != sessionId) return@onMain
        val failedDevice = connectedDevice
        publish(HidConnectionState.ERROR, "指令发送失败", "正在尝试恢复蓝牙连接")
        reconnectAttempt = 0
        connectionGeneration++
        currentSessionId = null
        connectedDevice = null
        connectingDevice = null
        scope.launch { bluetoothExecutor.unbindAfterTransportLoss(sessionId) }
        if (failedDevice != null && hasConnectPermission()) {
            runCatching { hidProxy?.disconnect(failedDevice) }
            scheduleAutomaticReconnect(failedDevice)
        }
        message("$message，正在恢复连接")
    }

    private fun ensureConnectPermission(prompt: Boolean): Boolean {
        if (hasConnectPermission()) return true
        publishPermissionRequired()
        if (prompt && !connectPermissionRequestInFlight && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            connectPermissionRequestInFlight = true
            safeHost { requestBluetoothConnectPermission() }
        }
        return false
    }

    private fun hasConnectPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    private fun hasAdvertisePermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) ==
            PackageManager.PERMISSION_GRANTED

    private fun publishPermissionRequired() = publish(
        HidConnectionState.PERMISSION_REQUIRED,
        "需要附近设备权限",
        "允许蓝牙连接与配对后即可使用 PC遥控器",
    )

    private fun publishBluetoothDisabled() = publish(
        HidConnectionState.BLUETOOTH_DISABLED,
        "蓝牙尚未开启",
        "开启蓝牙后即可连接电脑",
    )

    private fun requestDiscoverabilityFromHost() {
        if (bluetoothAdapter == null) return
        safeHost { requestDiscoverability(PAIRING_DURATION_SECONDS) }
    }

    private fun publish(state: HidConnectionState, title: String, detail: String) {
        val connectedInfo = connectedDevice?.let(::deviceInfo)
        mutableUiState.value = BluetoothHidUiState(
            connectionState = state,
            title = title,
            detail = detail,
            connectedDevice = connectedInfo,
            connectingDeviceAddress = connectingDevice?.let(::safeDeviceAddress),
            hidRegistered = hidRegistered,
            canConnect = hidRegistered && connectedDevice == null && connectingDevice == null,
            canRepair = state == HidConnectionState.ERROR || state == HidConnectionState.REGISTERING,
            profileAttempt = profileAttempt,
            registrationAttempt = registrationAttempt,
            reconnectAttempt = reconnectAttempt,
        )
    }

    @SuppressLint("MissingPermission")
    private fun deviceInfo(device: BluetoothDevice): PairedBluetoothDevice? {
        val address = safeDeviceAddress(device) ?: return null
        val state = when {
            sameDevice(connectedDevice, device) -> PairedDeviceState.CONNECTED
            sameDevice(connectingDevice, device) -> PairedDeviceState.CONNECTING
            else -> PairedDeviceState.PAIRED
        }
        return PairedBluetoothDevice(
            address = address,
            name = safeDeviceName(device),
            state = state,
            wasLastConnected = preferences.getString(PREF_LAST_DEVICE, null) == address,
        )
    }

    @SuppressLint("MissingPermission")
    private fun safeDeviceName(device: BluetoothDevice?): String {
        if (device == null) return "未知设备"
        return runCatching { device.name?.trim().orEmpty() }
            .getOrDefault("")
            .takeIf(String::isNotBlank)
            ?: safeDeviceAddress(device)
            ?: "未知设备"
    }

    @SuppressLint("MissingPermission")
    private fun safeDeviceAddress(device: BluetoothDevice): String? =
        runCatching { device.address }.getOrNull()

    private fun sameDevice(first: BluetoothDevice?, second: BluetoothDevice?): Boolean {
        if (first == null || second == null) return false
        val firstAddress = safeDeviceAddress(first)
        return firstAddress != null && firstAddress == safeDeviceAddress(second)
    }

    private fun closeIncomingProxy(profile: Int, proxy: BluetoothProfile) {
        runCatching { bluetoothAdapter?.closeProfileProxy(profile, proxy) }
    }

    private fun message(text: String) = safeHost { showMessage(text) }

    private inline fun safeHost(block: BluetoothHidHostCallbacks.() -> Unit) {
        runCatching { hostCallbacks.block() }
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    private fun postDelayed(delayMillis: Long, block: () -> Unit) {
        mainHandler.postDelayed(block, delayMillis)
    }

    private companion object {
        const val BLUETOOTH_PREFERENCES = "douyin_remote_settings"
        const val PREF_LAST_DEVICE = "last_device_address"
        const val PREF_AUTO_CONNECT = "auto_connect"
        const val SDP_NAME = "PC遥控器"
        const val SDP_DESCRIPTION = "PC遥控器 · Keyboard, mouse and media controls"
        const val SDP_PROVIDER = "PC遥控器"
        const val MAX_PROFILE_ATTEMPTS = 5
        const val MAX_REGISTRATION_ATTEMPTS = 5
        const val MAX_RECONNECT_ATTEMPTS = 3
        const val PAIRING_DURATION_SECONDS = 300
        const val CONNECTION_TIMEOUT_MILLIS = 8_000L
        const val REGISTRATION_CONFIRM_TIMEOUT_MILLIS = 3_200L
        const val PROFILE_ACQUISITION_TIMEOUT_MILLIS = 4_000L
    }
}
