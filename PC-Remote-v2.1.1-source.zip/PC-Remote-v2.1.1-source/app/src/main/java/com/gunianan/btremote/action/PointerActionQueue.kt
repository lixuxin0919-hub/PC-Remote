package com.gunianan.btremote.action

import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.MouseCommand
import com.gunianan.btremote.domain.RemoteActionConfig
import java.util.ArrayDeque
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

/**
 * A small, non-blocking ingress queue for high-frequency pointer input.
 *
 * One worker owns [execute], so callers can use [offer] directly from pointer callbacks without
 * launching a coroutine for every sample. Adjacent movement and scroll samples are accumulated,
 * then emitted in HID-safe -127..127 chunks. Discrete actions retain FIFO ordering. Capacity is
 * reserved for one release per mouse button, ensuring a valid mouse UP is never rejected after a
 * corresponding DOWN was admitted.
 */
class PointerActionQueue(
    scope: CoroutineScope,
    val capacity: Int = DEFAULT_CAPACITY,
    private val onExecutionError: (Throwable) -> Unit = {},
    private val execute: suspend (RemoteActionConfig) -> Unit,
) : AutoCloseable {

    enum class OfferResult {
        ENQUEUED,
        MERGED,
        REJECTED_FULL,
        IGNORED_EMPTY_MOTION,
        CLOSED,
    }

    data class Snapshot(
        val pendingCount: Int,
        val capacity: Int,
        val isClosed: Boolean,
        val mergedMotionCount: Long,
        val droppedMotionCount: Long,
        val rejectedCount: Long,
    )

    private val lock = Any()
    private val pending = ArrayDeque<PendingAction>(capacity)
    private val wakeUp = Channel<Unit>(Channel.CONFLATED)
    private val regularCapacity = capacity - RELEASE_RESERVE

    private var closed = false
    private var mergedMotionCount = 0L
    private var droppedMotionCount = 0L
    private var rejectedCount = 0L

    private val worker: Job

    init {
        require(capacity > RELEASE_RESERVE) {
            "capacity must be greater than the number of supported mouse buttons"
        }
        worker = scope.launch { consumePendingActions() }
        worker.invokeOnCompletion {
            synchronized(lock) {
                closed = true
                pending.clear()
            }
            wakeUp.close()
        }
    }

    /**
     * Offers an action without suspending. The result explicitly reports back-pressure.
     *
     * Motion may be merged or rejected under pressure. A valid mouse UP is accepted whenever its
     * latest queued state is DOWN; redundant UPs are coalesced because one release is sufficient.
     */
    fun offer(action: RemoteActionConfig): OfferResult {
        val candidate = PendingAction.from(action)
            ?: return OfferResult.IGNORED_EMPTY_MOTION

        val result = synchronized(lock) {
            if (closed) return@synchronized OfferResult.CLOSED

            mergeWithTail(candidate)?.let { return@synchronized it }

            when {
                candidate.isMouseRelease -> admitRelease(candidate)
                pending.size < regularCapacity -> enqueue(candidate)
                pending.size == regularCapacity && evictOldestMotion() -> enqueue(candidate)
                else -> reject()
            }
        }

        if (result == OfferResult.ENQUEUED) {
            wakeUp.trySend(Unit)
        }
        return result
    }

    val pendingCount: Int
        get() = synchronized(lock) { pending.size }

    val isClosed: Boolean
        get() = synchronized(lock) { closed }

    fun snapshot(): Snapshot = synchronized(lock) {
        Snapshot(
            pendingCount = pending.size,
            capacity = capacity,
            isClosed = closed,
            mergedMotionCount = mergedMotionCount,
            droppedMotionCount = droppedMotionCount,
            rejectedCount = rejectedCount,
        )
    }

    /** Cancels the sole worker and atomically discards all queued input. */
    fun cancel() = close()

    /** Cancels the sole worker and atomically discards all queued input. */
    override fun close() {
        val shouldCancel = synchronized(lock) {
            if (closed) {
                false
            } else {
                closed = true
                pending.clear()
                true
            }
        }
        if (shouldCancel) {
            wakeUp.close()
            worker.cancel()
        }
    }

    private suspend fun consumePendingActions() {
        for (ignored in wakeUp) {
            while (true) {
                val next = synchronized(lock) {
                    if (closed) null else pending.pollFirst()
                } ?: break

                for (action in next.toExecutableActions()) {
                    try {
                        execute(action)
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (failure: Throwable) {
                        runCatching { onExecutionError(failure) }
                    }
                }
            }
        }
    }

    private fun mergeWithTail(candidate: PendingAction): OfferResult? {
        val tail = pending.peekLast() ?: return null
        val merged = tail.merge(candidate) ?: return null
        pending.removeLast()
        pending.addLast(merged)
        mergedMotionCount++
        return OfferResult.MERGED
    }

    private fun admitRelease(candidate: PendingAction): OfferResult {
        val release = candidate as PendingAction.Discrete
        val button = (release.action as RemoteActionConfig.MouseAction).button

        // If the last queued state for this button is already released, another UP adds no safety.
        val iterator = pending.descendingIterator()
        while (iterator.hasNext()) {
            val action = (iterator.next() as? PendingAction.Discrete)?.action
                as? RemoteActionConfig.MouseAction ?: continue
            if (action.button != button) continue
            when (action.command) {
                MouseCommand.UP, MouseCommand.CLICK -> return OfferResult.MERGED
                MouseCommand.DOWN -> break
                MouseCommand.MOVE -> Unit
            }
        }

        return when {
            pending.size < capacity -> enqueue(candidate)
            evictOldestMotion() -> enqueue(candidate)
            else -> {
                // This branch cannot be reached with validated input: regular admission reserves
                // one slot for every MouseButton enum value, and no new DOWN enters that reserve.
                // If invariants are violated by concurrent, unvalidated input, release safety still
                // wins over a lower-priority discrete action.
                if (evictOldestNonRelease()) enqueue(candidate) else OfferResult.MERGED
            }
        }
    }

    private fun evictOldestNonRelease(): Boolean {
        val iterator = pending.iterator()
        while (iterator.hasNext()) {
            if (!iterator.next().isMouseRelease) {
                iterator.remove()
                return true
            }
        }
        return false
    }

    private fun enqueue(action: PendingAction): OfferResult {
        pending.addLast(action)
        return OfferResult.ENQUEUED
    }

    private fun reject(): OfferResult {
        rejectedCount++
        return OfferResult.REJECTED_FULL
    }

    private fun evictOldestMotion(): Boolean {
        val iterator = pending.iterator()
        while (iterator.hasNext()) {
            if (iterator.next() is PendingAction.Motion) {
                iterator.remove()
                droppedMotionCount++
                return true
            }
        }
        return false
    }

    private sealed interface PendingAction {
        val isMouseRelease: Boolean
            get() = false

        fun merge(other: PendingAction): PendingAction? = null

        fun toExecutableActions(): Sequence<RemoteActionConfig>

        data class Discrete(val action: RemoteActionConfig) : PendingAction {
            override val isMouseRelease: Boolean
                get() = action is RemoteActionConfig.MouseAction &&
                    action.command == MouseCommand.UP && action.button != null

            override fun toExecutableActions(): Sequence<RemoteActionConfig> = sequenceOf(action)
        }

        sealed interface Motion : PendingAction

        data class MouseMove(val deltaX: Long, val deltaY: Long) : Motion {
            override fun merge(other: PendingAction): PendingAction? =
                (other as? MouseMove)?.let {
                    MouseMove(deltaX.saturatingPlus(it.deltaX), deltaY.saturatingPlus(it.deltaY))
                }

            override fun toExecutableActions(): Sequence<RemoteActionConfig> =
                chunkedDeltas(deltaX, deltaY) { x, y ->
                    RemoteActionConfig.MouseAction(
                        command = MouseCommand.MOVE,
                        deltaX = x,
                        deltaY = y,
                    )
                }
        }

        data class Scroll(val horizontal: Long, val vertical: Long) : Motion {
            override fun merge(other: PendingAction): PendingAction? =
                (other as? Scroll)?.let {
                    Scroll(
                        horizontal.saturatingPlus(it.horizontal),
                        vertical.saturatingPlus(it.vertical),
                    )
                }

            override fun toExecutableActions(): Sequence<RemoteActionConfig> =
                chunkedDeltas(horizontal, vertical) { x, y ->
                    RemoteActionConfig.ScrollAction(horizontal = x, vertical = y)
                }
        }

        data class ModifiedScroll(
            val modifiers: Set<com.gunianan.btremote.domain.KeyboardModifier>,
            val vertical: Long,
        ) : Motion {
            override fun merge(other: PendingAction): PendingAction? =
                (other as? ModifiedScroll)?.takeIf { it.modifiers == modifiers }?.let {
                    copy(vertical = vertical.saturatingPlus(it.vertical))
                }

            override fun toExecutableActions(): Sequence<RemoteActionConfig> = sequence {
                var remaining = vertical
                while (remaining != 0L) {
                    val chunk = remaining.coerceIn(MIN_DELTA, MAX_DELTA).toInt()
                    yield(RemoteActionConfig.ModifiedScrollAction(modifiers, chunk))
                    remaining -= chunk
                }
            }
        }

        companion object {
            fun from(action: RemoteActionConfig): PendingAction? = when (action) {
                is RemoteActionConfig.MouseAction -> {
                    if (action.command != MouseCommand.MOVE) {
                        Discrete(action)
                    } else if (action.deltaX == 0 && action.deltaY == 0) {
                        null
                    } else {
                        MouseMove(
                            action.deltaX.toLong(),
                            action.deltaY.toLong(),
                        )
                    }
                }
                is RemoteActionConfig.ScrollAction -> {
                    if (action.horizontal == 0 && action.vertical == 0) {
                        null
                    } else {
                        Scroll(
                            action.horizontal.toLong(),
                            action.vertical.toLong(),
                        )
                    }
                }
                is RemoteActionConfig.ModifiedScrollAction -> if (action.vertical == 0) {
                    null
                } else {
                    ModifiedScroll(action.modifiers, action.vertical.toLong())
                }
                else -> Discrete(action)
            }
        }
    }

    companion object {
        const val DEFAULT_CAPACITY = 24
        private val RELEASE_RESERVE = MouseButton.entries.size

        private fun Long.saturatingPlus(other: Long): Long = when {
            other > 0 && this > Long.MAX_VALUE - other -> Long.MAX_VALUE
            other < 0 && this < Long.MIN_VALUE - other -> Long.MIN_VALUE
            else -> this + other
        }

        private fun chunkedDeltas(
            first: Long,
            second: Long,
            create: (Int, Int) -> RemoteActionConfig,
        ): Sequence<RemoteActionConfig> = sequence {
            var remainingFirst = first
            var remainingSecond = second
            while (remainingFirst != 0L || remainingSecond != 0L) {
                val firstChunk = remainingFirst.coerceIn(MIN_DELTA, MAX_DELTA).toInt()
                val secondChunk = remainingSecond.coerceIn(MIN_DELTA, MAX_DELTA).toInt()
                yield(create(firstChunk, secondChunk))
                remainingFirst -= firstChunk
                remainingSecond -= secondChunk
            }
        }

        private const val MIN_DELTA = -127L
        private const val MAX_DELTA = 127L
    }
}
