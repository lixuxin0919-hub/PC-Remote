package com.gunianan.btremote.trackpad.settings

import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.RemoteActionConfig
import kotlinx.serialization.Serializable

@Serializable
data class TrackpadSettings(
    val sensitivityPreset: PointerSensitivityPreset = PointerSensitivityPreset.STANDARD,
    val pointerSensitivity: Float = 1.0f,
    val pointerAcceleration: Float = 0.22f,
    val naturalScrolling: Boolean = true,
    val scrollSpeed: Float = 1.0f,
    val doubleTapTimeoutMs: Long = 300L,
    val dragMode: TrackpadDragMode = TrackpadDragMode.DOUBLE_TAP_HOLD_OR_LONG_PRESS,
    val twoFingerNavigationEnabled: Boolean = true,
    val horizontalScrollMode: HorizontalScrollMode = HorizontalScrollMode.SHIFT_WHEEL,
    val threeFingerGesturesEnabled: Boolean = true,
    val fourFingerGesturesEnabled: Boolean = false,
    val showMouseButtons: Boolean = true,
    val hapticEnabled: Boolean = true,
    val adaptivePressureEnabled: Boolean = true,
    val pressureSensitivity: Float = 1.0f,
    val normalPressThreshold: Float = 0.48f,
    val forcePressThreshold: Float = 0.74f,
    val forcePressAction: ForcePressAction = ForcePressAction.DRAG,
    val pressureHapticEnabled: Boolean = true,
    val calibration: PressureCalibrationProfile? = null,
    val gestureActions: TrackpadGestureActions = TrackpadGestureActions(),
    val reliablePressureWeights: PressureModelWeights = PressureModelWeights(
        pressure = 0.55f,
        size = 0.20f,
        contactArea = 0.15f,
        duration = 0.10f,
    ),
    val simulatedPressureWeights: PressureModelWeights = PressureModelWeights(
        pressure = 0f,
        size = 0.45f,
        contactArea = 0.35f,
        duration = 0.20f,
    ),
)

@Serializable
enum class PointerSensitivityPreset { PRECISE, STANDARD, FAST, CUSTOM }

@Serializable
enum class TrackpadDragMode { DOUBLE_TAP_HOLD, LONG_PRESS, DOUBLE_TAP_HOLD_OR_LONG_PRESS }

@Serializable
enum class HorizontalScrollMode { SHIFT_WHEEL }

@Serializable
enum class ForcePressAction { DRAG, NONE }

@Serializable
data class PressureCalibrationProfile(
    val pressureReliable: Boolean,
    val pressureMinimum: Float,
    val pressureMaximum: Float,
    val sizeMinimum: Float,
    val sizeMaximum: Float,
    val contactAreaMinimum: Float,
    val contactAreaMaximum: Float,
    val normalPressThreshold: Float,
    val forcePressThreshold: Float,
    val sampleCount: Int,
    val calibratedAt: Long,
)

@Serializable
data class PressureModelWeights(
    val pressure: Float,
    val size: Float,
    val contactArea: Float,
    val duration: Float,
) {
    val total: Float get() = pressure + size + contactArea + duration
}

@Serializable
data class TrackpadGestureActions(
    val twoFingerBack: RemoteActionConfig = shortcut(KeyboardModifier.LEFT_ALT, keyCode = 0x50),
    val twoFingerForward: RemoteActionConfig = shortcut(KeyboardModifier.LEFT_ALT, keyCode = 0x4F),
    val threeFingerUp: RemoteActionConfig = shortcut(KeyboardModifier.LEFT_GUI, keyCode = 0x2B),
    val threeFingerDown: RemoteActionConfig = shortcut(KeyboardModifier.LEFT_GUI, keyCode = 0x07),
    val threeFingerLeft: RemoteActionConfig = shortcut(KeyboardModifier.LEFT_GUI, KeyboardModifier.LEFT_CONTROL, keyCode = 0x50),
    val threeFingerRight: RemoteActionConfig = shortcut(KeyboardModifier.LEFT_GUI, KeyboardModifier.LEFT_CONTROL, keyCode = 0x4F),
    val threeFingerTap: RemoteActionConfig = shortcut(KeyboardModifier.LEFT_GUI, keyCode = 0x16),
) {
    fun actionFor(slot: TrackpadGestureActionSlot): RemoteActionConfig = when (slot) {
        TrackpadGestureActionSlot.TWO_FINGER_BACK -> twoFingerBack
        TrackpadGestureActionSlot.TWO_FINGER_FORWARD -> twoFingerForward
        TrackpadGestureActionSlot.THREE_FINGER_UP -> threeFingerUp
        TrackpadGestureActionSlot.THREE_FINGER_DOWN -> threeFingerDown
        TrackpadGestureActionSlot.THREE_FINGER_LEFT -> threeFingerLeft
        TrackpadGestureActionSlot.THREE_FINGER_RIGHT -> threeFingerRight
        TrackpadGestureActionSlot.THREE_FINGER_TAP -> threeFingerTap
    }

    fun withAction(slot: TrackpadGestureActionSlot, action: RemoteActionConfig): TrackpadGestureActions = when (slot) {
        TrackpadGestureActionSlot.TWO_FINGER_BACK -> copy(twoFingerBack = action)
        TrackpadGestureActionSlot.TWO_FINGER_FORWARD -> copy(twoFingerForward = action)
        TrackpadGestureActionSlot.THREE_FINGER_UP -> copy(threeFingerUp = action)
        TrackpadGestureActionSlot.THREE_FINGER_DOWN -> copy(threeFingerDown = action)
        TrackpadGestureActionSlot.THREE_FINGER_LEFT -> copy(threeFingerLeft = action)
        TrackpadGestureActionSlot.THREE_FINGER_RIGHT -> copy(threeFingerRight = action)
        TrackpadGestureActionSlot.THREE_FINGER_TAP -> copy(threeFingerTap = action)
    }
}

@Serializable
enum class TrackpadGestureActionSlot(val displayName: String) {
    TWO_FINGER_BACK("双指后退"),
    TWO_FINGER_FORWARD("双指前进"),
    THREE_FINGER_UP("三指上滑"),
    THREE_FINGER_DOWN("三指下滑"),
    THREE_FINGER_LEFT("三指左滑"),
    THREE_FINGER_RIGHT("三指右滑"),
    THREE_FINGER_TAP("三指轻点"),
}

private fun shortcut(
    vararg modifiers: KeyboardModifier,
    keyCode: Int,
): RemoteActionConfig = RemoteActionConfig.KeyboardShortcut(modifiers.toSet(), keyCode)
