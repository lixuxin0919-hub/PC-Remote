package com.gunianan.btremote.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object PcRemoteColors {
    val Primary = Color(0xFF0A84FF)
    val PrimaryDeep = Color(0xFF2567E8)
    val Text = Color(0xFF121F33)
    val Muted = Color(0xFF536784)
    val Success = Color(0xFF30BE5C)
    val Warning = Color(0xFFFF9500)
    val Error = Color(0xFFFF3B30)
    val Idle = Color(0xFF8997AB)
    val Glass = Color(0xDDF7FAFF)
    val GlassStrong = Color(0xF2FFFFFF)
    val GlassBorder = Color(0xD9FFFFFF)
    val Hairline = Color(0x33709AC8)
    val AuroraTop = Color(0xFFF6F9FF)
    val AuroraBlue = Color(0xFFD8EBFF)
    val AuroraCyan = Color(0xFFD8F7FF)
    val AuroraLavender = Color(0xFFE8E7FF)
}

object PcRemoteTypography {
    val ScreenTitle = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 32.sp,
        lineHeight = 38.sp,
        fontWeight = FontWeight.SemiBold,
        color = PcRemoteColors.Text,
    )
    val SectionTitle = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 17.sp,
        lineHeight = 22.sp,
        fontWeight = FontWeight.Medium,
        color = PcRemoteColors.Text,
    )
    val Body = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 15.sp,
        lineHeight = 21.sp,
        fontWeight = FontWeight.Normal,
        color = PcRemoteColors.Text,
    )
    val Caption = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 12.sp,
        lineHeight = 17.sp,
        fontWeight = FontWeight.Normal,
        color = PcRemoteColors.Muted,
    )
}

private val AppColorScheme = lightColorScheme(
    primary = PcRemoteColors.Primary,
    onPrimary = Color.White,
    secondary = PcRemoteColors.PrimaryDeep,
    onSecondary = Color.White,
    background = PcRemoteColors.AuroraTop,
    onBackground = PcRemoteColors.Text,
    surface = PcRemoteColors.Glass,
    onSurface = PcRemoteColors.Text,
    surfaceVariant = PcRemoteColors.GlassStrong,
    onSurfaceVariant = PcRemoteColors.Muted,
    error = PcRemoteColors.Error,
)

@Composable
fun PcRemoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = MaterialTheme.typography.copy(
            displaySmall = PcRemoteTypography.ScreenTitle,
            titleMedium = PcRemoteTypography.SectionTitle,
            bodyMedium = PcRemoteTypography.Body,
            labelMedium = PcRemoteTypography.Caption,
        ),
        content = content,
    )
}
