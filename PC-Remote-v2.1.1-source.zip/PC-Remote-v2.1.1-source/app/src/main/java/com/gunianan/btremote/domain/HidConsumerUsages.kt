package com.gunianan.btremote.domain

/**
 * Consumer-page usages supported by the app's current one-byte HID report descriptor.
 *
 * Persisted configuration must use this catalog so an action accepted by validation can
 * also be represented by the active Bluetooth transport. Future transports may support a
 * wider set independently, but the current configuration schema deliberately stays honest.
 */
object HidConsumerUsages {
    const val FAST_FORWARD: Int = 0xB3
    const val NEXT_TRACK: Int = 0xB5
    const val PREVIOUS_TRACK: Int = 0xB6
    const val STOP: Int = 0xB7
    const val PLAY_PAUSE: Int = 0xCD
    const val MUTE: Int = 0xE2
    const val VOLUME_INCREMENT: Int = 0xE9
    const val VOLUME_DECREMENT: Int = 0xEA

    val SUPPORTED_USAGE_IDS: Set<Int> = setOf(
        VOLUME_INCREMENT,
        VOLUME_DECREMENT,
        MUTE,
        PLAY_PAUSE,
        NEXT_TRACK,
        PREVIOUS_TRACK,
        STOP,
        FAST_FORWARD,
    )
}
