package com.gunianan.btremote.domain

import kotlinx.serialization.Serializable

const val CURRENT_SCHEMA_VERSION: Int = 2
const val SYSTEM_DEFAULT_PROFILE_ID: String = "system.default.video"
const val SYSTEM_TRACKPAD_PROFILE_ID: String = "system.trackpad"

val SYSTEM_PROFILE_IDS: Set<String> = setOf(
    SYSTEM_DEFAULT_PROFILE_ID,
    SYSTEM_TRACKPAD_PROFILE_ID,
)

@Serializable
data class ControlProfile(
    val id: String,
    val name: String,
    val icon: String? = null,
    val customIconPath: String? = null,
    val customIconUpdatedAt: Long? = null,
    /** Identifies the built-in baseline. Startup selection is stored separately. */
    val isDefault: Boolean = false,
    val isSystemProfile: Boolean = false,
    val controlAreaType: ControlAreaType,
    val controls: List<ControlItem> = emptyList(),
    val gestureBindings: List<GestureBinding> = emptyList(),
    val appearance: ProfileAppearance? = null,
    val customGestures: List<GestureTemplate> = emptyList(),
    val createdAt: Long,
    val updatedAt: Long,
)

@Serializable
enum class ControlAreaType {
    GESTURE,
    TOUCHPAD,
    HYBRID,
}

@Serializable
data class ControlItem(
    val id: String,
    val title: String,
    val icon: String? = null,
    val position: Int,
    val size: ControlItemSize = ControlItemSize.STANDARD,
    val visible: Boolean = true,
    val section: ControlSection = ControlSection.QUICK,
    val tapAction: RemoteActionConfig? = null,
    val doubleTapAction: RemoteActionConfig? = null,
    val longPressAction: RemoteActionConfig? = null,
    val repeatAction: RemoteActionConfig? = null,
)

@Serializable
enum class ControlItemSize {
    COMPACT,
    STANDARD,
    WIDE,
    LARGE,
}

@Serializable
enum class ControlSection {
    TOP,
    PRIMARY,
    QUICK,
    BOTTOM,
}

@Serializable
data class GestureBinding(
    val id: String,
    val gestureType: GestureType,
    val customGestureId: String? = null,
    val action: RemoteActionConfig,
    val enabled: Boolean = true,
    val minConfidence: Float? = null,
    val repeatPolicy: RepeatPolicy? = null,
)

@Serializable
enum class GestureType {
    SWIPE_UP,
    SWIPE_DOWN,
    SWIPE_LEFT,
    SWIPE_RIGHT,
    TAP,
    DOUBLE_TAP,
    LONG_PRESS,
    CIRCLE,
    X,
    Z,
    CHECK,
    CUSTOM,
    TOUCHPAD_TAP,
    TOUCHPAD_DOUBLE_TAP,
    TOUCHPAD_LONG_PRESS_DRAG,
    TOUCHPAD_TWO_FINGER_SCROLL,
    TOUCHPAD_TWO_FINGER_TAP,
}

@Serializable
data class RepeatPolicy(
    val initialDelayMs: Long = 500,
    val intervalMs: Long = 100,
    val maxDurationMs: Long = 30_000,
)

@Serializable
data class ProfileAppearance(
    val layout: ControlLayout = ControlLayout.LARGE_GESTURE,
    val gridColumns: Int = 3,
    val gestureAreaHeightFraction: Float = 0.58f,
    val accentColorArgb: Long? = null,
    val handedness: Handedness = Handedness.INHERIT,
    /** Null inherits the global haptic setting. */
    val hapticEnabled: Boolean? = null,
    val gestureSensitivity: Float = 1.0f,
    val confidenceThreshold: Float = 0.72f,
)

@Serializable
enum class ControlLayout {
    SINGLE_COLUMN,
    TWO_COLUMN,
    THREE_COLUMN,
    LARGE_GESTURE,
    COMPACT_REMOTE,
    FULLSCREEN_GESTURE,
    CUSTOM_GRID,
}

@Serializable
enum class Handedness {
    INHERIT,
    LEFT,
    RIGHT,
}

@Serializable
data class GestureTemplate(
    val id: String,
    val name: String,
    val rotationInvariant: Boolean = false,
    val startingDirection: Float? = null,
    val samples: List<GestureSample>,
    val createdAt: Long,
    val updatedAt: Long,
)

@Serializable
data class GestureSample(
    val points: List<GesturePoint>,
)

@Serializable
data class GesturePoint(
    /** Normalized X coordinate, normally in the [-1, 1] range. */
    val x: Float,
    /** Normalized Y coordinate, normally in the [-1, 1] range. */
    val y: Float,
    val elapsedMs: Long,
)
