package com.gunianan.btremote.ui.localized

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import java.util.concurrent.ConcurrentHashMap

/** Drop-in Material Text wrapper that localizes legacy UI literals during the resource migration. */
@Composable
fun LocalizedText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: (TextLayoutResult) -> Unit = {},
    style: TextStyle = LocalTextStyle.current,
    localize: Boolean = true,
) {
    val language = LocalConfiguration.current.locales[0].language
    androidx.compose.material3.Text(
        text = if (localize) UiTextTranslator.translate(text, language) else text,
        modifier = modifier,
        color = if (color == Color.Unspecified) LocalContentColor.current else color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        onTextLayout = onTextLayout,
        style = style,
    )
}

object UiTextTranslator {
    private const val MAX_CACHE_ENTRIES = 1_024
    private val englishCache = ConcurrentHashMap<String, String>()
    private val translations: List<Pair<String, String>> by lazy {
        buildMap<String, String> {
        rawEntries.lines().forEach { line ->
            val separator = line.indexOf('\t')
            if (separator > 0) put(line.substring(0, separator), line.substring(separator + 1))
        }
        }.entries.sortedByDescending { it.key.length }.map { it.key to it.value }
    }

    fun translate(text: String, language: String): String {
        if (!language.equals("en", ignoreCase = true) || text.none(::isCjk)) return text
        englishCache[text]?.let { return it }
        var translated = text
        translations.forEach { (source, target) -> translated = translated.replace(source, target) }
        if (englishCache.size >= MAX_CACHE_ENTRIES) englishCache.clear()
        englishCache[text] = translated
        return translated
    }

    private fun isCjk(character: Char): Boolean = character.code in 0x3400..0x9FFF

    private val rawEntries = """
PC遥控器只读取系统已配对设备，不扫描位置	PC Remote only reads paired devices; it does not scan for location
PC遥控器	PC Remote
蓝牙 HID 已就绪	Bluetooth HID ready
首次使用请进入配对模式	Enter pairing mode for first-time setup
默认视频模式	Default video profile
触控板模式	Touchpad profile
上一个视频	Previous video
暂停视频	Play/Pause video
下一个视频	Next video
音量减小	Volume down
音量增加	Volume up
三指上滑	Three-finger swipe up
三指下滑	Three-finger swipe down
三指左滑	Three-finger swipe left
三指右滑	Three-finger swipe right
三指轻点	Three-finger tap
双指前进	Two-finger forward
双指后退	Two-finger back
上一首 / 上一条	Previous track / previous item
下一首 / 下一条	Next track / next item
停止播放	Stop playback
尚未连接电脑	No computer connected
请先连接电脑	Connect a computer first
未知设备	Unknown device
未知错误	Unknown error
导入成功	Import successful
导出失败	Export failed
控制模式已保存	Control profile saved
已切换到 	Switched to 
已创建 	Created 
默认视频模式已恢复	Default video profile restored
图标保存失败	Failed to save icon
无法保存图标	Unable to save icon
无法保存设置	Unable to save settings
无法保存控制模式	Unable to save control profile
无法读取已配对设备	Unable to read paired devices
需要附近设备权限	Nearby devices permission required
开启蓝牙后即可连接电脑	Turn on Bluetooth to connect a computer
此手机不支持蓝牙	This phone does not support Bluetooth
正在自动连接…	Connecting automatically…
正在断开…	Disconnecting…
连接超时	Connection timed out
连接请求失败	Connection request failed
自动连接失败	Automatic connection failed
返回应用后继续连接	Return to the app to continue connecting
手机已进入配对模式，请在电脑蓝牙设置中添加 PC遥控器	Pairing mode is active. Add PC Remote from the computer's Bluetooth settings.
已导出	exported
导出失败：	Export failed: 
无法写入文件	Unable to write the file
无法打开系统蓝牙设置	Unable to open system Bluetooth settings
开发者邮箱：	Developer email: 
 · 上次连接	 · Last connected
 不是触控板手势	 is not a touchpad gesture
 个模式 · 设置会自动保存	 profiles · Changes save automatically
% 相似	% similar
 · 单笔轨迹	 · Single-stroke path
5 次测试完成	5 tests completed
1. 配对电脑	1. Pair a computer
2. 连接	2. Connect
5. 安全释放	5. Safe release
Shift + 滚轮（兼容模式）	Shift + wheel (compatibility mode)
仅重置触控板与压力选项	Only reset touchpad and pressure options
估算接触面积	Estimated contact area
使用日常点击的力度按住并移动	Press and move with your normal clicking pressure
像移动光标一样轻轻触摸并移动	Touch lightly and move as if moving the pointer
全选并复制	Select all and copy
内置多步模板	Built-in multi-step template
再绘制 5 次验证稳定性 · 	Draw it 5 more times to verify stability · 
切换控制区类型	Switch control area type
切换控制模式	Switch control profile
删除“	Delete “
”后，其控件、手势配置和自定义图标也会被移除。\n此操作无法撤销。	”. Its controls, gesture configuration, and custom icon will also be removed.\nThis cannot be undone.
加宽	Widen
动作只描述意图，由执行器统一发送	Actions describe intent and are sent by the shared executor
单独设置识别阈值	Set a separate recognition threshold
双指缩放，拖动调整位置	Pinch with two fingers; drag to adjust position
发现 	Found 
 个相似手势	 similar gestures
启动	Launch
回车	Enter
图标	Icon
复制后粘贴	Copy, then paste
大手势区	Large gesture area
已选择	Selected
布局	Layout
常用键	Common keys
平滑 pressure	Smoothed pressure
序列预览	Sequence preview
应用内 · 	In-app · 
应用内	In-app
当前成功率 	Current success rate 
录制手势样本	Record gesture samples
快捷键 · 	Shortcut · 
快捷键	Shortcut
快进	Fast forward
成功率 	Success rate 
我的手势	My gestures
手势区	Gesture area
手指上移时内容向上滚动	Content scrolls up when your fingers move up
打开设置	Open settings
按下 	Press 
按下右键	Press right button
按下左键	Press left button
按键会直接发送到已连接的电脑	Keys are sent directly to the connected computer
控制期间不自动熄屏	Prevent screen timeout while controlling
新控件	New control
槽位 	Slot 
测试第 	Test 
测试自定义手势	Test custom gesture
滚动 · 	Scroll · 
滚动	Scroll
点击 	Tap 
点击	Tap
用明显更大的力度按住，但不要让手指不适	Press noticeably harder, without causing discomfort
移动指针	Move pointer
空格	Space
等待 	Wait 
组合滚动 · 	Modified scroll · 
组合键	Key combination
绘制第 	Drawing 
能力边界	Capability limits
请自然绘制同一手势 3 次 · 	Draw the same gesture naturally 3 times · 
跟随模式 	Follow profile 
连接	Connect
退格	Backspace
释放 	Release 
释放右键	Release right button
释放左键	Release left button
重复 	Repeat 
重复方向键	Repeat arrow key
长按拖动	Hold to drag
震动反馈	Haptic feedback
 个控件	 controls
 个手势	 gestures
 个样本	 samples
 次未识别	 failed recognitions
 次	
 步	 steps
 列	 columns
按下	Press 
释放	Release 
样本	Samples
次	Times
需要 Android 9 或更高版本，且手机系统支持 Bluetooth HID Device Profile。	Requires Android 9 or later and Bluetooth HID Device Profile support.
说明：蓝牙 HID 只能发送键盘、媒体与鼠标输入，无法读取电脑当前播放、音量或静音状态。	Bluetooth HID can send keyboard, media, and mouse input, but cannot read playback, volume, or mute state from the computer.
纯 HID 不会读取电脑音量、播放或静音状态，界面不会伪造这些状态。	HID cannot read the computer's volume, playback, or mute state, so the app never fabricates them.
系统模式的名称、控件、动作和手势会恢复初始值；其他模式保持不变。	The system profile name, controls, actions, and gestures will be reset. Other profiles stay unchanged.
系统模式会恢复为首次启动时的控件与手势。你创建的其他模式不会被删除。	The system profile will return to its original controls and gestures. Your other profiles will not be deleted.
页面切换、模式切换、断连、退到后台和 30 秒超时都会释放按住的键。	Held keys are released on page or profile changes, disconnection, backgrounding, and the 30-second timeout.
默认模式支持上下左右、轻点；自定义模式可绑定圆圈、X、Z、勾和录制手势。	The default profile supports directional swipes and taps. Custom profiles can bind circles, X, Z, checks, and recorded gestures.
单指移动，轻点左键，双击，两指滚动，两指轻点右键，长按后拖动。	Move with one finger, tap to left-click, double-tap, scroll with two fingers, two-finger tap to right-click, and hold to drag.
从已配对设备列表点按连接；系统允许时会自动恢复上次电脑。	Tap Connect in the paired-device list. When permitted, the last computer reconnects automatically.
在设备页进入配对模式，再从 Windows 蓝牙设置添加本手机。	Enter pairing mode on the Devices page, then add this phone from Windows Bluetooth settings.
所有尺寸均按网格与比例约束，不支持容易产生重叠的自由像素拖拽	Sizes follow a grid and proportional constraints to prevent overlapping free-form placement
混合模式会在手势与触控板之间进行意图仲裁，默认仍建议从单一模式开始	Hybrid mode resolves intent between gestures and the touchpad; start with a single mode when possible
识别失败或低于阈值时不会发送动作	No action is sent when recognition fails or confidence is below the threshold
执行时会严格按顺序处理按下、释放、等待和重复	Press, release, wait, and repeat steps run strictly in order
按固定槽位排序，避免重叠与误触	Controls use fixed slots to avoid overlap and accidental taps
添加控件后，可分别绑定点击、双击、长按和重复动作。	After adding a control, bind separate tap, double-tap, hold, and repeat actions.
添加方向、点击、图形或触控板手势，并为它选择动作。	Add a direction, tap, shape, or touchpad gesture and choose its action.
系统模式可编辑，但不能删除；可随时恢复初始配置	System profiles can be edited but not deleted, and can be reset at any time
JSON 导入会校验版本与 ID 冲突，不会覆盖系统模式	JSON imports validate versions and ID conflicts and never overwrite system profiles
点按卡片切换当前模式；编辑不会影响其他模式	Tap a card to switch profiles; editing does not affect other profiles
从空白开始，或复制一个可用模板	Start from scratch or copy an existing template
创建适合不同软件与工作流的控制模式	Create control profiles for different apps and workflows
保存前可录制自定义手势；操作说明已移入这里，不占用底部标签页	Record custom gestures before saving. Help now lives here instead of using a bottom tab.
名称和图标会显示在控制页的模式切换器中	The name and icon appear in the profile switcher on the control page
关闭后会保留起笔方向，降低旋转误触	When off, the starting direction is preserved to reduce rotation mistakes
只建议在实际测试能稳定区分时开启	Enable only when real tests can distinguish gestures reliably
建议重新录制差异更明确的样本后再保存。	Record more distinct samples before saving.
减小与增加支持长按连续发送	Decrease and increase support continuous sending while held
切换上一条、播放暂停或下一条	Switch to previous, play or pause, or next
配对、连接、触控板和自定义手势指南	Guide to pairing, connecting, touchpad use, and custom gestures
全局交互、启动模式与使用说明	Global interaction, startup profile, and help
打开应用后尝试恢复上一次 HID 连接	Try to restore the last HID connection when the app opens
成功与失败使用不同触感；模式可单独覆盖	Use distinct haptics for success and failure; profiles can override this
允许手势与触控板在同一区域进行意图仲裁	Allow gestures and touchpad input to share one area with intent resolution
绘制手势时在控制板上显示实时蓝色轨迹	Show a live blue trail while drawing gestures
控制模式中的设置优先于这里	Profile-specific settings override these defaults
固定全屏模式、滚动与自适应压力	Fixed full-screen mode, scrolling, and adaptive pressure
快速横滑执行自定义的前进或后退动作	A quick horizontal swipe runs the custom forward or back action
上、下、左、右与轻点动作均可自定义	Up, down, left, right, and tap actions are customizable
修改双指前进后退与三指手势执行的动作	Change actions for two-finger navigation and three-finger gestures
默认关闭；开启后预留高级扩展	Off by default; enable to reserve advanced extensions
在触控区底部显示左键和右键	Show left and right mouse buttons below the touch area
点击与模式锁定时提供轻微震动	Provide light haptics for clicks and mode locks
压力不可用时自动改用接触面积与按住时长	Use contact area and hold duration when pressure is unavailable
达到重按阈值时按住鼠标左键；关闭后仅显示强度	Hold the left mouse button at force pressure; when off, only intensity is shown
首次达到重按状态时提供一次轻微反馈	Give one light haptic when force pressure is first reached
按轻触、正常按压与重按完成设备适配	Calibrate the device with light, normal, and force presses
实时查看 pressure、面积与设备信号可靠性	Inspect pressure, contact area, and device signal reliability in real time
若 pressure 长期不变，正式模式会自动使用接触面积与按住时长。	If pressure stays constant, normal mode automatically uses contact area and hold duration.
配对、连接、触控板和自定义手势指南	Pairing, connection, touchpad, and custom gesture guide
不会删除你的其他自定义模式	Your other custom profiles will not be deleted
当前模式没有可见控件	This profile has no visible controls
可在“自定义”中添加控件或打开已有控件。	Add controls or enable existing ones in Customize.
所有动作均由当前模式配置驱动	All actions are driven by the active profile
切换后所有控件与手势立即更新	All controls and gestures update immediately after switching
识别失败或低于阈值时不会发送动作	No action is sent on failed or low-confidence recognition
先进入配对模式，再从电脑添加本手机	Enter pairing mode first, then add this phone from the computer
连接已配对的 Windows 电脑	Connect to a paired Windows computer
尚未读取到设备	No devices have been read yet
暂无已配对设备	No paired devices
全局交互、启动模式与使用说明	Global interaction, startup profile, and help
自动连接上次电脑	Reconnect to last computer
保持屏幕常亮	Keep screen awake
启用混合模式	Enable hybrid mode
显示滑动轨迹	Show gesture trail
交互偏好	Interaction preferences
手势默认值	Gesture defaults
识别置信度	Recognition confidence
指针灵敏度	Pointer sensitivity
灵敏度预设	Sensitivity preset
鼠标加速度	Pointer acceleration
滚动速度	Scroll speed
双击速度	Double-tap speed
拖拽方式	Drag method
自然滚动	Natural scrolling
双指导航	Two-finger navigation
三指快捷手势	Three-finger shortcuts
自定义手势快捷键	Customize gesture shortcuts
四指扩展手势	Four-finger extensions
显示鼠标按键	Show mouse buttons
触控反馈	Touch feedback
自适应压力	Adaptive pressure
压力灵敏度	Pressure sensitivity
正常按压阈值	Normal press threshold
重按阈值	Force press threshold
重按拖拽	Force-press drag
压感震动	Pressure haptics
压力校准	Pressure calibration
压力调试	Pressure diagnostics
水平滚动回退	Horizontal scroll fallback
恢复触控板默认设置	Reset touchpad defaults
左右手与启动	Handedness and startup
主要使用手	Primary hand
启动控制模式	Startup profile
选择启动模式	Choose startup profile
帮助与安全	Help and safety
快速开始与手势说明	Quick start and gesture guide
恢复默认视频模式	Reset default video profile
开发者联系方式	Developer contact
选择启动控制模式	Choose startup profile
恢复默认视频模式？	Reset the default video profile?
使用说明	Instructions
自定义触控板手势	Customize touchpad gestures
触摸并改变力度	Touch and vary pressure
在这里按压	Press here
样本差异不足，请重新完成校准	Samples are too similar. Please calibrate again.
轻点单击 · 长按拖动 · 双指右键	Tap to click · Hold to drag · Two-finger right-click
单指移动 · 双指滚动 · 三指切换	One-finger move · Two-finger scroll · Three-finger switch
多指快捷手势	Multi-finger shortcut
四指扩展手势	Four-finger extension
面积识别	Area detection
按键 开	Buttons On
按键 关	Buttons Off
触控板设置	Touchpad settings
在此区域触控	Touch here
双指滚动	Two-finger scroll
双指缩放	Two-finger zoom
水平滚动	Horizontal scroll
双指右键	Two-finger right-click
快捷调整视频	Quick video controls
快捷控件	Quick controls
当前模式	Current profile
打开模式选择	Open profile picker
设备状态	Device status
当前设备	Current device
已连接 · 蓝牙 HID	Connected · Bluetooth HID
正在连接…	Connecting…
连接中	Connecting
已连接	Connected
断开	Disconnect
进入配对模式	Enter pairing mode
系统蓝牙	System Bluetooth
刷新设备	Refresh devices
重新注册 HID	Re-register HID
已配对设备	Paired devices
共 	Total 
 台设备	 devices
蓝牙工具	Bluetooth tools
暂无设备	No devices
电脑	Computer
控制	Control
设备	Devices
自定义	Customize
设置	Settings
遥控	Remote
控制模式	Control profile
当前选择	Current selection
选择控制模式	Choose control profile
新建模式	New profile
新建空白	New blank profile
复制默认视频模式	Copy default video profile
我的控制模式	My control profiles
配置与恢复	Configuration and recovery
导入模式 JSON	Import profile JSON
恢复系统默认模式	Reset system defaults
重命名控制模式	Rename control profile
模式名称	Profile name
选择模式图标	Choose profile icon
删除控制模式？	Delete control profile?
导入控制模式	Import control profile
粘贴 JSON	Paste JSON
校验并导入	Validate and import
模式信息	Profile information
编辑控制模式	Edit control profile
布局与手感	Layout and feel
控制区类型	Control area type
全屏手势	Full-screen gesture
紧凑遥控	Compact remote
混合控制	Hybrid control
手势区高度	Gesture area height
网格列数	Grid columns
单列	One column
双列	Two columns
三列	Three columns
左右手	Handedness
跟随全局	Follow global setting
左手	Left hand
右手	Right hand
触感反馈	Haptic feedback
控件	Controls
添加控件	Add control
还没有控件	No controls yet
控件名称	Control name
快捷区	Quick section
主控区	Main section
区域	Section
尺寸	Size
中号	Medium
大号	Large
顶部	Top
底部	Bottom
显示	Visible
手势绑定	Gesture bindings
添加手势	Add gesture
还没有手势绑定	No gesture bindings yet
选择动作	Choose action
应用内动作	In-app action
媒体动作	Media action
键盘动作	Keyboard action
鼠标动作	Mouse action
滚动动作	Scroll action
组合滚动动作	Modified scroll action
高级序列	Advanced sequence
执行动作	Run action
未绑定	Not assigned
停用	Disabled
清除绑定	Clear assignment
使用此动作	Use this action
按下后释放	Press and release
按住后释放	Release after hold
长按重复	Repeat while held
播放/暂停	Play/Pause
上一首	Previous track
下一首	Next track
音量减	Volume down
音量加	Volume up
静音	Mute
显示桌面 Win+D	Show desktop Win+D
切换窗口 Alt+Tab	Switch window Alt+Tab
任务管理器	Task Manager
全选 Ctrl+A	Select all Ctrl+A
复制 Ctrl+C	Copy Ctrl+C
粘贴 Ctrl+V	Paste Ctrl+V
剪切 Ctrl+X	Cut Ctrl+X
撤销 Ctrl+Z	Undo Ctrl+Z
保存 Ctrl+S	Save Ctrl+S
左键单击	Left click
右键单击	Right click
中键单击	Middle click
向上滚动	Scroll up
向下滚动	Scroll down
切换到指定模式	Switch to profile
打开键盘	Open keyboard
打开快捷动作	Open quick actions
自定义手势	Custom gestures
录制自定义手势	Record custom gesture
手势名称	Gesture name
录制样本	Record samples
测试识别	Test recognition
允许旋转识别	Allow rotation recognition
覆盖冲突继续保存	Save despite conflict
未发现明显冲突	No significant conflicts found
重新录制	Record again
测试与帮助	Test and help
编辑帮助	Editing help
保存图标	Save icon
裁剪模式图标	Crop profile icon
从相册选择	Choose from Photos
从文件选择	Choose from Files
移除自定义图标	Remove custom icon
更换图标	Change icon
管理模式	Manage profiles
设为启动	Set as startup
已设为启动	Startup profile
导出 JSON	Export JSON
删除此模式	Delete this profile
删除此绑定	Delete this binding
重命名	Rename
复制	Copy
编辑	Edit
保存	Save
取消	Cancel
关闭	Close
完成	Done
下一步	Next
恢复	Reset
删除	Delete
选择	Choose
开启	On
关闭	Off
启用	Enable
停止	Stop
刷新状态	Refresh status
知道了	Got it
关于	About
应用	App
版本	Version
系统模式	System profile
自定义模式	Custom profile
视频	Video
音乐	Music
游戏	Game
演示	Presentation
鼠标	Mouse
键盘	Keyboard
媒体	Media
音量	Volume
灵敏度	Sensitivity
精准	Precise
标准	Standard
快速	Fast
双击按住	Double-tap and hold
长按	Long press
两者	Both
轻触	Light touch
正常按压	Normal press
重按	Force press
按压	Press
按压时长	Press duration
综合压感	Combined pressure
真实压力可靠	Reliable pressure
模拟压感	Simulated pressure
数据不可靠	Unreliable data
未触摸	Not touching
手势已取消	Gesture cancelled
未识别手势	Gesture not recognized
手势未绑定到当前模式	Gesture is not assigned in this profile
左键	Left button
右键	Right button
中键	Middle button
上滑	Swipe up
下滑	Swipe down
左滑	Swipe left
右滑	Swipe right
轻点	Tap
双击	Double tap
画圆	Draw circle
画 X	Draw X
画 Z	Draw Z
画勾	Draw check
向上	Up
向下	Down
向左	Left
向右	Right
上移	Move up
下移	Move down
全屏	Full screen
紧凑	Compact
混合模式	Hybrid mode
触控板	Touchpad
手势控制	Gesture control
手势控制区	Gesture area
触控板控制区	Touchpad area
混合手势与触控板控制区	Hybrid gesture and touchpad area
手势敏感度	Gesture sensitivity
默认置信度阈值	Default confidence threshold
重复次数	Repeat count
等待毫秒	Wait milliseconds
键盘键	Keyboard key
鼠标键	Mouse button
当前状态	Current state
当前	Current
未命名控件	Untitled control
未命名模式	Untitled profile
系统	System
自定义网格	Custom grid
已校准 · 	Calibrated · 
是	Yes
否 · 模拟压感	No · simulated pressure
关	Off
开	On
    """.trimIndent()
}
