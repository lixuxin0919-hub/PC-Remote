package com.gunianan.btremote.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.R
import kotlin.math.abs
import kotlin.math.roundToInt

object ControlTokens {
    val SwitchWidth = 52.dp
    val SwitchHeight = 32.dp
    val SwitchThumbSize = 28.dp
    val MinimumTouchHeight = 48.dp
    val SliderTrackHeight = 7.dp
    val SliderThumbSize = 28.dp
}

@Composable
fun PcRemoteSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val haptic = LocalHapticFeedback.current
    val stateDescriptionText = stringResource(if (checked) R.string.switch_on else R.string.switch_off)
    val trackColor by animateColorAsState(
        when {
            !enabled -> Color(0xFFE5EAF0)
            checked -> PcRemoteColors.Primary
            else -> Color(0xFFD7E1EC)
        },
        tween(190), label = "switchTrack",
    )
    val thumbOffset by animateDpAsState(
        if (checked) ControlTokens.SwitchWidth - ControlTokens.SwitchThumbSize - 2.dp else 2.dp,
        spring(dampingRatio = 0.88f, stiffness = 720f), label = "switchThumb",
    )
    val thumbScale by animateFloatAsState(
        if (pressed && enabled) 1.045f else 1f,
        spring(dampingRatio = 0.82f, stiffness = 800f), label = "switchPressed",
    )
    Box(
        modifier = modifier
            .requiredSize(ControlTokens.SwitchWidth, ControlTokens.MinimumTouchHeight)
            .semantics { stateDescription = stateDescriptionText }
            .toggleable(
                value = checked,
                enabled = enabled,
                role = Role.Switch,
                interactionSource = interaction,
                indication = null,
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onCheckedChange(it)
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier.requiredSize(ControlTokens.SwitchWidth, ControlTokens.SwitchHeight)
                .clip(CircleShape)
                .drawWithCache {
                    val fill = if (checked && enabled) {
                        Brush.horizontalGradient(listOf(PcRemoteColors.Primary, Color(0xFF33A8FF)))
                    } else {
                        Brush.verticalGradient(listOf(trackColor.copy(alpha = 0.94f), trackColor))
                    }
                    onDrawBehind {
                        drawRoundRect(fill, cornerRadius = CornerRadius(size.height / 2f))
                        drawRoundRect(
                            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.18f), Color.Transparent)),
                            cornerRadius = CornerRadius(size.height / 2f),
                        )
                    }
                }
                .graphicsLayer { alpha = if (enabled) 1f else 0.55f },
            contentAlignment = Alignment.CenterStart,
        ) {
            Box(
                Modifier.graphicsLayer {
                    translationX = thumbOffset.toPx()
                    scaleX = thumbScale
                    scaleY = thumbScale
                }
                    .requiredSize(ControlTokens.SwitchThumbSize)
                    .shadow(
                        if (pressed) 8.dp else 5.dp,
                        CircleShape,
                        clip = false,
                        ambientColor = Color(0x332A496A),
                        spotColor = Color(0x3D203B59),
                    )
                    .clip(CircleShape)
                    .drawWithCache {
                        val fill = Brush.linearGradient(
                            listOf(Color.White, Color(0xFFF9FCFF), Color(0xFFF0F6FC)),
                            Offset.Zero,
                            Offset(size.width, size.height),
                        )
                        onDrawBehind {
                            drawCircle(fill)
                            drawCircle(
                                Brush.radialGradient(
                                    listOf(Color.White.copy(alpha = if (pressed) 0.42f else 0.26f), Color.Transparent),
                                    center = Offset(size.width * 0.31f, size.height * 0.24f),
                                    radius = size.minDimension * 0.68f,
                                ),
                            )
                            drawCircle(Color(0xFFB9DCFF).copy(alpha = 0.12f), size.minDimension * 0.49f)
                        }
                    },
            )
        }
    }
}

@Composable
fun PcRemoteSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
    enabled: Boolean = true,
    onValueChangeFinished: (() -> Unit)? = null,
) {
    require(valueRange.endInclusive > valueRange.start) { "Slider range must have positive length" }
    require(steps >= 0) { "Slider steps must not be negative" }
    val currentOnChange by rememberUpdatedState(onValueChange)
    val currentOnFinished by rememberUpdatedState(onValueChangeFinished)
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val viewConfiguration = LocalViewConfiguration.current
    var dragging by remember { mutableStateOf(false) }
    val normalized = normalize(value, valueRange)
    val thumbScale by animateFloatAsState(
        if (dragging) 1.075f else 1f,
        spring(dampingRatio = 0.82f, stiffness = 760f), label = "sliderThumb",
    )
    val updateValue: (Float) -> Unit = { fraction ->
        currentOnChange(valueAt(snapFraction(fraction, steps), valueRange))
    }

    BoxWithConstraints(
        modifier = modifier.fillMaxWidth().height(ControlTokens.MinimumTouchHeight)
            .semantics {
                progressBarRangeInfo = ProgressBarRangeInfo(value.coerceIn(valueRange), valueRange, steps)
                setProgress { target ->
                    if (!enabled) false else {
                        currentOnChange(valueAt(snapFraction(normalize(target, valueRange), steps), valueRange))
                        currentOnFinished?.invoke()
                        true
                    }
                }
            }
            .pointerInput(enabled, valueRange, steps) {
                if (!enabled) return@pointerInput
                val radius = with(density) { ControlTokens.SliderThumbSize.toPx() / 2f }
                val thumbTouchRadius = radius + with(density) { 10.dp.toPx() }
                fun updateFromX(x: Float) {
                    val travel = (size.width - radius * 2f).coerceAtLeast(1f)
                    updateValue(((x - radius) / travel).coerceIn(0f, 1f))
                }
                try {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Main)
                        val thumbCenter = radius + (size.width - radius * 2f).coerceAtLeast(0f) * normalized
                        if (!isWithinSliderThumb(down.position.x, thumbCenter, thumbTouchRadius)) {
                            return@awaitEachGesture
                        }

                        var dragStarted = false
                        val pointerId = down.id
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Main)
                            val change = event.changes.firstOrNull { it.id == pointerId } ?: break
                            if (!change.pressed) break
                            val delta = change.position - down.position
                            if (!dragStarted) {
                                val horizontalDistance = abs(delta.x)
                                val verticalDistance = abs(delta.y)
                                if (verticalDistance > viewConfiguration.touchSlop && verticalDistance > horizontalDistance) {
                                    break
                                }
                                if (horizontalDistance <= viewConfiguration.touchSlop || horizontalDistance <= verticalDistance) {
                                    continue
                                }
                                dragStarted = true
                                dragging = true
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                            updateFromX(change.position.x)
                            change.consume()
                        } while (event.changes.any { it.pressed })
                        if (dragStarted) {
                            dragging = false
                            currentOnFinished?.invoke()
                        }
                    }
                } finally {
                    dragging = false
                }
            },
    ) {
        val thumbPx = with(density) { ControlTokens.SliderThumbSize.toPx() }
        val thumbX = (constraints.maxWidth - thumbPx).coerceAtLeast(0f) * normalized
        SliderTrack(normalized, enabled)
        Box(
            Modifier.align(Alignment.CenterStart)
                .graphicsLayer {
                    translationX = thumbX
                    scaleX = thumbScale
                    scaleY = thumbScale
                    alpha = if (enabled) 1f else 0.6f
                }
                .requiredSize(ControlTokens.SliderThumbSize)
                .shadow(
                    if (dragging) 11.dp else 8.dp,
                    CircleShape,
                    clip = false,
                    ambientColor = Color(0x332A496A),
                    spotColor = Color(0x3D203B59),
                )
                .clip(CircleShape)
                .drawWithCache {
                    val fill = Brush.linearGradient(
                        listOf(Color.White, Color(0xFFF9FCFF), Color(0xFFF0F6FC)),
                        Offset.Zero,
                        Offset(size.width, size.height),
                    )
                    onDrawBehind {
                        drawCircle(fill)
                        drawCircle(
                            Brush.radialGradient(
                                listOf(Color.White.copy(alpha = if (dragging) 0.42f else 0.25f), Color.Transparent),
                                center = Offset(size.width * 0.31f, size.height * 0.23f),
                                radius = size.minDimension * 0.69f,
                            ),
                        )
                        drawCircle(Color(0xFFB9DCFF).copy(alpha = 0.12f), size.minDimension * 0.49f)
                        drawCircle(
                            color = Color(0xFF6F9FC7).copy(alpha = 0.88f),
                            radius = size.minDimension / 2f - 1.dp.toPx(),
                            style = Stroke(width = 1.5.dp.toPx()),
                        )
                    }
                },
        )
    }
}

@Composable
private fun SliderTrack(normalized: Float, enabled: Boolean) {
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(ControlTokens.MinimumTouchHeight)
            .drawWithCache {
                val height = ControlTokens.SliderTrackHeight.toPx()
                val radius = ControlTokens.SliderThumbSize.toPx() / 2f
                val start = radius
                val width = (size.width - radius * 2f).coerceAtLeast(0f)
                val y = (size.height - height) / 2f
                val inactiveColor = if (enabled) Color(0xFFB7C7D8) else Color(0xFFCBD6E2)
                val activeBrush = Brush.horizontalGradient(
                    listOf(PcRemoteColors.Primary, Color(0xFF32B6FF)),
                    startX = start,
                    endX = start + width.coerceAtLeast(1f),
                )
                onDrawBehind {
                    drawRoundRect(
                        color = inactiveColor,
                        topLeft = Offset(start, y),
                        size = Size(width, height),
                        cornerRadius = CornerRadius(height / 2f),
                    )
                    val activeWidth = width * normalized
                    if (activeWidth > 0f) {
                        drawRoundRect(
                            brush = activeBrush,
                            topLeft = Offset(start, y),
                            size = Size(activeWidth, height),
                            cornerRadius = CornerRadius(height / 2f),
                            alpha = if (enabled) 1f else 0.45f,
                        )
                    }
                }
            },
    ) {
    }
}

internal fun normalize(value: Float, range: ClosedFloatingPointRange<Float>): Float =
    ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)

internal fun valueAt(fraction: Float, range: ClosedFloatingPointRange<Float>): Float =
    range.start + (range.endInclusive - range.start) * fraction.coerceIn(0f, 1f)

internal fun snapFraction(fraction: Float, steps: Int): Float {
    val clamped = fraction.coerceIn(0f, 1f)
    if (steps == 0) return clamped
    val intervals = steps + 1
    return (clamped * intervals).roundToInt().toFloat() / intervals
}

internal fun isWithinSliderThumb(pointerX: Float, thumbCenterX: Float, touchRadius: Float): Boolean =
    abs(pointerX - thumbCenterX) <= touchRadius
