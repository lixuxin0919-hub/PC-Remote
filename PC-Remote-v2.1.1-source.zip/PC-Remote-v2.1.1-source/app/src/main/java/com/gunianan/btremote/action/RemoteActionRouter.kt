package com.gunianan.btremote.action

import com.gunianan.btremote.domain.ControlItem
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.GestureBinding
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.MouseCommand
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.domain.SequenceStep
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

fun interface ActionDelay {
    suspend fun wait(durationMillis: Long)
}

enum class ControlEvent {
    TAP,
    DOUBLE_TAP,
    LONG_PRESS_START,
    LONG_PRESS_REPEAT,
    LONG_PRESS_END,
}

/**
 * Converts all persisted button and gesture actions into transport-neutral commands.
 * This is the only action-dispatch boundary UI and recognition layers should call.
 */
class RemoteActionRouter(
    private val executor: RemoteCommandExecutor,
    private val actionDelay: ActionDelay = ActionDelay { delay(it) },
    private val limits: RouterLimits = RouterLimits(),
) {
    @Volatile
    private var activeProfile: ControlProfile? = null

    data class RouterLimits(
        val maximumSequenceDepth: Int = 8,
        val maximumExpandedSteps: Int = 1_024,
        val maximumSingleDelayMillis: Long = 30_000L,
        val maximumSequenceDurationMillis: Long = 30_000L,
    ) {
        init {
            require(maximumSequenceDepth > 0) { "maximumSequenceDepth must be positive" }
            require(maximumExpandedSteps > 0) { "maximumExpandedSteps must be positive" }
            require(maximumSingleDelayMillis >= 0L) {
                "maximumSingleDelayMillis must not be negative"
            }
            require(maximumSequenceDurationMillis > 0L) {
                "maximumSequenceDurationMillis must be positive"
            }
        }
    }

    fun updateProfile(profile: ControlProfile) {
        activeProfile = profile
    }

    fun clearProfile() {
        activeProfile = null
    }

    fun currentProfileId(): String? = activeProfile?.id

    suspend fun route(action: RemoteActionConfig?): ActionResult =
        executeAction(action, phaseOverride = null, ExecutionBudget(limits.maximumExpandedSteps), depth = 0)

    suspend fun route(control: ControlItem, event: ControlEvent): ActionResult {
        if (!control.visible) return ActionResult.Ignored(IgnoreReason.CONTROL_HIDDEN)
        return when (event) {
            ControlEvent.TAP -> route(control.tapAction)
            ControlEvent.DOUBLE_TAP -> route(control.doubleTapAction)
            ControlEvent.LONG_PRESS_START -> {
                val heldAction = control.longPressAction
                when {
                    heldAction != null -> executeAction(
                        heldAction,
                        // A repeat action denotes periodic taps. Without one, the action is held.
                        phaseOverride = if (control.repeatAction == null) KeyPhase.DOWN else KeyPhase.TAP,
                        budget = ExecutionBudget(limits.maximumExpandedSteps),
                        depth = 0,
                    )
                    control.repeatAction != null -> route(control.repeatAction)
                    else -> ActionResult.Ignored(IgnoreReason.NO_ACTION)
                }
            }
            ControlEvent.LONG_PRESS_REPEAT -> route(control.repeatAction)
            ControlEvent.LONG_PRESS_END -> {
                val heldAction = control.longPressAction
                if (heldAction == null || control.repeatAction != null) {
                    // Repeating tap actions do not own a pressed key that requires release.
                    ActionResult.Success(executedCommandCount = 0)
                } else {
                    executeAction(
                        heldAction,
                        phaseOverride = KeyPhase.UP,
                        budget = ExecutionBudget(limits.maximumExpandedSteps),
                        depth = 0,
                    )
                }
            }
        }
    }

    suspend fun routeControl(controlId: String, event: ControlEvent): ActionResult {
        val profile = activeProfile ?: return ActionResult.Ignored(IgnoreReason.NO_ACTIVE_PROFILE)
        val control = profile.controls.firstOrNull { it.id == controlId }
            ?: return ActionResult.Ignored(IgnoreReason.CONTROL_NOT_FOUND)
        return route(control, event)
    }

    suspend fun route(binding: GestureBinding): ActionResult {
        if (!binding.enabled) return ActionResult.Ignored(IgnoreReason.GESTURE_DISABLED)
        return route(binding.action)
    }

    suspend fun route(binding: GestureBinding, confidence: Float): ActionResult {
        if (!binding.enabled) return ActionResult.Ignored(IgnoreReason.GESTURE_DISABLED)
        val threshold = binding.minConfidence
        if (threshold != null && confidence < threshold) {
            return ActionResult.Ignored(IgnoreReason.LOW_CONFIDENCE)
        }
        return route(binding.action)
    }

    /** Gesture IDs are binding IDs, which remain stable across recognition implementations. */
    suspend fun routeGesture(bindingId: String): ActionResult {
        val profile = activeProfile ?: return ActionResult.Ignored(IgnoreReason.NO_ACTIVE_PROFILE)
        val binding = profile.gestureBindings.firstOrNull { it.id == bindingId }
            ?: return ActionResult.Ignored(IgnoreReason.GESTURE_NOT_FOUND)
        return route(binding)
    }

    suspend fun routeGesture(bindingId: String, confidence: Float): ActionResult {
        val profile = activeProfile ?: return ActionResult.Ignored(IgnoreReason.NO_ACTIVE_PROFILE)
        val binding = profile.gestureBindings.firstOrNull { it.id == bindingId }
            ?: return ActionResult.Ignored(IgnoreReason.GESTURE_NOT_FOUND)
        return route(binding, confidence)
    }

    private suspend fun executeAction(
        action: RemoteActionConfig?,
        phaseOverride: KeyPhase?,
        budget: ExecutionBudget,
        depth: Int,
        sequenceContext: SequenceExecutionContext? = null,
    ): ActionResult {
        if (action == null) return ActionResult.Ignored(IgnoreReason.NO_ACTION)
        if (depth > limits.maximumSequenceDepth) {
            return limitFailure("Action sequence nesting is too deep")
        }
        return try {
            when (action) {
                is RemoteActionConfig.KeyboardKey -> executeCommand(
                    RemoteCommand.Keyboard(
                        keyCode = action.keyCode,
                        phase = phaseOverride ?: KeyPhase.TAP,
                    ),
                    budget,
                    sequenceContext,
                )
                is RemoteActionConfig.KeyboardShortcut -> executeCommand(
                    RemoteCommand.Keyboard(
                        keyCode = action.keyCode,
                        modifierMask = action.modifiers.fold(0) { mask, modifier ->
                            mask or modifier.hidMask
                        },
                        phase = phaseOverride ?: KeyPhase.TAP,
                    ),
                    budget,
                    sequenceContext,
                )
                is RemoteActionConfig.ConsumerKey -> executeCommand(
                    RemoteCommand.Consumer(
                        usageId = action.usageId,
                        phase = phaseOverride ?: KeyPhase.TAP,
                    ),
                    budget,
                    sequenceContext,
                )
                is RemoteActionConfig.MouseAction -> executeMouseAction(
                    action,
                    phaseOverride,
                    budget,
                    sequenceContext,
                )
                is RemoteActionConfig.ScrollAction -> {
                    if (phaseOverride != null && phaseOverride != KeyPhase.TAP) {
                        unsupportedPhase(action, phaseOverride)
                    } else {
                        executeCommand(
                            RemoteCommand.Scroll(action.horizontal, action.vertical),
                            budget,
                            sequenceContext,
                        )
                    }
                }
                is RemoteActionConfig.ModifiedScrollAction -> {
                    if (phaseOverride != null && phaseOverride != KeyPhase.TAP) {
                        unsupportedPhase(action, phaseOverride)
                    } else {
                        executeCommand(
                            RemoteCommand.ModifiedScroll(
                                modifierMask = action.modifiers.fold(0) { mask, modifier ->
                                    mask or modifier.hidMask
                                },
                                vertical = action.vertical,
                            ),
                            budget,
                            sequenceContext,
                        )
                    }
                }
                is RemoteActionConfig.InternalAction -> {
                    if (phaseOverride != null && phaseOverride != KeyPhase.TAP) {
                        unsupportedPhase(action, phaseOverride)
                    } else {
                        executeCommand(
                            RemoteCommand.Internal(action.action.name, action.targetProfileId),
                            budget,
                            sequenceContext,
                        )
                    }
                }
                is RemoteActionConfig.CustomSequence -> {
                    if (phaseOverride != null && phaseOverride != KeyPhase.TAP) {
                        unsupportedPhase(action, phaseOverride)
                    } else {
                        if (sequenceContext == null) {
                            executeRootSequence(action, budget, depth + 1)
                        } else {
                            executeSequence(action, budget, depth + 1, sequenceContext)
                        }
                    }
                }
            }
        } catch (error: IllegalArgumentException) {
            ActionResult.Failure(
                reason = FailureReason.INVALID_ACTION,
                message = error.message ?: "Invalid action configuration",
                cause = error,
            )
        }
    }

    private suspend fun executeMouseAction(
        action: RemoteActionConfig.MouseAction,
        phaseOverride: KeyPhase?,
        budget: ExecutionBudget,
        sequenceContext: SequenceExecutionContext?,
    ): ActionResult {
        return when (action.command) {
            MouseCommand.MOVE -> {
                if (phaseOverride != null && phaseOverride != KeyPhase.TAP) {
                    unsupportedPhase(action, phaseOverride)
                } else {
                    executeCommand(
                        RemoteCommand.MouseMove(action.deltaX, action.deltaY),
                        budget,
                        sequenceContext,
                    )
                }
            }
            MouseCommand.CLICK,
            MouseCommand.DOWN,
            MouseCommand.UP,
            -> {
                val button = action.button
                    ?: return ActionResult.Failure(
                        reason = FailureReason.INVALID_ACTION,
                        message = "Mouse button action requires a button",
                    )
                val configuredPhase = when (action.command) {
                    MouseCommand.CLICK -> KeyPhase.TAP
                    MouseCommand.DOWN -> KeyPhase.DOWN
                    MouseCommand.UP -> KeyPhase.UP
                    MouseCommand.MOVE -> error("handled above")
                }
                executeCommand(
                    RemoteCommand.MouseButton(
                        button = button.toCommandButton(),
                        phase = phaseOverride ?: configuredPhase,
                    ),
                    budget,
                    sequenceContext,
                )
            }
        }
    }

    private suspend fun executeRootSequence(
        sequence: RemoteActionConfig.CustomSequence,
        budget: ExecutionBudget,
        depth: Int,
    ): ActionResult {
        val context = SequenceExecutionContext()
        return try {
            val result = withTimeout(limits.maximumSequenceDurationMillis) {
                executeSequence(sequence, budget, depth, context)
            }
            when {
                !result.isSuccessful -> {
                    releaseSequenceKeys(context)
                    result
                }
                context.hasHeldKeys -> {
                    releaseSequenceKeys(context)
                    ActionResult.Failure(
                        reason = FailureReason.INVALID_ACTION,
                        message = "Action sequence completed with keys still pressed",
                        executedCommandCount = result.executedCount(),
                    )
                }
                else -> result
            }
        } catch (error: TimeoutCancellationException) {
            releaseSequenceKeys(context)
            ActionResult.Failure(
                reason = FailureReason.SEQUENCE_LIMIT_EXCEEDED,
                message = "Action sequence exceeded ${limits.maximumSequenceDurationMillis} ms",
                cause = error,
                executedCommandCount = context.executedCommandCount,
            )
        } catch (error: CancellationException) {
            releaseSequenceKeys(context)
            throw error
        } catch (error: Throwable) {
            releaseSequenceKeys(context)
            ActionResult.Failure(
                reason = FailureReason.TRANSPORT_FAILURE,
                message = error.message ?: "Action sequence failed",
                cause = error,
                executedCommandCount = context.executedCommandCount,
            )
        }
    }

    /** Cleanup is deliberately outside normal cancellation and command budgets. */
    private suspend fun releaseSequenceKeys(context: SequenceExecutionContext) {
        val releaseCommands = context.drainReleaseCommands()
        withContext(NonCancellable) {
            releaseCommands.forEach { command ->
                try {
                    executor.execute(command)
                } catch (_: Throwable) {
                    // Continue best-effort cleanup so one failed release cannot strand other keys.
                }
            }
        }
    }

    private suspend fun executeSequence(
        sequence: RemoteActionConfig.CustomSequence,
        budget: ExecutionBudget,
        depth: Int,
        sequenceContext: SequenceExecutionContext,
    ): ActionResult {
        var executedCount = 0
        var firstFailure: ActionResult? = null
        for (step in sequence.steps) {
            val result = executeStep(step, budget, depth, sequenceContext)
            executedCount += result.executedCount()
            if (!result.isSuccessful) {
                if (sequence.stopOnFailure || step is SequenceStep.Down || step is SequenceStep.Up) {
                    return result.withExecutedCount(executedCount)
                }
                if (firstFailure == null) firstFailure = result
            }
        }
        return firstFailure?.withExecutedCount(executedCount)
            ?: ActionResult.Success(executedCommandCount = executedCount)
    }

    private suspend fun executeStep(
        step: SequenceStep,
        budget: ExecutionBudget,
        depth: Int,
        sequenceContext: SequenceExecutionContext,
    ): ActionResult {
        return when (step) {
            is SequenceStep.Tap -> executeAction(
                step.action,
                KeyPhase.TAP,
                budget,
                depth,
                sequenceContext,
            )
            is SequenceStep.Down -> executeAction(
                step.action,
                KeyPhase.DOWN,
                budget,
                depth,
                sequenceContext,
            )
            is SequenceStep.Up -> executeAction(
                step.action,
                KeyPhase.UP,
                budget,
                depth,
                sequenceContext,
            )
            is SequenceStep.Delay -> {
                if (step.durationMs !in 1..limits.maximumSingleDelayMillis) {
                    ActionResult.Failure(
                        reason = FailureReason.INVALID_ACTION,
                        message = "Sequence delay is outside the supported range",
                    )
                } else {
                    actionDelay.wait(step.durationMs)
                    ActionResult.Success(executedCommandCount = 0)
                }
            }
            is SequenceStep.Repeat -> {
                if (step.count !in 1..300 || step.intervalMs !in 30..limits.maximumSingleDelayMillis) {
                    return ActionResult.Failure(
                        reason = FailureReason.INVALID_ACTION,
                        message = "Repeat count or interval is invalid",
                    )
                }
                var executedCount = 0
                repeat(step.count) { index ->
                    val result = executeAction(
                        step.action,
                        KeyPhase.TAP,
                        budget,
                        depth,
                        sequenceContext,
                    )
                    executedCount += result.executedCount()
                    if (!result.isSuccessful) return result.withExecutedCount(executedCount)
                    if (index < step.count - 1) {
                        actionDelay.wait(step.intervalMs)
                    }
                }
                ActionResult.Success(executedCommandCount = executedCount)
            }
        }
    }

    private suspend fun executeCommand(
        command: RemoteCommand,
        budget: ExecutionBudget,
        sequenceContext: SequenceExecutionContext?,
    ): ActionResult {
        if (!budget.consume()) return limitFailure("Action sequence expands to too many commands")
        return try {
            executor.execute(command).also { result ->
                sequenceContext?.observe(command, result)
            }
        } catch (error: CancellationException) {
            throw error
        } catch (error: Throwable) {
            ActionResult.Failure(
                reason = FailureReason.TRANSPORT_FAILURE,
                message = error.message ?: "Command executor failed",
                cause = error,
            )
        }
    }

    private fun unsupportedPhase(action: RemoteActionConfig, phase: KeyPhase): ActionResult.Failure =
        ActionResult.Failure(
            reason = FailureReason.UNSUPPORTED_PHASE,
            message = "${action.javaClass.simpleName} does not support $phase",
        )

    private fun limitFailure(message: String): ActionResult.Failure = ActionResult.Failure(
        reason = FailureReason.SEQUENCE_LIMIT_EXCEEDED,
        message = message,
    )

    private fun MouseButton.toCommandButton(): MouseButtonId = when (this) {
        MouseButton.LEFT -> MouseButtonId.LEFT
        MouseButton.RIGHT -> MouseButtonId.RIGHT
        MouseButton.MIDDLE -> MouseButtonId.MIDDLE
    }

    private class ExecutionBudget(private var remaining: Int) {
        fun consume(): Boolean {
            if (remaining <= 0) return false
            remaining--
            return true
        }
    }

    private class SequenceExecutionContext {
        private val pendingReleaseCommands = mutableListOf<RemoteCommand>()
        var executedCommandCount: Int = 0
            private set

        val hasHeldKeys: Boolean get() = pendingReleaseCommands.isNotEmpty()

        fun observe(command: RemoteCommand, result: ActionResult) {
            executedCommandCount += result.executedCount()
            if (!result.isSuccessful) return

            val releaseCommand = command.releaseCommandOrNull() ?: return
            when (command.phaseOrNull()) {
                KeyPhase.DOWN -> pendingReleaseCommands += releaseCommand
                KeyPhase.UP -> {
                    val matchingIndex = pendingReleaseCommands.indexOfLast { it == releaseCommand }
                    if (matchingIndex >= 0) pendingReleaseCommands.removeAt(matchingIndex)
                }
                KeyPhase.TAP,
                null,
                -> Unit
            }
        }

        fun drainReleaseCommands(): List<RemoteCommand> {
            val releases = pendingReleaseCommands.asReversed().toList()
            pendingReleaseCommands.clear()
            return releases
        }
    }
}

private fun RemoteCommand.phaseOrNull(): KeyPhase? = when (this) {
    is RemoteCommand.Keyboard -> phase
    is RemoteCommand.Consumer -> phase
    is RemoteCommand.MouseButton -> phase
    is RemoteCommand.Internal,
    is RemoteCommand.MouseMove,
    is RemoteCommand.ModifiedScroll,
    is RemoteCommand.Scroll,
    -> null
}

private fun RemoteCommand.releaseCommandOrNull(): RemoteCommand? = when (this) {
    is RemoteCommand.Keyboard -> copy(phase = KeyPhase.UP)
    is RemoteCommand.Consumer -> copy(phase = KeyPhase.UP)
    is RemoteCommand.MouseButton -> copy(phase = KeyPhase.UP)
    is RemoteCommand.Internal,
    is RemoteCommand.MouseMove,
    is RemoteCommand.ModifiedScroll,
    is RemoteCommand.Scroll,
    -> null
}

private fun ActionResult.executedCount(): Int = when (this) {
    is ActionResult.Success -> executedCommandCount
    is ActionResult.Failure -> executedCommandCount
    is ActionResult.Ignored -> 0
}

private fun ActionResult.withExecutedCount(count: Int): ActionResult = when (this) {
    is ActionResult.Success -> copy(executedCommandCount = count)
    is ActionResult.Failure -> copy(executedCommandCount = count)
    is ActionResult.Ignored -> ActionResult.Failure(
        reason = FailureReason.EXECUTOR_REJECTED,
        message = message ?: "Command was ignored: $reason",
        executedCommandCount = count,
    )
}
