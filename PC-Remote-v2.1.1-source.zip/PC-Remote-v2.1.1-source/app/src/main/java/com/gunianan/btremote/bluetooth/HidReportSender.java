package com.gunianan.btremote.bluetooth;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Serializes complete HID press/release transactions on a dedicated worker thread.
 * A session binds reports to one immutable transport, so a delayed release can never
 * be delivered to a replacement Bluetooth connection. Closing is non-blocking: queued
 * work is rejected and an already-admitted transaction is interrupted during its hold
 * but still owns its original transport until its release attempt completes.
 */
public final class HidReportSender implements AutoCloseable {
    public static final int REPORT_ID_KEYBOARD = 1;
    public static final int REPORT_ID_MOUSE = 2;
    public static final int REPORT_ID_CONSUMER = 3;

    public static final int CONSUMER_VOLUME_UP = 0x01;
    public static final int CONSUMER_VOLUME_DOWN = 0x02;
    public static final int CONSUMER_MUTE = 0x04;
    public static final int CONSUMER_PLAY_PAUSE = 0x08;
    public static final int CONSUMER_NEXT_TRACK = 0x10;
    public static final int CONSUMER_PREVIOUS_TRACK = 0x20;

    private static final long DEFAULT_HOLD_MILLIS = 32L;
    private static final long MAX_HOLD_MILLIS = 5_000L;
    private static final int DEFAULT_MAX_PENDING_REPORTS = 128;
    private static final AtomicInteger WORKER_IDS = new AtomicInteger();

    @FunctionalInterface
    public interface Transport {
        /**
         * Must target one immutable HID proxy/device pair for the lifetime of its
         * session and return promptly. Implementations must not look up a mutable
         * "current device" when this method is invoked.
         */
        boolean sendReport(int reportId, byte[] payload) throws Exception;
    }

    @FunctionalInterface
    public interface Sleeper {
        /** Implementations must honor interruption so close can expedite release. */
        void sleep(long durationMillis) throws InterruptedException;
    }

    @FunctionalInterface
    public interface Clock {
        long monotonicTimeMillis();
    }

    public enum Status {
        COMPLETED,
        NO_SESSION,
        STALE_SESSION,
        CLOSED,
        PRESS_FAILED,
        RELEASE_FAILED,
        SEND_FAILED,
        DELAY_INTERRUPTED,
        DELAY_FAILED,
        QUEUE_FULL
    }

    public static final class SendResult {
        private final Status status;
        private final long sessionId;
        private final int reportId;
        private final long queuedAtMillis;
        private final long completedAtMillis;
        private final boolean releaseAttempted;
        private final Throwable failure;

        private SendResult(
                Status status,
                long sessionId,
                int reportId,
                long queuedAtMillis,
                long completedAtMillis,
                boolean releaseAttempted,
                Throwable failure) {
            this.status = status;
            this.sessionId = sessionId;
            this.reportId = reportId;
            this.queuedAtMillis = queuedAtMillis;
            this.completedAtMillis = completedAtMillis;
            this.releaseAttempted = releaseAttempted;
            this.failure = failure;
        }

        public Status getStatus() {
            return status;
        }

        public boolean isSuccessful() {
            return status == Status.COMPLETED;
        }

        public long getSessionId() {
            return sessionId;
        }

        public int getReportId() {
            return reportId;
        }

        public long getQueuedAtMillis() {
            return queuedAtMillis;
        }

        public long getCompletedAtMillis() {
            return completedAtMillis;
        }

        public boolean wasReleaseAttempted() {
            return releaseAttempted;
        }

        public Throwable getFailure() {
            return failure;
        }
    }

    public static final class Report {
        private final int reportId;
        private final byte[] pressed;
        private final byte[] released;

        private Report(int reportId, byte[] pressed, byte[] released) {
            if (reportId < 0 || reportId > 255) {
                throw new IllegalArgumentException("reportId must be between 0 and 255");
            }
            Objects.requireNonNull(pressed, "pressed");
            Objects.requireNonNull(released, "released");
            if (pressed.length == 0 || pressed.length != released.length) {
                throw new IllegalArgumentException("press and release payloads must have the same non-zero length");
            }
            this.reportId = reportId;
            this.pressed = pressed.clone();
            this.released = released.clone();
        }

        public static Report of(int reportId, byte[] pressed, byte[] released) {
            return new Report(reportId, pressed, released);
        }

        public static Report keyboard(int keyCode) {
            return keyboard(0, keyCode);
        }

        public static Report keyboard(int modifierMask, int keyCode) {
            requireUnsignedByte(modifierMask, "modifierMask");
            requireUnsignedByte(keyCode, "keyCode");
            byte[] pressed = new byte[8];
            pressed[0] = (byte) modifierMask;
            pressed[2] = (byte) keyCode;
            return new Report(REPORT_ID_KEYBOARD, pressed, new byte[8]);
        }

        public static Report mouseWheel(int amount) {
            if (amount == 0) {
                throw new IllegalArgumentException("mouse wheel amount must not be zero");
            }
            int clamped = Math.max(-127, Math.min(127, amount));
            return new Report(
                    REPORT_ID_MOUSE,
                    new byte[] {0, 0, 0, (byte) clamped},
                    new byte[] {0, 0, 0, 0});
        }

        /** Creates a mouse-button transaction while preserving any buttons already held. */
        public static Report mouseButton(int pressedButtons, int releasedButtons) {
            requireMouseButtons(pressedButtons);
            requireMouseButtons(releasedButtons);
            if (pressedButtons == releasedButtons) {
                throw new IllegalArgumentException("mouse button transaction must change button state");
            }
            return new Report(
                    REPORT_ID_MOUSE,
                    new byte[] {(byte) pressedButtons, 0, 0, 0},
                    new byte[] {(byte) releasedButtons, 0, 0, 0});
        }

        public static Report consumer(int usageMask) {
            if (usageMask <= 0 || usageMask > 255) {
                throw new IllegalArgumentException("consumer usageMask must be between 1 and 255");
            }
            return new Report(REPORT_ID_CONSUMER, new byte[] {(byte) usageMask}, new byte[] {0});
        }

        public int getReportId() {
            return reportId;
        }

        public byte[] getPressedPayload() {
            return pressed.clone();
        }

        public byte[] getReleasedPayload() {
            return released.clone();
        }

        private static void requireUnsignedByte(int value, String name) {
            if (value < 0 || value > 255) {
                throw new IllegalArgumentException(name + " must be between 0 and 255");
            }
        }

        private static void requireMouseButtons(int value) {
            if (value < 0 || value > 0x07) {
                throw new IllegalArgumentException("mouse buttons must use only the lowest three bits");
            }
        }
    }

    /** One raw HID frame, used for key phases and high-frequency pointer movement. */
    public static final class Frame {
        private final int reportId;
        private final byte[] payload;

        private Frame(int reportId, byte[] payload) {
            if (reportId < 0 || reportId > 255) {
                throw new IllegalArgumentException("reportId must be between 0 and 255");
            }
            Objects.requireNonNull(payload, "payload");
            if (payload.length == 0) {
                throw new IllegalArgumentException("payload must not be empty");
            }
            int expectedLength = expectedPayloadLength(reportId);
            if (expectedLength > 0 && payload.length != expectedLength) {
                throw new IllegalArgumentException(
                        "report " + reportId + " requires a " + expectedLength + "-byte payload");
            }
            this.reportId = reportId;
            this.payload = payload.clone();
        }

        public static Frame of(int reportId, byte[] payload) {
            return new Frame(reportId, payload);
        }

        public static Frame keyboard(int modifierMask, int keyCode) {
            Report.requireUnsignedByte(modifierMask, "modifierMask");
            Report.requireUnsignedByte(keyCode, "keyCode");
            byte[] payload = new byte[8];
            payload[0] = (byte) modifierMask;
            payload[2] = (byte) keyCode;
            return new Frame(REPORT_ID_KEYBOARD, payload);
        }

        public static Frame consumer(int usageMask) {
            if (usageMask < 0 || usageMask > 255) {
                throw new IllegalArgumentException("consumer usageMask must fit in one byte");
            }
            return new Frame(REPORT_ID_CONSUMER, new byte[] {(byte) usageMask});
        }

        public static Frame mouse(int buttons, int deltaX, int deltaY, int wheel) {
            Report.requireMouseButtons(buttons);
            return new Frame(
                    REPORT_ID_MOUSE,
                    new byte[] {
                        (byte) buttons,
                        (byte) clampSignedByte(deltaX),
                        (byte) clampSignedByte(deltaY),
                        (byte) clampSignedByte(wheel)
                    });
        }

        public int getReportId() {
            return reportId;
        }

        public byte[] getPayload() {
            return payload.clone();
        }

        private static int clampSignedByte(int value) {
            return Math.max(-127, Math.min(127, value));
        }

        private static int expectedPayloadLength(int reportId) {
            if (reportId == REPORT_ID_KEYBOARD) {
                return 8;
            }
            if (reportId == REPORT_ID_MOUSE) {
                return 4;
            }
            if (reportId == REPORT_ID_CONSUMER) {
                return 1;
            }
            return -1;
        }
    }

    public final class Session implements AutoCloseable {
        private final long id;
        private final Transport transport;
        private volatile boolean valid = true;

        private Session(long id, Transport transport) {
            this.id = id;
            this.transport = transport;
        }

        public long getId() {
            return id;
        }

        public boolean isValid() {
            return valid && !closed;
        }

        public CompletableFuture<SendResult> submit(Report report) {
            return submit(report, defaultHoldMillis);
        }

        public CompletableFuture<SendResult> submit(Report report, long holdMillis) {
            return enqueue(this, report, holdMillis);
        }

        public CompletableFuture<SendResult> submitFrame(Frame frame) {
            return enqueueFrame(this, frame);
        }

        @Override
        public void close() {
            invalidate(this);
        }
    }

    private final Object stateLock = new Object();
    private final long defaultHoldMillis;
    private final Sleeper sleeper;
    private final Clock clock;
    private final ThreadPoolExecutor worker;

    private volatile boolean closed;
    private long nextSessionId;
    private Session currentSession;

    public HidReportSender() {
        this(DEFAULT_HOLD_MILLIS, Thread::sleep, () -> System.nanoTime() / 1_000_000L);
    }

    public HidReportSender(Transport initialTransport) {
        this();
        openSession(initialTransport);
    }

    public HidReportSender(long defaultHoldMillis, Sleeper sleeper, Clock clock) {
        this(defaultHoldMillis, sleeper, clock, DEFAULT_MAX_PENDING_REPORTS);
    }

    public HidReportSender(
            long defaultHoldMillis,
            Sleeper sleeper,
            Clock clock,
            int maxPendingReports) {
        validateHoldMillis(defaultHoldMillis);
        if (maxPendingReports < 1) {
            throw new IllegalArgumentException("maxPendingReports must be positive");
        }
        this.defaultHoldMillis = defaultHoldMillis;
        this.sleeper = Objects.requireNonNull(sleeper, "sleeper");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.worker = new ThreadPoolExecutor(
                1,
                1,
                0L,
                TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(maxPendingReports),
                new SenderThreadFactory());
    }

    public Session openSession(Transport transport) {
        Objects.requireNonNull(transport, "transport");
        synchronized (stateLock) {
            if (closed) {
                throw new IllegalStateException("sender is closed");
            }
            if (currentSession != null) {
                currentSession.valid = false;
            }
            currentSession = new Session(++nextSessionId, transport);
            return currentSession;
        }
    }

    public void invalidateSession() {
        synchronized (stateLock) {
            if (currentSession != null) {
                currentSession.valid = false;
                currentSession = null;
            }
        }
    }

    public CompletableFuture<SendResult> submit(Report report) {
        return submit(report, defaultHoldMillis);
    }

    public CompletableFuture<SendResult> submit(Report report, long holdMillis) {
        Objects.requireNonNull(report, "report");
        validateHoldMillis(holdMillis);
        Session session;
        synchronized (stateLock) {
            if (closed) {
                return completed(Status.CLOSED, null, report, false, null);
            }
            session = currentSession;
            if (session == null) {
                return completed(Status.NO_SESSION, null, report, false, null);
            }
        }
        return enqueue(session, report, holdMillis);
    }

    public CompletableFuture<SendResult> submit(
            int reportId, byte[] pressed, byte[] released, long holdMillis) {
        return submit(Report.of(reportId, pressed, released), holdMillis);
    }

    public CompletableFuture<SendResult> submit(int reportId, byte[] pressed, byte[] released) {
        return submit(Report.of(reportId, pressed, released));
    }

    public CompletableFuture<SendResult> submitFrame(Frame frame) {
        Objects.requireNonNull(frame, "frame");
        Session session;
        synchronized (stateLock) {
            if (closed) {
                return completed(Status.CLOSED, null, frame.reportId, false, null);
            }
            session = currentSession;
            if (session == null) {
                return completed(Status.NO_SESSION, null, frame.reportId, false, null);
            }
        }
        return enqueueFrame(session, frame);
    }

    private CompletableFuture<SendResult> enqueue(Session session, Report report, long holdMillis) {
        Objects.requireNonNull(report, "report");
        validateHoldMillis(holdMillis);
        synchronized (stateLock) {
            if (closed) {
                return completed(Status.CLOSED, session, report, false, null);
            }
            if (!session.valid) {
                return completed(Status.STALE_SESSION, session, report, false, null);
            }
            Submission submission = new Submission(session, report, holdMillis, clock.monotonicTimeMillis());
            try {
                worker.execute(submission);
            } catch (RejectedExecutionException rejected) {
                submission.rejectQueueFull();
            }
            return submission.future;
        }
    }

    private CompletableFuture<SendResult> enqueueFrame(Session session, Frame frame) {
        Objects.requireNonNull(frame, "frame");
        synchronized (stateLock) {
            if (closed) {
                return completed(Status.CLOSED, session, frame.reportId, false, null);
            }
            if (!session.valid) {
                return completed(Status.STALE_SESSION, session, frame.reportId, false, null);
            }
            FrameSubmission submission = new FrameSubmission(
                    session,
                    frame,
                    clock.monotonicTimeMillis());
            try {
                worker.execute(submission);
            } catch (RejectedExecutionException rejected) {
                submission.rejectQueueFull();
            }
            return submission.future;
        }
    }

    private void invalidate(Session session) {
        synchronized (stateLock) {
            session.valid = false;
            if (currentSession == session) {
                currentSession = null;
            }
        }
    }

    private Status statusBeforeStart(Session session) {
        synchronized (stateLock) {
            if (closed) {
                return Status.CLOSED;
            }
            return session.valid ? null : Status.STALE_SESSION;
        }
    }

    @Override
    public void close() {
        List<Runnable> cancelled;
        synchronized (stateLock) {
            if (closed) {
                return;
            }
            closed = true;
            if (currentSession != null) {
                currentSession.valid = false;
                currentSession = null;
            }
            cancelled = worker.shutdownNow();
        }
        for (Runnable runnable : cancelled) {
            if (runnable instanceof PendingSubmission) {
                ((PendingSubmission) runnable).cancelBeforeRun();
            }
        }
    }

    private CompletableFuture<SendResult> completed(
            Status status,
            Session session,
            Report report,
            boolean releaseAttempted,
            Throwable failure) {
        return completed(status, session, report.reportId, releaseAttempted, failure);
    }

    private CompletableFuture<SendResult> completed(
            Status status,
            Session session,
            int reportId,
            boolean releaseAttempted,
            Throwable failure) {
        long now = clock.monotonicTimeMillis();
        return CompletableFuture.completedFuture(new SendResult(
                status,
                session == null ? 0L : session.id,
                reportId,
                now,
                now,
                releaseAttempted,
                failure));
    }

    private static void validateHoldMillis(long holdMillis) {
        if (holdMillis < 0L || holdMillis > MAX_HOLD_MILLIS) {
            throw new IllegalArgumentException("holdMillis must be between 0 and " + MAX_HOLD_MILLIS);
        }
    }

    private interface PendingSubmission extends Runnable {
        void cancelBeforeRun();
    }

    private final class Submission implements PendingSubmission {
        private final Session session;
        private final Report report;
        private final long holdMillis;
        private final long queuedAtMillis;
        private final CompletableFuture<SendResult> future = new CompletableFuture<>();

        private Submission(Session session, Report report, long holdMillis, long queuedAtMillis) {
            this.session = session;
            this.report = report;
            this.holdMillis = holdMillis;
            this.queuedAtMillis = queuedAtMillis;
        }

        @Override
        public void run() {
            Status rejected = statusBeforeStart(session);
            if (rejected != null) {
                complete(rejected, false, null);
                return;
            }

            Throwable failure = null;
            boolean pressed;
            try {
                pressed = session.transport.sendReport(report.reportId, report.pressed.clone());
            } catch (Exception error) {
                pressed = false;
                failure = error;
            }
            if (!pressed) {
                complete(Status.PRESS_FAILED, false, failure);
                return;
            }

            Status finalStatus = Status.COMPLETED;
            boolean interrupted = false;
            try {
                sleeper.sleep(holdMillis);
            } catch (InterruptedException error) {
                interrupted = true;
                failure = error;
                finalStatus = Status.DELAY_INTERRUPTED;
            } catch (RuntimeException error) {
                failure = error;
                finalStatus = Status.DELAY_FAILED;
            }

            boolean released;
            try {
                released = session.transport.sendReport(report.reportId, report.released.clone());
            } catch (Exception error) {
                released = false;
                failure = error;
            }
            if (!released) {
                finalStatus = Status.RELEASE_FAILED;
            }
            complete(finalStatus, true, failure);
            if (interrupted) {
                Thread.currentThread().interrupt();
            }
        }

        @Override
        public void cancelBeforeRun() {
            complete(Status.CLOSED, false, null);
        }

        private void rejectQueueFull() {
            complete(Status.QUEUE_FULL, false, null);
        }

        private void complete(Status status, boolean releaseAttempted, Throwable failure) {
            future.complete(new SendResult(
                    status,
                    session.id,
                    report.reportId,
                    queuedAtMillis,
                    clock.monotonicTimeMillis(),
                    releaseAttempted,
                    failure));
        }
    }

    private final class FrameSubmission implements PendingSubmission {
        private final Session session;
        private final Frame frame;
        private final long queuedAtMillis;
        private final CompletableFuture<SendResult> future = new CompletableFuture<>();

        private FrameSubmission(Session session, Frame frame, long queuedAtMillis) {
            this.session = session;
            this.frame = frame;
            this.queuedAtMillis = queuedAtMillis;
        }

        @Override
        public void run() {
            Status rejected = statusBeforeStart(session);
            if (rejected != null) {
                complete(rejected, null);
                return;
            }
            Throwable failure = null;
            boolean sent;
            try {
                sent = session.transport.sendReport(frame.reportId, frame.payload.clone());
            } catch (Exception error) {
                sent = false;
                failure = error;
            }
            complete(sent ? Status.COMPLETED : Status.SEND_FAILED, failure);
        }

        @Override
        public void cancelBeforeRun() {
            complete(Status.CLOSED, null);
        }

        private void rejectQueueFull() {
            complete(Status.QUEUE_FULL, null);
        }

        private void complete(Status status, Throwable failure) {
            future.complete(new SendResult(
                    status,
                    session.id,
                    frame.reportId,
                    queuedAtMillis,
                    clock.monotonicTimeMillis(),
                    false,
                    failure));
        }
    }

    private static final class SenderThreadFactory implements ThreadFactory {
        @Override
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "hid-report-sender-" + WORKER_IDS.incrementAndGet());
            thread.setDaemon(true);
            return thread;
        }
    }
}
