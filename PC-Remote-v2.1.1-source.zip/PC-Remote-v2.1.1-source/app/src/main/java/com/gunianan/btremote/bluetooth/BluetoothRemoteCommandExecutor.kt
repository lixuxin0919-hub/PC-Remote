package com.gunianan.btremote.bluetooth

import com.gunianan.btremote.action.ActionResult
import com.gunianan.btremote.action.FailureReason
import com.gunianan.btremote.action.HidKey
import com.gunianan.btremote.action.HidKeyStateManager
import com.gunianan.btremote.action.HidKeyTransport
import com.gunianan.btremote.action.IgnoreReason
import com.gunianan.btremote.action.KeyPhase
import com.gunianan.btremote.action.KeyReleaseReason
import com.gunianan.btremote.action.MonotonicClock
import com.gunianan.btremote.action.MouseButtonId
import com.gunianan.btremote.action.ReleaseAllResult
import com.gunianan.btremote.action.RemoteCommand
import com.gunianan.btremote.action.RemoteCommandExecutor
import java.util.concurrent.CompletableFuture
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Bluetooth HID implementation of the transport-neutral command contract.
 *
 * A bound sender session captures the proxy/device pair. No delayed frame can leak to
 * a replacement connection. All held keys are owned by [HidKeyStateManager] and are
 * released on lifecycle or session boundaries.
 */
class BluetoothRemoteCommandExecutor internal constructor(
    private val keyStateManager: HidKeyStateManager = HidKeyStateManager(),
    private val clock: MonotonicClock = MonotonicClock { System.nanoTime() / 1_000_000L },
    private val failureThrottleMillis: Long = 1_500L,
    private val watchdogScope: CoroutineScope? = null,
    private val heldKeyTimeoutMillis: Long = 30_000L,
    private val onTransportFailure: (sessionId: String, message: String) -> Unit = { _, _ -> },
) : RemoteCommandExecutor {
    init {
        require(failureThrottleMillis >= 0L) { "failureThrottleMillis must not be negative" }
        require(heldKeyTimeoutMillis > 0L) { "heldKeyTimeoutMillis must be positive" }
    }

    private data class BoundSession(
        val id: String,
        val senderSession: HidReportSender.Session,
        val keySession: HidKeyStateManager.Session,
    )

    private data class KeyboardStroke(val keyCode: Int, val modifierMask: Int)

    private val commandMutex = Mutex()
    private val lastFailureNotificationAt = AtomicLong(Long.MIN_VALUE)

    private var boundSession: BoundSession? = null
    private val heldKeyboard = linkedSetOf<KeyboardStroke>()
    private var heldConsumerMask = 0
    private var heldMouseButtons = 0
    private var implicitDragActive = false
    private var heldKeyWatchdog: Job? = null
    private var closed = false

    override suspend fun execute(command: RemoteCommand): ActionResult = commandMutex.withLock {
        if (closed) return@withLock sessionClosed("HID 指令执行器已关闭")
        val bound = boundSession ?: return@withLock sessionClosed("尚未连接电脑")
        val result = when (command) {
            is RemoteCommand.Keyboard -> executeKeyboard(bound, command)
            is RemoteCommand.Consumer -> executeConsumer(bound, command)
            is RemoteCommand.MouseButton -> executeMouseButton(bound, command)
            is RemoteCommand.MouseMove -> executeMouseMove(bound, command)
            is RemoteCommand.Scroll -> executeScroll(bound, command)
            is RemoteCommand.ModifiedScroll -> executeModifiedScroll(bound, command)
            is RemoteCommand.Internal -> ActionResult.Failure(
                reason = FailureReason.INVALID_ACTION,
                message = "内部应用动作不能由蓝牙 HID 传输执行",
            )
        }
        updateHeldKeyWatchdogLocked()
        result
    }

    internal suspend fun bindSession(
        sessionId: String,
        senderSession: HidReportSender.Session,
    ) = commandMutex.withLock {
        check(!closed) { "BluetoothRemoteCommandExecutor is closed" }
        val keySession = keyStateManager.openSession(
            sessionId,
            HidKeyTransport { _, command -> sendPhase(senderSession, sessionId, command) },
        )
        boundSession?.senderSession?.close()
        boundSession = BoundSession(sessionId, senderSession, keySession)
        lastFailureNotificationAt.set(Long.MIN_VALUE)
        cancelHeldKeyWatchdogLocked()
        resetTrackedReports()
    }

    suspend fun releaseAll(reason: KeyReleaseReason): ReleaseAllResult = commandMutex.withLock {
        if (closed || boundSession == null) return@withLock ReleaseAllResult(0, 0, emptyList())
        if (reason == KeyReleaseReason.TIMEOUT) {
            heldKeyWatchdog = null
        } else {
            cancelHeldKeyWatchdogLocked()
        }
        val result = keyStateManager.releaseAll(reason)
        implicitDragActive = false
        updateHeldKeyWatchdogLocked()
        result
    }

    /** Call after the platform has reported transport loss and release I/O is impossible. */
    internal suspend fun unbindAfterTransportLoss(sessionId: String? = null) = commandMutex.withLock {
        val current = boundSession ?: return@withLock
        if (sessionId != null && current.id != sessionId) return@withLock
        cancelHeldKeyWatchdogLocked()
        keyStateManager.discardAfterDisconnect()
        current.senderSession.close()
        boundSession = null
        resetTrackedReports()
    }

    internal suspend fun close() = commandMutex.withLock {
        if (closed) return@withLock
        closed = true
        cancelHeldKeyWatchdogLocked()
        keyStateManager.close()
        boundSession?.senderSession?.close()
        boundSession = null
        resetTrackedReports()
    }

    private suspend fun executeKeyboard(
        bound: BoundSession,
        command: RemoteCommand.Keyboard,
    ): ActionResult {
        val key = HidKey.Keyboard(command.keyCode, command.modifierMask)
        return when (command.phase) {
            KeyPhase.DOWN -> {
                val stroke = KeyboardStroke(command.keyCode, command.modifierMask)
                if (stroke !in heldKeyboard && heldKeyboard.size >= MAX_SIMULTANEOUS_KEYBOARD_KEYS) {
                    ActionResult.Failure(
                        reason = FailureReason.EXECUTOR_REJECTED,
                        message = "HID 键盘同时最多按住 6 个按键",
                    )
                } else {
                    bound.keySession.keyDown(key)
                }
            }
            KeyPhase.UP -> bound.keySession.keyUp(key)
            KeyPhase.TAP -> {
                val stroke = KeyboardStroke(command.keyCode, command.modifierMask)
                if (stroke in heldKeyboard) {
                    ActionResult.Ignored(IgnoreReason.DUPLICATE_KEY_DOWN)
                } else if (heldKeyboard.size >= MAX_SIMULTANEOUS_KEYBOARD_KEYS) {
                    ActionResult.Failure(
                        reason = FailureReason.EXECUTOR_REJECTED,
                        message = "HID 键盘同时最多按住 6 个按键",
                    )
                } else {
                    val pressed = keyboardPayload(heldKeyboard + stroke)
                    val released = keyboardPayload(heldKeyboard)
                    sendTransaction(
                        bound,
                        HidReportSender.Report.of(
                            HidReportSender.REPORT_ID_KEYBOARD,
                            pressed,
                            released,
                        ),
                    )
                }
            }
        }
    }

    private suspend fun executeConsumer(
        bound: BoundSession,
        command: RemoteCommand.Consumer,
    ): ActionResult {
        val usageMask = HidReportMapper.consumerMask(command.usageId)
            ?: return unsupportedConsumer(command.usageId)
        val key = HidKey.Consumer(command.usageId)
        return when (command.phase) {
            KeyPhase.DOWN -> bound.keySession.keyDown(key)
            KeyPhase.UP -> bound.keySession.keyUp(key)
            KeyPhase.TAP -> {
                if (heldConsumerMask and usageMask != 0) {
                    ActionResult.Ignored(IgnoreReason.DUPLICATE_KEY_DOWN)
                } else {
                    sendTransaction(
                        bound,
                        HidReportSender.Report.of(
                            HidReportSender.REPORT_ID_CONSUMER,
                            byteArrayOf((heldConsumerMask or usageMask).toByte()),
                            byteArrayOf(heldConsumerMask.toByte()),
                        ),
                    )
                }
            }
        }
    }

    private suspend fun executeMouseButton(
        bound: BoundSession,
        command: RemoteCommand.MouseButton,
    ): ActionResult {
        val mask = HidReportMapper.mouseButtonMask(command.button)
        val key = HidKey.MouseButton(command.button)
        return when (command.phase) {
            KeyPhase.DOWN -> bound.keySession.keyDown(key)
            KeyPhase.UP -> {
                if (command.button == MouseButtonId.LEFT) implicitDragActive = false
                bound.keySession.keyUp(key)
            }
            KeyPhase.TAP -> {
                if (heldMouseButtons and mask != 0) {
                    ActionResult.Ignored(IgnoreReason.DUPLICATE_KEY_DOWN)
                } else {
                    sendTransaction(bound, HidReportMapper.mouseClick(heldMouseButtons, command.button))
                }
            }
        }
    }

    private suspend fun executeMouseMove(
        bound: BoundSession,
        command: RemoteCommand.MouseMove,
    ): ActionResult {
        if (command.dragging && heldMouseButtons and HidReportMapper.MOUSE_LEFT == 0) {
            val down = bound.keySession.keyDown(HidKey.MouseButton(MouseButtonId.LEFT))
            if (!down.isSuccessful) return down
            implicitDragActive = true
        } else if (!command.dragging && implicitDragActive) {
            val up = bound.keySession.keyUp(HidKey.MouseButton(MouseButtonId.LEFT))
            if (!up.isSuccessful) return up
            implicitDragActive = false
        }
        return sendFrame(
            bound,
            HidReportMapper.mouseFrame(
                buttons = heldMouseButtons,
                deltaX = command.deltaX,
                deltaY = command.deltaY,
            ),
        )
    }

    private suspend fun executeScroll(
        bound: BoundSession,
        command: RemoteCommand.Scroll,
    ): ActionResult {
        if (command.horizontal != 0) {
            return ActionResult.Failure(
                reason = FailureReason.INVALID_ACTION,
                message = "当前兼容 HID 描述符仅支持垂直滚动",
            )
        }
        return sendFrame(
            bound,
            HidReportMapper.mouseFrame(
                buttons = heldMouseButtons,
                wheel = command.vertical,
            ),
        )
    }

    private suspend fun executeModifiedScroll(
        bound: BoundSession,
        command: RemoteCommand.ModifiedScroll,
    ): ActionResult {
        val modifierDown = sendFrame(
            bound,
            HidReportSender.Frame.keyboard(command.modifierMask, 0),
        )
        if (!modifierDown.isSuccessful) return modifierDown
        var wheelResult: ActionResult = ActionResult.Success(executedCommandCount = 0)
        var releaseResult: ActionResult = ActionResult.Success(executedCommandCount = 0)
        try {
            wheelResult = sendFrame(
                bound,
                HidReportMapper.mouseFrame(
                    buttons = heldMouseButtons,
                    wheel = command.vertical,
                ),
            )
        } finally {
            releaseResult = withContext(NonCancellable) {
                sendFrame(bound, HidReportSender.Frame.keyboard(0, 0))
            }
        }
        return when {
            !wheelResult.isSuccessful -> wheelResult
            !releaseResult.isSuccessful -> releaseResult
            else -> ActionResult.Success(executedCommandCount = 3)
        }
    }

    private suspend fun sendPhase(
        senderSession: HidReportSender.Session,
        sessionId: String,
        command: RemoteCommand,
    ): ActionResult {
        val prepared = when (command) {
            is RemoteCommand.Keyboard -> prepareKeyboardPhase(command)
            is RemoteCommand.Consumer -> prepareConsumerPhase(command)
            is RemoteCommand.MouseButton -> prepareMouseButtonPhase(command)
            is RemoteCommand.ModifiedScroll,
            is RemoteCommand.Internal,
            is RemoteCommand.MouseMove,
            is RemoteCommand.Scroll,
            -> return ActionResult.Failure(
                reason = FailureReason.UNSUPPORTED_PHASE,
                message = "该指令不支持按下/释放阶段",
            )
        }
        val result = senderSession.submitFrame(prepared.frame).awaitResult()
        val actionResult = result.toActionResult(sessionId)
        if (actionResult.isSuccessful) prepared.commit()
        return actionResult
    }

    private data class PreparedPhase(
        val frame: HidReportSender.Frame,
        val commit: () -> Unit,
    )

    private fun prepareKeyboardPhase(command: RemoteCommand.Keyboard): PreparedPhase {
        val stroke = KeyboardStroke(command.keyCode, command.modifierMask)
        val next = heldKeyboard.toMutableSet()
        if (command.phase == KeyPhase.DOWN) {
            if (next.size >= MAX_SIMULTANEOUS_KEYBOARD_KEYS && stroke !in next) {
                throw IllegalStateException("HID keyboard rollover limit reached")
            }
            next += stroke
        } else {
            next -= stroke
        }
        return PreparedPhase(
            frame = HidReportSender.Frame.of(
                HidReportSender.REPORT_ID_KEYBOARD,
                keyboardPayload(next),
            ),
            commit = {
                heldKeyboard.clear()
                heldKeyboard.addAll(next)
            },
        )
    }

    private fun prepareConsumerPhase(command: RemoteCommand.Consumer): PreparedPhase {
        val usageMask = HidReportMapper.consumerMask(command.usageId)
            ?: throw UnsupportedConsumerUsageException(command.usageId)
        val nextMask = if (command.phase == KeyPhase.DOWN) {
            heldConsumerMask or usageMask
        } else {
            heldConsumerMask and usageMask.inv()
        }
        return PreparedPhase(
            frame = HidReportSender.Frame.consumer(nextMask),
            commit = { heldConsumerMask = nextMask },
        )
    }

    private fun prepareMouseButtonPhase(command: RemoteCommand.MouseButton): PreparedPhase {
        val mask = HidReportMapper.mouseButtonMask(command.button)
        val nextMask = if (command.phase == KeyPhase.DOWN) {
            heldMouseButtons or mask
        } else {
            heldMouseButtons and mask.inv()
        }
        return PreparedPhase(
            frame = HidReportMapper.mouseFrame(nextMask),
            commit = { heldMouseButtons = nextMask },
        )
    }

    private suspend fun sendFrame(
        bound: BoundSession,
        frame: HidReportSender.Frame,
    ): ActionResult = bound.senderSession.submitFrame(frame).awaitResult().toActionResult(bound.id)

    private suspend fun sendTransaction(
        bound: BoundSession,
        report: HidReportSender.Report,
    ): ActionResult = bound.senderSession.submit(report).awaitResult().toActionResult(bound.id)

    private fun keyboardPayload(strokes: Collection<KeyboardStroke>): ByteArray {
        val payload = ByteArray(8)
        payload[0] = strokes.fold(0) { mask, stroke -> mask or stroke.modifierMask }.toByte()
        strokes.take(MAX_SIMULTANEOUS_KEYBOARD_KEYS).forEachIndexed { index, stroke ->
            payload[index + 2] = stroke.keyCode.toByte()
        }
        return payload
    }

    private fun HidReportSender.SendResult.toActionResult(sessionId: String): ActionResult = when (status) {
        HidReportSender.Status.COMPLETED -> ActionResult.Success()
        HidReportSender.Status.STALE_SESSION -> ActionResult.Ignored(IgnoreReason.STALE_SESSION)
        HidReportSender.Status.QUEUE_FULL -> ActionResult.Ignored(
            reason = IgnoreReason.RATE_LIMITED,
            message = "HID 发送队列已满，已丢弃过量输入",
        )
        HidReportSender.Status.NO_SESSION,
        HidReportSender.Status.CLOSED,
        -> sessionClosed("HID 连接会话已关闭")
        HidReportSender.Status.DELAY_INTERRUPTED -> sessionClosed("HID 指令在会话关闭时被中断")
        HidReportSender.Status.PRESS_FAILED,
        HidReportSender.Status.RELEASE_FAILED,
        HidReportSender.Status.SEND_FAILED,
        HidReportSender.Status.DELAY_FAILED,
        -> {
            val detail = failure?.message ?: "蓝牙 HID 报告发送失败"
            notifyTransportFailure(sessionId, detail)
            ActionResult.Failure(
                reason = FailureReason.TRANSPORT_FAILURE,
                message = detail,
                cause = failure,
            )
        }
    }

    private fun notifyTransportFailure(sessionId: String, message: String) {
        val now = clock.nowMillis()
        while (true) {
            val last = lastFailureNotificationAt.get()
            if (last != Long.MIN_VALUE && now >= last && now - last < failureThrottleMillis) return
            if (lastFailureNotificationAt.compareAndSet(last, now)) {
                onTransportFailure(sessionId, message)
                return
            }
        }
    }

    private fun resetTrackedReports() {
        heldKeyboard.clear()
        heldConsumerMask = 0
        heldMouseButtons = 0
        implicitDragActive = false
    }

    private fun updateHeldKeyWatchdogLocked() {
        val hasHeldKeys = heldKeyboard.isNotEmpty() || heldConsumerMask != 0 || heldMouseButtons != 0
        if (!hasHeldKeys) {
            cancelHeldKeyWatchdogLocked()
            return
        }
        if (heldKeyWatchdog?.isActive == true || watchdogScope == null || closed) return
        heldKeyWatchdog = watchdogScope.launch {
            delay(heldKeyTimeoutMillis)
            releaseAll(KeyReleaseReason.TIMEOUT)
        }
    }

    private fun cancelHeldKeyWatchdogLocked() {
        heldKeyWatchdog?.cancel()
        heldKeyWatchdog = null
    }

    private fun unsupportedConsumer(usageId: Int) = ActionResult.Failure(
        reason = FailureReason.INVALID_ACTION,
        message = "当前 HID 描述符不支持 Consumer usage 0x${usageId.toString(16).uppercase()}",
    )

    private fun sessionClosed(message: String) = ActionResult.Failure(
        reason = FailureReason.SESSION_CLOSED,
        message = message,
    )

    // Once a frame is admitted it must finish even if the caller is cancelled; otherwise a
    // successful DOWN could escape before HidKeyStateManager records the matching release.
    private suspend fun <T> CompletableFuture<T>.awaitResult(): T = suspendCoroutine { continuation ->
        whenComplete { value, error ->
            if (error == null) continuation.resume(value) else continuation.resumeWithException(error)
        }
    }

    private class UnsupportedConsumerUsageException(val usageId: Int) :
        IllegalArgumentException("Unsupported consumer usage $usageId")

    private companion object {
        const val MAX_SIMULTANEOUS_KEYBOARD_KEYS = 6
    }
}
