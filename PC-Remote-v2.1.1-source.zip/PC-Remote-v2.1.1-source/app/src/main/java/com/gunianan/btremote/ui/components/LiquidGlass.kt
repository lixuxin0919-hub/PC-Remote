package com.gunianan.btremote.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography
import com.gunianan.btremote.R

@Composable
fun AuroraBackground(
    modifier: Modifier = Modifier,
    plain: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithCache {
                if (plain) {
                    onDrawBehind { drawRect(Color(0xFFF6F8FC)) }
                } else {
                    val base = Brush.verticalGradient(
                        0.0f to PcRemoteColors.AuroraTop,
                        0.42f to PcRemoteColors.AuroraBlue,
                        1.0f to PcRemoteColors.AuroraCyan,
                    )
                    val glow = Brush.radialGradient(
                        colors = listOf(PcRemoteColors.AuroraLavender.copy(alpha = 0.72f), Color.Transparent),
                        radius = 920f,
                    )
                    onDrawBehind {
                        drawRect(base)
                        drawRect(glow)
                    }
                }
            },
    ) {
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 28.dp,
    contentPadding: PaddingValues = PaddingValues(18.dp),
    strong: Boolean = false,
    shadowElevation: Dp = 3.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(cornerRadius)
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = modifier
            .shadow(
                elevation = shadowElevation,
                shape = shape,
                ambientColor = Color(0x1A2D5B88),
                spotColor = Color(0x242D5B88),
            )
            .clip(shape)
            .background(if (strong) PcRemoteColors.GlassStrong else PcRemoteColors.Glass)
            .border(BorderStroke(1.dp, PcRemoteColors.GlassBorder), shape)
            .then(
                if (onClick == null) Modifier else Modifier.clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    role = Role.Button,
                    onClick = onClick,
                ),
            )
            .padding(contentPadding),
        content = content,
    )
}

@Composable
fun GlassPill(
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable RowScope.() -> Unit,
) {
    val shape = RoundedCornerShape(999.dp)
    Surface(
        modifier = modifier
            .shadow(if (active) 4.dp else 2.dp, shape)
            .then(if (onClick == null) Modifier else Modifier.clickable(role = Role.Button, onClick = onClick)),
        shape = shape,
        color = if (active) PcRemoteColors.GlassStrong else PcRemoteColors.Glass.copy(alpha = 0.88f),
        border = BorderStroke(1.dp, PcRemoteColors.GlassBorder),
        content = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp),
                content = content,
            )
        },
    )
}

@Composable
fun GlassActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    enabled: Boolean = true,
    localizeText: Boolean = true,
) {
    val shape = RoundedCornerShape(22.dp)
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val containerColor = when {
        !enabled -> Color(0xFFE5ECF4)
        pressed && primary -> Color(0xFF0075E5)
        pressed -> Color.White
        primary -> PcRemoteColors.Primary
        else -> PcRemoteColors.GlassStrong
    }
    val contentColor = when {
        !enabled -> Color(0xFF8EA0B3)
        primary -> Color.White
        else -> PcRemoteColors.Text
    }
    Box(
        modifier = modifier
            .heightIn(min = 52.dp)
            .shadow(if (!enabled) 0.dp else if (primary) 3.dp else 1.dp, shape)
            .clip(shape)
            .background(containerColor)
            .then(
                if (primary) Modifier else Modifier.border(
                    BorderStroke(1.dp, PcRemoteColors.GlassBorder),
                    shape,
                ),
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = contentColor,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            localize = localizeText,
        )
    }
}

@Composable
fun SectionHeading(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
) {
    Column(modifier) {
        Text(text = title, style = PcRemoteTypography.SectionTitle)
        if (subtitle != null) {
            Spacer(Modifier.height(3.dp))
            Text(text = subtitle, style = PcRemoteTypography.Caption)
        }
    }
}

@Composable
fun AssetIcon(
    @DrawableRes resourceId: Int,
    contentDescription: String,
    modifier: Modifier = Modifier,
    tint: Color? = PcRemoteColors.PrimaryDeep,
) {
    Box(
        modifier = modifier
            .clipToBounds()
            .semantics { this.contentDescription = contentDescription },
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(resourceId),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            colorFilter = tint?.let(ColorFilter::tint),
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val scale = assetVisualScale(resourceId)
                    scaleX = scale
                    scaleY = scale
                },
        )
    }
}

private fun assetVisualScale(@DrawableRes resourceId: Int): Float = when (resourceId) {
    R.drawable.volume_down,
    R.drawable.volume_mute,
    R.drawable.media_previous,
    R.drawable.media_next,
    R.drawable.profile_presentation,
    R.drawable.nav_help,
    -> 1.68f
    R.drawable.media_play_pause,
    R.drawable.mode_music,
    R.drawable.mode_video,
    R.drawable.profile_mouse,
    -> 1.56f
    else -> 1.45f
}

@Composable
fun StatusDot(color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(9.dp)
            .clip(CircleShape)
            .background(color),
    )
}
