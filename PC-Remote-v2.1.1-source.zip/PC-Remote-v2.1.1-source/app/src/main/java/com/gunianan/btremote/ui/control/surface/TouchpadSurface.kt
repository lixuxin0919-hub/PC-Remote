package com.gunianan.btremote.ui.control.surface

import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlin.math.hypot

/**
 * A pointer-only touchpad interpreter.
 *
 * Supported interactions are one-finger relative movement, delayed single tap,
 * double tap, 500 ms hold-then-drag, two-finger scroll and two-finger tap. The
 * component never assumes that the remote PC accepted a command.
 */
@Composable
fun TouchpadSurface(
    callbacks: TouchpadCallbacks,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    config: TouchpadSurfaceConfig = TouchpadSurfaceConfig(),
    colors: ControlSurfaceColors = ControlSurfaceDefaults.colors(),
    cornerRadius: Dp = 28.dp,
    contentDescription: String = "触控板控制区",
    content: @Composable BoxScope.() -> Unit = {},
) {
    val currentCallbacks by rememberUpdatedState(callbacks)
    var activeTouches by remember { mutableStateOf(emptyList<Offset>()) }

    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 220.dp)
            .controlSurfaceFrame(colors, cornerRadius)
            .semantics {
                this.contentDescription = contentDescription
                if (!enabled) disabled()
            }
            .pointerInput(enabled, config) {
                if (!enabled) {
                    activeTouches = emptyList()
                    return@pointerInput
                }
                detectTouchpadInput(
                    config = config,
                    callbacks = { currentCallbacks },
                    updateTouches = { activeTouches = it },
                )
            },
    ) {
        SurfaceGrid(
            colors = colors,
            touchPoints = activeTouches,
            enabled = enabled,
        )
        SurfaceContent(content)
    }
}

private suspend fun PointerInputScope.detectTouchpadInput(
    config: TouchpadSurfaceConfig,
    callbacks: () -> TouchpadCallbacks,
    updateTouches: (List<Offset>) -> Unit,
) = supervisorScope {
    val density = density
    val movementNoisePx = with(density) { config.movementNoise.toPx() }
    val tapSlopPx = with(density) { config.tapSlop.toPx() }
    val doubleTapPositionSlopPx = with(density) { config.doubleTapPositionSlop.toPx() }
    val longPressSlopPx = with(density) { config.longPressSlop.toPx() }
    val scrollActivationSlopPx = with(density) { config.scrollActivationSlop.toPx() }
    val twoFingerTapSlopPx = with(density) { config.twoFingerTapSlop.toPx() }

    var pendingTap: PendingTap? = null
    var pendingTapJob: Job? = null
    var nextTapToken = 0L
    var activeDrag = false
    var sessionActive = false

    fun dispatchTap(position: Offset, upTimeMillis: Long) {
        val previous = pendingTap
        val gap = previous?.let { upTimeMillis - it.upTimeMillis }
        if (
            previous != null &&
            gap != null && gap in 0..config.doubleTapMaximumGapMs &&
            offsetDistance(previous.position, position) <= doubleTapPositionSlopPx
        ) {
            pendingTapJob?.cancel()
            pendingTapJob = null
            pendingTap = null
            callbacks().onDoubleTap(position)
            return
        }

        if (previous != null) {
            pendingTapJob?.cancel()
            callbacks().onTap(previous.position)
        }

        val tap = PendingTap(position, upTimeMillis, ++nextTapToken)
        pendingTap = tap
        pendingTapJob = launch {
            delay(config.doubleTapMaximumGapMs)
            if (pendingTap?.token == tap.token) {
                pendingTap = null
                pendingTapJob = null
                callbacks().onTap(tap.position)
            }
        }
    }

    try {
        while (currentCoroutineContext().isActive) {
            awaitPointerEventScope {
                val down = awaitFirstDown(requireUnconsumed = false)
                down.consume()
                sessionActive = true
                updateTouches(listOf(down.position))

                val pointerId = down.id
                val downPosition = down.position
                val downTime = down.uptimeMillis
                var lastPosition = down.position
                var pathLength = 0f
                var intent = OneFingerIntent.UNDECIDED
                var twoFinger: TwoFingerSession? = null
                var finished = false
                var cancelledByPointerCount = false

                while (!finished) {
                    val event = awaitPointerEvent()
                    val pressed = event.changes.filter { it.pressed }
                    updateTouches(pressed.map { it.position })

                    val session = twoFinger
                    if (session == null) {
                        if (pressed.size > 2) {
                            cancelledByPointerCount = true
                            event.changes.forEach(PointerInputChange::consume)
                            drainPointersAndUpdate(updateTouches)
                            finished = true
                            continue
                        }

                        if (pressed.size == 2) {
                            if (activeDrag) {
                                callbacks().onDragEnd(true)
                                activeDrag = false
                            }
                            twoFinger = TwoFingerSession.start(
                                changes = pressed,
                                startTimeMillis = event.changes.maxOf { it.uptimeMillis },
                            )
                            event.changes.forEach(PointerInputChange::consume)
                            continue
                        }

                        val change = event.changes.firstOrNull { it.id == pointerId }
                        if (change == null) {
                            cancelledByPointerCount = true
                            event.changes.forEach(PointerInputChange::consume)
                            finished = true
                            continue
                        }

                        val delta = change.position - lastPosition
                        val stepDistance = delta.getDistance()
                        pathLength += stepDistance
                        val duration = (change.uptimeMillis - downTime).coerceAtLeast(0L)

                        if (!change.pressed) {
                            if (activeDrag) {
                                callbacks().onDragEnd(false)
                                activeDrag = false
                            } else if (
                                intent == OneFingerIntent.UNDECIDED &&
                                duration <= config.tapMaximumDurationMs &&
                                pathLength <= tapSlopPx
                            ) {
                                dispatchTap(change.position, change.uptimeMillis)
                            }
                            change.consume()
                            finished = true
                            continue
                        }

                        if (intent == OneFingerIntent.UNDECIDED) {
                            intent = when {
                                duration >= config.longPressDurationMs && pathLength <= longPressSlopPx -> {
                                    activeDrag = true
                                    callbacks().onDragStart(change.position)
                                    OneFingerIntent.DRAG
                                }

                                pathLength > tapSlopPx -> OneFingerIntent.MOVE
                                else -> OneFingerIntent.UNDECIDED
                            }
                        }

                        if (stepDistance >= movementNoisePx) {
                            when (intent) {
                                OneFingerIntent.MOVE -> callbacks().onMove(delta)
                                OneFingerIntent.DRAG -> callbacks().onDrag(delta)
                                OneFingerIntent.UNDECIDED -> Unit
                            }
                        }
                        lastPosition = change.position
                        event.changes.forEach(PointerInputChange::consume)
                    } else {
                        val foreignPressedPointer = pressed.any { it.id !in session.pointerIds }
                        if (foreignPressedPointer) {
                            cancelledByPointerCount = true
                            event.changes.forEach(PointerInputChange::consume)
                            drainPointersAndUpdate(updateTouches)
                            finished = true
                            continue
                        }

                        val update = session.update(event.changes)
                        if (update.bothPressed) {
                            if (!session.scrolling && session.maximumTravel >= scrollActivationSlopPx) {
                                session.scrolling = true
                            }
                            if (session.scrolling && update.centroidDelta.getDistance() >= movementNoisePx) {
                                callbacks().onScroll(update.centroidDelta)
                            }
                        }

                        if (update.allReleased) {
                            val duration = (update.eventTimeMillis - session.startTimeMillis).coerceAtLeast(0L)
                            if (
                                !session.scrolling &&
                                duration <= config.twoFingerTapMaximumDurationMs &&
                                session.maximumTravel <= twoFingerTapSlopPx
                            ) {
                                callbacks().onRightClick(session.currentCentroid())
                            }
                            finished = true
                        }
                        event.changes.forEach(PointerInputChange::consume)
                    }
                }

                sessionActive = false
                updateTouches(emptyList())
                if (cancelledByPointerCount) callbacks().onGestureCancelled()
            }
        }
    } catch (cancelled: CancellationException) {
        if (activeDrag) callbacks().onDragEnd(true)
        if (sessionActive) callbacks().onGestureCancelled()
        throw cancelled
    } finally {
        pendingTapJob?.cancel()
        pendingTapJob = null
        pendingTap = null
        activeDrag = false
        sessionActive = false
        updateTouches(emptyList())
    }
}

internal data class TwoFingerUpdate(
    val centroidDelta: Offset,
    val bothPressed: Boolean,
    val allReleased: Boolean,
    val eventTimeMillis: Long,
)

internal class TwoFingerSession private constructor(
    val pointerIds: Set<PointerId>,
    private val startPositions: Map<PointerId, Offset>,
    private val currentPositions: MutableMap<PointerId, Offset>,
    private val pressedState: MutableMap<PointerId, Boolean>,
    val startTimeMillis: Long,
) {
    var maximumTravel: Float = 0f
        private set
    var scrolling: Boolean = false

    fun update(changes: List<PointerInputChange>): TwoFingerUpdate {
        val previousCentroid = currentCentroid()
        var eventTime = startTimeMillis
        for (change in changes) {
            if (change.id !in pointerIds) continue
            currentPositions[change.id] = change.position
            pressedState[change.id] = change.pressed
            eventTime = maxOf(eventTime, change.uptimeMillis)
            val start = startPositions.getValue(change.id)
            maximumTravel = maxOf(maximumTravel, offsetDistance(start, change.position))
        }
        val centroid = currentCentroid()
        return TwoFingerUpdate(
            centroidDelta = centroid - previousCentroid,
            bothPressed = pressedState.values.all { it },
            allReleased = pressedState.values.none { it },
            eventTimeMillis = eventTime,
        )
    }

    fun currentCentroid(): Offset {
        var x = 0f
        var y = 0f
        currentPositions.values.forEach {
            x += it.x
            y += it.y
        }
        return Offset(x / currentPositions.size, y / currentPositions.size)
    }

    companion object {
        fun start(
            changes: List<PointerInputChange>,
            startTimeMillis: Long,
        ): TwoFingerSession {
            require(changes.size == 2)
            val starts = changes.associate { it.id to it.position }
            return TwoFingerSession(
                pointerIds = starts.keys,
                startPositions = starts,
                currentPositions = starts.toMutableMap(),
                pressedState = starts.keys.associateWith { true }.toMutableMap(),
                startTimeMillis = startTimeMillis,
            )
        }
    }
}

internal fun offsetDistance(first: Offset, second: Offset): Float =
    hypot(second.x - first.x, second.y - first.y)

internal suspend fun androidx.compose.ui.input.pointer.AwaitPointerEventScope.drainPointersAndUpdate(
    updateTouches: (List<Offset>) -> Unit,
) {
    while (true) {
        val event = awaitPointerEvent()
        event.changes.forEach(PointerInputChange::consume)
        val pressed = event.changes.filter { it.pressed }
        updateTouches(pressed.map { it.position })
        if (pressed.isEmpty()) return
    }
}
