package com.gunianan.btremote.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.ui.components.AssetIcon
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.customize.profileIconResource
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography

@Composable
fun ProfileSelectionDialog(
    profiles: List<ControlProfile>,
    activeProfileId: String,
    onSelect: (String) -> Unit,
    onCreate: () -> Unit,
    onManage: () -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = true),
    ) {
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 30.dp,
            contentPadding = PaddingValues(0.dp),
            strong = true,
            shadowElevation = 18.dp,
        ) {
            Column(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 22.dp, vertical = 19.dp)) {
                    Text("选择控制模式", style = PcRemoteTypography.SectionTitle)
                    Text("切换后所有控件与手势立即更新", style = PcRemoteTypography.Caption)
                }
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 430.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(profiles, key = ControlProfile::id) { profile ->
                        val selected = profile.id == activeProfileId
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(role = Role.RadioButton) { onSelect(profile.id) },
                            shape = RoundedCornerShape(20.dp),
                            color = if (selected) PcRemoteColors.Primary.copy(alpha = 0.12f) else PcRemoteColors.Glass,
                            border = BorderStroke(
                                1.dp,
                                if (selected) PcRemoteColors.Primary.copy(alpha = 0.48f) else PcRemoteColors.Hairline,
                            ),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                ProfileIconView(profile, Modifier.size(28.dp), PcRemoteColors.Primary)
                                Spacer(Modifier.size(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        profile.name,
                                        color = PcRemoteColors.Text,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        localize = profile.isSystemProfile,
                                    )
                                    Text(
                                        if (selected) "当前模式" else if (profile.isSystemProfile) "系统模式" else "自定义模式",
                                        style = PcRemoteTypography.Caption,
                                    )
                                }
                                if (selected) {
                                    Text("已选择", color = PcRemoteColors.Primary, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    GlassActionButton("新建模式", onClick = onCreate, modifier = Modifier.weight(1f), primary = true)
                    GlassActionButton("管理模式", onClick = onManage, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}
