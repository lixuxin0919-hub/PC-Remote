package com.gunianan.btremote.ui.customize

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gunianan.btremote.domain.ControlAreaType
import com.gunianan.btremote.domain.ControlItemSize
import com.gunianan.btremote.domain.ControlLayout
import com.gunianan.btremote.domain.ControlSection
import com.gunianan.btremote.domain.GestureType
import com.gunianan.btremote.domain.Handedness
import com.gunianan.btremote.domain.HidConsumerUsages
import com.gunianan.btremote.domain.InternalActionType
import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.MouseCommand
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.domain.SequenceStep
import com.gunianan.btremote.R
import com.gunianan.btremote.ui.theme.PcRemoteColors

@Composable
internal fun SelectionChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val shape = RoundedCornerShape(16.dp)
    Surface(
        modifier = modifier
            .heightIn(min = 44.dp)
            .clickable(enabled = enabled, role = Role.RadioButton, onClick = onClick),
        shape = shape,
        color = when {
            !enabled -> PcRemoteColors.Glass.copy(alpha = 0.55f)
            selected -> PcRemoteColors.Primary.copy(alpha = 0.13f)
            else -> PcRemoteColors.GlassStrong.copy(alpha = 0.78f)
        },
        border = BorderStroke(
            1.dp,
            if (selected) PcRemoteColors.Primary.copy(alpha = 0.55f) else PcRemoteColors.Hairline,
        ),
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = text,
                color = if (selected) PcRemoteColors.PrimaryDeep else PcRemoteColors.Text,
                fontSize = 13.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
internal fun InlineTag(
    text: String,
    modifier: Modifier = Modifier,
    tint: Color = PcRemoteColors.Primary,
) {
    Text(
        text = text,
        modifier = modifier
            .background(tint.copy(alpha = 0.11f), RoundedCornerShape(999.dp))
            .padding(horizontal = 9.dp, vertical = 4.dp),
        color = tint,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        fontWeight = FontWeight.SemiBold,
    )
}

@Composable
internal fun TwoColumnActions(
    modifier: Modifier = Modifier,
    first: @Composable RowScope.() -> Unit,
    second: @Composable RowScope.() -> Unit,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(Modifier.weight(1f), content = first)
        Row(Modifier.weight(1f), content = second)
    }
}

internal data class IconChoice(
    val token: String,
    @DrawableRes val resourceId: Int,
    val label: String,
)

internal val ProfileIconChoices = listOf(
    IconChoice("video", R.drawable.mode_video, "视频"),
    IconChoice("music", R.drawable.mode_music, "音乐"),
    IconChoice("remote", R.drawable.nav_remote, "遥控"),
    IconChoice("presentation", R.drawable.profile_presentation, "演示"),
    IconChoice("game", R.drawable.profile_game, "游戏"),
    IconChoice("keyboard", R.drawable.profile_keyboard, "键盘"),
    IconChoice("mouse", R.drawable.profile_mouse, "鼠标"),
    IconChoice("custom", R.drawable.nav_customize, "自定义"),
)

@DrawableRes
internal fun profileIconResource(token: String?): Int =
    ProfileIconChoices.firstOrNull { it.token == token }?.resourceId ?: R.drawable.nav_remote

internal fun ControlAreaType.displayName(): String = when (this) {
    ControlAreaType.GESTURE -> "手势区"
    ControlAreaType.TOUCHPAD -> "触控板"
    ControlAreaType.HYBRID -> "混合模式"
}

internal fun ControlItemSize.displayName(): String = when (this) {
    ControlItemSize.COMPACT -> "紧凑"
    ControlItemSize.STANDARD -> "标准"
    ControlItemSize.WIDE -> "加宽"
    ControlItemSize.LARGE -> "大号"
}

internal fun ControlSection.displayName(): String = when (this) {
    ControlSection.TOP -> "顶部"
    ControlSection.PRIMARY -> "主控区"
    ControlSection.QUICK -> "快捷区"
    ControlSection.BOTTOM -> "底部"
}

internal fun ControlLayout.displayName(): String = when (this) {
    ControlLayout.SINGLE_COLUMN -> "单列"
    ControlLayout.TWO_COLUMN -> "双列"
    ControlLayout.THREE_COLUMN -> "三列"
    ControlLayout.LARGE_GESTURE -> "大手势区"
    ControlLayout.COMPACT_REMOTE -> "紧凑遥控"
    ControlLayout.FULLSCREEN_GESTURE -> "全屏手势"
    ControlLayout.CUSTOM_GRID -> "自定义网格"
}

internal fun Handedness.displayName(): String = when (this) {
    Handedness.INHERIT -> "跟随全局"
    Handedness.LEFT -> "左手"
    Handedness.RIGHT -> "右手"
}

internal fun GestureType.displayName(): String = when (this) {
    GestureType.SWIPE_UP -> "上滑"
    GestureType.SWIPE_DOWN -> "下滑"
    GestureType.SWIPE_LEFT -> "左滑"
    GestureType.SWIPE_RIGHT -> "右滑"
    GestureType.TAP -> "轻点"
    GestureType.DOUBLE_TAP -> "双击"
    GestureType.LONG_PRESS -> "长按"
    GestureType.CIRCLE -> "画圆"
    GestureType.X -> "画 X"
    GestureType.Z -> "画 Z"
    GestureType.CHECK -> "画勾"
    GestureType.CUSTOM -> "自定义手势"
    GestureType.TOUCHPAD_TAP -> "触控板轻点"
    GestureType.TOUCHPAD_DOUBLE_TAP -> "触控板双击"
    GestureType.TOUCHPAD_LONG_PRESS_DRAG -> "长按拖动"
    GestureType.TOUCHPAD_TWO_FINGER_SCROLL -> "双指滚动"
    GestureType.TOUCHPAD_TWO_FINGER_TAP -> "双指右键"
}

internal fun RemoteActionConfig?.displaySummary(): String = when (this) {
    null -> "未绑定"
    is RemoteActionConfig.KeyboardKey -> "键盘 · ${keyboardKeyName(keyCode)}"
    is RemoteActionConfig.KeyboardShortcut -> {
        val modifierText = modifiers.joinToString("+") { it.shortName() }
        "快捷键 · ${listOf(modifierText, keyboardKeyName(keyCode)).filter(String::isNotBlank).joinToString("+")}"
    }
    is RemoteActionConfig.ConsumerKey -> "媒体 · ${consumerKeyName(usageId)}"
    is RemoteActionConfig.MouseAction -> "鼠标 · ${command.displayName(button)}"
    is RemoteActionConfig.ScrollAction -> "滚动 · ${scrollName(horizontal, vertical)}"
    is RemoteActionConfig.ModifiedScrollAction -> "组合滚动 · ${modifiers.joinToString("+") { it.shortName() }}"
    is RemoteActionConfig.InternalAction -> "应用内 · ${action.displayName()}"
    is RemoteActionConfig.CustomSequence -> "高级序列 · ${steps.size} 步"
}

internal fun KeyboardModifier.shortName(): String = when (this) {
    KeyboardModifier.LEFT_CONTROL, KeyboardModifier.RIGHT_CONTROL -> "Ctrl"
    KeyboardModifier.LEFT_SHIFT, KeyboardModifier.RIGHT_SHIFT -> "Shift"
    KeyboardModifier.LEFT_ALT, KeyboardModifier.RIGHT_ALT -> "Alt"
    KeyboardModifier.LEFT_GUI, KeyboardModifier.RIGHT_GUI -> "Win"
}

internal fun MouseCommand.displayName(button: MouseButton?): String = when (this) {
    MouseCommand.CLICK -> when (button) {
        MouseButton.RIGHT -> "右键单击"
        MouseButton.MIDDLE -> "中键单击"
        else -> "左键单击"
    }
    MouseCommand.DOWN -> "按下${button.displayName()}"
    MouseCommand.UP -> "释放${button.displayName()}"
    MouseCommand.MOVE -> "移动指针"
}

internal fun MouseButton?.displayName(): String = when (this) {
    MouseButton.LEFT -> "左键"
    MouseButton.RIGHT -> "右键"
    MouseButton.MIDDLE -> "中键"
    null -> "鼠标键"
}

internal fun InternalActionType.displayName(): String = when (this) {
    InternalActionType.OPEN_PROFILE_PICKER -> "打开模式选择"
    InternalActionType.OPEN_KEYBOARD -> "打开键盘"
    InternalActionType.OPEN_QUICK_ACTIONS -> "打开快捷动作"
    InternalActionType.TOGGLE_CONTROL_AREA_TYPE -> "切换控制区类型"
    InternalActionType.SWITCH_PROFILE -> "切换控制模式"
    InternalActionType.OPEN_SETTINGS -> "打开设置"
}

internal fun SequenceStep.displaySummary(): String = when (this) {
    is SequenceStep.Tap -> "点击 ${action.displaySummary()}"
    is SequenceStep.Down -> "按下 ${action.displaySummary()}"
    is SequenceStep.Up -> "释放 ${action.displaySummary()}"
    is SequenceStep.Repeat -> "重复 ${count} 次 · ${action.displaySummary()}"
    is SequenceStep.Delay -> "等待 ${durationMs}ms"
}

internal fun keyboardKeyName(code: Int): String = CommonKeyboardKeys
    .firstOrNull { it.code == code }
    ?.label
    ?: "HID 0x${code.toString(16).uppercase()}"

internal fun consumerKeyName(usageId: Int): String = CommonConsumerKeys
    .firstOrNull { it.code == usageId }
    ?.label
    ?: "Usage 0x${usageId.toString(16).uppercase()}"

private fun scrollName(horizontal: Int, vertical: Int): String = when {
    vertical < 0 -> "向上"
    vertical > 0 -> "向下"
    horizontal < 0 -> "向左"
    horizontal > 0 -> "向右"
    else -> "停止"
}

internal data class HidChoice(val label: String, val code: Int)

internal val CommonKeyboardKeys = listOf(
    HidChoice("空格", 0x2C),
    HidChoice("回车", 0x28),
    HidChoice("Esc", 0x29),
    HidChoice("Tab", 0x2B),
    HidChoice("退格", 0x2A),
    HidChoice("↑", 0x52),
    HidChoice("↓", 0x51),
    HidChoice("←", 0x50),
    HidChoice("→", 0x4F),
    HidChoice("Home", 0x4A),
    HidChoice("End", 0x4D),
    HidChoice("PageUp", 0x4B),
    HidChoice("PageDown", 0x4E),
    HidChoice("Delete", 0x4C),
    HidChoice("A", 0x04),
    HidChoice("C", 0x06),
    HidChoice("D", 0x07),
    HidChoice("S", 0x16),
    HidChoice("V", 0x19),
    HidChoice("X", 0x1B),
    HidChoice("Z", 0x1D),
)

internal val CommonConsumerKeys = listOf(
    HidChoice("播放/暂停", HidConsumerUsages.PLAY_PAUSE),
    HidChoice("上一首", HidConsumerUsages.PREVIOUS_TRACK),
    HidChoice("下一首", HidConsumerUsages.NEXT_TRACK),
    HidChoice("停止", HidConsumerUsages.STOP),
    HidChoice("快进", HidConsumerUsages.FAST_FORWARD),
    HidChoice("音量减", HidConsumerUsages.VOLUME_DECREMENT),
    HidChoice("静音", HidConsumerUsages.MUTE),
    HidChoice("音量加", HidConsumerUsages.VOLUME_INCREMENT),
)
