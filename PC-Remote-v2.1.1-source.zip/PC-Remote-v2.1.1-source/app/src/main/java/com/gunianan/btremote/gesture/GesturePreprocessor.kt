package com.gunianan.btremote.gesture

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Linear-time filtering, resampling and normalization shared by both stored
 * templates and live candidates.
 */
class GesturePreprocessor(
    val sampleCount: Int = 64,
    val squareSize: Float = 250f,
    private val smoothingAlpha: Float = 0.35f,
    private val duplicatePointDistancePx: Float = 0.75f,
) {
    init {
        require(sampleCount >= 8)
        require(squareSize > 0f)
        require(smoothingAlpha in 0f..1f)
        require(duplicatePointDistancePx >= 0f)
    }

    data class Vec2(val x: Float, val y: Float)

    data class PreparedPath(
        val points: List<Vec2>,
        val originalPathLength: Float,
    )

    fun prepare(
        input: List<PointSample>,
        rotationInvariant: Boolean,
    ): PreparedPath? {
        if (input.size < 2) return null
        if (input.any { it.strokeId != input.first().strokeId }) return null

        val originalLength = rawPathLength(input)
        if (originalLength <= EPSILON) return null

        val filtered = smoothAndDedupe(input)
        if (filtered.size < 2) return null

        val filteredLength = pathLength(filtered)
        if (filteredLength <= EPSILON) return null

        var points = resample(filtered, sampleCount)
        if (points.size != sampleCount) return null

        if (rotationInvariant) {
            points = rotateBy(points, -indicativeAngle(points))
        }
        points = scaleToSquare(points, squareSize)
        points = translateToOrigin(points)
        return PreparedPath(points, originalLength)
    }

    fun rawPathLength(input: List<PointSample>): Float {
        var length = 0f
        for (index in 1 until input.size) {
            if (input[index].strokeId != input[index - 1].strokeId) continue
            length += hypot(
                input[index].x - input[index - 1].x,
                input[index].y - input[index - 1].y,
            )
        }
        return length
    }

    private fun smoothAndDedupe(input: List<PointSample>): List<Vec2> {
        val output = ArrayList<Vec2>(input.size)
        var smoothedX = input.first().x
        var smoothedY = input.first().y
        output += Vec2(smoothedX, smoothedY)

        for (index in 1 until input.size) {
            val sample = input[index]
            val previousSample = input[index - 1]
            if (sample.strokeId != previousSample.strokeId) continue

            smoothedX += smoothingAlpha * (sample.x - smoothedX)
            smoothedY += smoothingAlpha * (sample.y - smoothedY)
            val previous = output.last()
            if (hypot(smoothedX - previous.x, smoothedY - previous.y) >= duplicatePointDistancePx) {
                output += Vec2(smoothedX, smoothedY)
            }
        }

        val last = input.last()
        val previous = output.last()
        if (hypot(last.x - previous.x, last.y - previous.y) > EPSILON) {
            output += Vec2(last.x, last.y)
        }
        return output
    }

    /** Resamples without inserting into the input list, avoiding O(n^2). */
    private fun resample(input: List<Vec2>, targetCount: Int): List<Vec2> {
        val totalLength = pathLength(input)
        if (totalLength <= EPSILON) return emptyList()

        val cumulative = FloatArray(input.size)
        for (index in 1 until input.size) {
            cumulative[index] = cumulative[index - 1] + distance(input[index - 1], input[index])
        }

        val output = ArrayList<Vec2>(targetCount)
        var segmentIndex = 1
        for (sampleIndex in 0 until targetCount) {
            val targetDistance = totalLength * sampleIndex / (targetCount - 1f)
            while (segmentIndex < cumulative.lastIndex && cumulative[segmentIndex] < targetDistance) {
                segmentIndex++
            }

            val startIndex = (segmentIndex - 1).coerceAtLeast(0)
            val startDistance = cumulative[startIndex]
            val endDistance = cumulative[segmentIndex]
            val segmentLength = endDistance - startDistance
            val ratio = if (segmentLength <= EPSILON) {
                0f
            } else {
                ((targetDistance - startDistance) / segmentLength).coerceIn(0f, 1f)
            }
            val start = input[startIndex]
            val end = input[segmentIndex]
            output += Vec2(
                x = start.x + (end.x - start.x) * ratio,
                y = start.y + (end.y - start.y) * ratio,
            )
        }
        return output
    }

    private fun indicativeAngle(points: List<Vec2>): Float {
        val center = centroid(points)
        return atan2(center.y - points.first().y, center.x - points.first().x)
    }

    internal fun rotateBy(points: List<Vec2>, radians: Float): List<Vec2> {
        val center = centroid(points)
        val cosine = cos(radians)
        val sine = sin(radians)
        return points.mapTo(ArrayList(points.size)) { point ->
            val x = point.x - center.x
            val y = point.y - center.y
            Vec2(
                x = x * cosine - y * sine + center.x,
                y = x * sine + y * cosine + center.y,
            )
        }
    }

    private fun scaleToSquare(points: List<Vec2>, size: Float): List<Vec2> {
        var minX = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        for (point in points) {
            minX = kotlin.math.min(minX, point.x)
            maxX = kotlin.math.max(maxX, point.x)
            minY = kotlin.math.min(minY, point.y)
            maxY = kotlin.math.max(maxY, point.y)
        }

        val width = max(maxX - minX, EPSILON)
        val height = max(maxY - minY, EPSILON)
        return points.mapTo(ArrayList(points.size)) { point ->
            Vec2(
                x = (point.x - minX) * size / width,
                y = (point.y - minY) * size / height,
            )
        }
    }

    private fun translateToOrigin(points: List<Vec2>): List<Vec2> {
        val center = centroid(points)
        return points.mapTo(ArrayList(points.size)) { Vec2(it.x - center.x, it.y - center.y) }
    }

    internal fun pathDistance(first: List<Vec2>, second: List<Vec2>): Float {
        if (first.size != second.size || first.isEmpty()) return Float.POSITIVE_INFINITY
        var total = 0f
        for (index in first.indices) {
            total += distance(first[index], second[index])
        }
        return total / first.size
    }

    private fun pathLength(points: List<Vec2>): Float {
        var total = 0f
        for (index in 1 until points.size) {
            total += distance(points[index - 1], points[index])
        }
        return total
    }

    private fun centroid(points: List<Vec2>): Vec2 {
        var x = 0.0
        var y = 0.0
        for (point in points) {
            x += point.x
            y += point.y
        }
        return Vec2((x / points.size).toFloat(), (y / points.size).toFloat())
    }

    private fun distance(first: Vec2, second: Vec2): Float =
        hypot(first.x - second.x, first.y - second.y)

    private companion object {
        const val EPSILON = 0.0001f
    }
}
