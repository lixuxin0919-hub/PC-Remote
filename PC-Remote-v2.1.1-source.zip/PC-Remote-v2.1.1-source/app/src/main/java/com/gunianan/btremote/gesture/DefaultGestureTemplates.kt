package com.gunianan.btremote.gesture

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Built-in, dependency-free symbol recordings. */
object DefaultGestureTemplates {
    fun create(): List<GestureTemplate> = listOf(
        circle(),
        xShape(),
        zShape(),
        checkShape(),
    )

    fun circle(): GestureTemplate {
        val clockwise = circlePoints(clockwise = true)
        val counterClockwise = circlePoints(clockwise = false)
        return GestureTemplate(
            id = "circle",
            displayName = "圆圈",
            points = clockwise,
            rotationInvariant = true,
            additionalSamples = listOf(counterClockwise),
        )
    }

    fun xShape(): GestureTemplate = GestureTemplate(
        id = "x",
        displayName = "X",
        points = interpolate(
            listOf(
                30f to 30f,
                270f to 270f,
                150f to 150f,
                270f to 30f,
                30f to 270f,
            ),
        ),
        rotationInvariant = true,
        additionalSamples = listOf(
            interpolate(
                listOf(
                    35f to 35f,
                    265f to 265f,
                    148f to 148f,
                    260f to 38f,
                    38f to 262f,
                ),
            ),
        ),
    )

    fun zShape(): GestureTemplate = GestureTemplate(
        id = "z",
        displayName = "Z",
        points = interpolate(
            listOf(
                35f to 45f,
                260f to 45f,
                40f to 250f,
                270f to 250f,
            ),
        ),
        rotationInvariant = false,
    )

    fun checkShape(): GestureTemplate = GestureTemplate(
        id = "check",
        displayName = "勾",
        points = interpolate(
            listOf(
                40f to 105f,
                115f to 235f,
                260f to 55f,
            ),
        ),
        rotationInvariant = false,
        additionalSamples = listOf(
            interpolate(
                listOf(
                    45f to 112f,
                    112f to 225f,
                    255f to 62f,
                ),
            ),
        ),
    )

    private fun circlePoints(clockwise: Boolean): List<PointSample> =
        (0 until 72).map { index ->
            val direction = if (clockwise) 1.0 else -1.0
            val angle = direction * 2.0 * PI * index / 71.0
            PointSample(
                x = (150.0 + 110.0 * cos(angle)).toFloat(),
                y = (150.0 + 110.0 * sin(angle)).toFloat(),
                timeMillis = index * 12L,
            )
        }

    internal fun interpolate(
        anchors: List<Pair<Float, Float>>,
        pointsPerSegment: Int = 24,
        millisPerPoint: Long = 12L,
    ): List<PointSample> {
        require(anchors.size >= 2)
        require(pointsPerSegment > 0)
        val output = ArrayList<PointSample>((anchors.size - 1) * pointsPerSegment + 1)
        var timestamp = 0L

        for (segmentIndex in 1 until anchors.size) {
            val start = anchors[segmentIndex - 1]
            val end = anchors[segmentIndex]
            for (step in 0 until pointsPerSegment) {
                val ratio = step.toFloat() / pointsPerSegment
                output += PointSample(
                    x = start.first + (end.first - start.first) * ratio,
                    y = start.second + (end.second - start.second) * ratio,
                    timeMillis = timestamp,
                )
                timestamp += millisPerPoint
            }
        }

        val last = anchors.last()
        output += PointSample(last.first, last.second, timestamp)
        return output
    }
}
