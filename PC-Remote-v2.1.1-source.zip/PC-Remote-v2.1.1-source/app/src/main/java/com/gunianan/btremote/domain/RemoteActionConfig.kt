package com.gunianan.btremote.domain

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Serializable description of a remote command.
 *
 * UI and gesture recognition code should only create these values. Transport-specific
 * conversion belongs to the command executor layer.
 */
@Serializable
sealed class RemoteActionConfig {

    @Serializable
    @SerialName("keyboard_key")
    data class KeyboardKey(
        /** USB HID keyboard usage ID. */
        val keyCode: Int,
    ) : RemoteActionConfig()

    @Serializable
    @SerialName("keyboard_shortcut")
    data class KeyboardShortcut(
        val modifiers: Set<KeyboardModifier>,
        /** USB HID keyboard usage ID for the non-modifier key. */
        val keyCode: Int,
    ) : RemoteActionConfig()

    @Serializable
    @SerialName("consumer_key")
    data class ConsumerKey(
        /** USB HID Consumer Page usage ID. */
        val usageId: Int,
    ) : RemoteActionConfig()

    @Serializable
    @SerialName("mouse")
    data class MouseAction(
        val command: MouseCommand,
        val button: MouseButton? = null,
        val deltaX: Int = 0,
        val deltaY: Int = 0,
    ) : RemoteActionConfig()

    @Serializable
    @SerialName("scroll")
    data class ScrollAction(
        val horizontal: Int = 0,
        val vertical: Int = 0,
    ) : RemoteActionConfig()

    /** Standard wheel report emitted while keyboard modifiers are held, then always released. */
    @Serializable
    @SerialName("modified_scroll")
    data class ModifiedScrollAction(
        val modifiers: Set<KeyboardModifier>,
        val vertical: Int,
    ) : RemoteActionConfig()

    @Serializable
    @SerialName("internal")
    data class InternalAction(
        val action: InternalActionType,
        val targetProfileId: String? = null,
    ) : RemoteActionConfig()

    @Serializable
    @SerialName("custom_sequence")
    data class CustomSequence(
        val steps: List<SequenceStep>,
        val stopOnFailure: Boolean = true,
    ) : RemoteActionConfig()
}

@Serializable
enum class KeyboardModifier(val hidMask: Int) {
    LEFT_CONTROL(0x01),
    LEFT_SHIFT(0x02),
    LEFT_ALT(0x04),
    LEFT_GUI(0x08),
    RIGHT_CONTROL(0x10),
    RIGHT_SHIFT(0x20),
    RIGHT_ALT(0x40),
    RIGHT_GUI(0x80),
}

@Serializable
enum class MouseButton(val hidMask: Int) {
    LEFT(0x01),
    RIGHT(0x02),
    MIDDLE(0x04),
}

@Serializable
enum class MouseCommand {
    CLICK,
    DOWN,
    UP,
    MOVE,
}

@Serializable
enum class InternalActionType {
    OPEN_PROFILE_PICKER,
    OPEN_KEYBOARD,
    OPEN_QUICK_ACTIONS,
    TOGGLE_CONTROL_AREA_TYPE,
    SWITCH_PROFILE,
    OPEN_SETTINGS,
}

/** One executable step in an advanced sequence. */
@Serializable
sealed class SequenceStep {

    @Serializable
    @SerialName("tap")
    data class Tap(val action: RemoteActionConfig) : SequenceStep()

    @Serializable
    @SerialName("down")
    data class Down(val action: RemoteActionConfig) : SequenceStep()

    @Serializable
    @SerialName("up")
    data class Up(val action: RemoteActionConfig) : SequenceStep()

    @Serializable
    @SerialName("repeat")
    data class Repeat(
        val action: RemoteActionConfig,
        val count: Int,
        val intervalMs: Long,
    ) : SequenceStep()

    @Serializable
    @SerialName("delay")
    data class Delay(val durationMs: Long) : SequenceStep()
}
