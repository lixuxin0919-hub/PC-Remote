package com.gunianan.btremote.ui.customize

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.OutlinedTextField
import com.gunianan.btremote.ui.components.PcRemoteSwitch
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.GestureBinding
import com.gunianan.btremote.domain.GesturePoint
import com.gunianan.btremote.domain.GestureSample
import com.gunianan.btremote.domain.GestureType
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.gesture.DefaultGestureTemplates
import com.gunianan.btremote.gesture.GestureEngine
import com.gunianan.btremote.gesture.GestureTemplate
import com.gunianan.btremote.gesture.PointSample
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.SectionHeading
import com.gunianan.btremote.ui.control.surface.GestureSurface
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt

/** Three recordings, conflict review, action selection and five validation attempts. */
@Composable
fun CustomGestureEditorScreen(
    profile: ControlProfile,
    availableProfiles: List<ControlProfile>,
    confidenceThreshold: Float,
    onCancel: () -> Unit,
    onSave: (com.gunianan.btremote.domain.GestureTemplate, GestureBinding) -> Unit,
    modifier: Modifier = Modifier,
) {
    val gestureId = rememberSaveable { "custom.${UUID.randomUUID()}" }
    val bindingId = rememberSaveable { "gesture.${UUID.randomUUID()}" }
    var name by rememberSaveable { mutableStateOf("我的手势") }
    var rotationInvariant by rememberSaveable { mutableStateOf(true) }
    var recordings by remember { mutableStateOf<List<List<PointSample>>>(emptyList()) }
    var tests by remember { mutableStateOf<List<Boolean>>(emptyList()) }
    var action by remember { mutableStateOf<RemoteActionConfig?>(null) }
    var showActionPicker by remember { mutableStateOf(false) }
    var allowConflictOverride by rememberSaveable { mutableStateOf(false) }

    val runtimeTemplate = remember(gestureId, name, rotationInvariant, recordings) {
        recordings.firstOrNull()?.let { first ->
            GestureTemplate(
                id = gestureId,
                displayName = name.ifBlank { "自定义手势" },
                points = first,
                rotationInvariant = rotationInvariant,
                additionalSamples = recordings.drop(1),
            )
        }
    }
    val existingRuntimeTemplates = remember(profile.customGestures) {
        profile.customGestures.mapNotNull { it.toRuntimeTemplate() }
    }
    val conflictEngine = remember(existingRuntimeTemplates) {
        GestureEngine(DefaultGestureTemplates.create() + existingRuntimeTemplates)
    }
    val conflicts = remember(runtimeTemplate, recordings) {
        if (runtimeTemplate != null && recordings.size >= REQUIRED_RECORDINGS) {
            conflictEngine.findConflicts(runtimeTemplate)
        } else {
            emptyList()
        }
    }
    val testEngine = remember(runtimeTemplate, existingRuntimeTemplates) {
        runtimeTemplate?.let {
            GestureEngine(DefaultGestureTemplates.create() + existingRuntimeTemplates + it)
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, top = 142.dp, end = 20.dp, bottom = 132.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                GlassActionButton("取消", onCancel)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("录制自定义手势", style = PcRemoteTypography.SectionTitle)
                    Text("${profile.name} · 单笔轨迹", style = PcRemoteTypography.Caption)
                }
                GlassActionButton(
                    text = "保存",
                    onClick = {
                        val template = runtimeTemplate ?: return@GlassActionButton
                        val selectedAction = action ?: return@GlassActionButton
                        onSave(
                            template.toDomainTemplate(),
                            GestureBinding(
                                id = bindingId,
                                gestureType = GestureType.CUSTOM,
                                customGestureId = gestureId,
                                action = selectedAction,
                                minConfidence = confidenceThreshold,
                            ),
                        )
                    },
                    primary = true,
                    enabled = recordings.size >= REQUIRED_RECORDINGS && tests.size >= REQUIRED_TESTS &&
                        action != null && (conflicts.isEmpty() || allowConflictOverride),
                )
            }
        }

        item(key = "identity") {
            GlassCard {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(30) },
                    label = { Text("手势名称") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("允许旋转识别", fontWeight = FontWeight.SemiBold)
                        Text("关闭后会保留起笔方向，降低旋转误触", style = PcRemoteTypography.Caption)
                    }
                    PcRemoteSwitch(checked = rotationInvariant, onCheckedChange = {
                        rotationInvariant = it
                        tests = emptyList()
                    })
                }
            }
        }

        item(key = "progress") {
            SectionHeading(
                title = if (recordings.size < REQUIRED_RECORDINGS) "录制样本" else "测试识别",
                subtitle = if (recordings.size < REQUIRED_RECORDINGS) {
                    "请自然绘制同一手势 3 次 · ${recordings.size}/$REQUIRED_RECORDINGS"
                } else {
                    "再绘制 5 次验证稳定性 · ${tests.size}/$REQUIRED_TESTS"
                },
            )
        }

        item(key = "surface") {
            GlassCard(contentPadding = PaddingValues(6.dp), cornerRadius = 34.dp) {
                GestureSurface(
                    onStrokeComplete = { points ->
                        if (recordings.size < REQUIRED_RECORDINGS) {
                            recordings = recordings + listOf(points)
                            tests = emptyList()
                        } else if (tests.size < REQUIRED_TESTS) {
                            val result = testEngine?.recognizeDetailed(points)
                            tests = tests + (result?.match?.gestureId == gestureId)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(360.dp),
                    contentDescription = if (recordings.size < REQUIRED_RECORDINGS) "录制手势样本" else "测试自定义手势",
                    referenceStrokes = recordings,
                    retainCompletedStroke = false,
                ) {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            if (recordings.size < REQUIRED_RECORDINGS) "绘制第 ${recordings.size + 1} 次" else "测试第 ${tests.size + 1} 次",
                            color = PcRemoteColors.Muted,
                        )
                        if (tests.isNotEmpty()) {
                            Text(
                                "当前成功率 ${successRate(tests)}%",
                                color = PcRemoteColors.Primary,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }
            }
        }

        item(key = "record-actions") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassActionButton(
                    text = "重新录制",
                    onClick = {
                        recordings = emptyList()
                        tests = emptyList()
                    },
                    modifier = Modifier.weight(1f),
                )
                GlassActionButton(
                    text = action?.displayName() ?: "选择动作",
                    onClick = { showActionPicker = true },
                    modifier = Modifier.weight(1f),
                    primary = action != null,
                    enabled = recordings.size >= REQUIRED_RECORDINGS,
                )
            }
        }

        if (recordings.size >= REQUIRED_RECORDINGS) {
            item(key = "conflicts") {
                GlassCard(strong = conflicts.isNotEmpty()) {
                    Text(
                        if (conflicts.isEmpty()) "未发现明显冲突" else "发现 ${conflicts.size} 个相似手势",
                        color = if (conflicts.isEmpty()) PcRemoteColors.Success else PcRemoteColors.Warning,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (conflicts.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        conflicts.take(4).forEach { conflict ->
                            Text(
                                "${conflict.existingDisplayName} · ${(conflict.similarity * 100).roundToInt()}% 相似",
                                style = PcRemoteTypography.Caption,
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("覆盖冲突继续保存", fontWeight = FontWeight.SemiBold)
                                Text("只建议在实际测试能稳定区分时开启", style = PcRemoteTypography.Caption)
                            }
                            PcRemoteSwitch(checked = allowConflictOverride, onCheckedChange = { allowConflictOverride = it })
                        }
                    }
                }
            }
        }

        if (tests.size >= REQUIRED_TESTS) {
            item(key = "test-result") {
                val rate = successRate(tests)
                GlassCard(strong = true) {
                    Text("5 次测试完成", fontWeight = FontWeight.SemiBold)
                    Text(
                        "成功率 $rate% · ${tests.count(Boolean::not)} 次未识别",
                        color = if (rate >= 80) PcRemoteColors.Success else PcRemoteColors.Warning,
                    )
                    if (rate < 80) {
                        Text("建议重新录制差异更明确的样本后再保存。", style = PcRemoteTypography.Caption)
                    }
                }
            }
        }
    }

    if (showActionPicker) {
        ActionPickerDialog(
            initialAction = action,
            availableProfiles = availableProfiles,
            onDismiss = { showActionPicker = false },
            onConfirm = {
                action = it
                showActionPicker = false
            },
            onClear = {
                action = null
                showActionPicker = false
            },
        )
    }
}

private fun successRate(results: List<Boolean>): Int =
    if (results.isEmpty()) 0 else (results.count { it } * 100f / results.size).roundToInt()

private fun RemoteActionConfig.displayName(): String = when (this) {
    is RemoteActionConfig.KeyboardKey -> "键盘动作"
    is RemoteActionConfig.KeyboardShortcut -> "组合键"
    is RemoteActionConfig.ConsumerKey -> "媒体动作"
    is RemoteActionConfig.MouseAction -> "鼠标动作"
    is RemoteActionConfig.ScrollAction -> "滚动动作"
    is RemoteActionConfig.ModifiedScrollAction -> "组合滚动动作"
    is RemoteActionConfig.InternalAction -> "应用内动作"
    is RemoteActionConfig.CustomSequence -> "高级序列"
}

private fun com.gunianan.btremote.domain.GestureTemplate.toRuntimeTemplate(): GestureTemplate? {
    val runtime = samples.map { sample ->
        sample.points.map { point ->
            PointSample(point.x * 200f, point.y * 200f, point.elapsedMs)
        }
    }.filter { it.size >= 2 }
    if (runtime.isEmpty()) return null
    return GestureTemplate(id, name, runtime.first(), rotationInvariant, runtime.drop(1))
}

private fun GestureTemplate.toDomainTemplate(): com.gunianan.btremote.domain.GestureTemplate {
    val now = System.currentTimeMillis()
    return com.gunianan.btremote.domain.GestureTemplate(
        id = id,
        name = displayName,
        rotationInvariant = rotationInvariant,
        samples = samples.map { GestureSample(it.normalizeForPersistence()) },
        createdAt = now,
        updatedAt = now,
    )
}

private fun List<PointSample>.normalizeForPersistence(): List<GesturePoint> {
    if (isEmpty()) return emptyList()
    val minX = minOf(PointSample::x)
    val maxX = maxOf(PointSample::x)
    val minY = minOf(PointSample::y)
    val maxY = maxOf(PointSample::y)
    val scale = max(maxX - minX, maxY - minY).coerceAtLeast(1f)
    val centerX = (minX + maxX) / 2f
    val centerY = (minY + maxY) / 2f
    val start = first().timeMillis
    return map { point ->
        GesturePoint(
            x = ((point.x - centerX) / scale * 2f).coerceIn(-1f, 1f),
            y = ((point.y - centerY) / scale * 2f).coerceIn(-1f, 1f),
            elapsedMs = (point.timeMillis - start).coerceAtLeast(0L),
        )
    }
}

private const val REQUIRED_RECORDINGS = 3
private const val REQUIRED_TESTS = 5
