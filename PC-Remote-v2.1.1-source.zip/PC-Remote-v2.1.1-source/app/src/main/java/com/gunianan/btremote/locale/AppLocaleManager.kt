package com.gunianan.btremote.locale

import android.app.LocaleManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import java.util.Locale

enum class AppLanguage(val persistedValue: String, val languageTag: String?) {
    SYSTEM("system", null),
    SIMPLIFIED_CHINESE("zh-CN", "zh-CN"),
    ENGLISH("en", "en"),
}

/** Keeps UI language outside the importable remote-control profile configuration. */
object AppLocaleManager {
    private const val PREFERENCES = "pc_remote_locale"
    private const val KEY_LANGUAGE = "selected_language"

    fun selectedLanguage(context: Context): AppLanguage {
        val stored = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
            .getString(KEY_LANGUAGE, AppLanguage.SYSTEM.persistedValue)
        return AppLanguage.entries.firstOrNull { it.persistedValue == stored } ?: AppLanguage.SYSTEM
    }

    fun setApplicationLanguage(context: Context, language: AppLanguage) {
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANGUAGE, language.persistedValue)
            .apply()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.getSystemService(LocaleManager::class.java)?.applicationLocales =
                LocaleList.forLanguageTags(language.languageTag.orEmpty())
        }
    }

    fun wrapContext(base: Context): Context {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) return base
        val tag = selectedLanguage(base).languageTag
        if (tag == null) {
            Locale.setDefault(base.resources.configuration.locales[0])
            return base
        }
        val locale = Locale.forLanguageTag(tag)
        Locale.setDefault(locale)
        val configuration = Configuration(base.resources.configuration)
        configuration.setLocale(locale)
        configuration.setLocales(LocaleList(locale))
        return base.createConfigurationContext(configuration)
    }
}
