package com.gunianan.btremote.gesture

import com.gunianan.btremote.gesture.GesturePreprocessor.PreparedPath
import com.gunianan.btremote.gesture.GesturePreprocessor.Vec2
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Pure Kotlin $1 unistroke recognizer for symbols and user recordings.
 * Templates are prepared once; a live trajectory is prepared at most twice
 * (direction-sensitive and rotation-invariant), independent of template count.
 */
class OneDollarRecognizer(
    templates: List<GestureTemplate> = emptyList(),
    private val preprocessor: GesturePreprocessor = GesturePreprocessor(),
) {
    private data class PreparedSample(
        val points: List<Vec2>,
        val sampleIndex: Int,
    )

    private data class PreparedTemplate(
        val id: String,
        val displayName: String,
        val rotationInvariant: Boolean,
        val samples: List<PreparedSample>,
    )

    @Volatile
    private var templatesSnapshot: List<GestureTemplate> = emptyList()

    @Volatile
    private var preparedSnapshot: List<PreparedTemplate> = emptyList()

    init {
        replaceTemplates(templates)
    }

    @Synchronized
    fun replaceTemplates(templates: List<GestureTemplate>) {
        val validTemplates = templates.filter { it.id.isNotBlank() && it.samples.any { sample -> sample.size >= 2 } }
        templatesSnapshot = validTemplates.map(::copyTemplate)
        preparedSnapshot = prepareTemplates(templatesSnapshot)
    }

    @Synchronized
    fun addTemplates(templates: List<GestureTemplate>) {
        replaceTemplates(templatesSnapshot + templates)
    }

    fun candidates(points: List<PointSample>): List<GestureCandidate> {
        val snapshot = preparedSnapshot
        if (points.size < 2 || snapshot.isEmpty()) return emptyList()

        val needsInvariant = snapshot.any { it.rotationInvariant }
        val needsSensitive = snapshot.any { !it.rotationInvariant }
        val invariantCandidate = if (needsInvariant) preprocessor.prepare(points, true) else null
        val sensitiveCandidate = if (needsSensitive) preprocessor.prepare(points, false) else null
        val halfDiagonal = 0.5f * sqrt(preprocessor.squareSize * preprocessor.squareSize * 2f)

        return snapshot.mapNotNull { template ->
            val candidate = if (template.rotationInvariant) invariantCandidate else sensitiveCandidate
            candidate ?: return@mapNotNull null

            var bestDistance = Float.POSITIVE_INFINITY
            var bestSampleIndex = -1
            for (sample in template.samples) {
                val distance = if (template.rotationInvariant) {
                    distanceAtBestAngle(candidate.points, sample.points)
                } else {
                    preprocessor.pathDistance(candidate.points, sample.points)
                }
                if (distance < bestDistance) {
                    bestDistance = distance
                    bestSampleIndex = sample.sampleIndex
                }
            }
            if (!bestDistance.isFinite()) return@mapNotNull null

            GestureCandidate(
                gestureId = template.id,
                displayName = template.displayName,
                confidence = (1f - bestDistance / halfDiagonal).coerceIn(0f, 1f),
                source = RecognitionSource.TEMPLATE,
                sampleIndex = bestSampleIndex,
            )
        }.sortedByDescending { it.confidence }
    }

    fun recognize(points: List<PointSample>): GestureMatch? =
        candidates(points).firstOrNull()?.let { candidate ->
            GestureMatch(
                gestureId = candidate.gestureId,
                confidence = candidate.confidence,
                source = RecognitionSource.TEMPLATE,
                displayName = candidate.displayName,
            )
        }

    /**
     * Returns likely collisions with [proposed]. Pass the edited gesture ID to
     * [excludeGestureId] so its previous recordings are not reported.
     */
    fun findConflicts(
        proposed: GestureTemplate,
        threshold: Float,
        excludeGestureId: String? = proposed.id,
    ): List<GestureConflict> {
        require(threshold in 0f..1f)
        val existing = preparedSnapshot.filter { it.id != excludeGestureId }
        if (existing.isEmpty()) return emptyList()

        val output = ArrayList<GestureConflict>()
        proposed.samples.forEachIndexed { proposedIndex, rawSample ->
            for (template in existing) {
                val candidate = preprocessor.prepare(rawSample, template.rotationInvariant) ?: continue
                for (existingSample in template.samples) {
                    val similarity = similarity(candidate, existingSample.points, template.rotationInvariant)
                    if (similarity >= threshold) {
                        output += GestureConflict(
                            existingGestureId = template.id,
                            existingDisplayName = template.displayName,
                            similarity = similarity,
                            proposedSampleIndex = proposedIndex,
                            existingSampleIndex = existingSample.sampleIndex,
                        )
                    }
                }
            }
        }
        return output.sortedByDescending { it.similarity }
    }

    fun similarity(
        first: List<PointSample>,
        second: List<PointSample>,
        rotationInvariant: Boolean,
    ): Float {
        val preparedFirst = preprocessor.prepare(first, rotationInvariant) ?: return 0f
        val preparedSecond = preprocessor.prepare(second, rotationInvariant) ?: return 0f
        return similarity(preparedFirst, preparedSecond.points, rotationInvariant)
    }

    private fun similarity(
        candidate: PreparedPath,
        template: List<Vec2>,
        rotationInvariant: Boolean,
    ): Float {
        val distance = if (rotationInvariant) {
            distanceAtBestAngle(candidate.points, template)
        } else {
            preprocessor.pathDistance(candidate.points, template)
        }
        val halfDiagonal = 0.5f * sqrt(preprocessor.squareSize * preprocessor.squareSize * 2f)
        return (1f - distance / halfDiagonal).coerceIn(0f, 1f)
    }

    private fun prepareTemplates(templates: List<GestureTemplate>): List<PreparedTemplate> {
        // Merge records that share an ID so callers may either use
        // additionalSamples or append several GestureTemplate instances.
        return templates.groupBy { it.id }.mapNotNull { (id, records) ->
            val exemplar = records.first()
            val samples = ArrayList<PreparedSample>()
            var sampleIndex = 0
            for (record in records) {
                for (rawSample in record.samples) {
                    val prepared = preprocessor.prepare(rawSample, exemplar.rotationInvariant)
                    if (prepared != null) {
                        samples += PreparedSample(prepared.points, sampleIndex)
                    }
                    sampleIndex++
                }
            }
            if (samples.isEmpty()) null else PreparedTemplate(
                id = id,
                displayName = exemplar.displayName,
                rotationInvariant = exemplar.rotationInvariant,
                samples = samples,
            )
        }
    }

    private fun copyTemplate(template: GestureTemplate): GestureTemplate = template.copy(
        points = template.points.toList(),
        additionalSamples = template.additionalSamples.map { it.toList() },
    )

    private fun distanceAtBestAngle(candidate: List<Vec2>, template: List<Vec2>): Float {
        val phi = 0.5f * (-1f + sqrt(5f))
        var lower = degreesToRadians(-45f)
        var upper = degreesToRadians(45f)
        val precision = degreesToRadians(2f)
        var firstAngle = phi * lower + (1f - phi) * upper
        var firstDistance = distanceAtAngle(candidate, template, firstAngle)
        var secondAngle = (1f - phi) * lower + phi * upper
        var secondDistance = distanceAtAngle(candidate, template, secondAngle)

        while (abs(upper - lower) > precision) {
            if (firstDistance < secondDistance) {
                upper = secondAngle
                secondAngle = firstAngle
                secondDistance = firstDistance
                firstAngle = phi * lower + (1f - phi) * upper
                firstDistance = distanceAtAngle(candidate, template, firstAngle)
            } else {
                lower = firstAngle
                firstAngle = secondAngle
                firstDistance = secondDistance
                secondAngle = (1f - phi) * lower + phi * upper
                secondDistance = distanceAtAngle(candidate, template, secondAngle)
            }
        }
        return min(firstDistance, secondDistance)
    }

    private fun distanceAtAngle(candidate: List<Vec2>, template: List<Vec2>, radians: Float): Float =
        preprocessor.pathDistance(preprocessor.rotateBy(candidate, radians), template)

    private fun degreesToRadians(degrees: Float): Float = (degrees * PI / 180.0).toFloat()
}
