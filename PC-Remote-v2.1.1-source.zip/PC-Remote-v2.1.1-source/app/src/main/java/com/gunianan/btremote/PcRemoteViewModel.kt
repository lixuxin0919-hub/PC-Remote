package com.gunianan.btremote

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.gunianan.btremote.action.ActionResult
import com.gunianan.btremote.action.ActionDisplayNameResolver
import com.gunianan.btremote.action.ControlEvent
import com.gunianan.btremote.action.FailureReason
import com.gunianan.btremote.action.LongPressCallbacks
import com.gunianan.btremote.action.LongPressRepeatController
import com.gunianan.btremote.action.OrderedLongPressDispatcher
import com.gunianan.btremote.action.PointerActionQueue
import com.gunianan.btremote.action.RemoteActionRouter
import com.gunianan.btremote.action.RemoteCommand
import com.gunianan.btremote.action.RemoteCommandExecutor
import com.gunianan.btremote.data.AppConfigRepository
import com.gunianan.btremote.data.ProfileIconStore
import com.gunianan.btremote.domain.AppConfig
import com.gunianan.btremote.domain.ControlAreaType
import com.gunianan.btremote.domain.ControlItem
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.GestureBinding
import com.gunianan.btremote.domain.GestureTemplate
import com.gunianan.btremote.domain.GestureType
import com.gunianan.btremote.domain.GlobalSettings
import com.gunianan.btremote.domain.Handedness
import com.gunianan.btremote.domain.InternalActionType
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.MouseCommand
import com.gunianan.btremote.domain.ProfileAppearance
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.domain.SYSTEM_DEFAULT_PROFILE_ID
import com.gunianan.btremote.domain.SYSTEM_TRACKPAD_PROFILE_ID
import com.gunianan.btremote.ui.navigation.AppTab
import com.gunianan.btremote.ui.control.GesturePanelState
import java.util.Collections
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

sealed interface PcRemoteUiEvent {
    data class Message(val text: String) : PcRemoteUiEvent
    data object HapticSuccess : PcRemoteUiEvent
    data object HapticFailure : PcRemoteUiEvent
    data object OpenQuickActions : PcRemoteUiEvent
    data object OpenKeyboard : PcRemoteUiEvent
}

/**
 * Process state owner for the four click-only pages and the editable control platform.
 * Bluetooth is injected through [attachCommandExecutor] so this layer remains transport-neutral.
 */
class PcRemoteViewModel(
    application: Application,
    private val savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {
    private val repository = AppConfigRepository.fromSharedPreferences(application)
    private val profileIconStore = ProfileIconStore(application)
    private val executorReference = AtomicReference<RemoteCommandExecutor?>()
    private val longPressController = LongPressRepeatController()
    private val inFlightActions = Collections.synchronizedSet(mutableSetOf<Job>())
    private val longPressActions = OrderedLongPressDispatcher(
        launchAction = ::launchAction,
        launchRelease = { block -> viewModelScope.launch { block() } },
    )

    private val _selectedTab = MutableStateFlow(
        savedStateHandle.get<String>(KEY_SELECTED_TAB)
            ?.let { persisted -> AppTab.entries.firstOrNull { it.name == persisted } }
            ?: AppTab.CONTROL,
    )
    val selectedTab: StateFlow<AppTab> = _selectedTab.asStateFlow()
    val config: StateFlow<AppConfig> = repository.config

    /**
     * Page-scoped projections keep unrelated configuration changes from invalidating the whole
     * Compose tree. The repository remains the single source of truth; these flows only narrow
     * the observation boundary for each screen.
     */
    val activeProfile: StateFlow<ControlProfile> = config
        .map(::activeProfileFrom)
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, activeProfileFrom(repository.current()))

    val globalSettings: StateFlow<GlobalSettings> = config
        .map { appConfig -> appConfig.globalSettings }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, repository.current().globalSettings)

    val profiles: StateFlow<List<ControlProfile>> = config
        .map { appConfig -> appConfig.profiles }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, repository.current().profiles)

    val startupProfileId: StateFlow<String> = config
        .map { appConfig -> appConfig.startupProfileId }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, repository.current().startupProfileId)

    val schemaVersion: StateFlow<Int> = config
        .map { appConfig -> appConfig.schemaVersion }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, repository.current().schemaVersion)

    val hapticEnabled: StateFlow<Boolean> = config
        .map { latest ->
            activeProfileFrom(latest).appearance?.hapticEnabled ?: latest.globalSettings.hapticEnabled
        }
        .distinctUntilChanged()
        .stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            activeProfileFrom(repository.current()).appearance?.hapticEnabled
                ?: repository.current().globalSettings.hapticEnabled,
        )

    private val _editorDraft = MutableStateFlow<ControlProfile?>(null)
    val editorDraft: StateFlow<ControlProfile?> = _editorDraft.asStateFlow()

    private val _gesturePanelState = MutableStateFlow<GesturePanelState>(GesturePanelState.Idle)
    val gesturePanelState: StateFlow<GesturePanelState> = _gesturePanelState.asStateFlow()
    private var gestureResultClearJob: Job? = null

    private val _profilePickerVisible = MutableStateFlow(false)
    val profilePickerVisible: StateFlow<Boolean> = _profilePickerVisible.asStateFlow()
    private val _profileIconCrop = MutableStateFlow<ProfileIconCropDraft?>(null)
    val profileIconCrop: StateFlow<ProfileIconCropDraft?> = _profileIconCrop.asStateFlow()

    private val _customGestureEditorProfileId = MutableStateFlow<String?>(null)
    val customGestureEditorProfileId: StateFlow<String?> = _customGestureEditorProfileId.asStateFlow()

    private val _events = MutableSharedFlow<PcRemoteUiEvent>(extraBufferCapacity = 24)
    val events: SharedFlow<PcRemoteUiEvent> = _events.asSharedFlow()

    private val router = RemoteActionRouter(RemoteCommandExecutor { command ->
        when (command) {
            is RemoteCommand.Internal -> executeInternal(command)
            else -> executorReference.get()?.execute(command) ?: ActionResult.Failure(
                reason = FailureReason.SESSION_CLOSED,
                message = "请先连接电脑",
            )
        }
    })
    @Volatile
    private var pointerActionQueue = createPointerActionQueue()

    init {
        repository.activateStartupProfile().let { initial ->
            initial.profiles.firstOrNull { it.id == initial.activeProfileId }
                ?.let(router::updateProfile)
        }
        viewModelScope.launch {
            config.collect { latest ->
                latest.profiles.firstOrNull { it.id == latest.activeProfileId }
                    ?.let(router::updateProfile)
            }
        }
        repository.recovery?.let { recovery ->
            _events.tryEmit(PcRemoteUiEvent.Message("配置已安全恢复：${recovery.reason}"))
        }
    }

    fun attachCommandExecutor(executor: RemoteCommandExecutor?) {
        executorReference.set(executor)
    }

    fun selectTab(tab: AppTab) {
        if (_selectedTab.value == tab) return
        cancelInFlightActions()
        longPressController.cancelForPageExit()
        clearGesturePanel()
        _selectedTab.value = tab
        savedStateHandle[KEY_SELECTED_TAB] = tab.name
    }

    fun activeProfile(): ControlProfile? = repository.current().let { current ->
        current.profiles.firstOrNull { it.id == current.activeProfileId }
    }

    fun selectProfile(profileId: String) = safely("无法切换控制模式") {
        cancelInFlightActions()
        longPressController.cancelForProfileSwitch()
        clearGesturePanel()
        val updated = repository.setActiveProfile(profileId)
        updated.profiles.firstOrNull { it.id == updated.activeProfileId }?.let(router::updateProfile)
        _profilePickerVisible.value = false
        _events.tryEmit(PcRemoteUiEvent.Message("已切换到 ${activeProfile()?.name.orEmpty()}"))
    }

    fun openProfilePicker() {
        _profilePickerVisible.value = true
    }

    fun closeProfilePicker() {
        _profilePickerVisible.value = false
    }

    fun createBlankProfile(name: String = "新控制模式"): ControlProfile? {
        var created: ControlProfile? = null
        safely("无法创建控制模式") {
            val now = System.currentTimeMillis()
            created = ControlProfile(
                id = "profile.${UUID.randomUUID()}",
                name = name.trim().takeIf(String::isNotEmpty) ?: "新控制模式",
                icon = "remote",
                controlAreaType = ControlAreaType.GESTURE,
                controls = emptyList(),
                gestureBindings = emptyList(),
                appearance = ProfileAppearance(),
                createdAt = now,
                updatedAt = now,
            )
            repository.upsertProfile(requireNotNull(created))
            repository.setActiveProfile(requireNotNull(created).id)
            _editorDraft.value = created
        }
        return created
    }

    fun copyProfile(profileId: String): ControlProfile? {
        var copy: ControlProfile? = null
        safely("无法复制控制模式") {
            copy = repository.copyProfile(profileId)
            _events.tryEmit(PcRemoteUiEvent.Message("已创建 ${copy?.name}"))
        }
        return copy
    }

    fun renameProfile(profileId: String, name: String) = safely("无法重命名") {
        val normalized = name.trim()
        require(normalized.isNotEmpty()) { "名称不能为空" }
        updateProfile(profileId) { it.copy(name = normalized, updatedAt = System.currentTimeMillis()) }
    }

    fun setProfileIcon(profileId: String, icon: String) = safely("无法更新图标") {
        val old = repository.current().profiles.firstOrNull { it.id == profileId }?.customIconPath
        updateProfile(profileId) { it.copy(icon = icon, customIconPath = null, customIconUpdatedAt = null, updatedAt = System.currentTimeMillis()) }
        profileIconStore.delete(old)
    }

    fun prepareProfileIcon(profileId: String, uri: Uri) = safely("无法读取图片") {
        require(repository.current().profiles.any { it.id == profileId }) { "控制模式不存在" }
        _profileIconCrop.value = ProfileIconCropDraft(profileId, profileIconStore.decode(uri))
    }

    fun saveProfileIconCrop(scale: Float, offsetX: Float, offsetY: Float) = safely("无法保存图标") {
        val draft = _profileIconCrop.value ?: return@safely
        val old = repository.current().profiles.firstOrNull { it.id == draft.profileId }?.customIconPath
        val path = profileIconStore.saveCropped(draft.profileId, draft.bitmap, scale, offsetX, offsetY)
        updateProfile(draft.profileId) { it.copy(customIconPath = path, customIconUpdatedAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()) }
        if (old != path) profileIconStore.delete(old)
        draft.bitmap.recycle()
        _profileIconCrop.value = null
    }

    fun cancelProfileIconCrop() { _profileIconCrop.value?.bitmap?.recycle(); _profileIconCrop.value = null }

    fun removeCustomProfileIcon(profileId: String) = safely("无法删除图标") {
        val old = repository.current().profiles.firstOrNull { it.id == profileId }?.customIconPath
        updateProfile(profileId) { it.copy(customIconPath = null, customIconUpdatedAt = null, updatedAt = System.currentTimeMillis()) }
        profileIconStore.delete(old)
    }

    fun deleteProfile(profileId: String) = safely("无法删除控制模式") {
        longPressController.cancelForProfileSwitch()
        repository.deleteProfile(profileId)
        if (_editorDraft.value?.id == profileId) _editorDraft.value = null
    }

    fun moveProfile(profileId: String, direction: Int) = safely("无法调整顺序") {
        if (direction == 0) return@safely
        repository.update { current ->
            val profiles = current.profiles.toMutableList()
            val from = profiles.indexOfFirst { it.id == profileId }
            if (from < 0) return@update current
            val to = (from + direction).coerceIn(0, profiles.lastIndex)
            if (from == to) return@update current
            val moved = profiles.removeAt(from)
            profiles.add(to, moved)
            current.copy(profiles = profiles)
        }
    }

    fun setStartupProfile(profileId: String) = safely("无法设置启动模式") {
        repository.setStartupProfile(profileId)
    }

    fun restoreSystemProfile() = safely("无法恢复系统模式") {
        longPressController.cancelForProfileSwitch()
        repository.restoreSystemProfile()
        _events.tryEmit(PcRemoteUiEvent.Message("默认视频模式已恢复"))
    }

    fun beginEditProfile(profileId: String) {
        if (profileId == SYSTEM_TRACKPAD_PROFILE_ID) {
            selectTab(AppTab.SETTINGS)
            _events.tryEmit(PcRemoteUiEvent.Message("触控板模式请在设置页自定义"))
            return
        }
        _editorDraft.value = repository.current().profiles.firstOrNull { it.id == profileId }
    }

    fun updateEditorDraft(profile: ControlProfile) {
        if (_editorDraft.value?.id != profile.id) return
        _editorDraft.value = profile
    }

    fun cancelEditor() {
        _customGestureEditorProfileId.value = null
        _editorDraft.value = null
    }

    fun openCustomGestureEditor(profileId: String) {
        if (_editorDraft.value?.id == profileId) {
            _customGestureEditorProfileId.value = profileId
        }
    }

    fun closeCustomGestureEditor() {
        _customGestureEditorProfileId.value = null
    }

    fun saveCustomGesture(template: GestureTemplate, binding: GestureBinding) {
        val draft = _editorDraft.value ?: return
        if (_customGestureEditorProfileId.value != draft.id) return
        val updated = draft.copy(
            customGestures = draft.customGestures.filterNot { it.id == template.id } + template,
            gestureBindings = draft.gestureBindings.filterNot { it.id == binding.id } + binding,
            updatedAt = System.currentTimeMillis(),
        )
        _editorDraft.value = updated
        _customGestureEditorProfileId.value = null
        _events.tryEmit(PcRemoteUiEvent.Message("自定义手势已加入模式，保存模式后生效"))
    }

    fun saveEditor() {
        val profile = _editorDraft.value ?: return
        saveEditor(profile)
    }

    fun saveEditor(profile: ControlProfile) = safely("无法保存控制模式") {
        val existing = repository.current().profiles.firstOrNull { it.id == profile.id }
        val protected = if (existing?.isSystemProfile == true) {
            profile.copy(
                isSystemProfile = true,
                isDefault = profile.id == SYSTEM_DEFAULT_PROFILE_ID,
            )
        } else {
            profile.copy(isSystemProfile = false, isDefault = false)
        }
        repository.upsertProfile(protected.copy(updatedAt = System.currentTimeMillis()))
        _editorDraft.value = null
        _events.tryEmit(PcRemoteUiEvent.Message("控制模式已保存"))
    }

    fun saveProfile(profile: ControlProfile) = safely("无法保存控制模式") {
        repository.upsertProfile(profile.copy(updatedAt = System.currentTimeMillis()))
    }

    fun exportProfile(profileId: String): String? = try {
        repository.exportProfile(profileId)
    } catch (error: RuntimeException) {
        _events.tryEmit(PcRemoteUiEvent.Message(error.message ?: "导出失败"))
        null
    }

    fun importProfile(rawJson: String): Boolean = try {
        val result = repository.importProfile(rawJson)
        val updated = repository.setActiveProfile(result.importedProfileId)
        updated.profiles.firstOrNull { it.id == updated.activeProfileId }?.let(router::updateProfile)
        _events.tryEmit(
            PcRemoteUiEvent.Message(
                if (result.idRemapped) "导入成功；冲突 ID 已安全重建" else "导入成功",
            ),
        )
        true
    } catch (error: RuntimeException) {
        _events.tryEmit(PcRemoteUiEvent.Message("导入失败：${error.message ?: "未知错误"}"))
        false
    }

    fun updateGlobalSettings(transform: (GlobalSettings) -> GlobalSettings) = safely("无法保存设置") {
        repository.update { current -> current.copy(globalSettings = transform(current.globalSettings)) }
    }

    fun setHandedness(handedness: Handedness) {
        updateGlobalSettings { it.copy(handedness = handedness) }
    }

    fun tapControl(controlId: String) {
        launchAction { publishActionResult(router.routeControl(controlId, ControlEvent.TAP)) }
    }

    fun dispatchAction(action: RemoteActionConfig, quiet: Boolean = false) {
        launchAction { publishActionResult(router.route(action), quiet) }
    }

    fun movePointer(deltaX: Int, deltaY: Int) {
        if (deltaX == 0 && deltaY == 0) return
        pointerActionQueue.offer(
            RemoteActionConfig.MouseAction(
                command = MouseCommand.MOVE,
                deltaX = deltaX,
                deltaY = deltaY,
            ),
        )
    }

    fun clickPointer(button: MouseButton) {
        pointerActionQueue.offer(RemoteActionConfig.MouseAction(MouseCommand.CLICK, button))
    }

    fun setPointerButton(button: MouseButton, pressed: Boolean) {
        pointerActionQueue.offer(
            RemoteActionConfig.MouseAction(
                command = if (pressed) MouseCommand.DOWN else MouseCommand.UP,
                button = button,
            ),
        )
    }

    fun scrollPointer(vertical: Int, horizontal: Int = 0) {
        if (vertical == 0 && horizontal == 0) return
        pointerActionQueue.offer(
            RemoteActionConfig.ScrollAction(
                horizontal = horizontal,
                vertical = vertical,
            ),
        )
    }

    fun doubleTapControl(controlId: String) {
        launchAction { publishActionResult(router.routeControl(controlId, ControlEvent.DOUBLE_TAP)) }
    }

    /** Starts one owner-scoped 500/100/30000 ms repeat session. */
    fun beginLongPress(controlId: String) {
        val control = activeProfile()?.controls?.firstOrNull { it.id == controlId } ?: return
        longPressController.start(
            ownerId = controlId,
            callbacks = LongPressCallbacks(
                onStart = {
                    longPressActions.start {
                        publishActionResult(router.route(control, ControlEvent.LONG_PRESS_START))
                    }
                },
                onRepeat = {
                    if (control.repeatAction != null) {
                        longPressActions.repeat {
                            publishActionResult(
                                router.route(control, ControlEvent.LONG_PRESS_REPEAT),
                                quiet = true,
                            )
                        }
                    }
                },
                onStop = {
                    if (control.repeatAction == null) {
                        longPressActions.stop {
                            publishActionResult(router.route(control, ControlEvent.LONG_PRESS_END), quiet = true)
                        }
                    } else {
                        longPressActions.finishRepeating()
                    }
                },
            ),
        )
    }

    /** A release before 500 ms remains an ordinary tap. */
    fun endLongPress(controlId: String, invokeTapWhenShort: Boolean = true): Boolean {
        val activated = longPressController.isActivated
        val owned = longPressController.release(controlId)
        if (owned && !activated && invokeTapWhenShort) tapControl(controlId)
        return owned && activated
    }

    fun cancelForDisconnect() {
        cancelInFlightActions()
        longPressController.cancelForDisconnect()
    }

    fun cancelForBackground() {
        cancelInFlightActions()
        longPressController.cancelForBackground()
    }

    fun cancelTrackpadInput() {
        cancelInFlightActions()
        longPressController.cancelForPageExit()
    }

    fun dispatchGesture(
        gestureType: GestureType,
        confidence: Float,
        customGestureId: String? = null,
        label: String = gestureType.displayName(),
    ) {
        val binding = activeProfile()?.gestureBindings?.firstOrNull {
            it.enabled && it.gestureType == gestureType &&
                (gestureType != GestureType.CUSTOM || it.customGestureId == customGestureId)
        }
        if (binding == null) {
            clearGesturePanel()
            _events.tryEmit(PcRemoteUiEvent.HapticFailure)
            return
        }
        launchAction {
            val result = router.route(binding, confidence)
            val success = result.isSuccessful
            _events.emit(if (success) PcRemoteUiEvent.HapticSuccess else PcRemoteUiEvent.HapticFailure)
            if (success) {
                showGestureResult(ActionDisplayNameResolver.resolve(binding.action))
            } else {
                clearGesturePanel()
                publishActionResult(result, quiet = false)
            }
        }
    }

    fun reportGestureFailure(reason: String, confidence: Float = 0f) {
        clearGesturePanel()
        _events.tryEmit(PcRemoteUiEvent.HapticFailure)
    }

    fun clearGesturePanel() {
        gestureResultClearJob?.cancel()
        gestureResultClearJob = null
        _gesturePanelState.value = GesturePanelState.Idle
    }

    override fun onCleared() {
        cancelInFlightActions(resetPointerQueue = false)
        pointerActionQueue.close()
        longPressController.close()
        clearGesturePanel()
        _customGestureEditorProfileId.value = null
        executorReference.set(null)
        repository.close()
        super.onCleared()
    }

    private fun activeProfileFrom(config: AppConfig): ControlProfile =
        config.profiles.firstOrNull { it.id == config.activeProfileId } ?: config.profiles.first()

    private fun updateProfile(profileId: String, transform: (ControlProfile) -> ControlProfile) {
        val existing = repository.current().profiles.firstOrNull { it.id == profileId }
            ?: throw IllegalArgumentException("控制模式不存在")
        repository.upsertProfile(transform(existing))
    }

    private fun showGestureResult(actionName: String) {
        gestureResultClearJob?.cancel()
        _gesturePanelState.value = GesturePanelState.Result(actionName)
        gestureResultClearJob = viewModelScope.launch {
            delay(GESTURE_RESULT_DURATION_MS)
            _gesturePanelState.value = GesturePanelState.Idle
        }
    }

    private suspend fun executeInternal(command: RemoteCommand.Internal): ActionResult {
        val action = runCatching { InternalActionType.valueOf(command.actionId) }.getOrNull()
            ?: return ActionResult.Failure(FailureReason.INVALID_ACTION, "未知应用内动作")
        return try {
            when (action) {
                InternalActionType.OPEN_PROFILE_PICKER -> openProfilePicker()
                InternalActionType.OPEN_KEYBOARD -> _events.emit(PcRemoteUiEvent.OpenKeyboard)
                InternalActionType.OPEN_QUICK_ACTIONS -> _events.emit(PcRemoteUiEvent.OpenQuickActions)
                InternalActionType.TOGGLE_CONTROL_AREA_TYPE -> {
                    val profile = activeProfile() ?: error("没有当前控制模式")
                    val next = when (profile.controlAreaType) {
                        ControlAreaType.GESTURE -> ControlAreaType.TOUCHPAD
                        ControlAreaType.TOUCHPAD -> ControlAreaType.HYBRID
                        ControlAreaType.HYBRID -> ControlAreaType.GESTURE
                    }
                    repository.upsertProfile(profile.copy(controlAreaType = next))
                }
                InternalActionType.SWITCH_PROFILE -> selectProfile(
                    command.targetProfileId ?: error("未指定目标模式"),
                )
                InternalActionType.OPEN_SETTINGS -> selectTab(AppTab.SETTINGS)
            }
            ActionResult.Success()
        } catch (error: RuntimeException) {
            ActionResult.Failure(
                FailureReason.INVALID_ACTION,
                error.message ?: "应用内动作失败",
                error,
            )
        }
    }

    private suspend fun publishActionResult(result: ActionResult, quiet: Boolean = false) {
        when (result) {
            is ActionResult.Success -> if (!quiet) _events.emit(PcRemoteUiEvent.HapticSuccess)
            is ActionResult.Failure -> {
                if (!quiet) {
                    _events.emit(PcRemoteUiEvent.HapticFailure)
                    _events.emit(PcRemoteUiEvent.Message(result.message))
                }
            }
            is ActionResult.Ignored -> if (!quiet) {
                _events.emit(PcRemoteUiEvent.Message(result.message ?: "当前动作未执行"))
            }
        }
    }

    private fun launchAction(block: suspend () -> Unit): Job {
        lateinit var job: Job
        job = viewModelScope.launch(start = CoroutineStart.LAZY) { block() }
        inFlightActions += job
        job.invokeOnCompletion { inFlightActions -= job }
        job.start()
        return job
    }

    private fun cancelInFlightActions(resetPointerQueue: Boolean = true) {
        val snapshot = synchronized(inFlightActions) { inFlightActions.toList() }
        snapshot.forEach(Job::cancel)
        if (resetPointerQueue) {
            val previous = pointerActionQueue
            pointerActionQueue = createPointerActionQueue()
            previous.cancel()
        }
    }

    private fun createPointerActionQueue() = PointerActionQueue(
        scope = viewModelScope,
        onExecutionError = { error ->
            _events.tryEmit(PcRemoteUiEvent.Message(error.message ?: "触控指令执行失败"))
        },
    ) { action ->
        publishActionResult(router.route(action), quiet = true)
    }

    private inline fun safely(prefix: String, block: () -> Unit) {
        try {
            block()
        } catch (error: RuntimeException) {
            _events.tryEmit(PcRemoteUiEvent.Message("$prefix：${error.message ?: "未知错误"}"))
        }
    }

    private fun GestureType.displayName(): String = when (this) {
        GestureType.SWIPE_UP -> "上滑"
        GestureType.SWIPE_DOWN -> "下滑"
        GestureType.SWIPE_LEFT -> "左滑"
        GestureType.SWIPE_RIGHT -> "右滑"
        GestureType.TAP -> "轻点"
        GestureType.DOUBLE_TAP -> "双击"
        GestureType.LONG_PRESS -> "长按"
        GestureType.CIRCLE -> "圆圈"
        GestureType.X -> "X"
        GestureType.Z -> "Z"
        GestureType.CHECK -> "勾"
        GestureType.CUSTOM -> "自定义手势"
        GestureType.TOUCHPAD_TAP -> "触控板轻点"
        GestureType.TOUCHPAD_DOUBLE_TAP -> "触控板双击"
        GestureType.TOUCHPAD_LONG_PRESS_DRAG -> "长按拖动"
        GestureType.TOUCHPAD_TWO_FINGER_SCROLL -> "双指滚动"
        GestureType.TOUCHPAD_TWO_FINGER_TAP -> "双指右键"
    }

    companion object {
        private const val GESTURE_RESULT_DURATION_MS = 1_000L
        private const val KEY_SELECTED_TAB = "selected_tab"
    }
}

data class ProfileIconCropDraft(val profileId: String, val bitmap: Bitmap)
