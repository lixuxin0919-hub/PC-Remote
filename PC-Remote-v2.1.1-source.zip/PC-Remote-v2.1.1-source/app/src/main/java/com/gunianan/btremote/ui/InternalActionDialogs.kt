package com.gunianan.btremote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.gunianan.btremote.domain.ControlItem
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.GlassPill
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography

internal enum class InternalActionPanel {
    KEYBOARD,
    QUICK_ACTIONS,
}

private data class HidKey(
    val label: String,
    val keyCode: Int,
)

private val KeyboardRows = listOf(
    listOf(HidKey("Esc", 0x29), HidKey("Tab", 0x2B), HidKey("退格", 0x2A)),
    listOf(HidKey("Home", 0x4A), HidKey("↑", 0x52), HidKey("PageUp", 0x4B)),
    listOf(HidKey("←", 0x50), HidKey("↓", 0x51), HidKey("→", 0x4F)),
    listOf(HidKey("End", 0x4D), HidKey("空格", 0x2C), HidKey("PageDown", 0x4E)),
    listOf(HidKey("Insert", 0x49), HidKey("Delete", 0x4C), HidKey("回车", 0x28)),
)

@Composable
internal fun HidKeyboardPanel(
    onKeyClick: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    InternalActionDialogFrame(
        title = "HID 键盘",
        subtitle = "按键会直接发送到已连接的电脑",
        onDismiss = onDismiss,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false),
            contentPadding = PaddingValues(bottom = 2.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(KeyboardRows) { rowKeys ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    rowKeys.forEach { key ->
                        KeyboardKey(
                            key = key,
                            onClick = { onKeyClick(key.keyCode) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun QuickActionsPanel(
    profile: ControlProfile,
    onControlClick: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val visibleControls = remember(profile.controls) {
        profile.controls.filter(ControlItem::visible).sortedBy(ControlItem::position)
    }
    InternalActionDialogFrame(
        title = "快捷控件",
        subtitle = profile.name,
        onDismiss = onDismiss,
    ) {
        if (visibleControls.isEmpty()) {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 22.dp,
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 22.dp),
            ) {
                Text(
                    text = "当前模式没有可见控件",
                    style = PcRemoteTypography.SectionTitle,
                )
                Spacer(Modifier.size(4.dp))
                Text(
                    text = "可在“自定义”中添加控件或打开已有控件。",
                    style = PcRemoteTypography.Caption,
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
                contentPadding = PaddingValues(bottom = 2.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(
                    items = visibleControls,
                    key = ControlItem::id,
                ) { control ->
                    GlassActionButton(
                        text = control.title,
                        onClick = { onControlClick(control.id) },
                        modifier = Modifier.fillMaxWidth(),
                        primary = control == visibleControls.first(),
                    )
                }
            }
        }
    }
}

@Composable
private fun InternalActionDialogFrame(
    title: String,
    subtitle: String,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        Box(Modifier.fillMaxSize()) {
            val dismissInteraction = remember { MutableInteractionSource() }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.20f))
                    .clickable(
                        interactionSource = dismissInteraction,
                        indication = null,
                        role = Role.Button,
                        onClick = onDismiss,
                    ),
            )
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 620.dp)
                        .heightIn(max = maxHeight),
                    cornerRadius = 30.dp,
                    contentPadding = PaddingValues(18.dp),
                    strong = true,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(text = title, style = PcRemoteTypography.SectionTitle)
                            Text(
                                text = subtitle,
                                style = PcRemoteTypography.Caption,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Spacer(Modifier.size(12.dp))
                        GlassPill(onClick = onDismiss) {
                            Text(
                                text = "关闭",
                                color = PcRemoteColors.PrimaryDeep,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                    Spacer(Modifier.size(16.dp))
                    content()
                }
            }
        }
    }
}

@Composable
private fun KeyboardKey(
    key: HidKey,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(18.dp)
    GlassCard(
        modifier = modifier
            .clip(shape)
            .clickable(role = Role.Button, onClick = onClick),
        cornerRadius = 18.dp,
        contentPadding = PaddingValues(0.dp),
        strong = true,
        shadowElevation = 4.dp,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .padding(horizontal = 6.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = key.label,
                style = PcRemoteTypography.Body,
                color = PcRemoteColors.Text,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
