package com.gunianan.btremote.ui.control.surface

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

internal fun Modifier.controlSurfaceFrame(
    colors: ControlSurfaceColors,
    cornerRadius: Dp,
): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return clip(shape)
        .background(colors.container)
        .border(1.dp, colors.border, shape)
}

@Composable
internal fun SurfaceGrid(
    colors: ControlSurfaceColors,
    modifier: Modifier = Modifier,
    path: Path? = null,
    pathVersion: Int = 0,
    referencePaths: List<Path> = emptyList(),
    touchPoints: List<Offset> = emptyList(),
    enabled: Boolean = true,
) {
    // Reading pathVersion is intentional: Path is mutable and this state value
    // invalidates only the draw layer when another sampled point is appended.
    @Suppress("UNUSED_VARIABLE")
    val redrawToken = pathVersion
    Canvas(modifier.fillMaxSize()) {
        val gridStep = 28.dp.toPx()
        var x = gridStep
        while (x < size.width) {
            drawLine(colors.grid, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
            x += gridStep
        }
        var y = gridStep
        while (y < size.height) {
            drawLine(colors.grid, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            y += gridStep
        }

        referencePaths.forEachIndexed { index, referencePath ->
            drawPath(
                path = referencePath,
                color = colors.trace.copy(alpha = 0.18f + index.coerceAtMost(2) * 0.07f),
                style = Stroke(width = 3.dp.toPx()),
            )
        }

        if (path != null) {
            drawPath(
                path = path,
                color = colors.trace,
                style = Stroke(width = 4.dp.toPx()),
            )
        }
        for (point in touchPoints) {
            drawCircle(
                color = colors.touchIndicator,
                radius = 18.dp.toPx(),
                center = point,
            )
            drawCircle(
                color = colors.trace.copy(alpha = 0.72f),
                radius = 4.dp.toPx(),
                center = point,
            )
        }
        if (!enabled) {
            drawRect(colors.disabledOverlay, size = Size(size.width, size.height))
        }
    }
}

@Composable
internal fun SurfaceContent(
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
        content = content,
    )
}
