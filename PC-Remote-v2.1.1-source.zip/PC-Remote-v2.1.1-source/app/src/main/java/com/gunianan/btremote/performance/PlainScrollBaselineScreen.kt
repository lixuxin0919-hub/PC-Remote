package com.gunianan.btremote.performance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Featureless benchmark content; reachable only with the debug Intent extra. */
@Composable
fun PlainScrollBaselineScreen() {
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFFF6F8FC))) {
        items((1..50).toList(), key = { it }) { index ->
            Text(
                text = "Baseline row $index",
                color = Color(0xFF172033),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp),
            )
        }
    }
}
