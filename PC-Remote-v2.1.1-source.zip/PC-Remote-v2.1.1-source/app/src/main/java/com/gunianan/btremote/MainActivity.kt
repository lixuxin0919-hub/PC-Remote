package com.gunianan.btremote

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.gunianan.btremote.action.KeyReleaseReason
import com.gunianan.btremote.bluetooth.BluetoothHidController
import com.gunianan.btremote.bluetooth.BluetoothHidHostCallbacks
import com.gunianan.btremote.locale.AppLanguage
import com.gunianan.btremote.locale.AppLocaleManager
import com.gunianan.btremote.performance.PerformanceIsolation
import com.gunianan.btremote.performance.PerformanceJankReporter
import com.gunianan.btremote.ui.PcRemoteApp
import com.gunianan.btremote.ui.PcRemoteHostActions
import com.gunianan.btremote.ui.localized.UiTextTranslator
import java.util.Locale
import kotlinx.coroutines.launch

/** Host-only activity: platform intents and Bluetooth permission UI stay outside Compose state. */
class MainActivity : ComponentActivity(), BluetoothHidHostCallbacks {
    private val viewModel: PcRemoteViewModel by viewModels()
    private lateinit var bluetoothController: BluetoothHidController
    private var promptPermissionsOnNextStart = true
    private var pendingExport: PendingExport? = null
    private var pendingIconProfileId: String? = null
    private val photoPicker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val id = pendingIconProfileId.also { pendingIconProfileId = null } ?: return@registerForActivityResult
        if (uri != null) viewModel.prepareProfileIcon(id, uri)
    }
    private val iconFilePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val id = pendingIconProfileId.also { pendingIconProfileId = null } ?: return@registerForActivityResult
        if (uri != null) viewModel.prepareProfileIcon(id, uri)
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppLocaleManager.wrapContext(newBase))
    }

    private val connectPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> bluetoothController.onBluetoothConnectPermissionResult(granted) }

    private val advertisePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> bluetoothController.onBluetoothAdvertisePermissionResult(granted) }

    private val enableBluetoothLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        val enabled = result.resultCode == Activity.RESULT_OK || runCatching {
            getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        }.getOrDefault(false)
        bluetoothController.onBluetoothEnableResult(enabled)
    }

    private val discoverableLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result -> bluetoothController.onDiscoverabilityResult(result.resultCode > 0) }

    private val exportDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        val export = pendingExport
        pendingExport = null
        if (uri == null || export == null) return@registerForActivityResult
        runCatching {
            contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                writer.write(export.json)
            } ?: error("无法打开导出文件")
        }.onSuccess {
            showMessage("“${export.profileName}”已导出")
        }.onFailure { error ->
            showMessage("导出失败：${error.message ?: "无法写入文件"}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        promptPermissionsOnNextStart = savedInstanceState == null
        configureEdgeToEdge()
        PerformanceIsolation.updateFromIntent(intent)
        PerformanceJankReporter.start(window)

        bluetoothController = BluetoothHidController(this, this)
        viewModel.attachCommandExecutor(bluetoothController.remoteCommandExecutor)

        setContent {
            PcRemoteApp(
                viewModel = viewModel,
                hidState = bluetoothController.uiState,
                pairedDevices = bluetoothController.pairedDevices,
                hostActions = PcRemoteHostActions(
                    onPairing = bluetoothController::enterPairingMode,
                    onOpenSystemBluetooth = ::openSystemBluetooth,
                    onRefreshDevices = bluetoothController::refresh,
                    onRepairHid = bluetoothController::repair,
                    onConnectDevice = bluetoothController::connect,
                    onDisconnectDevice = bluetoothController::disconnect,
                    onExportProfile = ::exportProfile,
                    onOpenDeveloperEmail = ::openDeveloperEmail,
                    onKeepScreenOnChanged = ::setKeepScreenOn,
                    onAutoConnectChanged = bluetoothController::setAutoConnectEnabled,
                    onLanguageChanged = ::changeLanguage,
                    onReleaseAllKeys = { reason ->
                        lifecycleScope.launch { bluetoothController.releaseAllKeys(reason) }
                    },
                    onPickProfileIconPhoto = { id -> pendingIconProfileId = id; photoPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onPickProfileIconFile = { id -> pendingIconProfileId = id; iconFilePicker.launch(arrayOf("image/png", "image/jpeg", "image/webp")) },
                ),
            )
        }
    }

    override fun onStart() {
        super.onStart()
        bluetoothController.onStart(promptPermissionsOnNextStart)
        promptPermissionsOnNextStart = false
    }

    override fun onResume() {
        super.onResume()
        PerformanceJankReporter.resume()
        bluetoothController.onResume()
    }

    override fun onPause() {
        PerformanceJankReporter.pause()
        viewModel.cancelForBackground()
        bluetoothController.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        PerformanceJankReporter.stop()
        viewModel.attachCommandExecutor(null)
        bluetoothController.onDestroy()
        super.onDestroy()
    }

    override fun requestBluetoothConnectPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            bluetoothController.onBluetoothConnectPermissionResult(true)
            return
        }
        connectPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
    }

    override fun requestBluetoothAdvertisePermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            bluetoothController.onBluetoothAdvertisePermissionResult(true)
            return
        }
        advertisePermissionLauncher.launch(Manifest.permission.BLUETOOTH_ADVERTISE)
    }

    override fun requestBluetoothEnable() {
        enableBluetoothLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
    }

    override fun requestDiscoverability(durationSeconds: Int) {
        discoverableLauncher.launch(
            Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
                putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, durationSeconds.coerceIn(1, 300))
            },
        )
    }

    override fun showMessage(message: String) {
        val language = resources.configuration.locales[0].language
        runOnUiThread {
            Toast.makeText(this, UiTextTranslator.translate(message, language), Toast.LENGTH_SHORT).show()
        }
    }

    private fun configureEdgeToEdge() {
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        PerformanceIsolation.updateFromIntent(intent)
    }

    private fun openSystemBluetooth() {
        runCatching { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            .onFailure { showMessage("无法打开系统蓝牙设置") }
    }

    private fun openDeveloperEmail() {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:lixuxin0919@gmail.com")
            putExtra(Intent.EXTRA_SUBJECT, "PC遥控器反馈")
        }
        runCatching { startActivity(intent) }
            .onFailure { showMessage("开发者邮箱：lixuxin0919@gmail.com") }
    }

    private fun exportProfile(profileName: String, json: String) {
        pendingExport = PendingExport(profileName, json)
        val safeName = profileName
            .lowercase(Locale.getDefault())
            .replace(Regex("[^a-z0-9\\u4e00-\\u9fa5._-]+"), "-")
            .trim('-')
            .ifBlank { "pc-remote-profile" }
        exportDocumentLauncher.launch("$safeName.json")
    }

    private fun setKeepScreenOn(enabled: Boolean) {
        if (enabled) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun changeLanguage(language: AppLanguage) {
        if (AppLocaleManager.selectedLanguage(this) == language) return
        lifecycleScope.launch {
            viewModel.cancelForBackground()
            bluetoothController.releaseAllKeys(KeyReleaseReason.EXPLICIT)
            AppLocaleManager.setApplicationLanguage(this@MainActivity, language)
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) recreate()
        }
    }

    private data class PendingExport(val profileName: String, val json: String)
}
