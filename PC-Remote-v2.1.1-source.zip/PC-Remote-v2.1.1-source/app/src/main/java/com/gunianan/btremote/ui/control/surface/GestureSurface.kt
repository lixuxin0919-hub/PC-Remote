package com.gunianan.btremote.ui.control.surface

import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.gunianan.btremote.gesture.PointSample
import kotlinx.coroutines.CancellationException
import kotlin.math.hypot

/**
 * Captures and renders one raw stroke without assigning it an action.
 *
 * The caller owns tap/double-tap/long-press, directional, shape and custom
 * recognition by passing [onStrokeComplete] to [com.gunianan.btremote.gesture.GestureEngine].
 * A second pointer cancels the current stroke instead of producing an ambiguous
 * sample. There is no navigation or HID behavior in this component.
 */
@Composable
fun GestureSurface(
    onStrokeComplete: (List<PointSample>) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    config: GestureSurfaceConfig = GestureSurfaceConfig(),
    colors: ControlSurfaceColors = ControlSurfaceDefaults.colors(),
    cornerRadius: Dp = 28.dp,
    contentDescription: String = "手势控制区",
    referenceStrokes: List<List<PointSample>> = emptyList(),
    retainCompletedStroke: Boolean = true,
    showTrail: Boolean = true,
    onStrokeStarted: () -> Unit = {},
    onStrokeCancelled: () -> Unit = {},
    content: @Composable BoxScope.() -> Unit = {},
) {
    val currentOnComplete by rememberUpdatedState(onStrokeComplete)
    val currentOnCancelled by rememberUpdatedState(onStrokeCancelled)
    val currentOnStarted by rememberUpdatedState(onStrokeStarted)
    val path = remember { Path() }
    val referencePaths = remember(referenceStrokes) {
        referenceStrokes.mapNotNull { stroke ->
            val first = stroke.firstOrNull() ?: return@mapNotNull null
            Path().apply {
                moveTo(first.x, first.y)
                stroke.drop(1).forEach { point -> lineTo(point.x, point.y) }
            }
        }
    }
    var pathVersion by remember { mutableIntStateOf(0) }
    var activePoint by remember { mutableStateOf<Offset?>(null) }

    fun clearPath() {
        path.reset()
        activePoint = null
        pathVersion++
    }

    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 220.dp)
            .controlSurfaceFrame(colors, cornerRadius)
            .semantics {
                this.contentDescription = contentDescription
                if (!enabled) disabled()
            }
            .pointerInput(enabled, config, retainCompletedStroke, showTrail) {
                if (!enabled) {
                    clearPath()
                    return@pointerInput
                }

                val minimumDistancePx = config.minimumSampleDistance.toPx()
                while (true) {
                    var strokeActive = false
                    try {
                        awaitPointerEventScope {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            down.consume()
                            currentOnStarted()
                            strokeActive = true
                            val trackedPointer = down.id
                            val points = ArrayList<PointSample>(128)
                            if (showTrail) {
                                path.reset()
                                path.moveTo(down.position.x, down.position.y)
                            }
                            points += down.toPointSample()
                            if (showTrail) {
                                activePoint = down.position
                                pathVersion++
                            }

                            var lastSamplePosition = down.position
                            var lastSampleTime = down.uptimeMillis
                            var cancelled = false

                            while (true) {
                                val event = awaitPointerEvent()
                                val pressedCount = event.changes.count { it.pressed }
                                if (pressedCount > 1) {
                                    event.changes.forEach(PointerInputChange::consume)
                                    cancelled = true
                                    drainPointers()
                                    break
                                }

                                val tracked = event.changes.firstOrNull { it.id == trackedPointer }
                                if (tracked == null) {
                                    cancelled = true
                                    break
                                }
                                tracked.consume()

                                if (!tracked.pressed) {
                                    appendFinalPoint(points, tracked, config.maximumPointCount)
                                    if (showTrail && tracked.position != lastSamplePosition) {
                                        path.lineTo(tracked.position.x, tracked.position.y)
                                    }
                                    if (showTrail) {
                                        activePoint = null
                                        pathVersion++
                                    }
                                    break
                                }

                                val distance = distance(lastSamplePosition, tracked.position)
                                val elapsed = tracked.uptimeMillis - lastSampleTime
                                if (distance >= minimumDistancePx || elapsed >= config.maximumSampleIntervalMs) {
                                    appendSample(points, tracked, config.maximumPointCount)
                                    if (showTrail) path.lineTo(tracked.position.x, tracked.position.y)
                                    lastSamplePosition = tracked.position
                                    lastSampleTime = tracked.uptimeMillis
                                    if (showTrail) {
                                        activePoint = tracked.position
                                        pathVersion++
                                    }
                                }
                            }

                            strokeActive = false
                            if (cancelled) {
                                clearPath()
                                currentOnCancelled()
                            } else {
                                // Copy at the boundary so the pointer loop can reuse its buffer.
                                currentOnComplete(points.toList())
                                if (!retainCompletedStroke) clearPath()
                            }
                        }
                    } catch (cancelled: CancellationException) {
                        if (strokeActive) currentOnCancelled()
                        clearPath()
                        throw cancelled
                    } catch (_: Throwable) {
                        // Pointer streams can be cancelled by the platform. Do not turn a
                        // partial stroke into an action, but keep the recognizer loop alive.
                        if (strokeActive) currentOnCancelled()
                        clearPath()
                    }
                }
            },
    ) {
        SurfaceGrid(
            colors = colors.copy(grid = Color.Transparent, touchIndicator = Color.Transparent),
            path = path.takeIf { showTrail },
            pathVersion = pathVersion,
            enabled = enabled,
        )
        SurfaceContent(content)
    }
}

private fun PointerInputChange.toPointSample() = PointSample(
    x = position.x,
    y = position.y,
    timeMillis = uptimeMillis,
)

private fun appendSample(
    points: ArrayList<PointSample>,
    change: PointerInputChange,
    maximumPointCount: Int,
) {
    val sample = change.toPointSample()
    if (points.size < maximumPointCount) {
        points += sample
    } else {
        // Retain a bounded allocation while keeping the most recent endpoint.
        points[points.lastIndex] = sample
    }
}

private fun appendFinalPoint(
    points: ArrayList<PointSample>,
    change: PointerInputChange,
    maximumPointCount: Int,
) {
    val final = change.toPointSample()
    val previous = points.lastOrNull()
    if (previous == null || previous.x != final.x || previous.y != final.y || previous.timeMillis != final.timeMillis) {
        appendSample(points, change, maximumPointCount)
    }
}

private fun distance(first: Offset, second: Offset): Float =
    hypot(second.x - first.x, second.y - first.y)

private suspend fun androidx.compose.ui.input.pointer.AwaitPointerEventScope.drainPointers() {
    while (true) {
        val event = awaitPointerEvent()
        event.changes.forEach(PointerInputChange::consume)
        if (event.changes.none { it.pressed }) return
    }
}
