package com.gunianan.btremote.action

import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.Job

/**
 * Orders asynchronous long-press work across the scheduler and UI threads.
 *
 * A release always waits for its matching start job, and a new press waits for the previous
 * release barrier. Repeat callbacks are conflated to one in-flight operation so a slow HID
 * transport cannot build a 10 Hz backlog.
 */
class OrderedLongPressDispatcher(
    private val launchAction: (suspend () -> Unit) -> Job,
    private val launchRelease: (suspend () -> Unit) -> Job,
) {
    private val startJob = AtomicReference<Job?>()
    private val repeatJob = AtomicReference<Job?>()
    private val releaseBarrier = AtomicReference<Job?>()
    private val repeatLock = Any()

    fun start(block: suspend () -> Unit): Job {
        val previousRelease = releaseBarrier.get()
        val job = launchAction {
            previousRelease?.join()
            block()
        }
        startJob.getAndSet(job)?.cancel()
        return job
    }

    /** Returns false when one repeat is already waiting or executing. */
    fun repeat(block: suspend () -> Unit): Boolean = synchronized(repeatLock) {
        if (repeatJob.get()?.isActive == true) return@synchronized false
        val matchingStart = startJob.get()
        val job = launchAction {
            matchingStart?.join()
            block()
        }
        repeatJob.set(job)
        job.invokeOnCompletion { repeatJob.compareAndSet(job, null) }
        true
    }

    fun stop(block: suspend () -> Unit): Job {
        val matchingStart = startJob.getAndSet(null)
        val job = launchRelease {
            matchingStart?.join()
            block()
        }
        releaseBarrier.set(job)
        return job
    }

    /** Creates a barrier after the last periodic tap; repeating taps do not need a key-up. */
    fun finishRepeating(): Job {
        val matchingStart = startJob.getAndSet(null)
        val matchingRepeat = repeatJob.getAndSet(null)
        val job = launchRelease {
            matchingStart?.join()
            matchingRepeat?.join()
        }
        releaseBarrier.set(job)
        return job
    }
}
