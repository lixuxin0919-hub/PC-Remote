package com.gunianan.btremote.action

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex

/** Immutable identity used to deduplicate key-down events and build matching key-up events. */
sealed interface HidKey {
    fun asCommand(phase: KeyPhase): RemoteCommand

    data class Keyboard(
        val keyCode: Int,
        val modifierMask: Int = 0,
    ) : HidKey {
        init {
            require(keyCode in 0..0xff) { "keyCode must fit in one HID byte" }
            require(modifierMask in 0..0xff) { "modifierMask must fit in one HID byte" }
        }

        override fun asCommand(phase: KeyPhase): RemoteCommand =
            RemoteCommand.Keyboard(keyCode, modifierMask, phase)
    }

    data class Consumer(val usageId: Int) : HidKey {
        init {
            require(usageId > 0) { "usageId must be positive" }
        }

        override fun asCommand(phase: KeyPhase): RemoteCommand =
            RemoteCommand.Consumer(usageId, phase)
    }

    data class MouseButton(val button: MouseButtonId) : HidKey {
        override fun asCommand(phase: KeyPhase): RemoteCommand =
            RemoteCommand.MouseButton(button, phase)
    }
}

/**
 * The transport instance is captured by a session. It must never consult a mutable
 * "current device" because a delayed release belongs to the transport that received down.
 */
fun interface HidKeyTransport {
    suspend fun send(sessionId: String, command: RemoteCommand): ActionResult
}

enum class KeyReleaseReason {
    EXPLICIT,
    PAGE_EXIT,
    PROFILE_SWITCH,
    DISCONNECTED,
    APP_BACKGROUND,
    TIMEOUT,
    SESSION_REPLACED,
    MANAGER_CLOSED,
}

data class ReleaseAllResult(
    val attempted: Int,
    val released: Int,
    val failures: List<ActionResult.Failure>,
) {
    val allReleased: Boolean = attempted == released
}

/**
 * Serializes HID key state for one active immutable transport session.
 *
 * Key-up and release-all bypass rate limiting. A failed key-up remains tracked so a
 * subsequent lifecycle release can retry it instead of silently losing state.
 */
class HidKeyStateManager(
    private val clock: MonotonicClock = MonotonicClock { System.nanoTime() / 1_000_000L },
    private val minimumDownIntervalMillis: Long = 20L,
) {
    init {
        require(minimumDownIntervalMillis >= 0L) {
            "minimumDownIntervalMillis must not be negative"
        }
    }

    internal class SessionState(
        val publicId: String,
        val generation: Long,
        val transport: HidKeyTransport,
    ) {
        val pressedKeys = linkedSetOf<HidKey>()
        var lastDownAtMillis: Long? = null
        var valid: Boolean = true
    }

    inner class Session internal constructor(private val state: SessionState) {
        val id: String get() = state.publicId

        suspend fun keyDown(key: HidKey): ActionResult = withLock {
            keyDownLocked(state, key)
        }

        suspend fun keyUp(key: HidKey): ActionResult = withLock {
            keyUpLocked(state, key)
        }

        /** Sends a matching up even when the down-to-up interval is below the rate limit. */
        suspend fun tap(key: HidKey): ActionResult = withLock {
            val down = keyDownLocked(state, key)
            if (!down.isSuccessful) return@withLock down
            val up = keyUpLocked(state, key)
            if (up.isSuccessful) ActionResult.Success(executedCommandCount = 2) else up
        }

        suspend fun releaseAll(
            reason: KeyReleaseReason = KeyReleaseReason.EXPLICIT,
        ): ReleaseAllResult = withLock {
            releaseAllLocked(state, reason)
        }

        /** Use only after transport loss, when emitting release reports is impossible. */
        suspend fun discardAfterDisconnect(): Int = withLock {
            if (!isCurrentLocked(state)) return@withLock 0
            val count = state.pressedKeys.size
            state.pressedKeys.clear()
            state.valid = false
            if (currentSession === state) currentSession = null
            count
        }

        suspend fun pressedKeys(): Set<HidKey> = withLock {
            if (!isCurrentLocked(state)) emptySet() else state.pressedKeys.toSet()
        }
    }

    private val mutex = Mutex()
    private var currentSession: SessionState? = null
    private var nextGeneration = 0L
    private var closed = false

    /**
     * Releases the previous session on its own captured transport before replacement.
     * The old handle becomes stale even if one of those best-effort releases fails.
     */
    suspend fun openSession(sessionId: String, transport: HidKeyTransport): Session = withLock {
        require(sessionId.isNotBlank()) { "sessionId must not be blank" }
        check(!closed) { "HidKeyStateManager is closed" }
        currentSession?.let { previous ->
            releaseAllLocked(previous, KeyReleaseReason.SESSION_REPLACED)
            previous.valid = false
        }
        val state = SessionState(
            publicId = sessionId,
            generation = ++nextGeneration,
            transport = transport,
        )
        currentSession = state
        Session(state)
    }

    suspend fun currentPressedKeys(): Set<HidKey> = withLock {
        currentSession?.pressedKeys?.toSet().orEmpty()
    }

    suspend fun releaseAll(
        reason: KeyReleaseReason = KeyReleaseReason.EXPLICIT,
    ): ReleaseAllResult = withLock {
        val state = currentSession ?: return@withLock ReleaseAllResult(0, 0, emptyList())
        releaseAllLocked(state, reason)
    }

    /** Clears current state without transport I/O after an observed disconnect. */
    suspend fun discardAfterDisconnect(): Int = withLock {
        val state = currentSession ?: return@withLock 0
        val count = state.pressedKeys.size
        state.pressedKeys.clear()
        state.valid = false
        currentSession = null
        count
    }

    suspend fun close(): ReleaseAllResult = withLock {
        if (closed) return@withLock ReleaseAllResult(0, 0, emptyList())
        closed = true
        val state = currentSession ?: return@withLock ReleaseAllResult(0, 0, emptyList())
        val result = releaseAllLocked(state, KeyReleaseReason.MANAGER_CLOSED)
        state.valid = false
        currentSession = null
        result
    }

    private suspend fun keyDownLocked(state: SessionState, key: HidKey): ActionResult {
        staleResult(state)?.let { return it }
        if (key in state.pressedKeys) {
            return ActionResult.Ignored(IgnoreReason.DUPLICATE_KEY_DOWN)
        }
        val now = clock.nowMillis()
        val lastDown = state.lastDownAtMillis
        if (
            lastDown != null &&
            now >= lastDown &&
            now - lastDown < minimumDownIntervalMillis
        ) {
            return ActionResult.Ignored(IgnoreReason.RATE_LIMITED)
        }

        val result = safeSend(state, key.asCommand(KeyPhase.DOWN))
        if (result.isSuccessful) {
            state.pressedKeys += key
            state.lastDownAtMillis = now
        }
        return result
    }

    private suspend fun keyUpLocked(state: SessionState, key: HidKey): ActionResult {
        staleResult(state)?.let { return it }
        if (key !in state.pressedKeys) {
            return ActionResult.Ignored(IgnoreReason.KEY_NOT_PRESSED)
        }
        val result = safeSend(state, key.asCommand(KeyPhase.UP))
        if (result.isSuccessful) state.pressedKeys -= key
        return result
    }

    @Suppress("UNUSED_PARAMETER")
    private suspend fun releaseAllLocked(
        state: SessionState,
        reason: KeyReleaseReason,
    ): ReleaseAllResult {
        if (!state.valid) return ReleaseAllResult(0, 0, emptyList())
        val snapshot = state.pressedKeys.toList()
        var released = 0
        val failures = mutableListOf<ActionResult.Failure>()
        for (key in snapshot) {
            when (val result = safeSend(state, key.asCommand(KeyPhase.UP))) {
                is ActionResult.Success -> {
                    state.pressedKeys -= key
                    released++
                }
                is ActionResult.Failure -> failures += result
                is ActionResult.Ignored -> failures += ActionResult.Failure(
                    reason = FailureReason.TRANSPORT_FAILURE,
                    message = result.message ?: "Transport ignored a required key release",
                )
            }
        }
        return ReleaseAllResult(snapshot.size, released, failures)
    }

    private suspend fun safeSend(state: SessionState, command: RemoteCommand): ActionResult = try {
        state.transport.send(state.publicId, command)
    } catch (error: CancellationException) {
        throw error
    } catch (error: Throwable) {
        ActionResult.Failure(
            reason = FailureReason.TRANSPORT_FAILURE,
            message = error.message ?: "Key transport failed",
            cause = error,
        )
    }

    private fun staleResult(state: SessionState): ActionResult.Ignored? =
        if (isCurrentLocked(state)) null else ActionResult.Ignored(IgnoreReason.STALE_SESSION)

    private fun isCurrentLocked(state: SessionState): Boolean =
        !closed && state.valid && currentSession === state

    private suspend fun <T> withLock(block: suspend () -> T): T {
        mutex.lock()
        return try {
            block()
        } finally {
            mutex.unlock()
        }
    }
}
