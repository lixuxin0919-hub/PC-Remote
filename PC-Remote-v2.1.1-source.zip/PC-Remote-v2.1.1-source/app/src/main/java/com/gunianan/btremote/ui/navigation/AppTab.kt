package com.gunianan.btremote.ui.navigation

import androidx.annotation.DrawableRes
import com.gunianan.btremote.R

enum class AppTab(
    val label: String,
    @DrawableRes val iconResource: Int,
) {
    CONTROL("控制", R.drawable.nav_remote),
    DEVICES("设备", R.drawable.nav_devices),
    CUSTOMIZE("自定义", R.drawable.nav_customize),
    SETTINGS("设置", R.drawable.nav_settings),
}
