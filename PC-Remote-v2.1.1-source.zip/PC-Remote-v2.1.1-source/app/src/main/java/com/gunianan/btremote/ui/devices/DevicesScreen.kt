package com.gunianan.btremote.ui.devices

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gunianan.btremote.R
import com.gunianan.btremote.bluetooth.BluetoothHidUiState
import com.gunianan.btremote.bluetooth.HidConnectionState
import com.gunianan.btremote.bluetooth.PairedBluetoothDevice
import com.gunianan.btremote.bluetooth.PairedDeviceState
import com.gunianan.btremote.ui.components.AssetIcon
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.SectionHeading
import com.gunianan.btremote.ui.components.StatusDot
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography

data class DeviceScreenCallbacks(
    val onPairing: () -> Unit,
    val onOpenSystemBluetooth: () -> Unit,
    val onRefresh: () -> Unit,
    val onRepair: () -> Unit,
    val onConnect: (String) -> Unit,
    val onDisconnect: () -> Unit,
)

@Composable
fun DevicesScreen(
    uiState: BluetoothHidUiState,
    pairedDevices: List<PairedBluetoothDevice>,
    callbacks: DeviceScreenCallbacks,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(start = 20.dp, top = 154.dp, end = 20.dp, bottom = 138.dp),
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") {
            Column {
                Text("设备", style = PcRemoteTypography.ScreenTitle)
                Spacer(Modifier.height(4.dp))
                Text("连接已配对的 Windows 电脑", style = PcRemoteTypography.Body, color = PcRemoteColors.Muted)
            }
        }

        item(key = "current") {
            SectionHeading("当前设备")
            Spacer(Modifier.height(9.dp))
            GlassCard(strong = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AssetIcon(
                        resourceId = R.drawable.nav_devices,
                        contentDescription = "电脑",
                        modifier = Modifier.size(44.dp),
                        tint = PcRemoteColors.Primary,
                    )
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = uiState.connectedDevice?.name ?: uiState.title,
                            style = PcRemoteTypography.SectionTitle,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusDot(uiState.connectionState.statusColor(), Modifier.size(8.dp))
                            Spacer(Modifier.size(6.dp))
                            Text(uiState.detail, style = PcRemoteTypography.Caption)
                        }
                    }
                }
                Spacer(Modifier.height(15.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    GlassActionButton(
                        text = if (uiState.connectionState == HidConnectionState.CONNECTED) "已连接" else "刷新状态",
                        onClick = callbacks.onRefresh,
                        modifier = Modifier.weight(1f),
                        primary = uiState.connectionState == HidConnectionState.CONNECTED,
                    )
                    GlassActionButton(
                        text = "断开",
                        onClick = callbacks.onDisconnect,
                        modifier = Modifier.weight(1f),
                        enabled = uiState.connectionState == HidConnectionState.CONNECTED,
                    )
                }
            }
        }

        item(key = "tools") {
            SectionHeading("蓝牙工具", subtitle = "PC遥控器只读取系统已配对设备，不扫描位置")
            Spacer(Modifier.height(9.dp))
            GlassCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    GlassActionButton("进入配对模式", callbacks.onPairing, Modifier.weight(1f), primary = true)
                    GlassActionButton("系统蓝牙", callbacks.onOpenSystemBluetooth, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    GlassActionButton("刷新设备", callbacks.onRefresh, Modifier.weight(1f))
                    GlassActionButton("重新注册 HID", callbacks.onRepair, Modifier.weight(1f))
                }
            }
        }

        item(key = "paired-title") {
            SectionHeading(
                "已配对设备",
                subtitle = if (pairedDevices.isEmpty()) "尚未读取到设备" else "共 ${pairedDevices.size} 台设备",
            )
        }

        if (pairedDevices.isEmpty()) {
            item(key = "empty") {
                GlassCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        AssetIcon(
                            resourceId = R.drawable.nav_devices,
                            contentDescription = "暂无设备",
                            modifier = Modifier.size(38.dp),
                            tint = PcRemoteColors.Idle,
                        )
                        Spacer(Modifier.height(9.dp))
                        Text("暂无已配对设备", fontWeight = FontWeight.SemiBold)
                        Text("先进入配对模式，再从电脑添加本手机", style = PcRemoteTypography.Caption)
                    }
                }
            }
        } else {
            items(
                items = pairedDevices,
                key = PairedBluetoothDevice::address,
            ) { device ->
                GlassCard(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 5.dp)) {
                    PairedDeviceRow(device, callbacks.onConnect)
                }
            }
        }

        item(key = "limit") {
            Text(
                text = "说明：蓝牙 HID 只能发送键盘、媒体与鼠标输入，无法读取电脑当前播放、音量或静音状态。",
                style = PcRemoteTypography.Caption,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

@Composable
private fun PairedDeviceRow(device: PairedBluetoothDevice, onConnect: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AssetIcon(
            resourceId = R.drawable.nav_devices,
            contentDescription = device.name,
            modifier = Modifier.size(36.dp),
            tint = if (device.state == PairedDeviceState.CONNECTED) PcRemoteColors.Primary else PcRemoteColors.PrimaryDeep,
        )
        Spacer(Modifier.size(11.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = buildString {
                    append(device.name)
                    if (device.wasLastConnected) append(" · 上次连接")
                },
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = when (device.state) {
                    PairedDeviceState.CONNECTED -> "已连接 · 蓝牙 HID"
                    PairedDeviceState.CONNECTING -> "正在连接…"
                    PairedDeviceState.PAIRED -> device.address
                },
                style = PcRemoteTypography.Caption,
            )
        }
        GlassActionButton(
            text = when (device.state) {
                PairedDeviceState.CONNECTED -> "已连接"
                PairedDeviceState.CONNECTING -> "连接中"
                PairedDeviceState.PAIRED -> "连接"
            },
            onClick = { onConnect(device.address) },
            enabled = device.state == PairedDeviceState.PAIRED,
            primary = device.state == PairedDeviceState.CONNECTED,
        )
    }
}

private fun HidConnectionState.statusColor() = when (this) {
    HidConnectionState.CONNECTED -> PcRemoteColors.Success
    HidConnectionState.READY -> PcRemoteColors.Primary
    HidConnectionState.STARTING,
    HidConnectionState.ACQUIRING_PROFILE,
    HidConnectionState.REGISTERING,
    HidConnectionState.CONNECTING,
    HidConnectionState.DISCONNECTING,
    -> PcRemoteColors.Warning
    HidConnectionState.ERROR,
    HidConnectionState.PERMISSION_REQUIRED,
    HidConnectionState.UNSUPPORTED,
    -> PcRemoteColors.Error
    else -> PcRemoteColors.Idle
}
