package com.gunianan.btremote.action

/**
 * A transport-neutral command produced from a persisted action configuration.
 *
 * Commands intentionally contain no Android or Bluetooth types. A future Windows
 * network transport can therefore consume the same command stream as Bluetooth HID.
 */
sealed interface RemoteCommand {
    data class Keyboard(
        val keyCode: Int,
        val modifierMask: Int = 0,
        val phase: KeyPhase = KeyPhase.TAP,
    ) : RemoteCommand {
        init {
            require(keyCode in 0..0xff) { "keyCode must fit in one HID byte" }
            require(modifierMask in 0..0xff) { "modifierMask must fit in one HID byte" }
        }
    }

    data class Consumer(
        val usageId: Int,
        val phase: KeyPhase = KeyPhase.TAP,
    ) : RemoteCommand {
        init {
            require(usageId > 0) { "usageId must be positive" }
        }
    }

    data class MouseButton(
        val button: MouseButtonId,
        val phase: KeyPhase = KeyPhase.TAP,
    ) : RemoteCommand

    data class MouseMove(
        val deltaX: Int,
        val deltaY: Int,
        val dragging: Boolean = false,
    ) : RemoteCommand {
        init {
            require(deltaX != 0 || deltaY != 0) { "mouse movement must not be empty" }
        }
    }

    data class Scroll(
        val horizontal: Int = 0,
        val vertical: Int = 0,
    ) : RemoteCommand {
        init {
            require(horizontal != 0 || vertical != 0) { "scroll movement must not be empty" }
        }
    }

    data class ModifiedScroll(
        val modifierMask: Int,
        val vertical: Int,
    ) : RemoteCommand {
        init {
            require(modifierMask in 1..0xff) { "modifierMask must contain at least one modifier" }
            require(vertical != 0) { "modified scroll movement must not be empty" }
        }
    }

    data class Internal(
        val actionId: String,
        val targetProfileId: String? = null,
    ) : RemoteCommand {
        init {
            require(actionId.isNotBlank()) { "actionId must not be blank" }
        }
    }
}

enum class KeyPhase {
    TAP,
    DOWN,
    UP,
}

enum class MouseButtonId {
    LEFT,
    RIGHT,
    MIDDLE,
}
