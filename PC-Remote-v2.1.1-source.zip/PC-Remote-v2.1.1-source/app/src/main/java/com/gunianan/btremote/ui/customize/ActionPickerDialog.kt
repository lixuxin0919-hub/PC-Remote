package com.gunianan.btremote.ui.customize

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import com.gunianan.btremote.ui.localized.LocalizedText as Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.domain.InternalActionType
import com.gunianan.btremote.domain.KeyboardModifier
import com.gunianan.btremote.domain.MouseButton
import com.gunianan.btremote.domain.MouseCommand
import com.gunianan.btremote.domain.RemoteActionConfig
import com.gunianan.btremote.domain.SequenceStep
import com.gunianan.btremote.ui.components.GlassActionButton
import com.gunianan.btremote.ui.components.GlassCard
import com.gunianan.btremote.ui.components.SectionHeading
import com.gunianan.btremote.ui.theme.PcRemoteColors
import com.gunianan.btremote.ui.theme.PcRemoteTypography

/** All transport-neutral actions available to controls and gesture bindings. */
@Composable
@OptIn(ExperimentalLayoutApi::class)
fun ActionPickerDialog(
    initialAction: RemoteActionConfig?,
    availableProfiles: List<ControlProfile>,
    onDismiss: () -> Unit,
    onConfirm: (RemoteActionConfig) -> Unit,
    modifier: Modifier = Modifier,
    onClear: (() -> Unit)? = null,
) {
    var category by rememberSaveable(initialAction) {
        mutableStateOf(ActionCategory.from(initialAction))
    }
    var selectedAction by remember(initialAction) { mutableStateOf(initialAction) }
    var sequenceTemplate by rememberSaveable { mutableStateOf(SequenceTemplate.HOLD_AND_RELEASE) }
    var delayInput by rememberSaveable { mutableStateOf("300") }
    var repeatInput by rememberSaveable { mutableStateOf("5") }

    val delayMs = delayInput.toLongOrNull()?.coerceIn(30L, 10_000L) ?: 300L
    val repeatCount = repeatInput.toIntOrNull()?.coerceIn(1, 100) ?: 5
    val advancedAction = remember(sequenceTemplate, delayMs, repeatCount) {
        sequenceTemplate.build(delayMs, repeatCount)
    }
    val candidate = if (category == ActionCategory.ADVANCED) advancedAction else selectedAction

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center,
        ) {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 760.dp)
                    .fillMaxHeight(),
                cornerRadius = 30.dp,
                strong = true,
                contentPadding = PaddingValues(18.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("选择动作", style = PcRemoteTypography.SectionTitle, fontSize = 20.sp)
                        Spacer(Modifier.height(2.dp))
                        Text("动作只描述意图，由执行器统一发送", style = PcRemoteTypography.Caption)
                    }
                    TextButton(onClick = onDismiss) { Text("关闭") }
                }

                Spacer(Modifier.height(12.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    ActionCategory.entries.forEach { item ->
                        SelectionChip(
                            text = item.label,
                            selected = item == category,
                            onClick = { category = item },
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 12.dp),
                ) {
                    item(key = "summary") {
                        GlassCard(
                            cornerRadius = 20.dp,
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                        ) {
                            Text("当前选择", style = PcRemoteTypography.Caption)
                            Spacer(Modifier.height(3.dp))
                            Text(
                                candidate.displaySummary(),
                                color = if (candidate == null) PcRemoteColors.Muted else PcRemoteColors.PrimaryDeep,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                            )
                        }
                    }

                    when (category) {
                        ActionCategory.KEYBOARD -> item(key = "keyboard") {
                            ActionChoiceGrid(
                                choices = CommonKeyboardKeys,
                                label = { it.label },
                                selected = { selectedAction == RemoteActionConfig.KeyboardKey(it.code) },
                                onSelect = { selectedAction = RemoteActionConfig.KeyboardKey(it.code) },
                            )
                        }

                        ActionCategory.SHORTCUT -> item(key = "shortcut") {
                            ActionChoiceGrid(
                                choices = CommonShortcuts,
                                label = { it.label },
                                selected = { selectedAction == it.action },
                                onSelect = { selectedAction = it.action },
                            )
                        }

                        ActionCategory.MEDIA -> item(key = "media") {
                            ActionChoiceGrid(
                                choices = CommonConsumerKeys,
                                label = { it.label },
                                selected = { selectedAction == RemoteActionConfig.ConsumerKey(it.code) },
                                onSelect = { selectedAction = RemoteActionConfig.ConsumerKey(it.code) },
                            )
                        }

                        ActionCategory.MOUSE -> item(key = "mouse") {
                            ActionChoiceGrid(
                                choices = MouseChoices,
                                label = { it.label },
                                selected = { selectedAction == it.action },
                                onSelect = { selectedAction = it.action },
                            )
                        }

                        ActionCategory.SCROLL -> item(key = "scroll") {
                            ActionChoiceGrid(
                                choices = ScrollChoices,
                                label = { it.label },
                                selected = { selectedAction == it.action },
                                onSelect = { selectedAction = it.action },
                            )
                        }

                        ActionCategory.INTERNAL -> item(key = "internal") {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                ActionChoiceGrid(
                                    choices = InternalActionType.entries.filter { it != InternalActionType.SWITCH_PROFILE },
                                    label = { it.displayName() },
                                    selected = {
                                        selectedAction == RemoteActionConfig.InternalAction(it)
                                    },
                                    onSelect = {
                                        selectedAction = RemoteActionConfig.InternalAction(it)
                                    },
                                )
                                if (availableProfiles.isNotEmpty()) {
                                    SectionHeading("切换到指定模式")
                                    ActionChoiceGrid(
                                        choices = availableProfiles,
                                        label = { it.name },
                                        selected = {
                                            selectedAction == RemoteActionConfig.InternalAction(
                                                InternalActionType.SWITCH_PROFILE,
                                                it.id,
                                            )
                                        },
                                        onSelect = {
                                            selectedAction = RemoteActionConfig.InternalAction(
                                                InternalActionType.SWITCH_PROFILE,
                                                it.id,
                                            )
                                        },
                                    )
                                }
                            }
                        }

                        ActionCategory.ADVANCED -> item(key = "advanced") {
                            AdvancedSequenceEditor(
                                selected = sequenceTemplate,
                                delayInput = delayInput,
                                repeatInput = repeatInput,
                                action = advancedAction,
                                onSelectTemplate = { sequenceTemplate = it },
                                onDelayChange = { delayInput = it.filter(Char::isDigit).take(5) },
                                onRepeatChange = { repeatInput = it.filter(Char::isDigit).take(3) },
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (onClear != null) {
                        TextButton(onClick = onClear) {
                            Text("清除绑定", color = PcRemoteColors.Error)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    GlassActionButton(text = "取消", onClick = onDismiss)
                    GlassActionButton(
                        text = "使用此动作",
                        onClick = { candidate?.let(onConfirm) },
                        primary = true,
                        enabled = candidate != null,
                    )
                }
            }
        }
    }
}

@Composable
private fun <T> ActionChoiceGrid(
    choices: List<T>,
    label: (T) -> String,
    selected: (T) -> Boolean,
    onSelect: (T) -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val columns = when {
            maxWidth >= 680.dp -> 3
            maxWidth >= 360.dp -> 2
            else -> 1
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            choices.chunked(columns).forEach { rowChoices ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowChoices.forEach { choice ->
                        SelectionChip(
                            text = label(choice),
                            selected = selected(choice),
                            onClick = { onSelect(choice) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    repeat(columns - rowChoices.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun AdvancedSequenceEditor(
    selected: SequenceTemplate,
    delayInput: String,
    repeatInput: String,
    action: RemoteActionConfig.CustomSequence,
    onSelectTemplate: (SequenceTemplate) -> Unit,
    onDelayChange: (String) -> Unit,
    onRepeatChange: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionHeading("内置多步模板", subtitle = "执行时会严格按顺序处理按下、释放、等待和重复")
        ActionChoiceGrid(
            choices = SequenceTemplate.entries,
            label = { it.label },
            selected = { it == selected },
            onSelect = onSelectTemplate,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = delayInput,
                onValueChange = onDelayChange,
                modifier = Modifier.weight(1f),
                label = { Text("等待毫秒") },
                suffix = { Text("ms") },
                keyboardOptions = KeyboardOptions.Default,
                singleLine = true,
            )
            OutlinedTextField(
                value = repeatInput,
                onValueChange = onRepeatChange,
                modifier = Modifier.weight(1f),
                label = { Text("重复次数") },
                suffix = { Text("次") },
                keyboardOptions = KeyboardOptions.Default,
                singleLine = true,
            )
        }
        GlassCard(cornerRadius = 18.dp, contentPadding = PaddingValues(13.dp)) {
            Text("序列预览", style = PcRemoteTypography.Caption)
            Spacer(Modifier.height(7.dp))
            action.steps.forEachIndexed { index, step ->
                Text(
                    "${index + 1}. ${step.displaySummary()}",
                    color = PcRemoteColors.Text,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

private enum class ActionCategory(val label: String) {
    KEYBOARD("常用键"),
    SHORTCUT("快捷键"),
    MEDIA("媒体"),
    MOUSE("鼠标"),
    SCROLL("滚动"),
    INTERNAL("应用内"),
    ADVANCED("高级序列");

    companion object {
        fun from(action: RemoteActionConfig?): ActionCategory = when (action) {
            is RemoteActionConfig.KeyboardKey -> KEYBOARD
            is RemoteActionConfig.KeyboardShortcut -> SHORTCUT
            is RemoteActionConfig.ConsumerKey -> MEDIA
            is RemoteActionConfig.MouseAction -> MOUSE
            is RemoteActionConfig.ScrollAction -> SCROLL
            is RemoteActionConfig.ModifiedScrollAction -> SCROLL
            is RemoteActionConfig.InternalAction -> INTERNAL
            is RemoteActionConfig.CustomSequence -> ADVANCED
            null -> KEYBOARD
        }
    }
}

private data class ActionChoice(
    val label: String,
    val action: RemoteActionConfig,
)

private val CommonShortcuts = listOf(
    ActionChoice("复制 Ctrl+C", shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x06)),
    ActionChoice("粘贴 Ctrl+V", shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x19)),
    ActionChoice("剪切 Ctrl+X", shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x1B)),
    ActionChoice("撤销 Ctrl+Z", shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x1D)),
    ActionChoice("保存 Ctrl+S", shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x16)),
    ActionChoice("全选 Ctrl+A", shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x04)),
    ActionChoice("切换窗口 Alt+Tab", shortcut(KeyboardModifier.LEFT_ALT, keyCode = 0x2B)),
    ActionChoice("显示桌面 Win+D", shortcut(KeyboardModifier.LEFT_GUI, keyCode = 0x07)),
    ActionChoice(
        "任务管理器",
        RemoteActionConfig.KeyboardShortcut(
            setOf(KeyboardModifier.LEFT_CONTROL, KeyboardModifier.LEFT_SHIFT),
            0x29,
        ),
    ),
)

private fun shortcut(
    vararg modifiers: KeyboardModifier,
    keyCode: Int,
) = RemoteActionConfig.KeyboardShortcut(modifiers.toSet(), keyCode)

private val MouseChoices = listOf(
    ActionChoice("左键单击", RemoteActionConfig.MouseAction(MouseCommand.CLICK, MouseButton.LEFT)),
    ActionChoice("右键单击", RemoteActionConfig.MouseAction(MouseCommand.CLICK, MouseButton.RIGHT)),
    ActionChoice("中键单击", RemoteActionConfig.MouseAction(MouseCommand.CLICK, MouseButton.MIDDLE)),
    ActionChoice("按下左键", RemoteActionConfig.MouseAction(MouseCommand.DOWN, MouseButton.LEFT)),
    ActionChoice("释放左键", RemoteActionConfig.MouseAction(MouseCommand.UP, MouseButton.LEFT)),
    ActionChoice("按下右键", RemoteActionConfig.MouseAction(MouseCommand.DOWN, MouseButton.RIGHT)),
    ActionChoice("释放右键", RemoteActionConfig.MouseAction(MouseCommand.UP, MouseButton.RIGHT)),
)

private val ScrollChoices = listOf(
    ActionChoice("向上滚动", RemoteActionConfig.ScrollAction(vertical = -1)),
    ActionChoice("向下滚动", RemoteActionConfig.ScrollAction(vertical = 1)),
)

private enum class SequenceTemplate(val label: String) {
    HOLD_AND_RELEASE("按住后释放"),
    REPEAT_ARROW("重复方向键"),
    SELECT_COPY("全选并复制"),
    COPY_THEN_PASTE("复制后粘贴");

    fun build(delayMs: Long, repeatCount: Int): RemoteActionConfig.CustomSequence {
        val space = RemoteActionConfig.KeyboardKey(0x2C)
        val right = RemoteActionConfig.KeyboardKey(0x4F)
        val copy = shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x06)
        val paste = shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x19)
        val selectAll = shortcut(KeyboardModifier.LEFT_CONTROL, keyCode = 0x04)
        val steps = when (this) {
            HOLD_AND_RELEASE -> listOf(
                SequenceStep.Down(space),
                SequenceStep.Delay(delayMs),
                SequenceStep.Up(space),
            )
            REPEAT_ARROW -> listOf(
                SequenceStep.Repeat(right, repeatCount, delayMs.coerceAtMost(2_000L)),
            )
            SELECT_COPY -> listOf(
                SequenceStep.Tap(selectAll),
                SequenceStep.Delay(delayMs),
                SequenceStep.Tap(copy),
            )
            COPY_THEN_PASTE -> listOf(
                SequenceStep.Tap(copy),
                SequenceStep.Delay(delayMs),
                SequenceStep.Tap(paste),
            )
        }
        return RemoteActionConfig.CustomSequence(steps = steps)
    }
}
