package com.gunianan.btremote.ui.control.surface

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.gunianan.btremote.ui.theme.PcRemoteColors

/**
 * Visual tokens shared by all control surfaces.
 *
 * Pointer coordinates and deltas emitted by the surfaces stay in local pixels,
 * matching Compose's pointer API. Gesture thresholds use [Dp], so classification
 * remains consistent across screen densities. The action layer can apply the
 * profile's sensitivity before converting a delta into a HID report.
 */
@Immutable
data class ControlSurfaceColors(
    val container: Color,
    val border: Color,
    val grid: Color,
    val trace: Color,
    val touchIndicator: Color,
    val disabledOverlay: Color,
)

object ControlSurfaceDefaults {
    @Composable
    fun colors(
        container: Color = PcRemoteColors.Glass.copy(alpha = 0.78f),
        border: Color = PcRemoteColors.GlassBorder,
        grid: Color = PcRemoteColors.Hairline.copy(alpha = 0.38f),
        trace: Color = PcRemoteColors.Primary,
        touchIndicator: Color = PcRemoteColors.Primary.copy(alpha = 0.22f),
        disabledOverlay: Color = Color.White.copy(alpha = 0.42f),
    ) = ControlSurfaceColors(
        container = container,
        border = border,
        grid = grid,
        trace = trace,
        touchIndicator = touchIndicator,
        disabledOverlay = disabledOverlay,
    )
}

@Immutable
data class GestureSurfaceConfig(
    val minimumSampleDistance: Dp = 2.dp,
    val maximumSampleIntervalMs: Long = 18L,
    val maximumPointCount: Int = 768,
) {
    init {
        require(minimumSampleDistance >= 0.dp)
        require(maximumSampleIntervalMs > 0L)
        require(maximumPointCount >= 8)
    }
}

@Immutable
data class TouchpadSurfaceConfig(
    val movementNoise: Dp = 0.5.dp,
    val tapSlop: Dp = 10.dp,
    val tapMaximumDurationMs: Long = 260L,
    val doubleTapMaximumGapMs: Long = 300L,
    val doubleTapPositionSlop: Dp = 34.dp,
    val longPressDurationMs: Long = 500L,
    val longPressSlop: Dp = 10.dp,
    val scrollActivationSlop: Dp = 5.dp,
    val twoFingerTapSlop: Dp = 14.dp,
    val twoFingerTapMaximumDurationMs: Long = 320L,
) {
    init {
        require(movementNoise >= 0.dp)
        require(tapSlop >= 0.dp)
        require(tapMaximumDurationMs > 0L)
        require(doubleTapMaximumGapMs > 0L)
        require(doubleTapPositionSlop >= 0.dp)
        require(longPressDurationMs > tapMaximumDurationMs)
        require(longPressSlop >= 0.dp)
        require(scrollActivationSlop >= 0.dp)
        require(twoFingerTapSlop >= 0.dp)
        require(twoFingerTapMaximumDurationMs > 0L)
    }
}

/**
 * Stateless action contract for [TouchpadSurface] and [HybridSurface].
 *
 * The surface only interprets pointer intent. It deliberately has no knowledge
 * of Bluetooth, HID reports, bindings, or PC state.
 */
@Immutable
data class TouchpadCallbacks(
    val onMove: (deltaPx: Offset) -> Unit = {},
    val onTap: (positionPx: Offset) -> Unit = {},
    val onDoubleTap: (positionPx: Offset) -> Unit = {},
    val onDragStart: (positionPx: Offset) -> Unit = {},
    val onDrag: (deltaPx: Offset) -> Unit = {},
    val onDragEnd: (cancelled: Boolean) -> Unit = {},
    /** Positive Y means the fingers moved down; the executor chooses wheel sign. */
    val onScroll: (deltaPx: Offset) -> Unit = {},
    val onRightClick: (positionPx: Offset) -> Unit = {},
    val onGestureCancelled: () -> Unit = {},
)

/**
 * HYBRID is intentionally conservative and should remain disabled unless a
 * profile explicitly selects it. This avoids cursor movement stealing a short
 * one-stroke gesture.
 */
@Immutable
data class HybridArbitrationConfig(
    val gesture: GestureSurfaceConfig = GestureSurfaceConfig(),
    val touchpad: TouchpadSurfaceConfig = TouchpadSurfaceConfig(),
    val mouseActivationDurationMs: Long = 380L,
    val mouseActivationDistance: Dp = 12.dp,
    val immediateMouseDistance: Dp = 120.dp,
) {
    init {
        require(mouseActivationDurationMs in 1 until touchpad.longPressDurationMs)
        require(mouseActivationDistance > 0.dp)
        require(immediateMouseDistance > mouseActivationDistance)
    }
}

internal data class PendingTap(
    val position: Offset,
    val upTimeMillis: Long,
    val token: Long,
)

internal enum class OneFingerIntent {
    UNDECIDED,
    MOVE,
    DRAG,
}
