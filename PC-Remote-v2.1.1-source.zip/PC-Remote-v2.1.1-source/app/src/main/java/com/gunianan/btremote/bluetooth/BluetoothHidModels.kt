package com.gunianan.btremote.bluetooth

/** Observable stages of the Android Bluetooth HID lifecycle. */
enum class HidConnectionState {
    UNSUPPORTED,
    PERMISSION_REQUIRED,
    BLUETOOTH_DISABLED,
    STARTING,
    ACQUIRING_PROFILE,
    REGISTERING,
    READY,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    SUSPENDED,
    ERROR,
    DESTROYED,
}

enum class PairedDeviceState {
    PAIRED,
    CONNECTING,
    CONNECTED,
}

/** Android-free device projection safe to retain in UI state. */
data class PairedBluetoothDevice(
    val address: String,
    val name: String,
    val state: PairedDeviceState,
    val wasLastConnected: Boolean,
)

data class BluetoothHidUiState(
    val connectionState: HidConnectionState = HidConnectionState.STARTING,
    val title: String = "正在启动 PC遥控器",
    val detail: String = "正在检查蓝牙 HID 能力",
    val connectedDevice: PairedBluetoothDevice? = null,
    val connectingDeviceAddress: String? = null,
    val hidRegistered: Boolean = false,
    val canConnect: Boolean = false,
    val canRepair: Boolean = false,
    val profileAttempt: Int = 0,
    val registrationAttempt: Int = 0,
    val reconnectAttempt: Int = 0,
)

/** Activity boundary for operations that require host-owned UI or runtime permissions. */
interface BluetoothHidHostCallbacks {
    fun requestBluetoothConnectPermission()
    fun requestBluetoothAdvertisePermission()
    fun requestBluetoothEnable()
    fun requestDiscoverability(durationSeconds: Int)
    fun showMessage(message: String)
}
