package com.gunianan.btremote.data

import android.content.SharedPreferences

/** Minimal persistence boundary that keeps repository behavior JVM-testable. */
interface KeyValueStore {
    fun contains(key: String): Boolean
    fun getString(key: String): String?
    fun getBoolean(key: String, defaultValue: Boolean): Boolean
    fun putString(key: String, value: String): Boolean
    fun putBoolean(key: String, value: Boolean): Boolean
}

class SharedPreferencesKeyValueStore(
    private val preferences: SharedPreferences,
) : KeyValueStore {
    override fun contains(key: String): Boolean = preferences.contains(key)

    override fun getString(key: String): String? = preferences.getString(key, null)

    override fun getBoolean(key: String, defaultValue: Boolean): Boolean =
        preferences.getBoolean(key, defaultValue)

    override fun putString(key: String, value: String): Boolean {
        preferences.edit().putString(key, value).apply()
        return true
    }

    override fun putBoolean(key: String, value: Boolean): Boolean {
        preferences.edit().putBoolean(key, value).apply()
        return true
    }
}
