package com.gunianan.btremote.domain

/** Creates the immutable baseline used on first launch and by “restore system profile”. */
object DefaultConfigFactory {
    private const val KEYBOARD_SPACE = 0x2C
    private const val KEYBOARD_RIGHT = 0x4F
    private const val KEYBOARD_LEFT = 0x50
    private const val KEYBOARD_DOWN = 0x51
    private const val KEYBOARD_UP = 0x52

    fun create(now: Long = System.currentTimeMillis()): AppConfig {
        val systemProfile = createSystemProfile(now)
        val trackpadProfile = createTrackpadSystemProfile(now)
        return AppConfig(
            profiles = listOf(systemProfile, trackpadProfile),
            activeProfileId = systemProfile.id,
            startupProfileId = systemProfile.id,
        )
    }

    fun createSystemProfile(now: Long = System.currentTimeMillis()): ControlProfile =
        ControlProfile(
            id = SYSTEM_DEFAULT_PROFILE_ID,
            name = "默认视频模式",
            icon = "video",
            isDefault = true,
            isSystemProfile = true,
            controlAreaType = ControlAreaType.GESTURE,
            controls = defaultVideoControls() + defaultVolumeControls(),
            gestureBindings = defaultGestureBindings(),
            appearance = ProfileAppearance(gestureAreaHeightFraction = 0.43f),
            createdAt = now,
            updatedAt = now,
        )

    fun createTrackpadSystemProfile(now: Long = System.currentTimeMillis()): ControlProfile =
        ControlProfile(
            id = SYSTEM_TRACKPAD_PROFILE_ID,
            name = "触控板模式",
            icon = "mouse",
            isDefault = false,
            isSystemProfile = true,
            controlAreaType = ControlAreaType.TOUCHPAD,
            controls = emptyList(),
            gestureBindings = emptyList(),
            appearance = ProfileAppearance(
                layout = ControlLayout.FULLSCREEN_GESTURE,
                gestureAreaHeightFraction = 0.90f,
            ),
            createdAt = now,
            updatedAt = now,
        )

    fun restoreSystemProfile(
        config: AppConfig,
        now: Long = System.currentTimeMillis(),
    ): AppConfig {
        val restored = listOf(createSystemProfile(now), createTrackpadSystemProfile(now))
        val customProfiles = config.profiles.filterNot { it.id in SYSTEM_PROFILE_IDS }
        val profiles = restored + customProfiles
        return config.copy(profiles = profiles, revision = config.revision + 1)
    }

    fun migrateVideoControls(profile: ControlProfile): ControlProfile {
        val existingIds = profile.controls.mapTo(hashSetOf()) { it.id }
        val missing = defaultVideoControls().filterNot { it.id in existingIds }
        if (missing.isEmpty()) return profile
        val shifted = profile.controls.map { item ->
            if (item.section == ControlSection.QUICK) item.copy(position = item.position + missing.size) else item
        }
        return profile.copy(controls = missing + shifted)
    }

    private fun defaultVideoControls(): List<ControlItem> = listOf(
        ControlItem(
            id = "system.video.previous",
            title = "上一个视频",
            icon = "media_previous",
            position = 0,
            section = ControlSection.QUICK,
            tapAction = RemoteActionConfig.KeyboardKey(KEYBOARD_UP),
        ),
        ControlItem(
            id = "system.video.play_pause",
            title = "暂停视频",
            icon = "media_play_pause",
            position = 1,
            section = ControlSection.QUICK,
            tapAction = RemoteActionConfig.ConsumerKey(HidConsumerUsages.PLAY_PAUSE),
        ),
        ControlItem(
            id = "system.video.next",
            title = "下一个视频",
            icon = "media_next",
            position = 2,
            section = ControlSection.QUICK,
            tapAction = RemoteActionConfig.KeyboardKey(KEYBOARD_DOWN),
        ),
    )

    private fun defaultVolumeControls(): List<ControlItem> = listOf(
        ControlItem(
            id = "system.volume.down",
            title = "音量减小",
            icon = "volume_down",
            position = 3,
            section = ControlSection.QUICK,
            tapAction = RemoteActionConfig.ConsumerKey(HidConsumerUsages.VOLUME_DECREMENT),
            longPressAction = RemoteActionConfig.ConsumerKey(HidConsumerUsages.VOLUME_DECREMENT),
            repeatAction = RemoteActionConfig.ConsumerKey(HidConsumerUsages.VOLUME_DECREMENT),
        ),
        ControlItem(
            id = "system.volume.mute",
            title = "静音",
            icon = "volume_mute",
            position = 4,
            section = ControlSection.QUICK,
            tapAction = RemoteActionConfig.ConsumerKey(HidConsumerUsages.MUTE),
        ),
        ControlItem(
            id = "system.volume.up",
            title = "音量增加",
            icon = "volume_up",
            position = 5,
            section = ControlSection.QUICK,
            tapAction = RemoteActionConfig.ConsumerKey(HidConsumerUsages.VOLUME_INCREMENT),
            longPressAction = RemoteActionConfig.ConsumerKey(HidConsumerUsages.VOLUME_INCREMENT),
            repeatAction = RemoteActionConfig.ConsumerKey(HidConsumerUsages.VOLUME_INCREMENT),
        ),
    )

    private fun defaultGestureBindings(): List<GestureBinding> = listOf(
        binding("system.gesture.up", GestureType.SWIPE_UP, KEYBOARD_UP),
        binding("system.gesture.down", GestureType.SWIPE_DOWN, KEYBOARD_DOWN),
        binding("system.gesture.left", GestureType.SWIPE_LEFT, KEYBOARD_LEFT),
        binding("system.gesture.right", GestureType.SWIPE_RIGHT, KEYBOARD_RIGHT),
        binding("system.gesture.tap", GestureType.TAP, KEYBOARD_SPACE),
        GestureBinding(
            id = "system.gesture.long_press",
            gestureType = GestureType.LONG_PRESS,
            action = RemoteActionConfig.KeyboardKey(KEYBOARD_RIGHT),
        ),
    )

    private fun binding(id: String, type: GestureType, keyCode: Int) = GestureBinding(
        id = id,
        gestureType = type,
        action = RemoteActionConfig.KeyboardKey(keyCode),
    )
}
