package com.gunianan.btremote.trackpad.pressure

import com.gunianan.btremote.trackpad.input.TrackpadPointerSample
import com.gunianan.btremote.trackpad.settings.PressureCalibrationProfile
import com.gunianan.btremote.trackpad.settings.TrackpadSettings
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

enum class PressureLevel { LIGHT, NORMAL, FORCE, UNRELIABLE }

data class PressureReading(
    val level: PressureLevel,
    val score: Float,
    val pressure: Float,
    val size: Float,
    val contactArea: Float,
    val reliable: Boolean,
    val simulated: Boolean,
    val durationMillis: Long,
    val smoothedPressure: Float,
    val pressureVelocity: Float,
    val areaVelocity: Float,
)

/** Device-adaptive pressure estimator. It degrades to area + hold duration when pressure is flat. */
class AdaptivePressureEngine {
    private val recentPressure = ArrayDeque<Float>()
    private val recentScores = ArrayDeque<Float>()
    private var smoothedScore = 0f
    private var smoothedPressure = 0f
    private var currentLevel = PressureLevel.LIGHT
    private var previousPressure = 0f
    private var previousArea = 0f
    private var previousDurationMillis = 0L

    fun evaluate(
        sample: TrackpadPointerSample,
        holdDurationMillis: Long,
        settings: TrackpadSettings,
    ): PressureReading {
        val calibration = settings.calibration
        recentPressure.addLast(sample.pressure)
        while (recentPressure.size > RELIABILITY_WINDOW) recentPressure.removeFirst()
        val pressureReliable = calibration?.pressureReliable ?: isPressureSignalReliable()
        val area = contactArea(sample)
        val pressureScore = normalize(
            sample.pressure,
            calibration?.pressureMinimum ?: 0f,
            calibration?.pressureMaximum ?: 1f,
        )
        val areaScore = normalize(
            area,
            calibration?.contactAreaMinimum ?: 0f,
            calibration?.contactAreaMaximum?.takeIf { it > 0f } ?: DEFAULT_MAX_AREA,
        )
        val sizeScore = normalize(
            sample.size,
            calibration?.sizeMinimum ?: 0f,
            calibration?.sizeMaximum?.takeIf { it > 0f } ?: 1f,
        )
        val durationScore = (holdDurationMillis / 700f).coerceIn(0f, 1f)
        val weights = if (pressureReliable) settings.reliablePressureWeights else settings.simulatedPressureWeights
        val raw = pressureScore * weights.pressure +
            sizeScore * weights.size +
            areaScore * weights.contactArea +
            durationScore * weights.duration
        val adjusted = (raw * settings.pressureSensitivity).coerceIn(0f, 1f)
        recentScores.addLast(adjusted)
        while (recentScores.size > MEDIAN_WINDOW) recentScores.removeFirst()
        val medianFiltered = recentScores.sorted()[recentScores.size / 2]
        val bounded = medianFiltered.coerceIn(smoothedScore - 0.28f, smoothedScore + 0.28f)
        smoothedScore += (bounded - smoothedScore) * 0.38f
        smoothedPressure += (sample.pressure - smoothedPressure) * 0.32f
        val elapsedSeconds = ((holdDurationMillis - previousDurationMillis).coerceAtLeast(1L)) / 1_000f
        val pressureVelocity = (sample.pressure - previousPressure) / elapsedSeconds
        val areaVelocity = (area - previousArea) / elapsedSeconds
        previousPressure = sample.pressure
        previousArea = area
        previousDurationMillis = holdDurationMillis
        currentLevel = nextLevel(
            smoothedScore,
            settings.normalPressThreshold,
            settings.forcePressThreshold,
            pressureReliable || area > 0f,
        )
        return PressureReading(
            level = currentLevel,
            score = smoothedScore,
            pressure = sample.pressure,
            size = sample.size,
            contactArea = area,
            reliable = pressureReliable,
            simulated = !pressureReliable,
            durationMillis = holdDurationMillis,
            smoothedPressure = smoothedPressure,
            pressureVelocity = pressureVelocity,
            areaVelocity = areaVelocity,
        )
    }

    fun reset() {
        recentPressure.clear()
        recentScores.clear()
        smoothedScore = 0f
        smoothedPressure = 0f
        currentLevel = PressureLevel.LIGHT
        previousPressure = 0f
        previousArea = 0f
        previousDurationMillis = 0L
    }

    private fun isPressureSignalReliable(): Boolean {
        if (recentPressure.size < 6) return false
        val min = recentPressure.minOrNull() ?: return false
        val max = recentPressure.maxOrNull() ?: return false
        val unique = recentPressure.map { (it * 1000).toInt() }.distinct().size
        val average = recentPressure.average().toFloat()
        val standardDeviation = sqrt(
            recentPressure.sumOf { value -> ((value - average) * (value - average)).toDouble() }.toFloat() /
                recentPressure.size,
        )
        return max - min >= 0.035f && standardDeviation >= 0.012f && unique >= 4
    }

    private fun nextLevel(score: Float, normal: Float, force: Float, usable: Boolean): PressureLevel {
        if (!usable) return PressureLevel.UNRELIABLE
        val hysteresis = 0.06f
        return when (currentLevel) {
            PressureLevel.FORCE -> if (score < force - hysteresis) PressureLevel.NORMAL else PressureLevel.FORCE
            PressureLevel.NORMAL -> when {
                score >= force -> PressureLevel.FORCE
                score < normal - hysteresis -> PressureLevel.LIGHT
                else -> PressureLevel.NORMAL
            }
            PressureLevel.LIGHT, PressureLevel.UNRELIABLE -> when {
                score >= force -> PressureLevel.FORCE
                score >= normal -> PressureLevel.NORMAL
                else -> PressureLevel.LIGHT
            }
        }
    }

    companion object {
        private const val RELIABILITY_WINDOW = 18
        private const val MEDIAN_WINDOW = 5
        private const val DEFAULT_MAX_AREA = 400f

        fun contactArea(sample: TrackpadPointerSample): Float {
            val major = max(sample.touchMajor, sample.touchMinor)
            val minor = minOf(sample.touchMajor, sample.touchMinor)
            return if (major > 0f && minor > 0f) major * minor else sample.size * DEFAULT_MAX_AREA
        }

        private fun normalize(value: Float, minimum: Float, maximum: Float): Float {
            val span = maximum - minimum
            return if (span <= 0.0001f) 0f else ((value - minimum) / span).coerceIn(0f, 1f)
        }
    }
}

data class PressureCalibrationSamples(
    val light: List<TrackpadPointerSample>,
    val normal: List<TrackpadPointerSample>,
    val force: List<TrackpadPointerSample>,
)

object PressureCalibrator {
    fun calibrate(samples: PressureCalibrationSamples, now: Long): PressureCalibrationProfile? {
        val all = samples.light + samples.normal + samples.force
        if (all.size < 15 || samples.normal.isEmpty() || samples.force.isEmpty()) return null
        val pressures = trimOutliers(all.map { it.pressure })
        val sizes = trimOutliers(all.map { it.size })
        val areas = trimOutliers(all.map(AdaptivePressureEngine::contactArea))
        val pressureRange = (pressures.maxOrNull() ?: 0f) - (pressures.minOrNull() ?: 0f)
        val normalScore = samples.normal.map { it.pressure }.average().toFloat()
        val forceScore = samples.force.map { it.pressure }.average().toFloat()
        val separated = abs(forceScore - normalScore) >= 0.035f
        val pressureReliable = pressureRange >= 0.05f && separated
        val signalMin = if (pressureReliable) pressures.minOrNull() ?: 0f else areas.minOrNull() ?: 0f
        val signalMax = if (pressureReliable) pressures.maxOrNull() ?: 1f else areas.maxOrNull() ?: 1f
        fun averageSignal(group: List<TrackpadPointerSample>): Float = group.map { sample ->
            val value = if (pressureReliable) sample.pressure else AdaptivePressureEngine.contactArea(sample)
            if (signalMax - signalMin <= 0.0001f) 0f else ((value - signalMin) / (signalMax - signalMin)).coerceIn(0f, 1f)
        }.average().toFloat()
        val lightMean = averageSignal(samples.light)
        val normalMean = averageSignal(samples.normal)
        val forceMean = averageSignal(samples.force)
        val normalThreshold = ((lightMean + normalMean) / 2f).coerceIn(0.28f, 0.62f)
        val forceThreshold = maxOf(normalThreshold + 0.12f, (normalMean + forceMean) / 2f).coerceIn(0.52f, 0.90f)
        return PressureCalibrationProfile(
            pressureReliable = pressureReliable,
            pressureMinimum = pressures.minOrNull() ?: 0f,
            pressureMaximum = pressures.maxOrNull() ?: 1f,
            sizeMinimum = sizes.minOrNull() ?: 0f,
            sizeMaximum = sizes.maxOrNull() ?: 1f,
            contactAreaMinimum = areas.minOrNull() ?: 0f,
            contactAreaMaximum = areas.maxOrNull() ?: 1f,
            normalPressThreshold = normalThreshold,
            forcePressThreshold = forceThreshold,
            sampleCount = all.size,
            calibratedAt = now,
        )
    }

    private fun trimOutliers(values: List<Float>): List<Float> {
        if (values.size < 10) return values
        val sorted = values.sorted()
        val trim = (sorted.size * 0.1f).toInt().coerceAtLeast(1)
        return sorted.subList(trim, sorted.size - trim)
    }
}
