package com.gunianan.btremote.data

import com.gunianan.btremote.domain.AppConfig
import com.gunianan.btremote.domain.CURRENT_SCHEMA_VERSION
import com.gunianan.btremote.domain.DefaultConfigFactory
import com.gunianan.btremote.domain.SYSTEM_DEFAULT_PROFILE_ID
import com.gunianan.btremote.domain.SYSTEM_TRACKPAD_PROFILE_ID

/** Deterministic, idempotent migration into the current persisted configuration schema. */
object ConfigMigrator {
    const val OLDEST_SUPPORTED_SCHEMA_VERSION = 1

    fun migrate(source: AppConfig, now: Long = System.currentTimeMillis()): AppConfig {
        require(source.schemaVersion in OLDEST_SUPPORTED_SCHEMA_VERSION..CURRENT_SCHEMA_VERSION) {
            "不支持的配置版本：${source.schemaVersion}"
        }
        if (source.schemaVersion == CURRENT_SCHEMA_VERSION) return source
        val video = source.profiles.firstOrNull { it.id == SYSTEM_DEFAULT_PROFILE_ID }
            ?.let(DefaultConfigFactory::migrateVideoControls)
            ?: DefaultConfigFactory.createSystemProfile(now)
        val trackpad = source.profiles.firstOrNull { it.id == SYSTEM_TRACKPAD_PROFILE_ID }
            ?.copy(isSystemProfile = true, isDefault = false)
            ?: DefaultConfigFactory.createTrackpadSystemProfile(now)
        val custom = source.profiles.filterNot {
            it.id == SYSTEM_DEFAULT_PROFILE_ID || it.id == SYSTEM_TRACKPAD_PROFILE_ID
        }
        val profiles = listOf(
            video.copy(isSystemProfile = true, isDefault = true),
            trackpad,
        ) + custom
        val knownIds = profiles.mapTo(hashSetOf()) { it.id }
        return source.copy(
            schemaVersion = CURRENT_SCHEMA_VERSION,
            profiles = profiles,
            activeProfileId = source.activeProfileId.takeIf { it in knownIds } ?: SYSTEM_DEFAULT_PROFILE_ID,
            startupProfileId = source.startupProfileId.takeIf { it in knownIds } ?: SYSTEM_DEFAULT_PROFILE_ID,
        )
    }
}
