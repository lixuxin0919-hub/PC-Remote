package com.gunianan.btremote.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

class ProfileIconException(message: String) : IllegalArgumentException(message)

class ProfileIconStore(private val context: Context) {
    private val directory = File(context.filesDir, "profile_icons").apply { mkdirs() }

    fun decode(uri: Uri): Bitmap {
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                if (total > MAX_BYTES) throw ProfileIconException("图片不能超过 10MB")
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        } ?: throw ProfileIconException("无法读取所选图片")
        if (!isSupported(bytes)) throw ProfileIconException("仅支持 PNG、JPEG 和 WebP 图片")
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: throw ProfileIconException("图片已损坏或无法解码")
    }

    fun saveCropped(profileId: String, source: Bitmap, scale: Float, offsetX: Float, offsetY: Float): String {
        val side = min(source.width, source.height)
        val cropSide = (side / scale.coerceIn(1f, 4f)).toInt().coerceAtLeast(64)
        val maxX = (source.width - cropSide).coerceAtLeast(0)
        val maxY = (source.height - cropSide).coerceAtLeast(0)
        val left = ((maxX / 2f) - offsetX.coerceIn(-1f, 1f) * maxX / 2f).toInt().coerceIn(0, maxX)
        val top = ((maxY / 2f) - offsetY.coerceIn(-1f, 1f) * maxY / 2f).toInt().coerceIn(0, maxY)
        val cropped = Bitmap.createBitmap(source, left, top, cropSide, cropSide)
        val output = Bitmap.createScaledBitmap(cropped, OUTPUT_SIZE, OUTPUT_SIZE, true)
        val file = File(directory, sanitize(profileId) + ".png")
        FileOutputStream(file).use { stream ->
            if (!output.compress(Bitmap.CompressFormat.PNG, 100, stream)) throw ProfileIconException("图标保存失败")
        }
        if (cropped !== source) cropped.recycle()
        if (output !== cropped) output.recycle()
        return file.absolutePath
    }

    fun delete(path: String?) {
        path?.let(::File)?.takeIf { it.parentFile == directory }?.delete()
    }

    private fun sanitize(id: String) = id.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun isSupported(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val png = bytes.take(8) == listOf(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A).map(Int::toByte)
        val jpeg = bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte()
        val webp = String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WEBP"
        return png || jpeg || webp
    }

    companion object { private const val MAX_BYTES = 10 * 1024 * 1024; private const val OUTPUT_SIZE = 512 }
}
