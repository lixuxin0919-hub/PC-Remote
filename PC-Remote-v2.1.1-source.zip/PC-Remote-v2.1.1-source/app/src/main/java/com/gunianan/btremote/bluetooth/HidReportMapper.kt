package com.gunianan.btremote.bluetooth

import com.gunianan.btremote.action.MouseButtonId
import com.gunianan.btremote.domain.HidConsumerUsages

/** Pure descriptor mapping kept separate from Android so it can be covered by JVM tests. */
internal object HidReportMapper {
    const val MOUSE_LEFT = 0x01
    const val MOUSE_RIGHT = 0x02
    const val MOUSE_MIDDLE = 0x04

    private val consumerUsageToMask = mapOf(
        HidConsumerUsages.VOLUME_INCREMENT to 0x01,
        HidConsumerUsages.VOLUME_DECREMENT to 0x02,
        HidConsumerUsages.MUTE to 0x04,
        HidConsumerUsages.PLAY_PAUSE to 0x08,
        HidConsumerUsages.NEXT_TRACK to 0x10,
        HidConsumerUsages.PREVIOUS_TRACK to 0x20,
        HidConsumerUsages.STOP to 0x40,
        HidConsumerUsages.FAST_FORWARD to 0x80,
    )

    fun consumerMask(usageId: Int): Int? = consumerUsageToMask[usageId]

    fun mouseButtonMask(button: MouseButtonId): Int = when (button) {
        MouseButtonId.LEFT -> MOUSE_LEFT
        MouseButtonId.RIGHT -> MOUSE_RIGHT
        MouseButtonId.MIDDLE -> MOUSE_MIDDLE
    }

    fun keyboardFrame(modifierMask: Int, keyCode: Int) =
        HidReportSender.Frame.keyboard(modifierMask, keyCode)

    fun keyboardTap(modifierMask: Int, keyCode: Int) =
        HidReportSender.Report.keyboard(modifierMask, keyCode)

    fun consumerFrame(usageId: Int, pressed: Boolean): HidReportSender.Frame? =
        consumerMask(usageId)?.let { mask ->
            HidReportSender.Frame.consumer(if (pressed) mask else 0)
        }

    fun consumerTap(usageId: Int): HidReportSender.Report? =
        consumerMask(usageId)?.let(HidReportSender.Report::consumer)

    fun mouseFrame(
        buttons: Int,
        deltaX: Int = 0,
        deltaY: Int = 0,
        wheel: Int = 0,
    ): HidReportSender.Frame = HidReportSender.Frame.mouse(
        buttons,
        deltaX.coerceIn(-127, 127),
        deltaY.coerceIn(-127, 127),
        wheel.coerceIn(-127, 127),
    )

    fun mouseClick(currentButtons: Int, button: MouseButtonId): HidReportSender.Report {
        val buttonMask = mouseButtonMask(button)
        return HidReportSender.Report.mouseButton(currentButtons or buttonMask, currentButtons)
    }
}
