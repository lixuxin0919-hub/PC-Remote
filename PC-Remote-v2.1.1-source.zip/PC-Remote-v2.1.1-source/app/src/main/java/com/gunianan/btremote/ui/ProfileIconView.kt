package com.gunianan.btremote.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.gunianan.btremote.domain.ControlProfile
import com.gunianan.btremote.ui.components.AssetIcon
import com.gunianan.btremote.ui.customize.profileIconResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ProfileIconView(profile: ControlProfile, modifier: Modifier = Modifier, tint: Color? = null) {
    val path = profile.customIconPath
    val cacheKey = path?.let { "$it#${profile.customIconUpdatedAt ?: 0L}" }
    var bitmap by remember(cacheKey) {
        mutableStateOf(cacheKey?.let(ProfileIconBitmapCache::get))
    }
    LaunchedEffect(cacheKey, path) {
        bitmap = if (path == null || cacheKey == null) null else withContext(Dispatchers.IO) {
            ProfileIconBitmapCache.get(cacheKey) ?: decodeProfileIcon(path)
                ?.asImageBitmap()
                ?.also { ProfileIconBitmapCache.put(cacheKey, it) }
        }
    }
    val currentBitmap = bitmap
    if (currentBitmap != null) {
        Image(currentBitmap, profile.name, modifier.clip(RoundedCornerShape(10)), contentScale = ContentScale.Crop)
    } else {
        AssetIcon(profileIconResource(profile.icon), profile.name, modifier, tint)
    }
}

private fun decodeProfileIcon(path: String): android.graphics.Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (
        bounds.outWidth / (sample * 2) >= PROFILE_ICON_DECODE_SIZE ||
            bounds.outHeight / (sample * 2) >= PROFILE_ICON_DECODE_SIZE
    ) {
        sample *= 2
    }
    return BitmapFactory.decodeFile(
        path,
        BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
        },
    )
}

private object ProfileIconBitmapCache {
    private val cache = object : LruCache<String, androidx.compose.ui.graphics.ImageBitmap>(12) {}

    @Synchronized fun get(key: String) = cache.get(key)
    @Synchronized fun put(key: String, bitmap: androidx.compose.ui.graphics.ImageBitmap) {
        cache.put(key, bitmap)
    }
}

private const val PROFILE_ICON_DECODE_SIZE = 512
