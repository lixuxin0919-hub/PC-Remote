package com.gunianan.btremote.domain

/** A stable machine-readable error plus a localized human-readable explanation. */
data class ValidationIssue(
    val path: String,
    val code: ValidationCode,
    val message: String,
)

enum class ValidationCode {
    UNSUPPORTED_SCHEMA,
    REQUIRED,
    OUT_OF_RANGE,
    INVALID_FORMAT,
    DUPLICATE_ID,
    INVALID_REFERENCE,
    SYSTEM_PROFILE_VIOLATION,
    INVALID_ACTION,
    INVALID_GESTURE,
}

data class ValidationResult(val issues: List<ValidationIssue>) {
    val isValid: Boolean get() = issues.isEmpty()

    fun requireValid() {
        if (!isValid) throw ConfigValidationException(issues)
    }
}

class ConfigValidationException(val issues: List<ValidationIssue>) : IllegalArgumentException(
    issues.joinToString(prefix = "配置校验失败：", separator = "；") {
        "${it.path} ${it.message}"
    },
)

/** Central validation boundary for persisted and imported configuration. */
object ConfigValidator {
    private val idPattern = Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
    private val bluetoothAddressPattern = Regex("^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")

    private const val MAX_PROFILES = 100
    private const val MAX_CONTROLS = 100
    private const val MAX_BINDINGS = 100
    private const val MAX_CUSTOM_GESTURES = 32
    private const val MAX_SEQUENCE_STEPS = 64
    private const val MAX_ACTION_DEPTH = 6
    private const val MAX_SEQUENCE_DURATION_MS = 30_000L

    fun validate(config: AppConfig): ValidationResult {
        val collector = IssueCollector()
        if (config.schemaVersion != CURRENT_SCHEMA_VERSION) {
            collector.add(
                "schemaVersion",
                ValidationCode.UNSUPPORTED_SCHEMA,
                "仅支持版本 $CURRENT_SCHEMA_VERSION",
            )
        }
        if (config.profiles.isEmpty() || config.profiles.size > MAX_PROFILES) {
            collector.add("profiles", ValidationCode.OUT_OF_RANGE, "模式数量必须为 1..$MAX_PROFILES")
        }

        reportDuplicateIds(config.profiles.map { it.id }, "profiles", collector)
        val knownProfileIds = config.profiles.mapTo(linkedSetOf()) { it.id }
        config.profiles.forEachIndexed { index, profile ->
            validateProfileInto(profile, "profiles[$index]", knownProfileIds, collector)
        }

        val systemProfiles = config.profiles.filter { it.isSystemProfile }
        val defaultProfiles = config.profiles.filter { it.isDefault }
        if (systemProfiles.mapTo(hashSetOf()) { it.id } != SYSTEM_PROFILE_IDS) {
            collector.add(
                "profiles",
                ValidationCode.SYSTEM_PROFILE_VIOLATION,
                "必须包含默认视频模式和触控板模式两个系统模式",
            )
        }
        if (defaultProfiles.size != 1 || defaultProfiles.singleOrNull()?.id != SYSTEM_DEFAULT_PROFILE_ID) {
            collector.add(
                "profiles",
                ValidationCode.SYSTEM_PROFILE_VIOLATION,
                "内置默认标记只能属于系统默认模式",
            )
        }
        if (config.activeProfileId !in knownProfileIds) {
            collector.add(
                "activeProfileId",
                ValidationCode.INVALID_REFERENCE,
                "当前模式不存在",
            )
        }
        if (config.startupProfileId !in knownProfileIds) {
            collector.add(
                "startupProfileId",
                ValidationCode.INVALID_REFERENCE,
                "启动模式不存在",
            )
        }
        if (config.revision < 0) {
            collector.add("revision", ValidationCode.OUT_OF_RANGE, "不能小于 0")
        }
        validateGlobalSettings(config.globalSettings, knownProfileIds, collector)
        return ValidationResult(collector.issues)
    }

    /** Validates a standalone profile before it is sanitized and merged during import. */
    fun validateProfile(profile: ControlProfile): ValidationResult {
        val collector = IssueCollector()
        // Cross-profile references are checked after the imported profile is merged.
        validateProfileInto(profile, "profile", emptySet(), collector)
        return ValidationResult(collector.issues)
    }

    fun validateAction(action: RemoteActionConfig): ValidationResult {
        val collector = IssueCollector()
        validateActionInto(action, "action", emptySet(), collector, depth = 0)
        return ValidationResult(collector.issues)
    }

    private fun validateProfileInto(
        profile: ControlProfile,
        path: String,
        knownProfileIds: Set<String>,
        collector: IssueCollector,
    ) {
        validateId(profile.id, "$path.id", collector)
        validateText(profile.name, "$path.name", 1, 40, collector)
        profile.icon?.let { validateText(it, "$path.icon", 1, 80, collector) }
        if (profile.isSystemProfile != (profile.id in SYSTEM_PROFILE_IDS)) {
            collector.add(
                "$path.isSystemProfile",
                ValidationCode.SYSTEM_PROFILE_VIOLATION,
                "系统模式标记与保留 ID 不一致",
            )
        }
        if (profile.id == SYSTEM_TRACKPAD_PROFILE_ID &&
            (profile.controlAreaType != ControlAreaType.TOUCHPAD ||
                profile.controls.isNotEmpty() || profile.gestureBindings.isNotEmpty())
        ) {
            collector.add(
                path,
                ValidationCode.SYSTEM_PROFILE_VIOLATION,
                "触控板系统模式必须使用专用触控板页面",
            )
        }
        if (profile.isDefault != (profile.id == SYSTEM_DEFAULT_PROFILE_ID)) {
            collector.add(
                "$path.isDefault",
                ValidationCode.SYSTEM_PROFILE_VIOLATION,
                "内置默认标记与保留 ID 不一致",
            )
        }
        if (profile.createdAt < 0 || profile.updatedAt < profile.createdAt) {
            collector.add("$path.updatedAt", ValidationCode.OUT_OF_RANGE, "更新时间不得早于创建时间")
        }

        if (profile.controls.size > MAX_CONTROLS) {
            collector.add("$path.controls", ValidationCode.OUT_OF_RANGE, "控件不能超过 $MAX_CONTROLS 个")
        }
        reportDuplicateIds(profile.controls.map { it.id }, "$path.controls", collector)
        profile.controls
            .groupBy { it.section }
            .forEach { (section, controls) ->
                val duplicatePositions = controls.groupingBy { it.position }.eachCount().filterValues { it > 1 }
                duplicatePositions.keys.forEach { position ->
                    collector.add(
                        "$path.controls",
                        ValidationCode.DUPLICATE_ID,
                        "$section 区域存在重复位置 $position",
                    )
                }
            }
        profile.controls.forEachIndexed { index, item ->
            validateControlItem(item, "$path.controls[$index]", knownProfileIds, collector)
        }

        if (profile.customGestures.size > MAX_CUSTOM_GESTURES) {
            collector.add(
                "$path.customGestures",
                ValidationCode.OUT_OF_RANGE,
                "自定义手势不能超过 $MAX_CUSTOM_GESTURES 个",
            )
        }
        reportDuplicateIds(profile.customGestures.map { it.id }, "$path.customGestures", collector)
        profile.customGestures.forEachIndexed { index, template ->
            validateGestureTemplate(template, "$path.customGestures[$index]", collector)
        }

        if (profile.gestureBindings.size > MAX_BINDINGS) {
            collector.add(
                "$path.gestureBindings",
                ValidationCode.OUT_OF_RANGE,
                "手势绑定不能超过 $MAX_BINDINGS 个",
            )
        }
        reportDuplicateIds(profile.gestureBindings.map { it.id }, "$path.gestureBindings", collector)
        val bindingKeys = profile.gestureBindings.map { it.gestureType to it.customGestureId }
        bindingKeys.groupingBy { it }.eachCount().filterValues { it > 1 }.keys.forEach { key ->
            collector.add(
                "$path.gestureBindings",
                ValidationCode.INVALID_GESTURE,
                "手势 ${key.first} 存在重复绑定",
            )
        }
        val customGestureIds = profile.customGestures.mapTo(hashSetOf()) { it.id }
        profile.gestureBindings.forEachIndexed { index, binding ->
            validateGestureBinding(
                binding,
                "$path.gestureBindings[$index]",
                customGestureIds,
                knownProfileIds,
                collector,
            )
        }
        profile.appearance?.let { validateAppearance(it, "$path.appearance", collector) }
    }

    private fun validateControlItem(
        item: ControlItem,
        path: String,
        knownProfileIds: Set<String>,
        collector: IssueCollector,
    ) {
        validateId(item.id, "$path.id", collector)
        validateText(item.title, "$path.title", 1, 40, collector)
        item.icon?.let { validateText(it, "$path.icon", 1, 80, collector) }
        if (item.position !in 0..999) {
            collector.add("$path.position", ValidationCode.OUT_OF_RANGE, "必须为 0..999")
        }
        val actions = listOf(
            "tapAction" to item.tapAction,
            "doubleTapAction" to item.doubleTapAction,
            "longPressAction" to item.longPressAction,
            "repeatAction" to item.repeatAction,
        )
        if (item.visible && actions.all { it.second == null }) {
            collector.add(path, ValidationCode.INVALID_ACTION, "可见控件至少需要一个动作")
        }
        actions.forEach { (name, action) ->
            action?.let { validateActionInto(it, "$path.$name", knownProfileIds, collector, 0) }
        }
        if (item.repeatAction != null && item.longPressAction == null) {
            collector.add(
                "$path.repeatAction",
                ValidationCode.INVALID_ACTION,
                "循环动作需要同时配置长按动作",
            )
        }
    }

    private fun validateGestureBinding(
        binding: GestureBinding,
        path: String,
        customGestureIds: Set<String>,
        knownProfileIds: Set<String>,
        collector: IssueCollector,
    ) {
        validateId(binding.id, "$path.id", collector)
        if (binding.gestureType == GestureType.CUSTOM) {
            val customId = binding.customGestureId
            if (customId == null || customId !in customGestureIds) {
                collector.add(
                    "$path.customGestureId",
                    ValidationCode.INVALID_REFERENCE,
                    "自定义手势模板不存在",
                )
            }
        } else if (binding.customGestureId != null) {
            collector.add(
                "$path.customGestureId",
                ValidationCode.INVALID_GESTURE,
                "内置手势不能引用自定义模板",
            )
        }
        binding.minConfidence?.let {
            if (!it.isFinite() || it !in 0.3f..1.0f) {
                collector.add("$path.minConfidence", ValidationCode.OUT_OF_RANGE, "必须为 0.3..1.0")
            }
        }
        binding.repeatPolicy?.let { validateRepeatPolicy(it, "$path.repeatPolicy", collector) }
        if (binding.repeatPolicy != null) {
            collector.add(
                "$path.repeatPolicy",
                ValidationCode.INVALID_ACTION,
                "当前版本仅支持控件长按连续触发，手势持续触发配置暂不接受",
            )
        }
        validateActionInto(binding.action, "$path.action", knownProfileIds, collector, 0)
    }

    private fun validateRepeatPolicy(
        policy: RepeatPolicy,
        path: String,
        collector: IssueCollector,
    ) {
        if (policy.initialDelayMs !in 100..5_000) {
            collector.add("$path.initialDelayMs", ValidationCode.OUT_OF_RANGE, "必须为 100..5000 毫秒")
        }
        if (policy.intervalMs !in 30..5_000) {
            collector.add("$path.intervalMs", ValidationCode.OUT_OF_RANGE, "必须为 30..5000 毫秒")
        }
        if (policy.maxDurationMs !in 1_000..30_000) {
            collector.add("$path.maxDurationMs", ValidationCode.OUT_OF_RANGE, "必须为 1000..30000 毫秒")
        }
        if (policy.maxDurationMs <= policy.initialDelayMs) {
            collector.add("$path.maxDurationMs", ValidationCode.OUT_OF_RANGE, "必须大于长按触发时间")
        }
    }

    private fun validateAppearance(
        appearance: ProfileAppearance,
        path: String,
        collector: IssueCollector,
    ) {
        if (appearance.gridColumns !in 1..4) {
            collector.add("$path.gridColumns", ValidationCode.OUT_OF_RANGE, "必须为 1..4")
        }
        if (!appearance.gestureAreaHeightFraction.isFinite() ||
            appearance.gestureAreaHeightFraction !in 0.30f..0.95f
        ) {
            collector.add(
                "$path.gestureAreaHeightFraction",
                ValidationCode.OUT_OF_RANGE,
                "必须为 0.30..0.95",
            )
        }
        appearance.accentColorArgb?.let {
            if (it !in 0..0xFFFF_FFFFL) {
                collector.add("$path.accentColorArgb", ValidationCode.OUT_OF_RANGE, "必须是 ARGB 颜色值")
            }
        }
        validateSensitivity(appearance.gestureSensitivity, "$path.gestureSensitivity", collector)
        validateConfidence(appearance.confidenceThreshold, "$path.confidenceThreshold", collector)
    }

    private fun validateGestureTemplate(
        template: GestureTemplate,
        path: String,
        collector: IssueCollector,
    ) {
        validateId(template.id, "$path.id", collector)
        validateText(template.name, "$path.name", 1, 40, collector)
        template.startingDirection?.let {
            if (!it.isFinite() || it !in -180f..180f) {
                collector.add("$path.startingDirection", ValidationCode.OUT_OF_RANGE, "必须为 -180..180 度")
            }
        }
        if (template.createdAt < 0 || template.updatedAt < template.createdAt) {
            collector.add("$path.updatedAt", ValidationCode.OUT_OF_RANGE, "更新时间不得早于创建时间")
        }
        if (template.samples.size !in 3..12) {
            collector.add("$path.samples", ValidationCode.OUT_OF_RANGE, "已保存手势需要 3..12 个样本")
        }
        template.samples.forEachIndexed { sampleIndex, sample ->
            val samplePath = "$path.samples[$sampleIndex]"
            if (sample.points.size !in 8..512) {
                collector.add("$samplePath.points", ValidationCode.OUT_OF_RANGE, "每个样本需要 8..512 个点")
            }
            var previousElapsed = -1L
            sample.points.forEachIndexed { pointIndex, point ->
                val pointPath = "$samplePath.points[$pointIndex]"
                if (!point.x.isFinite() || !point.y.isFinite() || point.x !in -2f..2f || point.y !in -2f..2f) {
                    collector.add(pointPath, ValidationCode.OUT_OF_RANGE, "坐标必须是有限的归一化值")
                }
                if (point.elapsedMs < previousElapsed || point.elapsedMs !in 0..60_000) {
                    collector.add("$pointPath.elapsedMs", ValidationCode.OUT_OF_RANGE, "时间必须单调且不超过 60 秒")
                }
                previousElapsed = point.elapsedMs
            }
        }
    }

    private fun validateActionInto(
        action: RemoteActionConfig,
        path: String,
        knownProfileIds: Set<String>,
        collector: IssueCollector,
        depth: Int,
    ) {
        if (depth > MAX_ACTION_DEPTH) {
            collector.add(path, ValidationCode.INVALID_ACTION, "动作嵌套层级不能超过 $MAX_ACTION_DEPTH")
            return
        }
        when (action) {
            is RemoteActionConfig.KeyboardKey -> validateKeyboardUsage(action.keyCode, "$path.keyCode", collector)
            is RemoteActionConfig.KeyboardShortcut -> {
                validateKeyboardUsage(action.keyCode, "$path.keyCode", collector)
                if (action.keyCode in 0xE0..0xE7) {
                    collector.add("$path.keyCode", ValidationCode.INVALID_ACTION, "组合键主键不能是修饰键")
                }
                if (action.modifiers.isEmpty()) {
                    collector.add("$path.modifiers", ValidationCode.REQUIRED, "组合键至少需要一个修饰键")
                }
            }
            is RemoteActionConfig.ConsumerKey -> if (
                action.usageId !in HidConsumerUsages.SUPPORTED_USAGE_IDS
            ) {
                collector.add(
                    "$path.usageId",
                    ValidationCode.INVALID_ACTION,
                    "当前 HID 传输不支持该 Consumer usage ID",
                )
            }
            is RemoteActionConfig.MouseAction -> validateMouseAction(action, path, collector)
            is RemoteActionConfig.ScrollAction -> {
                if (action.horizontal != 0) {
                    collector.add(
                        "$path.horizontal",
                        ValidationCode.INVALID_ACTION,
                        "当前 HID 传输仅支持垂直滚动",
                    )
                }
                if (action.vertical !in -127..127 || action.vertical == 0) {
                    collector.add(
                        "$path.vertical",
                        ValidationCode.INVALID_ACTION,
                        "垂直滚动量必须为 -127..127 且不能为 0",
                    )
                }
            }
            is RemoteActionConfig.ModifiedScrollAction -> {
                if (action.modifiers.isEmpty()) {
                    collector.add("$path.modifiers", ValidationCode.REQUIRED, "组合滚动至少需要一个修饰键")
                }
                if (action.vertical !in -127..127 || action.vertical == 0) {
                    collector.add(
                        "$path.vertical",
                        ValidationCode.INVALID_ACTION,
                        "组合滚动量必须为 -127..127 且不能为 0",
                    )
                }
            }
            is RemoteActionConfig.InternalAction -> {
                if (action.action == InternalActionType.SWITCH_PROFILE) {
                    val target = action.targetProfileId
                    if (target == null || (knownProfileIds.isNotEmpty() && target !in knownProfileIds)) {
                        collector.add(
                            "$path.targetProfileId",
                            ValidationCode.INVALID_REFERENCE,
                            "切换目标模式不存在",
                        )
                    }
                } else if (action.targetProfileId != null) {
                    collector.add(
                        "$path.targetProfileId",
                        ValidationCode.INVALID_ACTION,
                        "该内部动作不能设置目标模式",
                    )
                }
            }
            is RemoteActionConfig.CustomSequence -> {
                if (action.steps.isEmpty() || action.steps.size > MAX_SEQUENCE_STEPS) {
                    collector.add(
                        "$path.steps",
                        ValidationCode.OUT_OF_RANGE,
                        "步骤数量必须为 1..$MAX_SEQUENCE_STEPS",
                    )
                }
                action.steps.forEachIndexed { index, step ->
                    validateSequenceStep(step, "$path.steps[$index]", knownProfileIds, collector, depth + 1)
                }
                validateSequenceBalance(action.steps, "$path.steps", collector)
                if (action.estimatedDelayMillis() > MAX_SEQUENCE_DURATION_MS) {
                    collector.add(
                        "$path.steps",
                        ValidationCode.OUT_OF_RANGE,
                        "序列总延时不能超过 $MAX_SEQUENCE_DURATION_MS 毫秒",
                    )
                }
            }
        }
    }

    /**
     * Verifies each holdable action as a small state machine: released -> down -> released.
     * Pairing by effective HID identity permits mouse DOWN/UP command variants to match while
     * still treating shortcuts with different modifier masks as distinct held keys.
     */
    private fun validateSequenceBalance(
        steps: List<SequenceStep>,
        path: String,
        collector: IssueCollector,
    ) {
        val heldActions = linkedSetOf<HoldIdentity>()
        steps.forEachIndexed { index, step ->
            val stepPath = "$path[$index]"
            when (step) {
                is SequenceStep.Down -> step.action.holdIdentity()?.let { identity ->
                    if (!heldActions.add(identity)) {
                        collector.add(
                            stepPath,
                            ValidationCode.INVALID_ACTION,
                            "同一动作不能在释放前重复按下",
                        )
                    }
                }
                is SequenceStep.Up -> step.action.holdIdentity()?.let { identity ->
                    if (!heldActions.remove(identity)) {
                        collector.add(
                            stepPath,
                            ValidationCode.INVALID_ACTION,
                            "动作必须先按下才能释放",
                        )
                    }
                }
                is SequenceStep.Delay,
                is SequenceStep.Repeat,
                is SequenceStep.Tap,
                -> Unit
            }
        }
        if (heldActions.isNotEmpty()) {
            collector.add(
                path,
                ValidationCode.INVALID_ACTION,
                "序列结束前必须释放所有已按下动作",
            )
        }
    }

    private fun validateSequenceStep(
        step: SequenceStep,
        path: String,
        knownProfileIds: Set<String>,
        collector: IssueCollector,
        depth: Int,
    ) {
        when (step) {
            is SequenceStep.Delay -> if (step.durationMs !in 1..30_000) {
                collector.add("$path.durationMs", ValidationCode.OUT_OF_RANGE, "延时必须为 1..30000 毫秒")
            }
            is SequenceStep.Tap -> validateActionInto(step.action, "$path.action", knownProfileIds, collector, depth)
            is SequenceStep.Down -> {
                if (!step.action.canBeHeld()) {
                    collector.add("$path.action", ValidationCode.INVALID_ACTION, "该动作不支持按下状态")
                }
                validateActionInto(step.action, "$path.action", knownProfileIds, collector, depth)
            }
            is SequenceStep.Up -> {
                if (!step.action.canBeHeld()) {
                    collector.add("$path.action", ValidationCode.INVALID_ACTION, "该动作不支持释放状态")
                }
                validateActionInto(step.action, "$path.action", knownProfileIds, collector, depth)
            }
            is SequenceStep.Repeat -> {
                if (step.count !in 1..300) {
                    collector.add("$path.count", ValidationCode.OUT_OF_RANGE, "重复次数必须为 1..300")
                }
                if (step.intervalMs !in 30..30_000) {
                    collector.add("$path.intervalMs", ValidationCode.OUT_OF_RANGE, "间隔必须为 30..30000 毫秒")
                }
                if (step.action is RemoteActionConfig.CustomSequence) {
                    collector.add("$path.action", ValidationCode.INVALID_ACTION, "重复步骤不能再次嵌套序列")
                }
                validateActionInto(step.action, "$path.action", knownProfileIds, collector, depth)
            }
        }
    }

    private fun RemoteActionConfig.canBeHeld(): Boolean = holdIdentity() != null

    private fun RemoteActionConfig.holdIdentity(): HoldIdentity? = when (this) {
        is RemoteActionConfig.KeyboardKey -> HoldIdentity.Keyboard(keyCode, modifierMask = 0)
        is RemoteActionConfig.KeyboardShortcut -> HoldIdentity.Keyboard(
            keyCode = keyCode,
            modifierMask = modifiers.fold(0) { mask, modifier -> mask or modifier.hidMask },
        )
        is RemoteActionConfig.ConsumerKey -> HoldIdentity.Consumer(usageId)
        is RemoteActionConfig.MouseAction -> if (command != MouseCommand.MOVE && button != null) {
            HoldIdentity.Mouse(button)
        } else {
            null
        }
        is RemoteActionConfig.ModifiedScrollAction -> null
        else -> null
    }

    private sealed interface HoldIdentity {
        data class Keyboard(val keyCode: Int, val modifierMask: Int) : HoldIdentity
        data class Consumer(val usageId: Int) : HoldIdentity
        data class Mouse(val button: MouseButton) : HoldIdentity
    }

    private fun RemoteActionConfig.estimatedDelayMillis(): Long = when (this) {
        is RemoteActionConfig.CustomSequence -> steps.fold(0L) { total, step ->
            (total + step.estimatedDelayMillis()).coerceAtMost(MAX_SEQUENCE_DURATION_MS + 1L)
        }
        else -> 0L
    }

    private fun SequenceStep.estimatedDelayMillis(): Long = when (this) {
        is SequenceStep.Delay -> durationMs
        is SequenceStep.Repeat -> ((count.toLong() - 1L).coerceAtLeast(0L) * intervalMs)
            .coerceAtMost(MAX_SEQUENCE_DURATION_MS + 1L)
        is SequenceStep.Tap -> action.estimatedDelayMillis()
        is SequenceStep.Down,
        is SequenceStep.Up,
        -> 0L
    }

    private fun validateMouseAction(
        action: RemoteActionConfig.MouseAction,
        path: String,
        collector: IssueCollector,
    ) {
        if (action.deltaX !in -127..127 || action.deltaY !in -127..127) {
            collector.add(path, ValidationCode.OUT_OF_RANGE, "鼠标位移必须为 -127..127")
        }
        when (action.command) {
            MouseCommand.CLICK, MouseCommand.DOWN, MouseCommand.UP -> {
                if (action.button == null) {
                    collector.add("$path.button", ValidationCode.REQUIRED, "鼠标按键动作必须指定按键")
                }
                if (action.deltaX != 0 || action.deltaY != 0) {
                    collector.add(path, ValidationCode.INVALID_ACTION, "鼠标按键动作不能同时携带位移")
                }
            }
            MouseCommand.MOVE -> {
                if (action.button != null) {
                    collector.add("$path.button", ValidationCode.INVALID_ACTION, "移动动作不能指定按键")
                }
                if (action.deltaX == 0 && action.deltaY == 0) {
                    collector.add(path, ValidationCode.INVALID_ACTION, "鼠标位移不能同时为 0")
                }
            }
        }
    }

    private fun validateGlobalSettings(
        settings: GlobalSettings,
        knownProfileIds: Set<String>,
        collector: IssueCollector,
    ) {
        settings.lastDeviceAddress?.let {
            if (!bluetoothAddressPattern.matches(it)) {
                collector.add(
                    "globalSettings.lastDeviceAddress",
                    ValidationCode.INVALID_FORMAT,
                    "蓝牙地址格式无效",
                )
            }
        }
        validateSensitivity(settings.gestureSensitivity, "globalSettings.gestureSensitivity", collector)
        validateConfidence(settings.confidenceThreshold, "globalSettings.confidenceThreshold", collector)
        val trackpad = settings.trackpad
        if (!trackpad.pointerSensitivity.isFinite() || trackpad.pointerSensitivity !in 0.5f..2f) {
            collector.add("globalSettings.trackpad.pointerSensitivity", ValidationCode.OUT_OF_RANGE, "必须为 0.5..2.0")
        }
        if (!trackpad.pointerAcceleration.isFinite() || trackpad.pointerAcceleration !in 0f..0.6f) {
            collector.add("globalSettings.trackpad.pointerAcceleration", ValidationCode.OUT_OF_RANGE, "必须为 0..0.6")
        }
        if (!trackpad.scrollSpeed.isFinite() || trackpad.scrollSpeed !in 0.5f..2f) {
            collector.add("globalSettings.trackpad.scrollSpeed", ValidationCode.OUT_OF_RANGE, "必须为 0.5..2.0")
        }
        if (trackpad.doubleTapTimeoutMs !in 200L..500L) {
            collector.add("globalSettings.trackpad.doubleTapTimeoutMs", ValidationCode.OUT_OF_RANGE, "必须为 200..500")
        }
        if (!trackpad.pressureSensitivity.isFinite() || trackpad.pressureSensitivity !in 0.6f..1.6f) {
            collector.add("globalSettings.trackpad.pressureSensitivity", ValidationCode.OUT_OF_RANGE, "必须为 0.6..1.6")
        }
        if (trackpad.normalPressThreshold !in 0.2f..0.8f ||
            trackpad.forcePressThreshold !in 0.4f..0.95f ||
            trackpad.normalPressThreshold >= trackpad.forcePressThreshold
        ) {
            collector.add("globalSettings.trackpad", ValidationCode.OUT_OF_RANGE, "压力阈值必须递增且位于有效范围")
        }
        listOf(
            "reliablePressureWeights" to trackpad.reliablePressureWeights,
            "simulatedPressureWeights" to trackpad.simulatedPressureWeights,
        ).forEach { (name, weights) ->
            val values = listOf(weights.pressure, weights.size, weights.contactArea, weights.duration)
            if (values.any { !it.isFinite() || it < 0f } || kotlin.math.abs(weights.total - 1f) > 0.001f) {
                collector.add(
                    "globalSettings.trackpad.$name",
                    ValidationCode.OUT_OF_RANGE,
                    "压感权重必须为非负数且总和为 1",
                )
            }
        }
        com.gunianan.btremote.trackpad.settings.TrackpadGestureActionSlot.entries.forEach { slot ->
            validateActionInto(
                trackpad.gestureActions.actionFor(slot),
                "globalSettings.trackpad.gestureActions.${slot.name.lowercase()}",
                knownProfileIds,
                collector,
                depth = 0,
            )
        }
    }

    private fun validateSensitivity(value: Float, path: String, collector: IssueCollector) {
        if (!value.isFinite() || value !in 0.5f..2.0f) {
            collector.add(path, ValidationCode.OUT_OF_RANGE, "必须为 0.5..2.0")
        }
    }

    private fun validateConfidence(value: Float, path: String, collector: IssueCollector) {
        if (!value.isFinite() || value !in 0.3f..1.0f) {
            collector.add(path, ValidationCode.OUT_OF_RANGE, "必须为 0.3..1.0")
        }
    }

    private fun validateKeyboardUsage(value: Int, path: String, collector: IssueCollector) {
        if (value !in 0x04..0x65) {
            collector.add(
                path,
                ValidationCode.OUT_OF_RANGE,
                "必须为当前 HID 键盘描述符支持的 usage ID (0x04..0x65)",
            )
        }
    }

    private fun validateId(value: String, path: String, collector: IssueCollector) {
        if (!idPattern.matches(value)) {
            collector.add(path, ValidationCode.INVALID_FORMAT, "ID 只能包含字母、数字、点、下划线和连字符")
        }
    }

    private fun validateText(
        value: String,
        path: String,
        minLength: Int,
        maxLength: Int,
        collector: IssueCollector,
    ) {
        if (value.isBlank() || value.length !in minLength..maxLength || value.any(Char::isISOControl)) {
            collector.add(path, ValidationCode.OUT_OF_RANGE, "长度必须为 $minLength..$maxLength 且不能含控制字符")
        }
    }

    private fun reportDuplicateIds(ids: List<String>, path: String, collector: IssueCollector) {
        ids.groupingBy { it }.eachCount().filterValues { it > 1 }.keys.forEach { id ->
            collector.add(path, ValidationCode.DUPLICATE_ID, "存在重复 ID：$id")
        }
    }

    private class IssueCollector {
        private val mutableIssues = mutableListOf<ValidationIssue>()
        val issues: List<ValidationIssue> get() = mutableIssues

        fun add(path: String, code: ValidationCode, message: String) {
            if (mutableIssues.size < 200) mutableIssues += ValidationIssue(path, code, message)
        }
    }
}
