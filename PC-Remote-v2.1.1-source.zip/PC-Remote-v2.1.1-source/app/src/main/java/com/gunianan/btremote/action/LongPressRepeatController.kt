package com.gunianan.btremote.action

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

fun interface MonotonicClock {
    fun nowMillis(): Long
}

fun interface ScheduledTask {
    fun cancel()
}

/** Scheduler boundary kept injectable so long-press timing can be tested without sleeping. */
fun interface LongPressScheduler {
    fun schedule(delayMillis: Long, block: () -> Unit): ScheduledTask
}

data class LongPressTiming(
    val activationDelayMillis: Long = 500L,
    val repeatIntervalMillis: Long = 100L,
    val maximumDurationMillis: Long = 30_000L,
) {
    init {
        require(activationDelayMillis >= 0L) { "activationDelayMillis must not be negative" }
        require(repeatIntervalMillis > 0L) { "repeatIntervalMillis must be positive" }
        require(maximumDurationMillis > 0L) { "maximumDurationMillis must be positive" }
    }
}

data class LongPressCallbacks(
    /** Called once at the 500 ms activation boundary. Keep callbacks non-blocking. */
    val onStart: () -> Unit = {},
    /** Called every 100 ms after activation until the session is cancelled. */
    val onRepeat: () -> Unit = {},
    /** Called once if and only if onStart was reached. Use this to release held keys. */
    val onStop: (LongPressStopReason) -> Unit = {},
)

enum class LongPressStopReason {
    RELEASED,
    PAGE_EXIT,
    PROFILE_SWITCH,
    DISCONNECTED,
    APP_BACKGROUND,
    TIMEOUT,
    REPLACED,
    CALLBACK_FAILURE,
    CLOSED,
}

enum class LongPressStartResult {
    STARTED,
    ALREADY_RUNNING,
    CLOSED,
}

/**
 * Owns at most one repeat session and guarantees a single stop callback.
 *
 * Cancellation entry points are deliberately explicit so lifecycle callers do not
 * need to encode release semantics themselves.
 */
class LongPressRepeatController(
    private val scheduler: LongPressScheduler = SharedLongPressScheduler,
    private val clock: MonotonicClock = MonotonicClock { System.nanoTime() / 1_000_000L },
    private val timing: LongPressTiming = LongPressTiming(),
) : AutoCloseable {
    private data class ActiveSession(
        val ownerId: String,
        val generation: Long,
        val callbacks: LongPressCallbacks,
        var activatedAtMillis: Long? = null,
        var activationTask: ScheduledTask? = null,
        var repeatTask: ScheduledTask? = null,
        var timeoutTask: ScheduledTask? = null,
    )

    private val lock = Any()
    private var activeSession: ActiveSession? = null
    private var nextGeneration = 0L
    private var closed = false

    val isRunning: Boolean
        get() = synchronized(lock) { activeSession != null }

    val isActivated: Boolean
        get() = synchronized(lock) { activeSession?.activatedAtMillis != null }

    fun start(ownerId: String, callbacks: LongPressCallbacks): LongPressStartResult {
        require(ownerId.isNotBlank()) { "ownerId must not be blank" }
        synchronized(lock) {
            if (closed) return LongPressStartResult.CLOSED
            if (activeSession != null) return LongPressStartResult.ALREADY_RUNNING

            val session = ActiveSession(
                ownerId = ownerId,
                generation = ++nextGeneration,
                callbacks = callbacks,
            )
            activeSession = session
            try {
                session.activationTask = scheduler.schedule(timing.activationDelayMillis) {
                    activate(session.generation)
                }
            } catch (error: Throwable) {
                activeSession = null
                throw error
            }
            return LongPressStartResult.STARTED
        }
    }

    /** Only the owner that started the session may consume its pointer-up event. */
    fun release(ownerId: String): Boolean = stopIfOwner(ownerId, LongPressStopReason.RELEASED)

    fun cancelForPageExit(): Boolean = cancel(LongPressStopReason.PAGE_EXIT)

    fun cancelForProfileSwitch(): Boolean = cancel(LongPressStopReason.PROFILE_SWITCH)

    fun cancelForDisconnect(): Boolean = cancel(LongPressStopReason.DISCONNECTED)

    fun cancelForBackground(): Boolean = cancel(LongPressStopReason.APP_BACKGROUND)

    fun replace(): Boolean = cancel(LongPressStopReason.REPLACED)

    fun cancel(reason: LongPressStopReason): Boolean {
        val stopCallback = synchronized(lock) {
            stopLocked(activeSession, reason)
        }
        invokeStopSafely(stopCallback)
        return stopCallback != null
    }

    override fun close() {
        val stopCallback = synchronized(lock) {
            if (closed) return
            closed = true
            stopLocked(activeSession, LongPressStopReason.CLOSED)
        }
        invokeStopSafely(stopCallback)
    }

    private fun stopIfOwner(ownerId: String, reason: LongPressStopReason): Boolean {
        val stopped = synchronized(lock) {
            val session = activeSession ?: return@synchronized StopAttempt(false, null)
            if (session.ownerId != ownerId) return@synchronized StopAttempt(false, null)
            StopAttempt(true, stopLocked(session, reason))
        }
        invokeStopSafely(stopped.callback)
        return stopped.matched
    }

    private fun activate(generation: Long) {
        var failureCallback: (() -> Unit)? = null
        synchronized(lock) {
            val session = activeSession
            if (session == null || session.generation != generation || closed) return
            session.activationTask = null
            session.activatedAtMillis = clock.nowMillis()
            try {
                session.callbacks.onStart()
            } catch (_: Throwable) {
                failureCallback = stopLocked(session, LongPressStopReason.CALLBACK_FAILURE)
                return@synchronized
            }
            try {
                session.timeoutTask = scheduler.schedule(timing.maximumDurationMillis) {
                    timeout(generation)
                }
                session.repeatTask = scheduler.schedule(timing.repeatIntervalMillis) {
                    repeat(generation)
                }
            } catch (_: Throwable) {
                failureCallback = stopLocked(session, LongPressStopReason.CALLBACK_FAILURE)
            }
        }
        invokeStopSafely(failureCallback)
    }

    private fun repeat(generation: Long) {
        var failureCallback: (() -> Unit)? = null
        synchronized(lock) {
            val session = activeSession
            if (session == null || session.generation != generation || closed) return
            session.repeatTask = null
            val activatedAt = session.activatedAtMillis ?: return
            if (elapsedSince(activatedAt) >= timing.maximumDurationMillis) {
                failureCallback = stopLocked(session, LongPressStopReason.TIMEOUT)
                return@synchronized
            }
            try {
                session.callbacks.onRepeat()
            } catch (_: Throwable) {
                failureCallback = stopLocked(session, LongPressStopReason.CALLBACK_FAILURE)
                return@synchronized
            }
            try {
                session.repeatTask = scheduler.schedule(timing.repeatIntervalMillis) {
                    repeat(generation)
                }
            } catch (_: Throwable) {
                failureCallback = stopLocked(session, LongPressStopReason.CALLBACK_FAILURE)
            }
        }
        invokeStopSafely(failureCallback)
    }

    private fun timeout(generation: Long) {
        val stopCallback = synchronized(lock) {
            val session = activeSession
            if (session == null || session.generation != generation) return@synchronized null
            stopLocked(session, LongPressStopReason.TIMEOUT)
        }
        invokeStopSafely(stopCallback)
    }

    /** Returns a callback only after all scheduled work has been made stale. */
    private fun stopLocked(
        session: ActiveSession?,
        reason: LongPressStopReason,
    ): (() -> Unit)? {
        if (session == null || activeSession !== session) return null
        activeSession = null
        session.activationTask?.cancel()
        session.repeatTask?.cancel()
        session.timeoutTask?.cancel()
        val activated = session.activatedAtMillis != null
        return if (activated) {
            { session.callbacks.onStop(reason) }
        } else {
            // A pre-threshold release intentionally has no release callback because no key was pressed.
            {}
        }
    }

    private fun elapsedSince(startMillis: Long): Long {
        val now = clock.nowMillis()
        return if (now >= startMillis) now - startMillis else 0L
    }

    private fun invokeStopSafely(callback: (() -> Unit)?) {
        try {
            callback?.invoke()
        } catch (_: Throwable) {
            // State was already cleared. Lifecycle cancellation must not crash its caller.
        }
    }

    private data class StopAttempt(
        val matched: Boolean,
        val callback: (() -> Unit)?,
    )
}

/** One daemon thread is sufficient because controller callbacks are required to be non-blocking. */
private object SharedLongPressScheduler : LongPressScheduler {
    private val threadIds = AtomicLong()
    private val executor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { task ->
        Thread(task, "pc-remote-long-press-${threadIds.incrementAndGet()}").apply {
            isDaemon = true
        }
    }

    override fun schedule(delayMillis: Long, block: () -> Unit): ScheduledTask {
        require(delayMillis >= 0L) { "delayMillis must not be negative" }
        val future = executor.schedule(block, delayMillis, TimeUnit.MILLISECONDS)
        return ScheduledTask { future.cancel(false) }
    }
}
