package com.gunianan.btremote.ui.control

sealed interface GesturePanelState {
    data object Idle : GesturePanelState

    data class Result(
        val actionName: String,
        val eventId: Long = System.nanoTime(),
    ) : GesturePanelState
}
