# v2.1.1 全局滚动性能专项报告

## 范围

本轮仅优化滚动、重组、绘制和配置持久化路径；没有新增触控板、语音、Bluetooth HID 或模式管理业务能力。

## 已修复的共享根因

| 范围 | 修复 |
| --- | --- |
| 根状态 | `PcRemoteViewModel` 从 `AppConfig` 投影并去重 `activeProfile`、`globalSettings`、`profiles`、`startupProfileId`、`schemaVersion` 和 `hapticEnabled`；根 UI 不再直接收集完整配置快照。 |
| Activity 宿主 | 蓝牙 `StateFlow` 直接传入 Compose，避免每个蓝牙状态变化在 `MainActivity` 重建宿主参数对象。 |
| 配置写入 | UI 保持即时 StateFlow 更新；JSON 编码和 SharedPreferences `apply()` 在串行 I/O 执行器执行，写入顺序保持与配置版本一致。首次默认配置与损坏恢复仍同步写入。 |
| 共享视觉 | 降低卡片、按钮、底栏阴影；Slider 轨道 Brush 使用 `drawWithCache`；移除图标常态透明图层。 |
| 页面级 | 控制页按模式版本缓存控制项过滤、排序和分区；模式图标在 I/O 线程按 512px 显示目标采样并使用 LRU 缓存。 |

## 测量方法

- 设备：Android Emulator Pixel 9 Pro API 35，Android 15，1280×2856，系统仅支持 60Hz。
- 构建：归档 v2.1.0 Debug APK 与本次 v2.1.1 Debug APK；相同模拟器、相同应用数据和相同签名。
- 交互：每页预热 2 秒后，连续执行 25 组上/下往返滑动；每页、每版本重复 5 次。
- 指标：`adb shell dumpsys gfxinfo com.gunianan.btremote` 的总帧数、Janky frames、P50/P90/P95、Missed Vsync 与 Slow UI thread。

## 结果

| 页面 | 版本 | 总帧数 | 卡顿帧 | 卡顿比例 | 平均 P50/P90/P95 |
| --- | --- | ---: | ---: | ---: | --- |
| 自定义 | v2.1.0 | 3907 | 30 | 0.77% | 20 / 23 / 26ms |
| 自定义 | v2.1.1 | 3835 | 21 | 0.55% | 18 / 21 / 23ms |
| 设置 | v2.1.0 | 3725 | 87 | 2.34% | 17 / 22 / 25ms |
| 设置 | v2.1.1 | 3816 | 22 | 0.58% | 19 / 21 / 22ms |

设置页总卡顿帧减少 74.7%，自定义页总卡顿帧减少 30.0%。测试自动化手势会产生高输入延迟计数，不能将该字段与人工手势等同；对比以总帧、Janky frames、帧分位数、Missed Vsync 和 Slow UI thread 为准。

## 验证边界

- 默认控制页在该设备和默认模式下全部控件位于可视区域，空设备页也没有足够内容产生可测滚动帧；这两页不以“0 帧”冒充性能结果。
- 该 AVD 仅支持 60Hz，证明的是 60Hz 稳定性，不可用于宣称 90Hz/120Hz 帧率。应用仍请求同分辨率可用的最高刷新率，真实高刷新率手机需按相同脚本复测。
- `gfxinfo` 是 Debug 构建的运行时测量。最终发布判断仍需在 Profile 或 Release 类构建、真实设备和真实模式/设备列表数据量上复测。
