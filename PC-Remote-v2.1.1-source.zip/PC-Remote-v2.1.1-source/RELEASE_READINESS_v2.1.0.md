# Release Readiness — PC遥控器 v2.1.0

## Artifact identity

- Application ID: `com.gunianan.btremote`
- versionName / versionCode: `2.1.0` / `21`
- minSdk / targetSdk / compileSdk: `28` / `34` / `34`
- APK type: debug-signed delivery build
- Required build JDK: Temurin 21 used for verification

## Verification command

```bash
JAVA_HOME=/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home \
  ./gradlew --no-daemon clean check lintDebug testDebugUnitTest \
  hidReportSenderSelfTest assembleDebug
```

Result: BUILD SUCCESSFUL. Debug and Release each passed 124 JUnit tests; 7 HidReportSender self-tests passed; Android Lint reported 0 issues.

The final source ZIP was extracted into a clean temporary directory and `assembleDebug` completed successfully with 36 tasks executed. The separately built debug APK is functionally equivalent but not byte-identical to the delivered APK because Android debug packaging/signing output is not configured as a reproducible build.

## Functional acceptance completed

- Default language is Follow system on cleared app data.
- Explicit Simplified Chinese and English selection persist and apply after safe Activity recreation.
- English control, devices, customize, settings, touchpad, built-in profile, default controls, Bluetooth status, and action summaries show without mixed Chinese in the captured states.
- Slider track tap does not change the value; a thumb-originated horizontal drag does.
- Switch track/thumb are centered in the 48dp touch container.
- Disabled and regular glass buttons render without the previous horizontal light band.
- Image assets render at consistent visual weight without changing their source files.
- Settings scrolling and touchpad motion have saved `gfxinfo` evidence under `qa/v2.1`.

## Security and privacy

- No network dependency or cleartext traffic.
- No Bluetooth scan or location permission.
- No new runtime permission.
- App backup remains disabled.
- No secrets, signing keys, local paths, emulator data, Gradle caches, or build logs belong in the source ZIP.

## External acceptance still required

- Physical Android 9–12 language switching.
- OEM Bluetooth HID registration and Windows pairing/reconnection.
- Windows video/music previous, next, and play/pause behavior.
- Mouse, scrolling, long-press repeat, watchdog release, and background interruption on a real HID host.
- 90/120Hz physical-device frame pacing.

Release result: ready for debug APK delivery and physical-device acceptance; not a production-store signed release.
