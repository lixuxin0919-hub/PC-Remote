# Global jank investigation v2.1.2

## Environment

| Field | Value |
| --- | --- |
| Device | Pixel 9 Pro API 35 arm64 Android Emulator |
| System | Android 15 / API 35 |
| Display | 1280x2856, one 60.000004 Hz mode only |
| Power | 100%, power saver off, 25.0 C simulated battery |
| Build | Debug for interactive metrics; Release compiled but is unsigned |

`dumpsys display` reports `mIgnorePreferredRefreshRate: true`. This environment cannot validate physical 90/120 Hz, vendor GPU composition, thermal throttling, or Bluetooth transport load.

## Evidence and results

Static audit found a startup `preferredDisplayModeId` request, now removed. No fixed 8/16 ms UI loop, `Timer`, infinite Compose transition, same-direction nested scroll, or per-frame production log was found. Each main page uses one `LazyColumn`.

The fixed protocol was cold start, two seconds idle, `gfxinfo` reset, and five cycles of long up/down plus short up/down swipes. Each row is one aggregate run, not an invented per-round average.

| Scenario | Frames | Janky | P50 | P90 | P95 | P99 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Plain baseline, 50 text rows | 664 | 1.05% | 17 ms | 18 ms | 20 ms | 23 ms |
| Settings, normal chrome | 653 | 1.68% | 17 ms | 19 ms | 21 ms | 32 ms |
| Settings, only plain background | 652 | 1.69% | 17 ms | 20 ms | 22 ms | 34 ms |

The one-variable plain-background experiment did not improve the result, so the aurora background is not confirmed as the primary cause. The featureless baseline already misses a strict 16.67 ms P95 target, which prevents attributing the remaining gap solely to cards, controls, navigation, images, or state flows.

## Diagnostics

* Debug-only JankStats tracks a Window in memory, tags `screen` and `interaction`, and emits one aggregate line when the activity pauses. Settings output: `frames=710,janky=2,longestUiNanos=383841328`. The longest value includes lifecycle/transition frames and is not treated as a scrolling metric.
* Perfetto trace: `qa/performance-v2.1.2/pc-remote-settings.perfetto-trace` (30 MB), capturing sched, frequency, gfx, view, window, input, binder and disk during settings scrolling. The first attempt failed because this emulator rejects `-b 32768`; the successful repeat used `-b 32mb`.
* `dumpsys meminfo` after capture: total PSS 88,954 KB; Java heap PSS 21,356 KB; native heap PSS 19,148 KB. No GC/allocation causal conclusion is claimed without an allocation trace.

## Changes

1. Remove the startup highest-mode `preferredDisplayModeId` override; Android now chooses normally.
2. Add debug-only intent isolation flags and a `PlainScrollBaselineScreen`; neither enters release navigation. Example: `--ez perf_plain_baseline true` or `--ez perf_plain_background true`.
3. Add debug-only JankStats aggregation and Compose compiler reports at `app/build/compose_compiler/{reports,metrics}`.

## Not verified

* Real 60/90/120 Hz, OEM scheduling, GPU completion, thermal behavior, actual Bluetooth traffic and subjective feel require a physical device.
* Control/Device scroll, 20-profile Customize, and local-icon cold cache lack fixture data here.
* Macrobenchmark and Baseline Profile are not claimed: the project had no module, and a signed release-like target plus physical device is required before their output is meaningful.
* Slider write count is statically local-draft then finish-commit; an instrumentation counter was not added, so no write-count result is claimed.

## Reproduction

```sh
adb shell am force-stop com.gunianan.btremote
adb shell am start -W -n com.gunianan.btremote/.MainActivity --ez perf_plain_baseline true
adb shell dumpsys gfxinfo com.gunianan.btremote reset
# run fixed swipes
adb shell dumpsys gfxinfo com.gunianan.btremote
```
