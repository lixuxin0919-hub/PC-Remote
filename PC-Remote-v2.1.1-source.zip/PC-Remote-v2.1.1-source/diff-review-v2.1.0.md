# Diff Review — PC遥控器 v2.1.0

## Review scope

Compared the restored v2.0.0 source in Downloads with the v2.1.0 worktree, excluding generated Gradle/build and QA artifacts. The implementation changes are limited to locale handling, shared UI text rendering, switch/slider controls, glass/button/icon rendering, touchpad UI state isolation, navigation shadows, tests, and documentation. Bluetooth permissions, HID descriptor, report mapper, command executor, configuration schema, and user profile persistence were not changed.

## Safety findings

- No feature deletion, dependency addition, permission expansion, network access, cleartext traffic, backup enablement, or storage permission was introduced.
- Language preference is stored in its own SharedPreferences file and is not imported or exported with control profiles.
- Language switching cancels touch input and requests unified HID key release before Activity recreation.
- Slider track taps and vertical scroll intent remain unconsumed; only thumb-originated horizontal drags update local state and commit on completion. Accessibility `setProgress` remains available.
- Touchpad pressure state is read inside the pressure indicator rather than at the page scope; pointer/HID delta delivery is unchanged.
- Button fix removes problematic layer alpha and uses explicit disabled colors; it does not change click enablement.
- Image assets were not rewritten. Visual-size compensation is resource-ID based and clipped to the caller's icon bounds.
- The English cache is bounded to 1024 entries and is cleared before further growth.

## Regression checks

- Debug JUnit: 124 passed; Release JUnit: 124 passed.
- HidReportSender self-tests: 7 passed.
- Android Lint: 0 issues.
- Full `check`, `lintDebug`, `testDebugUnitTest`, `hidReportSenderSelfTest`, and `assembleDebug`: passed.
- Static UI catalog: 441 Chinese source literals, 494 translation entries, 0 literals retaining CJK after English translation.
- Emulator: default Follow system, explicit zh-CN, and return to Follow system verified.
- Slider: track tap remained 100%; thumb drag changed to 149%.
- Visual review: control, devices, customize, settings, touchpad, disabled button, English, and Chinese states checked.

## Remaining external risk

The API 35 emulator cannot validate an OEM Bluetooth HID Device Profile or Windows input delivery. Android 9–12 locale wrapping and real 90/120Hz performance require physical-device acceptance. No release claim treats those as completed.

Review result: no P0/P1/P2 code-diff findings remain open.
